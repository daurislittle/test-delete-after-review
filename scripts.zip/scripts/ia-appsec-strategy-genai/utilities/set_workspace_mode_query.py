#!/usr/bin/env python3

"""
set_workspace_mode_query.py 
This script sets the workspace to query mode as a preparation step for further QA processing.

Usage: ./set_workspace_mode_query.py --workspace-name <workspace-name> [--debug]
"""

import argparse
import os
import logging
import requests

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

def setup_logging(debug):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

def get_workspace(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        for ws in workspaces:
            if (ws['name'] == workspace_name):
                return ws
        logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
        return None
    else:
        logging.error(f"Error retrieving workspace '{workspace_name}'. Status code: {response.status_code}")
        logging.error(f"Response: {response.text}")
        raise Exception("Failed to retrieve workspace")

def set_chat_mode(workspace, new_chat_mode):
    slug = workspace['slug']
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{slug}/update"
    payload = {
        "chatMode": new_chat_mode
    }
    response = requests.post(api_url, json=payload, headers=headers)
    if response.status_code == 200:
        updated_workspace = response.json().get('workspace')
        return updated_workspace['chatMode'] == new_chat_mode
    else:
        logging.error(f"Failed to update chat mode. Status code: {response.status_code}")
        logging.error(f"Response: {response.text}")
        raise Exception("Failed to update chat mode")    


def main():
    parser = argparse.ArgumentParser(description="Set a workspace to query mode as a preparation step for QA processing")
    parser.add_argument("--workspace-name", required=True, help="Name of the workspace to change")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    setup_logging(args.debug)

    workspace = get_workspace(args.workspace_name)

    # Set the workspace to query mode
    if not set_chat_mode(workspace=workspace, new_chat_mode="query"):
        logging.error(f"Workspace '{args.workspace_name}' failed to set workspace to query mode.")
        return

    print(f"Workspace '{args.workspace_name}' set to query mode successfully.")

if __name__ == "__main__":
    main()
