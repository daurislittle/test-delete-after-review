# GenAI Flows
Check out our current [Lucidchart flow diagrams](https://lucid.app/lucidchart/599a1ee8-0827-48fd-bfa5-eeba6166a562/edit?viewport_loc=89%2C-123%2C4214%2C1808%2Cc-wP~KJC6gQ.&invitationId=inv_0df103d9-4b55-4bd4-b79e-5bba64304a00)

# Documentation
[Secure Code Review (SCR)](/scr/README.md)

[AppSec Program Assessment (ASPA)](/aspa/README.md)
