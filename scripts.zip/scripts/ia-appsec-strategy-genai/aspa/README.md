# Application Security Program Assessment (ASPA)

The scripts in this repo support automation of application security program assessment (ASPA) using Anything LLM.
The ASPA workflow is comprised of 4 processes, each process is described in detail below:
1. Preprocessing
2. Processing
3. Quality Assurance
4. Reporting

Please refer to the following flowchart for a visual outline of the workflow:
[ASPA Lucidchart flow diagram](https://lucid.app/lucidchart/599a1ee8-0827-48fd-bfa5-eeba6166a562/edit?viewport_loc=-82%2C-581%2C4947%2C2694%2Cc-wP~KJC6gQ.&invitationId=inv_0df103d9-4b55-4bd4-b79e-5bba64304a00)

## Directory Structure

The project is organized into the following directory structure:
```
├── aspa
│   ├── preprocessing
│   │   ├── nist
│   │   ├── prompts
│   │   ├── samm
│   │   │   └── src
│   │   └── utilities
│   ├── processing
│   ├── qualityassurance
│   ├── reporting
│   └── tests
│       └── benchmarks
│           └── medium_maturity
```
- `preprocessing`: Contains files and scripts for initial data preparation.
  - `nist`: Includes NIST-related documents and spreadsheets, supporting compliance with the Secure Software Development Framework (SSDF) requirements. These resources help organizations implement secure software development practices as outlined in NIST SP 800-218, enabling teams to produce more secure software while meeting federal security requirements and enhancing overall cybersecurity posture.
  - `samm`: Contains various SAMM-related JSON files and a `src` subdirectory with SAMM spreadsheets. These resources support implementation of the OWASP Software Assurance Maturity Model (SAMM), a framework that helps organizations formulate and implement a strategy for software security that is tailored to specific risks facing the organization. The included files facilitate SAMM assessments, maturity measurements, and roadmap development for improving secure software practices across the development lifecycle.
  - `prompts`: Stores system prompts, such as `samm_system_prompt.txt`. These prompts provide structured guidance for interacting with AI systems when performing OWASP Software Assurance Maturity Model (SAMM) assessments, ensuring consistent and comprehensive evaluation of security practices across the software development lifecycle.
  - `utilities`: Houses utility scripts for creating JSON and Markdown files, including `prep_samm_framework_json.py`. These utilities facilitate the processing and transformation of OWASP SAMM data, enabling automated generation of assessment materials, visualization of maturity levels, and creation of documentation to support SAMM implementation and reporting activities
  - `preprocessing`: Contains files and scripts for initial data preparation.
  - `nist`: Includes NIST-related documents and spreadsheets, supporting compliance with the Secure Software Development Framework (SSDF) requirements. These resources help organizations implement secure software development practices as outlined in NIST SP 800-218, enabling teams to produce more secure software while meeting federal security requirements and enhancing overall cybersecurity posture.
  - `samm`: Contains various SAMM-related JSON files and a `src` subdirectory with SAMM spreadsheets. These resources support implementation of the OWASP Software Assurance Maturity Model (SAMM), a framework that helps organizations formulate and implement a strategy for software security that is tailored to specific risks facing the organization. The included files facilitate SAMM assessments, maturity measurements, and roadmap development for improving secure software practices across the development lifecycle.
  - `prompts`: Stores system prompts, such as `samm_system_prompt.txt`. These prompts provide structured guidance for interacting with AI systems when performing OWASP Software Assurance Maturity Model (SAMM) assessments, ensuring consistent and comprehensive evaluation of security practices across the software development lifecycle.
  - `utilities`: Houses utility scripts for creating JSON and Markdown files, including `prep_samm_framework_json.py`. These utilities facilitate the processing and transformation of OWASP SAMM data, enabling automated generation of assessment materials, visualization of maturity levels, and creation of documentation to support SAMM implementation and reporting activities.

- `processing`: Contains scripts for processing ASPA data.
  - `process_aspa_anything.py`: Main script for processing ASPA through LLM.
  - `roadmap_aspa_chunks.py`: Script for processing each SAMM domain individually to generate prioritized recommendations.
  - `roadmap_aspa_whole.py`: Script for processing all domains collectively to create a comprehensive roadmap.
  - `score_aspa_results.py`: Script for scoring maturity of security practices.

- `qualityassurance`: Contains scripts for QA processes.
  - `qa_aspa_findings.py`: Script for performing QA on findings.

- `reporting TBD`: Contains templates and scripts for report generation. 
  - `GPS_Blank_Template.docx`: Word document template for reports.
  - `generate_asvs_report.py`: Script for generating ASVS reports.

- `tests`: Contains benchmark tests and related files.

## Preprocessing
The preprocessing scripts prepare discovery session transcripts for upload to Anything LLM, create the workspace in Anything LLM, and prepare the SAMM framework for assessment.

### Prerequisites
- Anything LLM
- Audio transcription tools (Whisper & Pyannote)
- Create environment variables for the Anything LLM API:
  - ANYTHING_LLM_BASE_URL=http://localhost:3001
  - ANYTHING_LLM_API_KEY

### Preprocessing Steps
1. **Audio Transcription**
   1. Use `whisper_diarization.py` to convert audio recordings to text transcripts
   2. `whisper_diarization.py` is located in /common/whisper_recordings
   3. Utilize diarization for speaker identification
   4. Store generated transcripts

2. **AnythingLLM Workspace Preparation**
   1. Run `prep_anything_workspace.py`
   2. **Inputs**
      1. --workspace-name [workspace] = Name of the workspace to create
      2. --artifacts-dir [path/to/artifacts/dir] = Path to the transcripts and notes directory
      3. --system-prompt [path/to/system_prompt] = Path to the system prompt file (available in /aspa/preprocessing/prompts/samm_system_prompt.txt)
   3. **Outputs**
      4. New workspace in Anything LLM
      5. Transcripts uploaded and embedded into the newly created workspace

3. **SAMM Framework Preparation**
   1. Run `prep_samm_framework_json.py`
   2. **Inputs**
      1. --input-json [path/to/samm/framework]= Path to SAMM framework template
      2. --output-json [path/to/output].json = Product/development team names
   3. **Outputs**
      1. New SAMM framework template with specific product/dev team names under each domain

## Processing

### Prerequisites
- Anything LLM workspace with discovery transcripts embedded
- Prepared SAMM framework JSON file

### Processing Steps
1. **ASPA Processing**
   1. Run `process_aspa_anything.py`
   2. **Inputs**
      1. --workspace-name [workspace] = Name of the existing workspace to use
      2. --framework-file [path/to/framework] = Path to the prepared SAMM framework JSON file
      3. --output-file [path/to/output/file].json = Directory to store processed findings
   3. **Outputs**
      1. JSON files containing LLM analysis of each SAMM domain with notes, current state, gaps, and recommendations
#### Important: Complete Quality Assurance (QA) on the processed ASPA results before proceeding to Roadmap Generation.

2. **Roadmap Generation**
   1. Run `roadmap_aspa_chunks.py` to process each domain individually
      1. --workspace-name [workspace] = Name of the existing workspace to use
      2. --findings-file [path/to/findings] = Path to QA'd findings file
   2. Run `roadmap_aspa_whole.py` to process all domains collectively
      1. TBD

3. **Optional: Maturity Scoring**
   1. Run `score_aspa_results.py`
   2. **Inputs**
      1. --input-file [path/to/processed/findings] = Path to the processed ASPA results file
      2. --scoring-file [aspa/preprocessing/samm/src/SAMM_scoring.json] = Path to the scoring criteria file
      3. --workspace-name [workspace] = Name of the existing workspace to use
      4. --output-file [path/to/output].json = Path for the output file with scored findings
   3. **Outputs**
      1. JSON file with scored findings (score, notes, current state, gaps, recommendations)

## Quality Assurance

### Prerequisites
- Processed ASPA results (and scored findings if maturity scoring was performed)
- Processed ASPA RoadMap

### QA Steps
1. **QA Process**
   1. Run `qa_aspa_findings.py`
   2. **Inputs**
      1. --framework-file [path/to/SAMM/framework] = Path to the SAMM framework file
      2. --findings-file [path/to/processed_results] = Path to processed ASPA findings file
      3. --workspace-name [workspace] = Name of the existing workspace to use
      4. --output-file [path/to/output].json = Path for the output file with QA results
   3. **Outputs**
      1. QA results for each finding
      2. Summary of QA results in JSON and CSV formats

2. **Roadmap QA TBD**
   1. Run `qa_roadmap_aspa_whole.py` to perform QA on the roadmap
   2. **Inputs**
      1. --findings-dir = Path to QA'd findings directory
      2. --workspace-name = Name of the existing workspace to use
      3. --weights-file = Optional file with weighting parameters for roadmap phasing
   3. **Outputs**
      1. Phased roadmap recommendations
      2. QA results for roadmap

## Reporting TBD
Reporting is still in development 

### Prerequisites
- QA'd findings and roadmap

### Reporting Steps
1. **Report Generation**
   1. Run `create_aspa_report.py`
   2. **Inputs**
      1. --findings-dir = Path to QA'd findings directory
      2. --roadmap-file = Path to QA'd roadmap file
      3. --template-file = Path to report template (GPS_Blank_Template.docx)
      4. --output-file = Path for the output report
   3. **Outputs**
      1. Word document report with GPS styling
      2. JSON format of the report for potential integration with other tools

2. **Optional: AE Summary Generation**
   1. Run `generate_AE_summary.py`
   2. **Inputs**
      1. --report-file = Path to the generated report JSON
      2. --output-file = Path for the AE summary
   3. **Outputs**
      1. High-level summary for Account Executive
      2. Outline of potential service and technology gaps for post-engagement sales

## Additional Notes
- The report JSON can be leveraged with outputs from other IA reports for a holistic view of the client's cybersecurity state.
- This data can be used in annual reports, CISO dashboards, and integrated with GPVUE.
