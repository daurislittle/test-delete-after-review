#!/usr/bin/env python3

import argparse
import json
import os
import logging
import requests
import time
import copy

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

def setup_logging(debug):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

def get_workspace_slug(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        for workspace in workspaces:
            if workspace['name'] == workspace_name:
                return workspace['slug']
    logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
    return None

def load_framework(file_path):
    with open(file_path, 'r') as file:
        framework = json.load(file)
    
    # The structure is already clean, so we don't need to modify it
    return framework, framework

def make_api_request(api_url, payload, headers, max_retries=3, delay=5):
    for attempt in range(max_retries):
        try:
            response = requests.post(api_url, json=payload, headers=headers)
            response.raise_for_status()
            return response.json()['textResponse']
        except requests.exceptions.RequestException as e:
            if attempt == max_retries - 1:
                raise
            logging.warning(f"API request failed. Retrying in {delay} seconds... (Attempt {attempt + 1}/{max_retries})")
            time.sleep(delay)
            delay *= 2  # Exponential backoff

def process_question(domain, practice, stream, question_id, question_data, workspace_slug):
    prompt = f"""
Based on the context provided in the files prefixed with "notes_" and "transcript_", please analyze the following question from the OWASP SAMM 2.0 framework:

Domain: {domain}
Security Practice: {practice}
Security Stream: {stream}
Question ID: {question_id}

Question: {question_data['question']}

Attributes:
{json.dumps(question_data['attributes'], indent=2)}

Please provide your analysis in valid JSON format using the following structure:

{{
    "{question_id}": {{
        "question": "{question_data['question']}",
        "attributes": {json.dumps(question_data['attributes'])},
        "current state": [
            "Bullet each note that is rephrased for executive audience, include both positives and negatives as these bullets accurately represent the current state"
            ...
        ],
        "notes": [
            "Note 1 (source: filename.ext)",
            "Note 2 (source: filename.ext)",
            ...
        ],
        "gaps": [
            {{
                "id": "{question_id}-A",
                "description": "Detailed gap description, including why addressing this gap is important, its business implications, and potential risks. "
            }},
            {{
                "id": "{question_id}-B",
                "description": "Detailed gap description, including why addressing this gap is important, its business implications, and potential risks."
            }},
            ...
        ],
        "recommendations": [
            {{
                "id": "1",
                "description": "Detailed recommendation description, including the benefits and impacts of implementing this recommendation.",
                "gaps_addressed": ["{question_id}-A", "{question_id}-B"]
            }},
            ...
        ]
    }}
}}


1. Create a comprehensive report for leadership based on 'notes_' and 'transcript_' files, identifying gaps and providing recommendations.

2. File selection:
   2.1. Use files named '*_{domain}.*' or '*_{domain}_{practice}.*'
   2.2. Prioritize files with both {domain} and {practice} if specified
   2.3. If no such files exist, state this and use files matching only {domain}
   2.4. Only use files that exactly match the {domain} or {domain}_{practice} in their name

3. Current State:
   3.1. Create a detailed "Current State" section based on the information in the notes
   3.2. Provide a comprehensive overview of the current situation related to the question

4. For each gap identified:
   4.1. Assign a unique Gap ID by appending a letter to the question ID (e.g., if the question ID is G-SM-A-1-1, the gap IDs would be G-SM-A-1-1-A, G-SM-A-1-1-B, G-SM-A-1-1-C, etc.)
   4.2. Provide a detailed explanation of the gap (the "what"), using non-technical language suitable for executive leadership
   4.3. Include in the description why addressing this gap is important, its business implications, and potential risks

5. Recommendation guidelines:
   5.1. Number recommendations sequentially (1, 2, 3, etc.) without any prefix or question ID
   5.2. Link each to corresponding Gap ID(s)
   5.3. Make them concise yet comprehensive, providing context and rationale
   5.4. Explain recommendations in business terms, avoiding technical jargon
   5.5. Include in the description the potential benefits and impacts of implementing the recommendation
   5.6. Develop holistic recommendations that can address multiple gaps where appropriate, rather than limiting each recommendation to a single gap. Ensure that the relationship between recommendations and gaps is clearly explained.
   5.7. Ensure they flow logically and include all implementation details
  
6. For the "notes" section:
   6.1. Include key points and observations from the source files
   6.2. For each note, cite the specific source file in parentheses at the end of the note

7. If insufficient information, clearly state this and provide recommendations based on industry best practices

8. Only consider gaps and recommendations directly tied to provided questions and attributes

9. For governance domain, focus on business risk threats, not traditional SDLC threat activities

10. Structure the report to be easily understood by executive leadership:
    10.1. Use clear, concise language free of technical jargon
    10.2. Provide context and background information where necessary
    10.3. Highlight key points and potential business impacts

11. Output in valid JSON format with no text outside the JSON structure

12. If no relevant files found, return an empty JSON structure with an explanatory note

13. Ensure each gap is based on specific attributes/questions, and each recommendation addresses a specific gap

14. For both gaps and recommendations, provide more verbose descriptions that include all relevant information (importance, benefits, etc.) in a narrative format

15. Do not include empty arrays or objects in the output. If there are no notes, gaps, or recommendations, omit these fields entirely from the JSON structure.

16. Ensure that the entire response is valid JSON. Do not include any text outside of the JSON structure.

17. If you encounter any issues or cannot provide a complete analysis, return a JSON object with an "error" field explaining the problem.

18. Double-check that all JSON keys and values are properly formatted and enclosed in double quotes.

19. Return the analysis as a single JSON object with the question ID as the top-level key, containing all the analysis details (question, attributes, Current State, notes, gaps, and recommendations) as its value.

20. Ensure that statements in the notes is accompanied by a citation to the specific source file(s) from which it was derived. Use the format (filename.ext) for citations.

21. For the "Current State" section:
    21.1. Provide bullet points for each note, rephrased for an executive audience.
    21.2. Include both positive and negative aspects to accurately represent the current state.
    21.3. Use clear, concise language free of technical jargon.
    21.4. Ensure each bullet point starts with a dash (-) and is enclosed in quotes.
"""

    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/chat"
    payload = {
        "message": prompt,
        "mode": "chat"
    }

    try:
        analysis = make_api_request(api_url, payload, headers)
        parsed_analysis = json.loads(analysis)
        
        # Extract the content from the nested structure
        if question_id in parsed_analysis:
            return {question_id: parsed_analysis[question_id]}
        else:
            return {question_id: {"error": "Question ID not found in response"}}
    except requests.exceptions.RequestException as e:
        logging.error(f"Error processing question {question_id}: {str(e)}")
        return {question_id: {"error": str(e)}}
    except json.JSONDecodeError:
        logging.error(f"Error decoding JSON response for question {question_id}")
        return {question_id: {"error": "Invalid JSON response"}}

def main():
    parser = argparse.ArgumentParser(description="Perform gap analysis using OWASP SAMM 2.0 framework")
    parser.add_argument("--framework-file", required=True, help="Path to the OWASP SAMM 2.0 framework JSON file")
    parser.add_argument("--workspace-name", required=True, help="Name of the existing workspace to use")
    parser.add_argument("--output-file", required=True, help="Path to the output JSON file")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    setup_logging(args.debug)

    # Load framework
    framework, _ = load_framework(args.framework_file)

    # Get workspace slug
    workspace_slug = get_workspace_slug(args.workspace_name)
    if not workspace_slug:
        logging.error(f"Workspace '{args.workspace_name}' not found. Exiting.")
        return

    # Load existing output if it exists
    output_data = copy.deepcopy(framework)
    if os.path.exists(args.output_file):
        with open(args.output_file, 'r') as f:
            output_data = json.load(f)

    # Process questions for all domains, practices, and streams
    for domain, practices in framework.items():
        for practice, streams in practices.items():
            for stream, questions in streams.items():
                for question_id, question_data in questions.items():
                    logging.info(f"Processing question: {question_id}")
                    
                    analysis = process_question(domain, practice, stream, question_id, question_data, workspace_slug)
                    
                    if "error" in analysis.get(question_id, {}):
                        logging.error(f"Error in analysis for question {question_id}: {analysis[question_id]['error']}")
                        continue

                    # Update the output data
                    output_data[domain][practice][stream][question_id].update(analysis[question_id])
                    
                    # Save the updated output after each question
                    with open(args.output_file, 'w') as f:
                        json.dump(output_data, f, indent=2)
                    
                    time.sleep(1)  # Add a small delay between requests to avoid rate limiting

    logging.info(f"Gap analysis complete. Results saved to {args.output_file}")

if __name__ == "__main__":
    main()
