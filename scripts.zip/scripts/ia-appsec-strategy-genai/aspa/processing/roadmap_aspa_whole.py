#!/usr/bin/env python3

import argparse
import json
import os
import logging
import requests
import time
import re

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

def setup_logging(debug):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

def get_workspace_info(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        for workspace in workspaces:
            if workspace['name'] == workspace_name:
                return workspace
    logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
    return None

def get_thread_chats(workspace_slug, thread_slug):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/{thread_slug}/chats"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        return response.json().get('history', [])
    logging.error(f"Failed to get chat history for thread '{thread_slug}'. Status code: {response.status_code}")
    logging.error(f"Response content: {response.text}")
    return []

def make_api_request(api_url, payload, headers, max_retries=3, delay=5):
    for attempt in range(max_retries):
        try:
            response = requests.post(api_url, json=payload, headers=headers)
            response.raise_for_status()
            return response.json()['textResponse']
        except requests.exceptions.RequestException as e:
            if attempt == max_retries - 1:
                raise
            logging.warning(f"API request failed. Retrying in {delay} seconds... (Attempt {attempt + 1}/{max_retries})")
            time.sleep(delay)
            delay *= 2  # Exponential backoff

def read_input_file(file_path):
    try:
        with open(file_path, 'r') as f:
            return f.read()
    except IOError as e:
        logging.error(f"Error reading input file '{file_path}': {str(e)}")
        return None

def process_roadmap_phase(content, workspace_slug, thread_slug, phase, weight_prompt=None):
    prompt = f"""
Phase {phase} Roadmap Development:

Using the provided content, analyze and identify:
1. Highest risk gaps in the organization's current security posture
2. Ongoing or planned security initiatives
3. "Low-hanging fruit" - easy-to-implement improvements with high impact

Then, create a Phase {phase} roadmap that:
1. Prioritizes actions based on risk, current initiatives, and ease of implementation
2. Considers dependencies between actions (what needs to be done first)
3. Maintains original gap IDs for consistency
4. Provides a concise summary for each recommendation (1-2 sentences max)
5. Focuses on the most critical and achievable items for Phase {phase}

Please take into account what the organization is already doing from a cost perspective. Things that are actually new are gonna cost more than what they are already doing.

Content:
{content}

"""

    if weight_prompt:
        prompt += f"""
Additional Requirement (Weight):
{weight_prompt}

"""

    prompt += """
Please present your Phase recommendations in the following format for each item:

[Item Name] (include relevant gap IDs)
Current State Summary: [1-2 sentences describing the current state]
Recommendation Summary: [1-2 sentences describing the recommendation]
Implementation Items:
• [Bullet point list of specific implementation items]


Ensure that:
1. Activities are prioritized based on risk, current initiatives, and ease of implementation.
2. Dependencies between activities are clearly identified.
3. Each recommendation includes a concise summary and rationale.
4. The roadmap is comprehensive yet focused on the most critical items for this phase.
5. Do not include a header for the phase number in your response.
"""

    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/chat"
    payload = {
        "message": prompt,
        "mode": "chat"
    }

    try:
        response = make_api_request(api_url, payload, headers)
        logging.debug(f"Raw response for phase {phase}: {response[:500]}...")  # Log first 500 characters of the response
        return response
    except requests.exceptions.RequestException as e:
        logging.error(f"Error processing roadmap phase {phase}: {str(e)}")
        return f"Error processing roadmap phase {phase}: {str(e)}"

def main():
    parser = argparse.ArgumentParser(description="Generate a holistic ASPA roadmap")
    parser.add_argument("--roadmap-file", required=True, help="Path to the input roadmap file")
    parser.add_argument("--workspace-name", required=True, help="Name of the existing workspace to use")
    parser.add_argument("--output-file", required=True, help="Path to the output file")
    parser.add_argument("--weight-prompt", help="Additional prompt for weighting/considerations (optional)")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument("--phases", type=int, default=4, help="Number of phases to generate (default: 4)")
    args = parser.parse_args()

    setup_logging(args.debug)

    # Get workspace info
    workspace_info = get_workspace_info(args.workspace_name)
    if not workspace_info:
        logging.error(f"Workspace '{args.workspace_name}' not found. Exiting.")
        return

    workspace_slug = workspace_info['slug']
    thread_slug = workspace_info['threads'][0]['slug']  # Assuming the first thread is the one we want to use

    # Read roadmap file
    content = read_input_file(args.roadmap_file)
    if not content:
        logging.error("Failed to read roadmap file. Exiting.")
        return

    # Process roadmap phases
    with open(args.output_file, 'w') as f:
        for phase in range(1, args.phases + 1):
            logging.info(f"Processing roadmap phase {phase}")
            phase_roadmap = process_roadmap_phase(content, workspace_slug, thread_slug, phase, args.weight_prompt)
            
            f.write(f"Phase {phase} Roadmap\n\n")
            f.write(phase_roadmap)
            f.write("\n\n")
            
            # Add a delay between phases to avoid rate limiting
            if phase < args.phases:
                time.sleep(5)

    logging.info(f"Holistic roadmap generated and saved to {args.output_file}")

if __name__ == "__main__":
    main()
