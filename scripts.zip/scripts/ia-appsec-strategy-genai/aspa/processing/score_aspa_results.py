#!/usr/bin/env python3

import argparse
import json
import os
import logging
import requests
import time
from difflib import SequenceMatcher

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

def setup_logging(debug):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

def get_workspace_slug(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        for workspace in workspaces:
            if workspace['name'] == workspace_name:
                return workspace['slug']
    logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
    return None

def load_samm_output(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def load_scoring_json(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def find_best_match(question, scoring_data):
    best_match = None
    best_ratio = 0
    for item in scoring_data:
        ratio = SequenceMatcher(None, question.lower(), item['title'].lower()).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_match = item
    return best_match

def generate_score(question_data, scoring_item, workspace_slug):
    question = question_data['question']
    
    prompt = f"""Based on the following SAMM question analysis, please select the most appropriate score and answer. Use the following scoring guide:

Question: {scoring_item['title']}

Choices:
{json.dumps(scoring_item['choices'], indent=2)}

Actual Question: {question}

Attributes:
{json.dumps(question_data.get('attributes', []), indent=2)}

Notes:
{json.dumps(question_data.get('notes', []), indent=2)}

Gaps:
{json.dumps(question_data.get('gaps', []), indent=2)}

Recommendations:
{json.dumps(question_data.get('recommendations', []), indent=2)}

Please provide your response as a JSON object in the following format:
{{
    "scoring_score": [score value],
    "scoring_answer": [corresponding answer text],
    "scoring_justification": "Brief explanation for the score"
}}

Ensure your response is in valid JSON format. Do not include any text outside of the JSON structure.
"""

    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/chat"
    payload = {
        "message": prompt,
        "mode": "chat"
    }

    try:
        response = requests.post(api_url, json=payload, headers=headers)
        response.raise_for_status()
        score_data = response.json()['textResponse']
        result = json.loads(score_data)
        return result
    except requests.exceptions.RequestException as e:
        logging.error(f"Error generating score for question: {str(e)}")
        return {"scoring_score": 0, "scoring_answer": "No", "scoring_justification": "Error occurred during score generation"}
    except json.JSONDecodeError:
        logging.error(f"Error decoding JSON response for question")
        return {"scoring_score": 0, "scoring_answer": "No", "scoring_justification": "Error in JSON decoding"}

def process_questions(data, scoring_data, workspace_slug, output_file):
    results = {}

    for domain, practices in data.items():
        results[domain] = {}
        for practice, streams in practices.items():
            results[domain][practice] = {}
            for stream, questions in streams.items():
                results[domain][practice][stream] = {}
                for question_id, question_data in questions.items():
                    # Extract team name if present
                    team_name = question_id.split(' - ')[-1] if ' - ' in question_id else None
                    
                    # Get the question content
                    question_key = f'question - {team_name}' if team_name else 'question'
                    question_content = question_data.get(question_key)
                    
                    if question_content is None:
                        logging.warning(f"No question found for {question_id}")
                        continue

                    logging.info(f"Scoring {question_id}")

                    # Find best matching scoring item
                    scoring_item = find_best_match(question_content, scoring_data)

                    # Prepare the question data for scoring
                    question_data_for_scoring = {
                        'question': question_content,
                        'attributes': question_data.get(f'attributes - {team_name}' if team_name else 'attributes', []),
                        'notes': question_data.get(f'notes - {team_name}' if team_name else 'notes', []),
                        'gaps': question_data.get(f'gaps - {team_name}' if team_name else 'gaps', []),
                        'recommendations': question_data.get(f'recommendations - {team_name}' if team_name else 'recommendations', [])
                    }
                    
                    score_data = generate_score(question_data_for_scoring, scoring_item, workspace_slug)
                    
                    # Update the question data with scoring information
                    question_data[question_key] = {
                        "content": question_content,
                        **score_data
                    }
                    
                    results[domain][practice][stream][question_id] = question_data

                    # Write current results to file after each question
                    with open(output_file, 'w') as f:
                        json.dump(results, f, indent=2)
                    
                    time.sleep(1)  # Add a small delay to avoid rate limiting

    return results

def main():
    parser = argparse.ArgumentParser(description="Score SAMM framework questions based on analysis")
    parser.add_argument("--findings-file", required=True, help="Path to the SAMM_Output JSON file")
    parser.add_argument("--scoring-file", required=True, help="Path to the scoring JSON file")
    parser.add_argument("--workspace-name", required=True, help="Name of the existing workspace to use")
    parser.add_argument("--output-file", required=True, help="Path to the output JSON file for scores")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    setup_logging(args.debug)

    samm_output = load_samm_output(args.findings_file)
    scoring_data = load_scoring_json(args.scoring_file)

    workspace_slug = get_workspace_slug(args.workspace_name)
    if not workspace_slug:
        logging.error(f"Workspace '{args.workspace_name}' not found. Exiting.")
        return

    results = process_questions(samm_output, scoring_data, workspace_slug, args.output_file)

    logging.info(f"Scoring complete. Results saved to {args.output_file}")

if __name__ == "__main__":
    main()
