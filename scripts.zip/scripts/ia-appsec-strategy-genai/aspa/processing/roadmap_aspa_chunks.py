import argparse
import requests
import logging
import os
import time
import json

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

EXPECTED_DOMAINS = ["Governance", "Design", "Implementation", "Verification", "Operations"]

def get_workspace_slug(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        for workspace in workspaces:
            if workspace['name'] == workspace_name:
                return workspace['slug']
    logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
    return None

def create_thread_in_workspace(workspace_slug, thread_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/new"
    payload = {
        "userId": 1,
        "name": thread_name
    }
    logging.info(f"Creating thread: {thread_name}")
    response = requests.post(api_url, json=payload, headers=headers)
    if response.status_code == 200:
        result = response.json()
        logging.info(f"Thread created successfully: {thread_name}")
        return result
    else:
        logging.error(f"Failed to create thread '{thread_name}'. Status code: {response.status_code}")
        return None

def create_threads_in_workspace(workspace_name, domain_names):
    workspace_slug = get_workspace_slug(workspace_name)
    if not workspace_slug:
        logging.error(f"Workspace '{workspace_name}' not found or couldn't be accessed.")
        return []

    results = []
    for domain_name in domain_names:
        result = create_thread_in_workspace(workspace_slug, domain_name)
        if result:
            results.append(result)
        else:
            logging.error(f"Failed to create thread '{domain_name}'")

    return results

def send_chat_message(workspace_slug, thread_slug, message, mode="chat", user_id=1):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/{thread_slug}/chat"
    
    payload = {
        "message": message,
        "mode": mode,
        "userId": user_id
    }

    logging.info(f"Sending context to thread: {thread_slug}")
    response = requests.post(api_url, json=payload, headers=headers)
    
    if response.status_code == 200:
        result = response.json()
        logging.info(f"Context sent successfully to thread: {thread_slug}")
        return result
    else:
        logging.error(f"Failed to send context to thread: {thread_slug}. Status code: {response.status_code}")
        return None

def read_findings_file(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def format_domain_prompt(domain_content):
    prompt = f"""
You are an expert consultant specializing in application security program development and OWASP SAMM assessments. I'll provide you with a section of a SAMM assessment report for a specific domain (e.g., Implementation, Verification, Operations). Your task is to analyze this information and organize the recommendations into logical workstreams for a phased implementation roadmap.
For each workstream:
1. Identify related Recommendations that logically belong together based on:
   - Similar security objectives or controls
   - Technical dependencies between recommendations
   - Efficiency gains from implementing related items together
   - Alignment with the client's current initiatives and priorities
2. Create executive-friendly workstream descriptions using this format:
   - Workstream Name: [Use the ID above the question, e.g., "G-SM-A-1-1"]
   - Current State Summary: Brief description of the client's current situation and key gaps in 2-3 sentences
   - Recommendation Summary: What GuidePoint recommends to address these gaps in 2-3 sentences. For each recommendation, include its ID and the gaps it addresses in parentheses, e.g., "(Rec 1, addresses G-SM-A-1-1-A)"
   - Implementation Items: Bullet list of specific actions to take (maximum of 5 items - less is ideal unless you need more)
   - Business Value Statement: 1-2 sentences explaining the business value of this workstream
3. Organize workstreams into implementation phases (1-4) based on:
   - Risk reduction (highest risks addressed in earlier phases)
   - Dependencies between workstreams
   - Quick wins and low-hanging fruit in earlier phases
   - Alignment with client's current initiatives
   - Implementation complexity and resource requirements
4. Each recommendation in the report provided must be addressed in a workstream.
Use third-person perspective throughout (e.g., "Client currently lacks..." and "GuidePoint recommends..."). Keep the language executive-friendly, focusing on business value rather than technical details, while still being specific enough to guide implementation.
Here is the SAMM assessment domain section to analyze:
"{domain_content}"
Provide your output in a code block.
"""
    return prompt


def send_domain_info_to_thread(workspace_slug, thread_slug, domain_info):
    if not domain_info:
        return False
    
    message = format_domain_prompt(json.dumps(domain_info, indent=2))
    return send_chat_message(workspace_slug, thread_slug, message)

def get_thread_chats(workspace_slug, thread_slug):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/{thread_slug}/chats"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        return response.json().get('history', [])
    logging.error(f"Failed to get chat history for thread '{thread_slug}'. Status code: {response.status_code}")
    return []

def write_llm_response_to_file(output_file, domain_name, response):
    with open(output_file, 'a') as f:
        f.write(f"Domain: {domain_name}\n")
        code_block = extract_code_block(response)
        f.write(f"{code_block}\n\n")

def extract_code_block(text):
    start = text.find('```')
    end = text.rfind('```')
    if start != -1 and end != -1 and end > start:
        return text[start+3:end].strip()
    return text  # Return the full text if no code block is found

def process_findings(workspace_name, findings_data, output_file):
    workspace_slug = get_workspace_slug(workspace_name)
    if not workspace_slug:
        logging.error(f"Workspace '{workspace_name}' not found or couldn't be accessed.")
        return

    domain_names = [name for name in findings_data.keys() if isinstance(name, str)]

    for domain_name in domain_names:
        if not any(expected_domain in domain_name for expected_domain in EXPECTED_DOMAINS):
            logging.warning(f"Unexpected domain name encountered: {domain_name}")

    threads = create_threads_in_workspace(workspace_name, domain_names)
    thread_dict = {thread['thread']['name']: thread['thread']['slug'] for thread in threads}

    for domain_name in domain_names:
        thread_slug = thread_dict.get(domain_name)
        if not thread_slug:
            logging.error(f"Thread '{domain_name}' not found or couldn't be created.")
            continue

        domain_info = findings_data.get(domain_name, {})
        if domain_info:
            result = send_domain_info_to_thread(workspace_slug, thread_slug, domain_info)
            if result:
                logging.info(f"Successfully sent information to {domain_name} thread")
                chat_history = get_thread_chats(workspace_slug, thread_slug)
                if chat_history:
                    latest_response = chat_history[-1].get('content', '')
                    write_llm_response_to_file(output_file, domain_name, latest_response)
                else:
                    logging.error(f"No chat history found for {domain_name} thread")
            else:
                logging.error(f"Failed to send information to {domain_name} thread")
        else:
            logging.info(f"No content to send for {domain_name} thread")

        time.sleep(1)  # Add a small delay between messages to avoid rate limiting

def main():
    parser = argparse.ArgumentParser(description="Create specific threads in a specified workspace and send messages.")
    parser.add_argument("--workspace-name", required=True, help="Name of the workspace")
    parser.add_argument("--findings-file", required=True, help="Path to the findings file")
    parser.add_argument("--output-file", required=True, help="Path to the output file for LLM responses")
    
    args = parser.parse_args()
    
    findings_data = read_findings_file(args.findings_file)
    process_findings(args.workspace_name, findings_data, args.output_file)

if __name__ == "__main__":
    main()
