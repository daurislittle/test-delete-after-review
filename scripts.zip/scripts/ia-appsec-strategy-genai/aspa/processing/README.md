# Processing

The processing scripts support the second phase of the application security program assessment (ASPA) workflow, transforming raw discovery data into structured security insights.

## Prerequisites
- Anything LLM workspace with discovery transcripts embedded
- Prepared SAMM framework JSON file

## Processing Steps

1. **ASPA Processing**
   1. Run `process_aspa_anything.py`
   2. **Inputs**
      1. --workspace-name [workspace] = Name of the existing workspace to use
      2. --framework-file [path/to/framework_file] = Path to the prepared SAMM framework JSON file
      3. --output-file [path/to/output/file].json = Directory to store processed findings
   3. **Outputs**
      1. JSON files containing LLM analysis of each SAMM domain with notes, current state, gaps, and recommendations

#### Important: Complete Quality Assurance (QA) on the processed ASPA results before proceeding to Roadmap Generation.

2. **Roadmap Generation**
   1. Run `roadmap_aspa_chunks.py` to process each domain individually
      1. --workspace-name [workspace] = Name of the existing workspace to use
      2. --findings-file [path/to/findings_file] = Path to QA'd findings file
   2. Run `roadmap_aspa_whole.py` to process all domains collectively
      1. TBD

3. **Optional: Maturity Scoring**
   1. Run `score_aspa_results.py`
   2. **Inputs**
      1. --findings-file [path/to/processed/findings] = Path to the processed ASPA results file
      2. --scoring-file [aspa/preprocessing/samm/src/SAMM_scoring.json] = Path to the scoring criteria file
      3. --workspace-name [workspace] = Name of the existing workspace to use
      4. --output-file [path/to/output_file] = Path for the output file with scored findings
   3. **Outputs**
      1. JSON file with scored findings (score, notes, current state, gaps, recommendations)

## Additional Notes
- The processing phase transforms raw discovery data into structured, actionable information about an organization's security posture
- Processed results serve as inputs for the Quality Assurance and Reporting phases
- The roadmap generation provides prioritized recommendations for security improvements
