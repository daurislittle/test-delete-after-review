# Preprocessing

This directory contains files and scripts for the initial data preparation stage of the Automated Security Program Assessment (ASPA) process.

## Contents
- `nist`: Contains NIST-related documents and spreadsheets.
- `prompts`: Stores system prompts for AI models.
- `samm`: Contains SAMM-related JSON files and spreadsheets.
- `utilities`: Houses utility scripts for data preparation.

## Purpose

The preprocessing stage is crucial for preparing the raw data and necessary frameworks for the ASPA process. It involves organizing reference materials, preparing AI prompts, and setting up the SAMM framework for assessment.

## Subdirectories

### nist

Contains NIST (National Institute of Standards and Technology) documents relevant to the security assessment process. These serve as reference materials for best practices and standards.

### prompts

Stores system prompts used to guide AI models in processing ASPA data. The `samm_system_prompt.txt` file is particularly important for SAMM-related assessments.

### samm

Contains various JSON files related to the OWASP SAMM (Software Assurance Maturity Model) framework. It also includes a `src/` subdirectory with SAMM spreadsheets in different formats and versions.

### utilities

Houses utility scripts for data preparation, including:
- `create_json.py`: Script for creating JSON files from raw data.
- `create_markdown.py`: Script for generating Markdown files.
- `prep_samm_framework_json.py`: Prepares the SAMM framework JSON tailored to a client's company for use in the assessment.
- `samm_genMarkdown.py`: Generates Markdown files from SAMM data.
- `samm_ingest_notes.py`: Ingests and processes assessment notes.



