# Organization
- With ACME's cloud opportunistic stance, and current initiatives driving cloud adoption, such as the Global Data Initiative, GuidePoint suggests that ACME plan to invest in hiring a cloud security architect, which they currently do not have. #phase1 #headcount #important #organization #people 
- It was stated that ACME allocates approximately 20% of the development team's capacity to addressing bugs and security vulnerabilities. However, during discovery, it was determined that teams have had hesitancy to pick up the work to address vulnerabilities because product owners push for feature work. ACME should ensure that capacity is allocated to address vulnerabilities within defined SLAs, which will be created as part of this roadmap. If SLAs can't be met, the risk acceptance process should be followed so ACME leadership can assess the risk and determine if it should be accepted. #phase1 #important #organization #process 
- ACME's recent decision to hire an application security architect will undoubtedly enhance application security expertise within the organization. However, GuidePoint suggests that ACME consider adding more application security personnel to the roster to effectively support the additional technologies and processes highlighted in this roadmap. Additionally, application security staff augmentation is recommended until an appropriate staffing level is reached. #headcount #phase1 #organization #important #people 

---
# Governance
## Strategy & Metrics
### Create and Promote
G-SM-A-1-1: Do you understand the enterprise-wide risk appetite for your applications?
* You capture the risk appetite of your organization's executive leadership
*  The organization's leadership vet and approve the set of risks
*  You identify the main business and technical threats to your assets and data
*  You document risks and store them in an accessible location
Notes:
- 
Gaps:
- No risk appetite defined.
- Risk acceptance process is not consistency followed. Risk acceptance forms are not required to be filled out by Product Owners. Acceptance is documented in a spreadsheet as part of a project's risk register, with no timeline or threshold for re-evaluation of risks.
Recommendations:
- ACME needs to develop risk appetite in order to understand what risks to accept. #process #phase1 #governance #important
- Ensure that a risk acceptance process is followed. Risk acceptance should be defined to include different levels of management sign off on it depending on the risk rating or severity of vulnerability. Additionally, a timeline should be set to determine when risk acceptance needs to be re-evaluated. #process #phase1 #governance #important 
- ACME should evaluate risk management tools to help better manage risks, risk acceptance, and associated SLAs. #technology #phase1 #governance #important #riskmanagementplatform
- If determined as beneficial, ACME should purchase and implement the risk management platform as determined in phase1. #phase2 #riskmanagementplatform #governance #important #technology #process 
- Recommendation to capture metrics on risk acceptance  #phase2 #process #governance #important 

G-SM-A-2-1: Do you have a strategic plan for application security and use it to make decisions?
* The plan reflects the organization's business priorities and risk appetite
*  The plan includes measurable milestones and a budget
*  The plan is consistent with the organization's business drivers and risks
*  The plan lays out a roadmap for strategic and tactical initiatives
*  You have buy-in from stakeholders, including development s
Notes:
- 
Gaps:
- Some training and tools exist, but a strategic plan for application security currently does not exist.
Recommendations:
- Should utilize this assessment and the associated roadmap to drive an application security strategic plan. #phase1 #governance #process #important 

G-SM-A-3-1: Do you regularly review and update the Strategic Plan for Application Security?
* You review and update the plan in response to significant changes in the business environment, the organization, or its risk appetite
*  Plan update steps include reviewing the plan with all the stakeholders and updating the business drivers and strategies
*  You adjust the plan and roadmap based on lessons learned from completed roadmap activities
*  You publish progress information on roadmap activities, making sure they are available to all stakeholders
Notes:
- 
Gaps:
- Strategic plan does not exist so it is not published, reviewed, and updated.
Recommendations:
- Once the strategic plan has been created, it should be updated when there are significant changes in the business environment, the organization, or the organization's risk appetite. Ensure that the roadmap is also updated based on lessons learned from completed tasks. The roadmap should be published and communicated. #phase2 #process #governance #important 
### Measure and Improve
G-SM-B-1-1: Do you use a set of metrics to measure the effectiveness and efficiency of the application security program across applications?
* You document each metric, including a description of the sources, measurement coverage, and guidance on how to use it to explain application security trends
*  Metrics include measures of efforts, results, and the environment measurement categories
*  Most of the metrics are frequently measured, easy or inexpensive to gather, and expressed as a cardinal number or a percentage
*  Application security and development teams publish metrics
Notes:
- 
Gaps:
- Not currently capturing any application security related metrics.
Recommendations:
- Recommendation to define metrics that should be captured from data derived in security testing tools. OWASP suggests capturing the effort, results, and the environment metrics. #phase1 #governance #process #important 
- Begin capturing at least one of the metrics defined in phase1. #phase2 #governance #process #important 
- Capture remaining metrics. #phase3 #governance #process #important 

G-SM-B-2-1: Did you define Key Performance Indicators (KPI) from available application security metrics?
* You defined KPIs after gathering enough information to establish realistic objectives
*  You developed KPIs with the buy-in from the leadership and teams responsible for application security
*  KPIs are available to the application teams and include acceptability thresholds and guidance in case teams need to take action
*  Success of the application security program is clearly visible based on defined KPIs
Notes:
- 
Gaps:
- KPIs are currently not derived as application security metrics are not captured.
Recommendations:
- Begin to derive KPIs from application security related metrics. #phase2 #process #governance #important 
- Derive more KPIs are more application security related metrics are captured. #phase3 #process #governance #important 

G-SM-B-3-1: Do you update the Application Security strategy and roadmap based on application security metrics and KPIs?
* You review KPIs at least yearly for their efficiency and effectiveness
*  KPIs and application security metrics trigger most of the changes to the application security strategy
Notes:
- 
Gaps:
- KPIs are currently not derived so annual review is not performed.
Recommendations:
- Once KPIs are derived, ensure they are updated at least annually to ensure they are effective. Also ensure that KPIs and application security metrics are used as a feedback loop to update the application security strategy. #phase3 #governance #process #important 

## Policy & Compliance
### Policy & Standards
G-PC-A-1-1: Do you have and apply a common set of policies and standards throughout your organization?
* You have adapted existing standards appropriate for the organization’s industry to account for domain-specific considerations
*  Your standards are aligned with your policies and incorporate technology-specific implementation guidance
Notes:
- 
Gaps:
- Comprehensive set of policies but standards are light. Although ACME is putting in place Standard Fusion, to aide in mapping policies to standards.
Recommendations:
- ACME should continue to prioritize the initiative to implement Standard Fusion, to aide in mapping policies to standards. This will ensure that standards are defined for all policies. #phase1 #process #governance #important 
- As new processes and technologies are implemented to fulfill objectives specified in the application security roadmap, ACME should ensure that the inclusion of relevant policies and standards are included in the planning of the implementation of said processes and technologies. #phase1 #governance #important #process 

G-PC-A-2-1: Do you publish the organization's policies as test scripts or run-books for easy interpretation by development teams?
* You create verification checklists and test scripts where applicable, aligned with the policy's requirements and the implementation guidance in the associated standards
*  You create versions adapted to each development methodology and technology the organization uses
Notes:
- 
Gaps:
- ACME currently does not provide implementation guidance, based on policy and standards requirements.
Recommendations:
- Once standards have been defined, ACME should define and publish baseline requirements in order to meet the defined standards. Requirements should also be published to meet standards for different data classifications and external compliance obligations. #phase2 #governance #important #process 

G-PC-A-3-1: Do you regularly report on policy and standard compliance, and use that information to guide compliance improvement efforts?
* You have procedures (automated, if possible) to regularly generate compliance reports
*  You deliver compliance reports to all relevant stakeholders
*  Stakeholders use the reported compliance status information to identify areas for improvement
Notes:
- 
Gaps:
- Reporting performed on policy compliance was not observed by GuidePoint.
Recommendations:
- ACME should regularly generate reports on adherence to application security related policy and standard compliance. Reports should be provided to relevant stakeholders. #phase3 #governance #process #important 

### Compliance Management
G-PC-B-1-1: Do you have a complete picture of your external compliance obligations?
* You have identified all sources of external compliance obligations
*  You have captured and reconciled compliance obligations from all sources
Notes:
- 
Gaps:
- ACME has a full understanding of their external compliance obligations and they know what they need to do in order to meet them - they are in scope for CCPA and NYDFS. Their prior efforts to become compliant for GDPR helped them prepare for CCPA. 
Recommendations:
- No recommendations as ACME understands their external compliance obligations.

G-PC-B-2-1: Do you have a standard set of security requirements and verification procedures addressing the organization's external compliance obligations?
* You map each external compliance obligation to a well-defined set of application requirements
*  You define verification procedures, including automated tests, to verify compliance with compliance-related requirements
Notes:
- 
Gaps:
- ACME does not have well-defined application security requirements documented for each external compliance obligation.
Recommendations:
- ACME needs to develop, publish, and communicate requirements and verification procedures for each external compliance obligation and data classification. This is something that Security Champions could collectively develop. #phase1 #governance #process #important #securitychampions #checkdependencies 

G-PC-B-3-1: Do you regularly report on adherence to external compliance obligations and use that information to guide efforts to close compliance gaps?
* You have established, well-defined compliance metrics
*  You measure and report on applications' compliance metrics regularly
*  Stakeholders use the reported compliance status information to identify compliance gaps and prioritize gap remediation efforts
Notes:
- 
Gaps:
- ACME's reporting on the adherence of external compliance obligations was not observed by GuidePoint. Well-defined compliance metrics were not observed.
Recommendations:
- ACME should define and collect metrics after establishing application security requirements and verification procedures. These metrics should be utilized by regular compliance reporting initiatives. #phase2 #governance #important #process 
- #checkdependencies on this one w/ other requirements documentation tasks. this one is also related to G-PC-B-2-1 so make sure dependencies make sense

## Education & Guidance
### Training and Awareness
G-EG-A-1-1: Do you require employees involved with application development to take SDLC training?
* Training is repeatable, consistent, and available to anyone involved with software development lifecycle
*  Training includes the latest OWASP Top 10 if appropriate and includes concepts such as Least Privilege, Defense-in-Depth, Fail Secure (Safe), Complete Mediation, Session Management, Open Design, and Psychological Acceptability
*  Training requires a sign-off or an acknowledgement from attendees
*  You have updated the training in the last 12 months
*  Training is required during employees' onboarding process
Notes:
- 
Gaps:
- Standard security awareness training is provided to all employees. Secure Software Development training is provided to software developers and QA teams. This includes several hours of training that these employees have to take upon hire and annually during cybersecurity awareness month. 
Recommendations:
- ACME's Secure Software Development training curriculum that GuidePoint reviewed provides a good foundation but courses should be expanded to include specific course modules for each OWASP Top 10 category. These modules should include detailed guidance on each of the OWASP top 10 categories. Training courses should include quizzes or some other way to gauge the employees level of knowledge gained by taking the training. ACME should ensure that all employees that write code be required to take this training during onboarding and annually. #phase1 #governance #process #important #training #people

G-EG-A-2-1: Is training customized for individual roles such as developers, testers, or security champions?
* Training includes all topics from maturity level 1, and adds more specific tools, techniques, and demonstrations
*  Training is mandatory for all employees and contractors
*  Training includes input from in-house SMEs and trainees
*  Training includes demonstrations of tools and techniques developed in-house
*  You use feedback to enhance and make future training more relevant
Notes:
- 
Gaps:
- ACME has started requiring role-based training for project managers and product owners. This training is related to risk-based training, focusing on key terms to watch out for. ACME is not providing any other role-based training, such as Security Champions training or QA Security tester training. 
Recommendations:
- ACME should expand the role-based training that it is providing. Threat Modeling and Security Champions training should be targeted for phase 2. #phase2 #governance #training #important #people
- ACME should provide hands-on, instructor led secure software development training to individuals identified to become Security Champions. Once trained, these employees will possess the skills to conduct secure code reviews of high risk code, mentor fellow team members, and assist with triaging results from applications security testing tools like SAST. #phase2 #training #important #governance #people 
- ACME should continue to expand the role-based training that it provides to employees. QA Security tester training should be provided in phase 3. #phase3 #governance #training #important #people 

G-EG-A-3-1: Have you implemented a Learning Management System or equivalent to track employee training and certification processes?
* A Learning Management System (LMS) is used to track trainings and certifications
*  Training is based on internal standards, policies, and procedures
*  You use certification programs or attendance records to determine access to development systems and resources
Notes:
- 
Gaps:
- ACME currently utilizes a LMS to manage courses, define due dates, and track attendance. Compliance of employees taking training courses is performed via periodic inspection. Acceptable use and security policy training are completed and tracked outside of the LMS, annually and as part of onboarding. However, since ACME does not have any documented standards, this type of training is not provided or tracked. 
Recommendations:
- Once ACME documents application security related standards, training on these standards should be provided and tracked ideally in the LMS or if that's not feasible, in another system of record. ACME should perform scheduled compliance inspection to ensure that training is taken by all employees and contractors annually. Employees should not have access to development systems and resources unless training has been completed adequately. #phase2 #governance #process #important 
### Organization and Culture
G-EG-B-1-1: Have you identified a Security Champion for each development team?
* Security Champions receive appropriate training
*  Application Security and Development teams receive periodic briefings from Security Champions on the overall status of security initiatives and fixes
*  The Security Champion reviews the results of external testing before adding to the application backlog
Notes:
- 
Gaps:
- There is currently no Security Champions Program.
Recommendations:
- GuidePoint recommends that ACME identify individuals to become Security Champions and these individuals should be provided Security Champions training. #phase2 #people #governance #important #training 

G-EG-B-2-1: Does the organization have a Secure Software Center of Excellence (SSCE)?
* The SSCE has a charter defining its role in the organization
*  Development teams review all significant architectural changes with the SSCE
*  The SSCE publishes SDLC standards and guidelines related to Application Security
*  Product Champions are responsible for promoting the use of specific security tools
Notes:
- 
Gaps:
- ACME currently does not have a function that serves as a Secure Software Center of Excellence (SSCE). There is a Belt program but it has withered a bit but has been used in the past.
Recommendations:
- ACME should form a Secure Software Center of Excellence (SSCE) or utilize the Security Champions and Security personnel as a DevSecOps Community of Practice to derive and publish SDLC standards and guidelines related to Application Security. This group should also collectively review all significant application architectural changes. #phase2 #process #governance #important #securitychampions 

G-EG-B-3-1: Is there a centralized portal where developers and application security professionals from different teams and business units are able to communicate and share information?
* The organization promotes use of a single portal across different teams and business units
*  The portal is used for timely information such as notification of security incidents, tool updates, architectural standard changes, and other related announcements
*  The portal is widely recognized by developers and architects as a centralized repository of the organization-specific application security information
*  All content is considered persistent and searchable
*  The portal provides access to application-specific security metrics
Notes:
- 
- Jabber is used for communications
- Want to move to Teams
Gaps:
- Although ACME has good collaboration between the Cloud, Development teams, and DevOps teams, they currently lack a centralized platform that can be utilized for collaboration, sharing of documentation, and notification of security incidents, tool updates, architectural standard changes, and other related announcements.
Recommendations:
- GuidePoint recommends that ACME evaluate the use of Microsoft Teams as a centralized platform that can be utilized for collaboration, sharing of documentation, and notification of security incidents, tool updates, architectural standard changes, and other related announcements. #phase1 #governance #important #technology

---
# Design
## Threat Assessment
### Application Risk Profile
D-TA-A-1-1: Do you classify applications according to business risk based on a simple and predefined set of questions?
* An agreed-upon risk classification exists
*  The application team understands the risk classification
*  The risk classification covers critical aspects of business risks the organization is facing
*  The organization has an inventory for the applications in scope
Notes:
- 
Gaps:
- Although risk assessments are done at the organizational level on an annual basis, the Written Information Security Policy (WISP) policy states that "critical assets and business processes will have risk assessments performed on a quarterly basis" or "in the event of significant changes". These updates are to be documented in the System Security Plan (SSP). There was no evidence that this was being performed.
Recommendations:
- ACME should ensure that an application's risk is assessed according to policy. Additionally, applications should be designated a risk classification based on a simple and predefined set of questions. The classification of the application should be documented in a location that is accessible by all stakeholders, preferably in the application inventory. #phase1 #design #important #process 

D-TA-A-2-1: Do you use centralized and quantified application risk profiles to evaluate business risk?
* The application risk profile is in line with the organizational risk standard
*  The application risk profile covers impact to security and privacy
*  You validate the quality of the risk profile manually and/or automatically
*  The application risk profiles are stored in a central inventory
Notes:
- 
Gaps:
- There was no evidence of the use of centralized and quantified application risk profiles although policy states that SSPs will be used.
Recommendations:
- ACME should create quantified application risk profiles that are stored in a centralized inventory. The application risk profile covers impact to security and privacy. #phase3 #important #design #process 

D-TA-A-3-1: Do you regularly review and update the risk profiles for your applications?
* The organizational risk standard considers historical feedback to improve the evaluation method
*  Significant changes in the application or business context trigger a review of the relevant risk profiles
Notes:
- 
Gaps:
- There was no evidence of the use of application risk profiles.
Recommendations:
- Once application risk profiles have been created, ACME should ensure that a process exists to ensure that significant changes in the application or business context trigger a review of the relevant risk profiles. #phase4 #important #process #design 

### Threat Modeling
D-TA-B-1-1: Do you identify and manage architectural design flaws with threat modeling?
* You perform threat modeling for high-risk applications
*  You use simple threat checklists, such as STRIDE
*  You persist the outcome of a threat model for later use
Notes:
- 
Gaps:
- Threat modeling is currently not being performed by ACME.
Recommendations:
- GuidePoint recommends that ACME begin performing threat modeling of 1 high risk application (as a proof of concept) during the design phase of the S-SDLC. This should begin after Threat Modeling training has been provided to relevant stakeholders. #phase2 #design #process #important 
- GuidePoint recommends that ACME utilize a standard framework to conduct threat modeling, like STRIDE #phase2 #design #process #important 

D-TA-B-2-1: Do you use a standard methodology, aligned on your application risk levels?
* You train your architects, security champions, and other stakeholders on how to do practical threat modeling
*  Your threat modeling methodology includes at least diagramming, threat identification, design flaw mitigations, and how to validate your threat model artifacts
*  Changes in the application or business context trigger a review of the relevant threat models
*  You capture the threat modeling artifacts with tools that are used by your application teams
Notes:
- 
Gaps:
- Currently no threat modeling is being performed and training has not been provided to architects, security champions, and other stakeholders on how to do practical threat modeling.
Recommendations:
- ACME should ensure that threat modeling training is provided to architects, security champions, and other stakeholders on how to do practical threat modeling, as specified in the Governance section. #phase2 #important #people #design 
- After ACME conducted a threat modeling proof on concept in phase2, ACME should expand threat modeling to all high risk applications. #phase3 #design #process #important 
- ACME should ensure that as part of the S-SDLC, changes in high risk applications trigger a review of the relevant threat models. #phase3 #design #process #important 

D-TA-B-3-1: Do you regularly review and update the threat modeling methodology for your applications?
* The threat model methodology considers historical feedback for improvement
*  You regularly (e.g., yearly) review the existing threat models to verify that no new threats are relevant for your applications
*  You automate parts of your threat modeling process with threat modeling tools
Notes:
- 
Gaps:
- Currently no threat modeling is being performed.
Recommendations:
- ACME should review existing threat models on an annual basis to verify that no new threats are relevant for your applications. #phase4 #design #important #process 

## Security Requirements
### Software Requirements
D-SR-A-1-1: Do project teams specify security requirements during development?
* Teams derive security requirements from functional requirements and customer or organization concerns
*  Security requirements are specific, measurable, and reasonable
*  Security requirements are in line with the organizational baseline
Notes:
- 
Gaps:
- Security requirements (including application security) are currently not documented for external compliance obligations or on a per-data classification perspective.
- On an ad-hoc basis, sometimes application security requirements are added to the Feature but this is not formal or structured as no requirements exist.
- ACME currently does not derive application security requirements from functional requirements.
- ACME seems to have more maturity from a requirements perspective when it comes to infrastructure and cloud security. Infrastructure as Code modules are created with baseline security requirements so when the modules get used, they are secure by default. #IaC
Recommendations:
- ACME should begin to derive application security requirements from functional requirements, in addition to publishing security requirements for external compliance obligations and on a per-data classification perspective. #phase2 #process #important #design 
- Although currently done on an ad-hoc basis right now, ACME should ensure that high availability requirements are also captured during the requirements gathering phase.  #phase2 #design #process 

D-SR-A-2-1: Do you define, structure, and include prioritization in the artifacts of the security requirements gathering process?
* Security requirements take into consideration domain specific knowledge when applying policies and guidance to product development
*  Domain experts are involved in the requirements definition process
*  You have an agreed upon structured notation for security requirements
*  Development teams have a security champion dedicated to reviewing security requirements and outcomes
Notes:
- 
Gaps:
- ACME currently does not define, structure, and include prioritization in the artifacts of the security requirements gathering process.
Recommendations:
- ACME should ensure that security requirements take into consideration domain specific knowledge when applying policies and guidance to product development. #phase3 #process #important #design 

D-SR-A-3-1: Do you use a standard requirements framework to streamline the elicitation of security requirements?
* A security requirements framework is available for project teams
*  The framework is categorized by common requirements and standards-based requirements
*  The framework gives clear guidance on the quality of requirements and how to describe them
*  The framework is adaptable to specific business requirements
Notes:
- 
Gaps:
- ACME captures security requirements on an ad-hoc basis, and they are added to the Feature in the ticketing system but this is not formal or structured as no requirements exist.
Recommendations:
- ACME should develop a standardized way to capture security requirements during the requirements gathering phase of a project. GuidePoint suggests that either a custom work item be created or specific User Stories bound to a Feature to capture security requirements are used. #phase2 #process #design #important 

### Supplier Security
D-SR-B-1-1: Do stakeholders review vendor collaborations for security requirements and methodology?
* You consider including specific security requirements, activities, and processes when creating third-party agreements
*  A vendor questionnaire is available and used to assess the strengths and weaknesses of your suppliers
Notes:
- 
Gaps:
- ACME utilizes BlueVoyant for TPRM activities with vendor reassessment based on vendor criticality which is either 1, 3, or 5 years.
Recommendations:
- GuidePoint suggests that 5 years for vendor reassessment is likely too long and ACME should reduce this as a lot can happen from a security perspective in 5 years. #phase1 #design #important #process 
- ACME should ensure that application security expertise is involved in the TPRM process to vet and approve of potential vendors/products. #phase1 #design #important #process 

D-SR-B-2-1: Do vendors meet the security responsibilities and quality measures of service level agreements defined by the organization?
* You discuss security requirements with the vendor when creating vendor agreements
*  Vendor agreements provide specific guidance on security defect remediation within an agreed upon timeframe
*  The organization has a templated agreement of responsibilities and service levels for key vendor security processes
*  You measure key performance indicators
Notes:
- 
Gaps:
- 
Recommendations:
- 

D-SR-B-3-1: Are vendors aligned with standard security controls and software development tools and processes that the organization utilizes?
* The vendor has a secure SDLC that includes secure build, secure deployment, defect management, and incident management that align with those used in your organization
*  You verify the solution meets quality and security objectives before every major release
*  When standard verification processes are not available, you use compensating controls such as software composition analysis and independent penetration testing
Notes:
- 
Gaps:
- 
Recommendations:
- GuidePoint recommends that ACME ensure that third-party vendors are aligned with standard security controls and software development tools and processes that ACME utilizes. Additionally, ACME should ensure that third-party vendor agreements provide specific guidance on security defect remediation within an agreed upon SLA. #phase1 #process #important #design 
- In instances where ACME cannot follow standard third-party verification processes, such as with open-source components that lack a specific owning company, it's crucial that the third-party risk management process utilize compensating controls such as utilizing Software Composition Analysis (SCA), independent code review, and/or penetration testing to ensure these components or services meet security standards. #phase2 #design #technology #important #SCA 

## Secure Architecture
### Architecture Design
D-SA-A-1-1: Do teams use security principles during design?
* You have an agreed upon checklist of security principles
*  You store your checklist in an accessible location
*  Relevant stakeholders understand security principles
Notes:
- 
Gaps:
- No evidence that application security principles have been defined or are used during design activities. All application security related design discussions suggested that it was all ad-hoc.
Recommendations:
- ACME should document and communicate application security principles. #phase1 #design #important #process 

D-SA-A-2-1: Do you use shared security services during design?
* You have a documented list of reusable security services, available to relevant stakeholders
*  You have reviewed the baseline security posture for each selected service
*  Your designers are trained to integrate each selected service following available guidance
Notes:
- 
Gaps:
- 
Recommendations:
- ACME utilizes a variety of shared security services, including Akamai WAF, AWS WAF, AWS Secrets Manager, AWS API Gateway, etc. ACME should document the list of reusable security services, available to relevant stakeholders that can be used during the design phase. #phase1 #important #design #process 
- ACME should evaluate their complete list of shared security services and ensure that on-premises resources have the same type of shared security services available as cloud resources as a significant of ACME's footprint is not in the cloud. #phase1 #design #process #important 

D-SA-A-3-1: Do you base your design on available reference architectures?
* You have one or more approved reference architectures documented and available to stakeholders
*  You improve the reference architectures continuously based on insights and best practices
*  You provide a set of components, libraries, and tools to implement each reference architecture
Notes:
- 
Gaps:
- There was no evidence that secure references architectures that include application security were documented or utilized.
Recommendations:
- ACME should ensure that application design is based on documented secure reference architectures that include the application security perspective. Application reference architectures should consistently be improved upon, based on feedback loops from architecture reviews, threat modeling, application penetration tests, etc. #phase2 #design #process #important 

### Technology Management
D-SA-B-1-1: Do you evaluate the security quality of important technologies used for development?
* You have a list of the most important technologies used in, or in support of, each application
*  You identify and track technological risks
*  You ensure the risks to these technologies are in line with the organizational baseline
Notes:
- 
Gaps:
- ACME used to utilize Software Composition Analysis to analyze third-party components but it appears to no longer be utilized.
- No evidence of ACME inventorying third-party components used in applications was identified.
Recommendations:
- ACME should implement an SCA tool to analyze third-party components used in applications. #phase1 #SCA #technology #process #design #important 
- In addition to understanding the third-party risks associated with utilizing some open-source third-party components, SCA can also be used to capture an inventory of the components in use. This can be provided as an SBOM. #phase1 #design #SCA #important #process #technology 
- ACME's Written Information Security Policy (WISP) states that the use of open-source technologies is prohibited. ACME should update the policy or prhibit the use of opensource technologies. #phase1 #design #process 

D-SA-B-2-1: Do you have a list of recommended technologies for the organization?
* The list is based on technologies used in the software portfolio
*  Lead architects and developers review and approve the list
*  You share the list across the organization
*  You review and update the list at least yearly
Notes:
- 
Gaps:
- Evidence of a formal, published list of approved technologies was not identified, although it was determined that ACME utilizes an ad-hoc process to vet and approve technologies and those technologies were then added to the artifact repository.
Recommendations:
- Although architects review, do proof-of-concepts, and vet and approve third-party components, which then get added to the artifact repository, so formal and structured process for vetting, approval, and inventory of third-party components was identified. ACME should ensure that a process exists to vet, approve, and inventory approved third-party components is created. Additionally, the inventory of approved third-party components should be published, communicated, and made readily available. #phase2 #design #important #process 

D-SA-B-3-1: Do you enforce the use of recommended technologies within the organization?
* You monitor applications regularly for the correct use of the recommended technologies
*  You solve violations against the list according to organizational policies
*  You take action if the number of violations falls outside the yearly objectives
Notes:
- 
Gaps:
- Since no official approved list of technologies exists, enforcement is not done on a structured basis.
Recommendations:
- Once a list of approved third-party components is published, ACME should create a process to enforce the use of recommended technologies within the organization and monitoring of applications regularly for the correct use of the recommended technologies is performed. #phase3 #design #process #important  

---
# Implementation
## Secure Build
### Build Process
I-SB-A-1-1: Is your full build process formally described?
* You have enough information to recreate the build processes
*  Your build documentation up to date
*  Your build documentation is stored in an accessible location
*  Produced artifact checksums are created during build to support later verification
*  You harden the tools that are used within the build process
Notes:
- ACME has a very mature build pipeline. It is self-documenting as Azure pipelines are used and build pipeline definitions are stored in source control. Additionally, these build pipeline definitions are stored in a separate code repository which facilitates robust separation of duties from a code repository management and also a branch protection perspective. Additionally, Azure DevOps, which is used for both build and release pipelines is hardened according to best practices. Additionally, artifacts that are built are checksummed for verification before release and stored in Azure Artifacts.
Gaps:
- No gaps exist but ACME should evaluate the effectiveness of Azure Artifacts from an application security perspective as compared to other artifact repositories on the market. GuidePoint suggests that ACME utilize an artifact repository that has more robust security controls around scanning and approving specific third-party components.
Recommendations:
- ACME has mature build processes that are formally described. #mature #implementation #important #process 
- ACME should evaluate the effectiveness of Azure Artifacts from an application security perspective as compared to other artifact repositories on the market. GuidePoint suggests that ACME utilize an artifact repository that has more robust security controls around scanning and approving specific third-party components. #phase2  #important #technology #implementation #artifactrepo
- ACME should implement the replacement artifact repository with one that was specified in phase 2. Once implemented, begin moving product teams to this new artifact repository. #phase3 #important #technology #implementation #artifactrepo 

I-SB-A-2-1: Is the build process fully automated?
* The build process itself doesn't require any human interaction
*  Your build tools are hardened as per best practice and vendor guidance
*  You encrypt the secrets required by the build tools and control access based on the principle of least privilege
Notes:
- ACME's build process is fully automated and mature. Builds do not require any human intervention but releases do, which is a best practice. ACME does not utilize secrets during the build process.
Gaps:
- 
Recommendations:
- ACME's build process is fully automated and mature. GuidePoint does not have any recommendations to further enhance this security practice. #mature #implementation #process 

I-SB-A-3-1: Do you enforce automated security checks in your build processes?
* Builds fail if the application doesn't meet a predefined security baseline
*  You have a maximum accepted severity for vulnerabilities
*  You log warnings and failures in a centralized system
*  You select and configure tools to evaluate each application against its security requirements at least once a year
Notes:
- 
Gaps:
- Although SAST scans are currently integrated with the build process, breaking of builds is currently not implemented when SAST scans fail. Additionally, failure thresholds based on vulnerability severity have not been defined in the SAST tool.
Recommendations:
- GuidePoint suggests that ACME define and implement failure thresholds based on vulnerability severity in the existing SAST platform and other application security testing platforms as they are implemented. #phase1 #important #implementation #process #headcount 

### Software Dependencies
I-SB-B-1-1: Do you have solid knowledge about dependencies you're relying on?
* You have a current bill of materials (BOM) for every application
*  You can quickly find out which applications are affected by a particular CVE
*  You have analyzed, addressed, and documented findings from dependencies at least once in the last three months
Notes:
- 
Gaps:
- ACME is currently does not create SBOMs for applications.
Recommendations:
- GuidePoint suggests that ACME implement an SCA tool to be used to capture an inventory of all third party components in use on a per-application basis. SBOMs should also be generated by the SCA tool. #phase1 #SCA #SBOM #implementation #important #technology 

I-SB-B-2-1: Do you handle 3rd party dependency risk by a formal process?
* You keep a list of approved dependencies that meet predefined criteria
*  You automatically evaluate dependencies for new CVEs and alert responsible staff
*  You automatically detect and alert to license changes with possible impact on legal application usage
*  You track and alert to usage of unmaintained dependencies
*  You reliably detect and remove unnecessary dependencies from the software
Notes:
- 
Gaps:
- ACME currently does not keep a list of approved third-party dependencies that meet predefined criteria.
- ACME currently does not evaluate third-party component licenses.
- ACME performs an ad-hoc, informal review of third-party components that involves discussions with team members.
Recommendations:
- ACME should create a formal vetting, approval, and inventory process for onboarding third-party components. Vetting and approval should involve the Security team and should also evaluate license requirements as some open-source licenses can potentially pose some risk to the organization. #phase2 #process #implementation #important 

I-SB-B-3-1: Do you prevent build of software if it's affected by vulnerabilities in dependencies?
* Your build system is connected to a system for tracking 3rd party dependency risk, causing build to fail unless the vulnerability is evaluated to be a false positive or the risk is explicitly accepted
*  You scan your dependencies using a static analysis tool
*  You report findings back to dependency authors using an established responsible disclosure process
*  Using a new dependency not evaluated for security risks causes the build to fail
Notes:
- 
Gaps:
- Although ACME utilizes a Static Application Security Testing (SAST) tool to scan for vulnerabilities in code, a process to break the software build is currently not implemented.
Recommendations:
- ACME should create thresholds in security testing tools, including SAST to break builds. GuidePoint suggests starting with a policy threshold that fails the build, when critical vulnerabilities are identified. As ACME gains more maturity, the threshold should be matured to include high severity vulnerabilities, then eventually to medium severity vulnerabilities. #phase2 #implementation #SAST #SCA #process #important

## Secure Deployment
### Deployment Process
I-SD-A-1-1: Do you use repeatable deployment processes?
* You have enough information to run the deployment processes
*  Your deployment documentation up to date
*  Your deployment documentation is accessible to relevant stakeholders
*  You ensure that only defined qualified personnel can trigger a deployment
*  You harden the tools that are used within the deployment process
Notes:
- ACME utilizes a repeatable deployment process. Classic release pipelines are utilized. A template of an a master classic release pipeline is cloned and renamed when a new release pipeline needs to be created. This ensures standardization.
- ACME utilizes an approval gate in the release pipeline to production that requires approval before the pipeline is authorizes to run.
- ACME utilizes Azure DevOps for all pipelines. This tools is hardened according to best practices.
Gaps:
- 
Recommendations:
- Although an approval gate is implemented in the pipeline and is required before release to the production environment, ACME should ensure that the person approving the pipeline release to production has received approval from the change management process. #phase1 #implementation #CAB #important #process 
- ACME should also ensure that the change management process has reviewed if any vulnerabilities exist in the artifact prior to granting authorization to production. If vulnerabilities exist, then change management should ensure that the risk management process has been followed and risks have been properly accepted.  #phase1 #implementation #CAB #important #process 

I-SD-A-2-1: Are deployment processes automated and employing security checks?
* Deployment processes are automated on all stages
*  Deployment includes automated security testing procedures
*  You alert responsible staff to identified vulnerabilities
*  You have logs available for your past deployments for a defined period of time
Notes:
- 
Gaps:
- ACME currently does not employ automated security checks during the deployment process.
Recommendations:
- ACME's release pipelines should trigger automated security checks during the deployment process. Dynamic Application Security Testing (DAST) can be used for this purpose to test for vulnerabilities during runtime in QA/staging/UAT environments. #DAST #technology #implementation #important #phase2 

I-SD-A-3-1: Do you consistently validate the integrity of deployed artifacts?
* You prevent or roll back deployment if you detect an integrity breach
*  The verification is done against signatures created during the build time
*  If checking of signatures is not possible (e.g. externally build software), you introduce compensating measures
Notes:
- 
Gaps:
- Although checksums are created for build artifacts, verification of the artifact is currently not being performed prior to deployment.
Recommendations:
- ACME should consistently validate the integrity of artifacts before deploying them. Although checksums are created for build artifacts, verification of the artifact is currently not being performed prior to deployment. #phase2 #important #implementation #process 

### Secret Management
I-SD-B-1-1: Do you limit access to application secrets according to the least privilege principle?
* You store production secrets protected in a secured location
*  Developers do not have access to production secrets
*  Production secrets are not available in non-production environments
Notes:
- ACME limits access to application secrets according to the least privilege principle. Release pipeline variable groups in Azure DevOps are locked down. Only build engineers can access them. Good separation of duties.
Gaps:
- 
Recommendations:
- ACME limits access to application secrets according to the least privilege principle. #mature #implementation #important #process 

I-SD-B-2-1: Do you inject production secrets into configuration files during deployment?
* Source code files no longer contain active application secrets
*  Under normal circumstances, no humans access secrets during deployment procedures
*  You log and alert when abnormal secrets access is attempted
Notes:
- ACME currently scans for secrets in source code using their SAST platform (Checkmarx), which is mature.
- ACME properly injects secrets during the release process using release pipeline variable groups in Azure DevOps that are locked down. Only build engineers can access them. Very good separation of duties.
Gaps:
- 
Recommendations:
- ACME properly injects production secrets into configuration files during deployment. Additionally, Release pipeline variable groups in Azure DevOps are locked down. Only build engineers can access them, which aligns with Microsoft's best practices. #mature #implementation #important #process 

I-SD-B-3-1: Do you practice proper lifecycle management for application secrets?
* You generate and synchronize secrets using a vetted solution
*  Secrets are different between different application instances
*  Secrets are regularly updated
Notes:
- ACME currently rotates secrets in AWS. No evidence that secrets are rotated outside of AWS.
Gaps:
- 
Recommendations:
- Although ACME currently rotates secrets in AWS, ACME should ensure that secrets in other environments are also rotated on a regular basis. #phase3 #implementation #important #process 

## Defect Management
### Defect Tracking
I-DM-A-1-1: Do you track all known security defects in accessible locations?
* You can easily get an overview of all security defects impacting one application
*  You have at least a rudimentary classification scheme in place
*  The process includes a strategy for handling false positives and duplicate entries
*  The defect management system covers defects from various sources and activities
Notes:
- 
Gaps:
- ACME currently tracks all security defects, including vulnerabilities in Jira. When the security defect is entered into Jira, it is not distinguished from non-security related defects, potentially making it difficult to identify and promote the security defect during Program Increment (PI) planning activities.
- Currently, security defects are triaged by a developer and a development team leader, with involvement by the Product Owner. No Security team representation is involved in triaging security defects.
Recommendations:
- ACME should ensure that all security defects are differentiated from non-security defects in Jira so they can be identified and promoted during Program Increment (PI) planning activities. #phase1 #important #implementation #process 
- ACME currently creates tickets in Jira for identified security defects to be addressed by product teams. However, there's a lack of a centralized vulnerability management platform to aggregate, correlate, and report data from all security testing tools. As more tools are onboarded, it's critical to have this single pane of glass for vulnerability management. ACME should evaluate vulnerability management platforms in phase 2 and finalize the purchase by phase 3. #vulnmanagement #phase2 #important #technology #verification  
-  ACME should implement the vulnerability management platform as determined in phase2 and begin integrating all relevant tooling (e.g. monitoring, build, deployment) with the platform. This will provide a single pane of glass on the state of vulnerabilities in the organization.  #phase3 #verification #important #technology #vulnmanagement 
- ACME should involve Security team representation in the triaging of security defects identified by security testing activities as triage is currently performed by the product team, which poses a conflict of interest. #phase1 #important #implementation #process 

I-DM-A-2-1: Do you keep an overview of the state of security defects across the organization?
* A single severity scheme is applied to all defects across the organization
*  The scheme includes SLAs for fixing particular severity classes
*  You regularly report compliance to SLAs
Notes:
- 
Gaps:
- ACME currently does not have SLAs in place for security defects and vulnerabilities. As such, ACME does not report on compliance to SLAs.
Recommendations:
- ACME should define SLAs to address vulnerabilities according to their severity. These SLAs should be part of the risk management process. #phase1 #important #process #implementation  
- Once SLAs are in place for security defects and vulnerabilities, ACME should regularly report on compliance to SLAs. #phase2 #important #process #implementation 

I-DM-A-3-1: Do you enforce SLAs for fixing security defects?
* You automatically alert of SLA breaches and transfer respective defects to the risk management process
*  You integrate relevant tooling (e.g. monitoring, build, deployment) with the defect management system
Notes:
- 
Gaps:
- ACME currently does not have SLAs in place for security defects and vulnerabilities, nor any reporting on SLAs. As such, ACME does not enforce SLAs.
Recommendations:
- Once SLAs are in place for security defects and vulnerabilities, ACME should begin to enforce SLAs. Breaches of the SLAs trigger the risk management process. #phase2 #important #implementation #process 

### Metrics and Feedback
I-DM-B-1-1: Do you use basic metrics about recorded security defects to carry out quick win improvement activities?
* You analyzed your recorded metrics at least once in the last year
*  At least basic information about this initiative is recorded and available
*  You have identified and carried out at least one quick win activity based on the data
Notes:
- 
Gaps:
- ACME does not currently have any application security metrics defined. As such, ACME does not analyze metrics.  
Recommendations:
- ACME should define metrics for defect classification and categorization that should be captured from defect data derived from security testing tools. #phase1 #verification #process #important 
- ACME should analyze recorded metrics at least annually and begin performing "quick win activities" based on the data. #phase2 #verification #process #important 

I-DM-B-2-1: Do you improve your security assurance program upon standardized metrics?
* You document metrics for defect classification and categorization and keep them up to date
*  Executive management regularly receives information about defects and has acted upon it in the last year
*  You regularly share technical details about security defects among teams
Notes:
- 
Gaps:
- ACME does not currently have any application security metrics defined. As such, metrics for defect classification and categorization are not kept them up to date and the security assurance program is not improved based upon these metrics.
Recommendations:
- Once ACME defines metrics for defect classification and categorization that are captured from defect data derived from security testing tools, they should utilize said metrics as a feedback loop to improve the security assurance program. #phase3 #important #process #verification 
- ACME should begin to share technical details about security defects among the product teams. #phase2 #verification #process #important 

I-DM-B-3-1: Do you regularly evaluate the effectiveness of your security metrics so that its input helps drive your security strategy?
* You have analyzed the effectiveness of the security metrics at least once in the last year
*  Where possible, you verify the correctness of the data automatically
*  The metrics is aggregated with other sources like threat intelligence or incident management
*  You derived at least one strategic activity from the metrics in the last year
Notes:
- 
Gaps:
- ACME  currently does not regularly evaluate the effectiveness of your security metrics so that its input helps drive the security strategy.
Recommendations:
- ACME should aggregate security metrics with other sources like threat intelligence or incident management. #phase3 #verification #important #process 
- ACME should evaluate the effectiveness of security metrics so that its input helps drive the security strategy. This should be done on an annual basis. #phase4 #verification #important #process 

---

# Verification
## Architecture Assessment
### Architecture Validation
V-AA-A-1-1: Do you review the application architecture for key security objectives on an ad-hoc basis?
* You have an agreed upon model of the overall software architecture
*  You include components, interfaces, and integrations in the architecture model
*  You verify the correct provision of general security mechanisms
*  You log missing security controls as defects
Notes:
- 
Gaps:
- ACME used to have an Architecture Review Board (ARB) in place to review the application architecture for key security requirements were met, but it was disbanded when the Enterprise Architect left the organization. Also, the ARB was not utilized as a gate in the S-SDLC. As it stand right now, there are no reviews that take place.
- ACME appears to have a more robust security architecture verification process when it comes to verifying infrastructure security but they are lacking on verifying application security.
Recommendations:
- GuidePoint recommends that ACME's ARB be re-established and is used to review the application architecture to ensure that security requirements that have been previously specified have been met, based on published application security requirements and security requirements captured from functional requirements. The ARB should initially focus on high risk applications on an ad-hoc basis, then when the process has been well exercised, it will be expanded in subsequent phases. The ARB should verify the correct provision of general security requirements and log missing security controls as defects. #phase2 #process #ARB #verification #important 

V-AA-A-2-1: Do you regularly review the security mechanisms of your architecture?
* You review compliance with internal and external requirements
*  You systematically review each interface in the system
*  You use a formalized review method and structured validation
*  You log missing security mechanisms as defects
Notes:
- 
Gaps:
- 
Recommendations:
- The ARB should mature its verification of high risk applications to to a more structured cadence and process, as compared to the ad-hoc approach in phase2.  Additionally, verification should also include the review compliance with internal and external requirements and a systematic review of all interfaces in the application. The ARB logs missing security requirements as defects. #phase3 #process #ARB #verification #important 

V-AA-A-3-1: Do you regularly review the effectiveness of the security controls?
* You evaluate the preventive, detective, and response capabilities of security controls
*  You evaluate the strategy alignment, appropriate support, and scalability of security controls
*  You evaluate the effectiveness at least yearly
*  You log identified shortcomings as defects
Notes:
- 
Gaps:
- 
Recommendations:
- The ARB should mature its verification to applications other than high risk ones. The verification review is performed at least annually. The ARB logs missing security requirements as defects.  #phase4 #verification #important #process #ARB 

### Architecture Mitigation
V-AA-B-1-1: Do you review the application architecture for mitigations of typical threats on an ad-hoc basis?
* You have an agreed upon model of the overall software architecture
*  Security savvy staff conduct the review
*  You consider different types of threats, including insider and data-related ones
Notes:
- 
Gaps:
- It appears that ACME only reviews infrastructure related architecture for mitigations of typical threats on an ad-hoc basis. There appears to be good use of network controls and IaC modules have been hardened to ensure they are secure by default, suggesting that they were reviewed for threats and hardened accordingly. On the application security perspective, ACME has rolled out Web Application Firewalls (WAFs) to help mitigate threats to their applications. However, despite these efforts, there was no evidence that the review of the application architecture for mitigations of typical threats was being performed on an ad-hoc basis.
Recommendations:
- On the application security perspective, ACME has rolled out Web Application Firewalls (WAFs) to help mitigate threats to their applications. However, despite these efforts, there was no evidence that the review of the application architecture for mitigations of typical threats was being performed on an ad-hoc basis. #phase2 #verification #important #process 

V-AA-B-2-1: Do you regularly evaluate the threats to your architecture?
* You systematically review each threat identified in the Threat Assessment
*  Trained or experienced people lead review exercise
*  You identify mitigating design-level features for each identified threat
*  You log unhandled threats as defects
Notes:
- 
Gaps:
- Threat modeling is currently not being performed.
Recommendations:
- ACME should train employees on threat modeling and ensure that the threat modeling program gets off the ground. Once it is in place and artifacts are being created as part of that process, the threats identified in the threat models should be used for verification activities to ensure that identified threats have been mitigated. #phase3 #process #verification #important 

V-AA-B-3-1: Do you regularly update your reference architectures based on architecture assessment findings?
* You assess your architectures in a standardized, documented manner
*  You use recurring findings to trigger a review of reference architectures
*  You independently review the quality of the architecture assessments on an ad-hoc basis
*  You use reference architecture updates to trigger reviews of relevant shared solutions, in a risk-based manner
Notes:
- 
Gaps:
- ACME currently does not have documented application reference architectures so they are currently not regularly updated based on architecture assessment findings.
Recommendations:
- Once secure application reference architectures have been documented, ACME should utilize various processes, including architecture assessments, threat modeling, security testing, etc. as a feedback loop to update said reference architectures. This will ensure that reference architectures are continuously hardened and when product teams utilize them, they will be utilizing ones that have been secured over time, reducing the likelihood of vulnerabilities. #phase2 #important #verification #process 

## Requirements Testing
### Control Verification
V-RT-A-1-1: Do you test applications for the correct functioning of standard security controls?
* Security testing at least verifies the implementation of authentication, access control, input validation, encoding and escaping data, and encryption controls
*  Security testing executes whenever the application changes its use of the controls
Notes:
- 
Gaps:
- It was stated that ACME currently only performs authorization testing to ensure that the correct provision of authorization security mechanisms in the Wealth TeamA application. However, this review is ad-hoc and not a thorough verification. Aside from this, there is no testing of the implementation of authentication, access control, input validation, encoding and escaping data, and encryption controls for applications.
Recommendations:
- GuidePoint suggests that ACME test applications for the correct functioning of standard security controls, including the implementation of authentication, access control, input validation, encoding and escaping data, and encryption controls. ACME should start with authentication and authorization and expand in subsequent phases. #phase2 #process #important #verification #DAST #technology 
- ACME should expand its testing of the correct functioning of standard security controls to now include input validation, encoding and escaping data, and encryption controls. #phase3 #process #verification #important #DAST #technology 
- ACME should ensure that security testing executes whenever the application changes its use of the controls. #phase3  #process #important #verification 

V-RT-A-2-1: Do you consistently write and execute test scripts to verify the functionality of security requirements?
* You tailor tests to each application and assert expected security functionality
*  You capture test results as a pass or fail condition
*  Tests use a standardized framework or DSL
Notes:
- 
Gaps:
- No evidence of test scripts was found that is used to verify the functionality of application security requirements.
Recommendations:
- ACME should write and execute test scripts to verify the functionality of application security requirements.  #phase3 #process #verification #important 
- In order to support the creation and execution of test scripts to verify the functionality of security requirements, Security QA tester training should be provided to select QA engineers, as outline din the Education and Guidance section. #phase3 #people #important #verification #training 

V-RT-A-3-1: Do you automatically test applications for security regressions?
* You consistently write tests for all identified bugs (possibly exceeding a pre-defined severity threshold)
*  You collect security tests in a test suite that is part of the existing unit testing framework
Notes:
- 
Gaps:
- 
Recommendations:
- Once maturity is reached regarding the use of test scripts to verify the functionality of application security requirements as defined in phase3, ACME should begin to automatically test applications for security regressions. #phase4 #verification #important #process 

### Misuse/Abuse Testing
V-RT-B-1-1: Do you test applications using randomization or fuzzing techniques?
* Testing covers most or all of the application's main input parameters
*  You record and inspect all application crashes for security impact on a best-effort basis
Notes:
- 
Gaps:
- Aside from frequency based penetration testing efforts, ACME does not test applications during runtime that covers most or all of the application's main input parameters.
Recommendations:
- ACME should evaluate a DAST solution that can be used to test applications during runtime. #phase1 #verification #technology #important #DAST 
- ACME should purchase and implement the DAST solution that was determined in phase1. DAST will be used to test applications using randomization or fuzzing techniques that covers most or all of the application's main input parameters. #phase2 #verification #technology #important #DAST 

V-RT-B-2-1: Do you create abuse cases from functional requirements and use them to drive security tests?
* Important business functionality has corresponding abuse cases
*  You build abuse stories around relevant personas with well-defined motivations and characteristics
*  You capture identified weaknesses as security requirements
Notes:
- 
Gaps:
- ACME does not create abuse cases from functional requirements and use them to drive security tests. Abuse stories should be built around relevant personas with well-defined motivations and characteristics.
Recommendations:
- ACME should create abuse cases from functional requirements and use them to drive security tests. Abuse stories should be built around relevant personas with well-defined motivations and characteristics. Weaknesses that are identified serve as a feedback loop to security requirements and cause an update to application reference architectures. #phase3 #verification #important #process 

V-RT-B-3-1: Do you perform denial of service and security stress testing?
* Stress tests target specific application resources (e.g. memory exhaustion by saving large amounts of data to a user session)
*  You design tests around relevant personas with well-defined capabilities (knowledge, resources)
*  You feed the results back to the Design practices
Notes:
- 
Gaps:
- ACME currently does not perform any denial of service and security stress testing.
Recommendations:
- 

## Security Testing
### Scalable Baseline
V-ST-A-1-1: Do you scan applications with automated security testing tools?
* You dynamically generate inputs for security tests using automated tools
*  You choose the security testing tools to fit the organization's architecture and technology stack, and balance depth and accuracy of inspection with usability of findings to the organization
Notes:
- 
Gaps:
- The only security testing tool that is in place from an application security testing perspective is SAST. DAST is not in use so ACME does not dynamically generate inputs for security tests using automated tools.
Recommendations:
- GuidePoint recommends that ACME expand its use of application security testing tools beyond SAST. ACME should also look at SCA to scan third-party components for vulnerabilities, and DAST to scan applications and APIs during runtime. This blend of application security testing tools provides a layered approach to analyzing applications from both a source code and runtime perspective, during different stages of the S-SDLC. #phase1 #verification #important #technology #DAST #SAST #SCA #API 
- As ACME grows its Application Security team over time, ACME can also utilize tools such as BurpSuite to aide in the verification of vulnerabilities identified by DAST as well as perform application penetration testing internally.

V-ST-A-2-1: Do you customize the automated security tools to your applications and technology stacks?
* You tune and select tool features which match your application or technology stack
*  You minimize false positives by silencing or automatically filter irrelevant warnings or low probability findings
*  You minimize false negatives by leverage tool extensions or DSLs to customize tools for your application or organizational standards
Notes:
- 
Gaps:
- 
Recommendations:
- From the moment of its implementation and throughout its lifecycle, ACME should ensure that all application security testing tools, including DAST, SAST, SCA, and others are consistently tuned by appropriate and experienced personnel. This continual tuning is vital to adapt to evolving threats and application changes, and to minimize false positives effectively. Regular reviews and adjustments should be scheduled to maintain the effectiveness of these tools in the organization's dynamic environment. #phase2 #important #SAST #SCA #DAST #verification #important #process #people

V-ST-A-3-1: Do you integrate automated security testing into the build and deploy process?
* Management and business stakeholders track and review test results throughout the development cycle
*  You merge test results into a central dashboard and feed them into defect management
Notes:
- 
Gaps:
- ACME has currently integrated their SAST tool into their build process. However, SAST scans are occurring only for an awareness perspective and breaking of builds and enforcement of severity thresholds is currently not being performed.
- Defects identified currently only get logged into a ticket management system and a vulnerability management platform is not used.
Recommendations:
- ACME recommends that all application security testing tools be integrated into build and release processes.
- ACME should ensure that the change management process is aware of any vulnerabilities that have not been remediated before the change management approves the release of the application to production. It is imperative that the risk acceptance process is followed in the case where a vulnerability will not be remediated before being released to production. #phase1 #process #CAB #important #verification 

### Deep Understanding
V-ST-B-1-1: Do you manually review the security quality of selected high-risk components?
* Criteria exist to help the reviewer focus on high-risk components
*  Qualified personnel conduct reviews following documented guidelines
*  You address findings in accordance with the organization's defect management policy
Notes:
- 
Gaps:
- ACME currently conducts code reviews although it was stated that the quality of the code reviews is likely lacking. These code reviews are not from the security context, as such, secure code reviews are not performed.
Recommendations:
- ACME currently conducts code reviews although it was stated that the quality of the code reviews is likely lacking. ACME should ensure that employees conducting code reviews are provided the appropriate capacity to do so. #phase2 #important #verification #people 
- Once trained, ACME should utilize Security Champions to conduct secure code reviews of high risk code during the existing code review/pull request process. #phase2 #process #securitychampions #important #verification 

V-ST-B-2-1: Do you perform penetration testing for your applications at regular intervals?
* Penetration testing uses application-specific security test cases to evaluate security
*  Penetration testing looks for both technical and logical issues in the application
*  Stakeholders review the test results and handle them in accordance with the organization's risk management
*  Qualified personnel performs penetration testing
Notes:
- 
Gaps:
- ACME is mature in this regard. They conduct penetration testing activities according to a regular frequency. Penetration tests encompass network, web application, AWS, and mobile applications.
- ACME stated that they have very basic requirements when choosing third party penetration testing vendors.
Recommendations:
- ACME has excellent maturity in regards to penetration testing. They conduct penetration testing activities by a third party according to industry standard frequency. Penetration tests encompass network, web application, AWS, and mobile applications.
- GuidePoint suggests that ACME expand its robust penetration testing program by conducting application penetration testing activities on high risk applications prior to release. #phase2 #pentesting #process #important #verification 
- GuidePoint suggests that ACME create a process to evaluate third party penetration testing vendors to ensure they follow standard testing methodologies, reporting guidelines, etc. #phase1 #important #pentesting #verification  #process 

V-ST-B-3-1: Do you use the results of security testing to improve the development lifecycle?
* You use results from other security activities to improve integrated security testing during development
*  You review test results and incorporate them into security awareness training and security testing playbooks
*  Stakeholders review the test results and handle them in accordance with the organization's risk management
Notes:
- 
Gaps:
- 
Recommendations:
- ACME should ensure that defects identified by all application security testing activities are used as a feedback loop to improve integrated security testing during development, training activities, reference architectures, the S-SDLC itself, etc.
- ACME should ensure that all defects identified by all security testing activities are aggregated in a vulnerability management platform.
- ACME should ensure that all defects/vulnerabilities are handled in accordance with the organization's risk management policy. #phase1 #important #process #verification 

# Operations
## Incident Management
### Incident Detection
O-IM-A-1-1: Do you analyze log data for security incidents periodically?
* You have a contact point for the creation of security incidents
*  You analyze data in accordance with the log data retention periods
*  The frequency of this analysis is aligned with the criticality of your applications
Notes:
- ACME utilizes a MDR vendor (Deepwatch) for level 1, then MDR escalates triaged incidents to the team. Good process from level 1 to internal team.
* MDR has a contact point for the creation of security incidents
- Log retention is 365 days and alerts are triggered when logs stop being sent to the SIEM.
Gaps:
- ACME utilizes Splunk for a SIEM. However, they are currently only ingesting system, network, AWS, Salesforce logs. Not ingesting application logs due to space issues. Currently ingesting 1TB per day but they are looking at Cribl for condensing the logs. 
Recommendations:
- ACME should prioritize any initiatives to provide more space for the SIEM as logs from critical applications are currently not being sent to the SIEM. #phase1 #important #operations #technology 

O-IM-A-2-1: Do you follow a documented process for incident detection?
* The process has a dedicated owner
*  You store process documentation in an accessible location
*  The process considers an escalation path for further analysis
*  You train employees responsible for incident detection in this process
*  You have a checklist of potential attacks to simplify incident detection
Notes:
-  yes - MDR -> internal. MDR triages, then sends msg to Slack channel or contacts on call. Criticals = on-call, Mediums or Highs = Slack
*  You store process documentation in an accessible location - yes - team uses product notebook
*  The process considers an escalation path for further analysis - yes - in the product notebook as well
*  You train employees responsible for incident detection in this process - yes - trained on the process and employees use the product notebook
*  You have a checklist of potential attacks to simplify incident detection - yes - they get baked into alerting rules which are continuously refined
Gaps:
- 
Recommendations:
- ACME's processes related to incident detection is solid. No recommendations for this security practice. See notes above.

O-IM-A-3-1: Do you review and update the incident detection process regularly?
* You perform reviews at least annually
*  You update the checklist of potential attacks with external and internal data
Notes:
- Continuous review w/ the Security Architect (Don)
* You update the checklist of potential attacks with external and internal data - yes - all docs are continuously updated
- Threat Hunting:
	- MDR does threat hunting as well
	- MDR is helping stand up a better threat hunting program
		- MITRE attack framework
		- Hypothesis based hunting
Gaps:
- 
Recommendations:
- ACME's review and update of the incident detection process is solid. No recommendations for this security practice. See notes above. #mature #operations #important #process

### Incident Response
O-IM-B-1-1: Do you respond to detected incidents?
* You have a defined person or role for incident handling
*  You document security incidents
Notes:
- 
Gaps:
- ACME stated that incidents are documented in ServiceNow, which is hosted by the MDR.
Recommendations:
- ACME should ensure that incidents are documented in their system of record and not in the MDR's system (ServiceNow). #phase1 #operations #process #important 

O-IM-B-2-1: Do you use a repeatable process for incident handling?
* You have an agreed upon incident classification
*  The process considers Root Case Analysis for high severity incidents
*  Employees responsible for incident response are trained in this process
*  Forensic analysis tooling is available
Notes:
- ACME has an Incident Response Plan and have run books in the team's product notebook. Incidents are documented in ServiceNow.
* ACME classifies incidents based on severity and users impacted.
* ACME performs Root Case Analysis for high severity incidents
* ACME's employees responsible for incident response are trained in this process
Gaps:
- 
Recommendations:
- GuidePoint has no recommendations as ACME has a robust, repeatable process for incident handling. #mature #operations #important #process 

O-IM-B-3-1: Do you have a dedicated incident response team available?
* The team performs Root Cause Analysis for all security incidents unless there is a specific reason not to do so
*  You review and update the response process at least annually
Notes:
- ACME has an Incident Management team
* The team performs Root Cause Analysis for all security incidents unless there is a specific reason not to do so
* ACME reviews and update the response process at least annually.
- ACME conducts tabletop incident response sessions (red teams/purple teams) 3 times per year, exceeding industry standards. 
Gaps:
- 
Recommendations:
- GuidePoint has no recommendations as ACME has a robust, repeatable process for incident handling. #mature #operations #important #process 

## Environment Management
### Configuration Hardening
O-EM-A-1-1: Do you harden configurations for key components of your technology stacks?
* You have identified the key components in each technology stack used
*  You have an established configuration standard for each key component
Notes:
- 
Gaps:
- ACME has some maturity in hardening infrastructure and cloud environments, including virtual machines, network equipment, AWS is hardened. There is a golden image process in place as well. and the hardening of Linux virtual machines is actively bring rolled out. However, despite these positive efforts to harden resources, there was no evidence of any hardening of application components and no inventory of them as well.
Recommendations:
- ACME should ensure that the current initiative to harden Linux systems is prioritized. #phase1 #operations #process 
- ACME should extend its hardening efforts beyond operating systems, network equipment, and AWS to also include key components in each technology stack. Hardening standards for each key component should be documented in an accessible location. #phase2 #operations #process #important 

O-EM-A-2-1: Do you have hardening baselines for your components?
* You have assigned an owner for each baseline
*  The owner keeps their assigned baselines up to date
*  You store baselines in an accessible location
*  You train employees responsible for configurations in these baselines
Notes:
- 
Gaps:
- ACME's TVM team utilizes CIS benchmarks for hardening baselines. the TVM team provides the operations teams with the baselines for them to implement. While ACME does perform some hardening and an owner (TVM) of the baselines has been established, ACME lacks any hardening of application components.
Recommendations:
- ACME should extend its hardening efforts beyond operating systems, network equipment, and AWS to also include key components in each technology stack. #phase2 #operations #process #important 

O-EM-A-3-1: Do you monitor and enforce conformity with hardening baselines?
* You perform conformity checks regularly, preferably using automation
*  You store conformity check results in an accessible location
*  You follow an established process to address reported non-conformities
*  You review each baseline at least annually, and update it when required
Notes:
- 
Gaps:
- 
Recommendations:
- ACME currently monitors for conformity with hardening baselines using Tenable. The TVM team performs scans and interfaces with operations teams if baselines are not met. #mature #operations #important #process 

### Patching and Updating
O-EM-B-1-1: Do you identify and patch vulnerable components?
* You have an up-to-date list of components, including version information
*  You regularly review public sources for vulnerabilities related to your components
Notes:
- 
Gaps:
- ACME has robust patch management processes for operating systems and infrastructure, with the exception of Linux. Linux patch management is not as robust but it is currently being ramped up. Developers rely on SAST (Checkmarx) to determine when a third-party component is vulnerable since an inventory of third-party components does not exist. 
Recommendations:
- ACME has robust patch management processes for operating systems and infrastructure, with the exception of Linux. Linux patch management is not as robust but it is currently being ramped up. GuidePoint recommends that ACME continue to prioritize this project. #phase1 #operations #important #process 
- Although developers generally stay abreast of frameworks and third party components via regular review of public sources for vulnerabilities, ACME should seek to inventory third-party components and use SCA to ensure additional assurance is in place to ensure that ACME  identify and patch vulnerable components used in applications. An inventory of components will allow ACME to understand what vulnerable components exist for applications that are currently no longer in development, and as such wouldn't be scanned by SAST or SCA. #phase1 #operations #important #SCA #technology 
- It was stated by ACME that if a patch is not able to be applied, there is no formal risk acceptance process that is followed. ACME should address this. #phase1 #operations #important #process 

O-EM-B-2-1: Do you follow an established process for updating components of your technology stacks?
* The process includes vendor information for third-party patches
*  The process considers external sources to gather information about zero day attacks, and includes appropriate risk mitigation steps
*  The process includes guidance for prioritizing component updates
Notes:
- 
Gaps:
- The ACME process to update application components is less structured and formal than that of the infrastructure and operating system process.
Recommendations:
- ACME has a robust process in place to update operating systems and infrastructure that includes testing the patch in a Dev and QA environment and promotion to production during maintenance windows. However, the application development process for updating technology stacks is less formal and structured.

O-EM-B-3-1: Do you regularly evaluate components and review patch level status?
* You update the list with components and versions
*  You identify and update missing updates according to existing SLA
*  You review and update the process based on feedback from the people who perform patching
Notes:
- 
Gaps:
- ACME currently does not have a defined SLA to address vulnerabilities.
Recommendations:
- ACME should define SLAs to address vulnerabilities according to their severity. These SLAs should be part of the risk management process. #phase1 #important #process #operations 

## Operational Management
### Data Protection
O-OM-A-1-1: Do you protect and handle information according to protection requirements for data stored and processed on each application?
* You know the data elements processed and stored by each application
* You know the type and sensitivity level of each identified data element
* You have controls to prevent propagation of unsanitized sensitive data from production to lower environments
Notes:
- 
Gaps:
- ACME uses some sensitive production data in non-production environments which is not advised.
- ACME currently does not know the data elements processed and stored by each application.
- ACME currently does not know the type and sensitivity level of each identified data element.
Recommendations:
- ACME should devise a plan to sanitize sensitive data elements when utilizing production data in non-production environments. The plan should also include the specification of controls to prevent the use of production data in non-production environments. #phase1 #operations #process #important 
- ACME should execute their plan to begin sanitizing production data to be used in non-production environments. #phase2 #operations #process #important  
- ACME currently does not know the data elements processed and stored by each application. However, a Global Data Initiative is currently underway to address this gap. GuidePoint recommends the continued prioritization of this initiative and also recommends that when the data classification of an application is determined, the application inventory is updated accordingly. #phase1 #operations #important #process 

O-OM-A-2-1: Do you maintain a data catalog, including types, sensitivity levels, and processing and storage locations?
* The data catalog is stored in an accessible location
*  You know which data elements are subject to specific regulation
*  You have controls for protecting and preserving data throughout its lifetime
*  You have retention requirements for data, and you destroy backups in a timely manner after the relevant retention period ends
Notes:
- ACME's compliance department maintains retention requirements and performs deletions.
Gaps:
- 
Recommendations:
- 

O-OM-A-3-1: Do you regularly review and update the data catalog and your data protection policies and procedures?
* You have automated monitoring to detect attempted or actual violations of the Data Protection Policy
*  You have tools for data loss prevention, access control and tracking, or anomalous behavior detection
*  You periodically audit the operation of automated mechanisms, including backups and record deletions
Notes:
- 
Gaps:
- 
Recommendations:
- GuidePoint recommends that ACME create a process and associated gate to update the data catalog early in the S-SDLC and perform verification prior to release to production. #phase2 #important #operations #process 
- ACME should ensure that as the data catalog is updated, data protection policies and procedures are updated as well. This includes DLP tools. #phase3 #important #process #operations 

### System Decommissioning / Legacy Management
O-OM-B-1-1: Do you identify and remove systems, applications, application dependencies, or services that are no longer used, have reached end of life, or are no longer actively developed or supported?
* You do not use unsupported applications or dependencies
*  You manage customer/user migration from older versions for each product and customer/user group
Notes:
- 
Gaps:
- ACME has a solid process in place for decommissioning but it only encompasses systems and infrastructure and not applications, application dependencies.
- The process in Cherwell uses a template and subtasks to ensure that supporting tickets are created for all employees with roles to play in the decommissioning of that resource. However, it was determined that service accounts were not in scope for the current decommissioning process, potentially creating some risk.
Recommendations:
- ACME should modify it's existing decommissioning process to include the decommissioning of applications, application dependencies, and service accounts as this is currently a gap. This process should ensure that application components are also removed from the artifact repository. #phase1 #operations #process #important 

O-OM-B-2-1: Do you follow an established process for removing all associated resources, as part of decommissioning of unused systems, applications, application dependencies, or services?
* You document the status of support for all released versions of your products, in an accessible location
*  The process includes replacement or upgrade of third-party applications, or application dependencies, that have reached end of life
*  Operating environments do not contain orphaned accounts, firewall rules, or other configuration artifacts
Notes:
- See above
Gaps:
- 
Recommendations:
- 

O-OM-B-3-1: Do you regularly evaluate the lifecycle state and support status of every software asset and underlying infrastructure component, and estimate their end of life?
* Your end of life management process is agreed upon
*  You inform customers and user groups of product timelines to prevent disruption of service or support
*  You review the process at least annually
Notes:
- 
Gaps:
- 
Recommendations:
- ACME should formalize the process to regularly evaluate the lifecycle state and support status of every software asset and underlying infrastructure component, and estimate their end of life as the current processes are ad-hoc. #phase2 #operations #important #process 
