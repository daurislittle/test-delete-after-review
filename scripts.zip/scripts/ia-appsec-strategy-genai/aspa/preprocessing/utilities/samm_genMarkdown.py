import csv
def add_bullet_points(multiline_string):
    lines = multiline_string.split('\n')
    bullet_point_lines = [f"* {line}" for line in lines]
    return '\n'.join(bullet_point_lines)
# domain, security practice, stream, question, attributes
def find_main_headers(filename):
    with open(filename, 'r') as file:
        reader = csv.reader(file)
        main_headers = []

        # Skip rows until the Governance header
        currentHeader = ""
        currentSecurityPracticeHeader = ""
        currentSecurityStream = ""
        currentQuestion = ""
        currentAttributes = ""
        for row in reader:
            if len(set(row)) == 2 and '' in set(row):
                main_header = [item for item in row if item]
                if main_header and main_header[0] == 'Governance':
                    main_headers.append(main_header[0])
                    currentHeader = main_header[0]
                    break
        
        # Process the rest of the rows
        for row in reader:
            if len(set(row)) == 2 and '' in set(row):  # check if the row consists of only two distinct elements: a string and an empty string
                main_header = [item for item in row if item]  # get the non-empty item
                if main_header and '\n' not in main_header[0]:  # if there is a non-empty item
                    main_headers.append(main_header[0])
                    currentHeader = main_header[0]
                    print(f"# {currentHeader}")
                else:
                    # this is a series of attributes
                    currentAttributes = add_bullet_points(main_header[0])
                    print(f"{currentAttributes}\r\nNotes:\r\n- \r\nGaps:\r\n- \r\nRecommendations:\r\n- \r\n")
            elif len(row) >= 4 and row[1] == 'Stream' and row[2] == 'Level':  # Check if the row starts with ', Stream, Level,'
                currentSecurityPracticeHeader = row[3]  # Store the third string
                print(f"## {currentSecurityPracticeHeader}")
                #break  # We found the security practice header, no need to check the rest of the rows
            elif len(row) >= 2 and 'Answer' in set(row) and 'Rating' in set(row):  # Check if the row matches the new pattern
                currentSecurityPracticeHeader = row[1]  # Store the first string
                print(f"## {currentSecurityPracticeHeader}")
                #break  # We found the security practice header, no need to check the rest of the rows
            elif len(row) >= 2 and row[0].count('-') > 2:
                if row[1]:
                    currentSecurityStream = row[1]
                    print(f"### {currentSecurityStream}")
                if row[3]:
                    currentQuestion = row[3]
                    print(f"{row[0]}: {currentQuestion}")
            #print(f"{currentHeader} - {currentSecurityPracticeHeader} - {currentSecurityStream} - {currentQuestion} - {currentAttributes}")
                    
    return main_headers

filename = "../samm/SAMM_spreadsheet_v2_0_8.csv"
main_headers = find_main_headers(filename)
#print(main_headers)