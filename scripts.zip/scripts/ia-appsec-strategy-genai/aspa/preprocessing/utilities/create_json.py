import csv
import json

def add_bullet_points(multiline_string):
    return [line.strip() for line in multiline_string.split('\n') if line.strip()]

def find_main_headers(filename):
    output = {}
    current_domain = ""
    current_practice = ""
    current_stream = ""
    current_question_id = ""
    current_question = ""

    with open(filename, 'r') as file:
        reader = csv.reader(file)
        
        # Skip rows until the Governance header
        for row in reader:
            if len(set(row)) == 2 and '' in set(row):
                main_header = [item for item in row if item]
                if main_header and main_header[0] == 'Governance':
                    current_domain = main_header[0]
                    output[current_domain] = {}
                    break
        
        # Process the rest of the rows
        for row in reader:
            if len(set(row)) == 2 and '' in set(row):
                main_header = [item for item in row if item]
                if main_header and '\n' not in main_header[0]:
                    current_domain = main_header[0]
                    output[current_domain] = {}
                else:
                    attributes = add_bullet_points(main_header[0])
                    if current_question_id:
                        output[current_domain][current_practice][current_stream][current_question_id]["attributes"] = attributes
            elif len(row) >= 4 and row[1] == 'Stream' and row[2] == 'Level':
                current_practice = row[3]
                output[current_domain][current_practice] = {}
            elif len(row) >= 2 and 'Answer' in set(row) and 'Rating' in set(row):
                current_practice = row[1]
                output[current_domain][current_practice] = {}
            elif len(row) >= 2 and row[0].count('-') > 2:
                if row[1]:
                    current_stream = row[1]
                    output[current_domain][current_practice][current_stream] = {}
                if row[3]:
                    current_question_id = row[0]
                    current_question = row[3]
                    output[current_domain][current_practice][current_stream][current_question_id] = {
                        "question": current_question,
                        "attributes": [],
                        "notes": [],
                        "gaps": [],
                        "recommendations": []
                    }

    return output

filename = "../samm/SAMM_spreadsheet_v2.10.csv"
result = find_main_headers(filename)

# Convert the result to JSON
json_output = json.dumps(result, indent=2)

# Print or save the JSON output
print(json_output)

# Optionally, save to a file
with open('../samm/output.json', 'w') as f:
    f.write(json_output)
