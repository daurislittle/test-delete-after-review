#!/usr/bin/env python3

"""
OWASP SAMM JSON Domain Duplicator

This script duplicates specified domains in an OWASP SAMM JSON file to support processing of multiple teams.
It performs the following operations:

1. Loads a JSON file containing OWASP SAMM data.
2. Duplicates specified domains (e.g., "Implementation") for each team defined.
3. Adds the team name to all keys within the duplicated domains.
4. Removes the original domains after duplication.
5. Maintains the original order of JSON keys throughout the process.
6. Saves the modified JSON to a new file.

Usage:
    Modify the TEAMS and DOMAINS_TO_DUPLICATE lists in the script, then run:
    python script_name.py --input-json input_file.json --output-json output_file.json

Note: Ensure that TEAMS and DOMAINS_TO_DUPLICATE are populated before running the script.
"""

import json
import argparse
import logging
import sys
from copy import deepcopy
from collections import OrderedDict

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

# Define product teams/subsidiaries (empty by default)
# Example: TEAMS = ["ConsultCorp", "MerpCorp"]
TEAMS = [""]

# Define domains to duplicate (empty by default)
# Example: DOMAINS_TO_DUPLICATE = ["Implementation"]
DOMAINS_TO_DUPLICATE = [""]

def parse_arguments():
    parser = argparse.ArgumentParser(description="Duplicate domains in OWASP SAMM JSON")
    parser.add_argument("--input-json", required=True, help="Input JSON file path")
    parser.add_argument("--output-json", required=True, help="Output JSON file path")
    return parser.parse_args()

def load_json(file_path):
    try:
        with open(file_path, 'r') as f:
            return json.loads(f.read(), object_pairs_hook=OrderedDict)
    except FileNotFoundError:
        logging.error(f"Input file not found: {file_path}")
        sys.exit(1)
    except json.JSONDecodeError:
        logging.error(f"Invalid JSON in input file: {file_path}")
        sys.exit(1)

def save_json(data, file_path):
    try:
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
        logging.info(f"Output saved to: {file_path}")
    except IOError:
        logging.error(f"Error writing to output file: {file_path}")
        sys.exit(1)

def add_team_to_keys(data, team):
    if isinstance(data, dict):
        return OrderedDict((f"{k} - {team}", add_team_to_keys(v, team)) for k, v in data.items())
    elif isinstance(data, list):
        return [add_team_to_keys(item, team) for item in data]
    else:
        return data

def duplicate_domains(data):
    new_data = OrderedDict()
    for key, value in data.items():
        if key in DOMAINS_TO_DUPLICATE:
            for team in TEAMS:
                new_key = f"{key} - {team}"
                new_data[new_key] = add_team_to_keys(deepcopy(value), team)
                logging.info(f"Created new domain: {new_key}")
            logging.info(f"Removed original domain: {key}")
        else:
            new_data[key] = value
    return new_data

def main():
    args = parse_arguments()

    if not TEAMS:
        logging.error("No teams specified. Please add teams to the TEAMS list in the script.")
        sys.exit(1)

    if not DOMAINS_TO_DUPLICATE:
        logging.error("No domains specified for duplication. Please add domains to the DOMAINS_TO_DUPLICATE list in the script.")
        sys.exit(1)

    logging.info(f"Loading input JSON from: {args.input_json}")
    data = load_json(args.input_json)
    
    logging.info("Duplicating specified domains...")
    modified_data = duplicate_domains(data)
    
    logging.info(f"Saving modified JSON to: {args.output_json}")
    save_json(modified_data, args.output_json)
    
    logging.info("Process completed successfully.")

if __name__ == "__main__":
    main()
