import re
import sys
import math
from openpyxl import load_workbook
from openpyxl.styles import Alignment, numbers

def process_markdown(file):
    with open(file, 'r') as f:
        data = f.read()
        
    pattern_identifier = re.compile(r'(\w+-\w+-\w+-\w+-\w+):(.*?(Notes:.*?)(?=(\w+-\w+-\w+-\w+-\w+:)|(#+ )|(\Z)))', re.DOTALL)

    responses = {}

    matches = pattern_identifier.findall(data)

    for match in matches:
        identifier, _, notes, _, _, _ = match
        responses[identifier] = notes.strip()
            
    return responses


# Use the first command-line argument as the excel file name
excel_file = sys.argv[2]

# Load the excel workbook and sheet
wb = load_workbook(excel_file)
markdown_file = sys.argv[1]
ws = wb['Interview']
def count_excess(s: str, threshold: int) -> int:
    lines = s.split('\n')
    return sum(math.floor(len(line) / threshold) for line in lines if len(line) > threshold)
def count_adjusted_sequences(s: str, threshold: int) -> int:
    lines = s.split('\n')
    
    count = len(lines) - 1
    for line in lines:
        remaining_chars = len(line)
        idx = 0
        
        while remaining_chars > 0:
            if idx + threshold < len(line) and line[idx + threshold] not in [' ', '\n']:
                end_idx = line.rfind(' ', idx, idx + threshold)
                if end_idx == -1:  # No space found within the threshold, so we take the full threshold
                    end_idx = idx + threshold
            else:
                end_idx = idx + threshold
            sequence_length = end_idx - idx
            remaining_chars -= sequence_length
            idx += sequence_length
            count += 1

            # If we didn't use up the entire threshold, but there are remaining characters, increment count for the ceiling effect.
            #if sequence_length < threshold and remaining_chars == 0:
            #    count += 1

    return count
# Get responses from markdown file
responses = process_markdown(markdown_file)
# Assume that column 'A' is the identifier and column 'I' is where the response should go
for row in ws.iter_rows(min_row=2):  # Start from 2 if you have a header row
    identifier = row[0].value
    if identifier in responses:
        #row[8].data_type = 's'
        response = responses[identifier]
        ws.row_dimensions[(row[0].row + 1)].height = (count_adjusted_sequences(response, 52)) * 13
        row[8].number_format = numbers.FORMAT_TEXT
        row[8].alignment = Alignment(wrapText=True)
        row[8].value = responses[identifier].replace('\n','\r\n')  # Column 'I' is index 8 because openpyxl is 0-indexed
    else:
        print(f"No response found for identifier {identifier}")

# Save the workbook back to the excel file
wb.save(excel_file)

