#
#  Script to fix post-processed markdown files that ended up having their format malformed
#

import re
import argparse

def convert_to_markdown(text):
    lines = text.split('\n')
    markdown_lines = []
    previous_was_section = False

    for line in lines:
        # Skip empty lines and lines with "---" or "+++"
        if not line.strip() or "---" in line or "+++" in line:
            continue

        is_section = re.match(r'[A-Z]-[A-Z]{2}-[A-Z]-\d-\d', line) or line in ["Notes:", "Gaps:", "Recommendations:"]

        # Add an empty line before sections/subsections, but not at the start
        if is_section and markdown_lines:
            markdown_lines.append('')

        if is_section:
            markdown_lines.append(f'## {line}')
        else:
            markdown_lines.append(f'- {line}')

        previous_was_section = is_section

    return '\n'.join(markdown_lines)

def read_file(file_path):
    with open(file_path, 'r') as file:
        return file.read()

def main():
    parser = argparse.ArgumentParser(description='Convert text file to Markdown format.')
    parser.add_argument('file', help='Path to the text file')
    args = parser.parse_args()

    text = read_file(args.file)
    markdown_text = convert_to_markdown(text)
    print(markdown_text)

if __name__ == '__main__':
    main()

