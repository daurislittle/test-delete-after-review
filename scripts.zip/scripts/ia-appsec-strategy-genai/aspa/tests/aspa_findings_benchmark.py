import argparse
import json
import logging
import os
import requests

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

def setup_logging(debug):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

def load_text_file(file_path):
    with open(file_path, 'r') as file:
        return file.read()

def load_json_file(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def get_workspace_slug(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        for workspace in workspaces:
            if workspace['name'] == workspace_name:
                return workspace['slug']
    logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
    return None

def perform_qa(benchmark_text, findings_json, workspace_slug):
    prompt = f"""
Analyze the following benchmark text and JSON findings carefully:

Benchmark (text format):
{benchmark_text}

Findings (JSON format):
{json.dumps(findings_json, indent=2)}

Your task is to provide a detailed, accurate, and comprehensive analysis of the findings against the benchmark for each domain and its subdomains found in the findings JSON.

Format your response as a JSON object with the following structure:

{{
  "{{DOMAIN_NAME}}": {{
    "{{SUBDOMAIN_NAME}}": {{
      "content_quality": "Detailed and evidence-based assessment of the content quality for this section",
      "alignment": "Specific assessment of how well the findings align with the benchmark requirements, citing examples",
      "missing_elements": [
        "Precise list of elements mentioned in the benchmark but missing from the findings"
      ],
      "extra_elements": [
        "Specific list of elements in the findings not explicitly required by the benchmark"
      ]
    }},
    // Repeat for each subdomain
  }},
  // Repeat for each domain
}}

Replace {{DOMAIN_NAME}} and {{SUBDOMAIN_NAME}} with the actual names from the findings JSON. Include all relevant domains and subdomains.

For each subdomain, provide:
1. A detailed assessment of content quality in the "content_quality" field.
2. A specific assessment of alignment with benchmark requirements in the "alignment" field.
3. A list of missing elements in the "missing_elements" array. If there are no missing elements, include ["No significant missing elements identified."].
4. A list of extra elements in the "extra_elements" array. If there are no extra elements, include ["No extra elements identified."].

Ensure your response is a valid JSON object. Do not include any text outside of the JSON structure. Strive for accuracy, completeness, and objectivity in your analysis, maintaining the level of detail and insights from the current findings.
"""
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/chat"
    payload = {
        "message": prompt,
        "mode": "chat"
    }

    try:
        response = requests.post(api_url, json=payload, headers=headers)
        response.raise_for_status()
        return json.loads(response.json()['textResponse'])
    except requests.exceptions.RequestException as e:
        logging.error(f"Error performing QA: {str(e)}")
        return {"error": str(e)}
    except json.JSONDecodeError:
        logging.error("Error decoding JSON response")
        return {"error": "Invalid JSON response"}

def main():
    parser = argparse.ArgumentParser(description="Perform AI-assisted QA on findings against a benchmark")
    parser.add_argument("--benchmark-file", required=True, help="Path to the benchmark text file")
    parser.add_argument("--findings-file", required=True, help="Path to the findings JSON file")
    parser.add_argument("--workspace-name", required=True, help="Name of the existing workspace to use")
    parser.add_argument("--output-file", required=True, help="Path to the output JSON file for QA results")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    setup_logging(args.debug)

    benchmark = load_text_file(args.benchmark_file)
    findings = load_json_file(args.findings_file)

    workspace_slug = get_workspace_slug(args.workspace_name)
    if not workspace_slug:
        logging.error(f"Workspace '{args.workspace_name}' not found. Exiting.")
        return

    qa_results = perform_qa(benchmark, findings, workspace_slug)

    with open(args.output_file, 'w') as f:
        json.dump(qa_results, f, indent=2)

    logging.info(f"AI-assisted QA analysis complete. Results saved to {args.output_file}")

if __name__ == "__main__":
    main()
