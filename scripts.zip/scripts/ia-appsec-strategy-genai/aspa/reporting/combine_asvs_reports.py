import os
import csv
import argparse
import logging
from docx import Document
from docx.enum.text import WD_BREAK
from docx.oxml.shared import OxmlElement, qn
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml
from docx.shared import Inches
import re

def setup_logging(debug=False):
    """Set up logging configuration."""
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

def load_asvs_controls(csv_file):
    """
    Load ASVS controls from CSV file.
    
    Args:
        csv_file: Path to the CSV file containing ASVS controls
        
    Returns:
        Dictionary mapping control IDs to chapter names
    """
    control_chapters = {}
    try:
        with open(csv_file, 'r', encoding='utf-8-sig') as f:  # Handle BOM if present
            reader = csv.DictReader(f)
            for row in reader:
                # Use req_id for control ID and chapter_name for chapter
                control_id = row.get('req_id')
                chapter_name = row.get('chapter_name')
                
                if control_id and chapter_name:
                    control_chapters[control_id] = chapter_name
        
        logging.info(f"Loaded {len(control_chapters)} controls from CSV file")
        
        # Log a sample of the loaded controls
        sample_controls = list(control_chapters.items())[:5]
        for control_id, chapter in sample_controls:
            logging.debug(f"Control {control_id} -> Chapter '{chapter}'")
            
        return control_chapters
    except Exception as e:
        logging.error(f"Error loading ASVS controls from CSV: {e}")
        import traceback
        logging.error(traceback.format_exc())
        return {}


def get_control_files(reports_dir):
    """
    Get all control report files from the directory.
    
    Args:
        reports_dir: Directory containing control report files
        
    Returns:
        List of (control_id, file_path) tuples sorted by control_id
    """
    control_files = []
    
    for file in os.listdir(reports_dir):
        # Skip temporary files created by Microsoft Word (start with ~$)
        if file.startswith('~$'):
            logging.debug(f"Skipping temporary file: {file}")
            continue
            
        if file.endswith("_Report.docx"):
            # Extract control ID from filename (e.g., "V1.1.1_Report.docx" -> "V1.1.1")
            control_id = file.replace("_Report.docx", "")
            file_path = os.path.join(reports_dir, file)
            control_files.append((control_id, file_path))
        elif file.endswith(".docx"):
            # For other docx files, try to extract control ID from the first part
            control_id = file.split("_")[0].split(".docx")[0]
            # Check if it looks like a control ID (starts with V followed by numbers and dots)
            if re.match(r'^V\d+(\.\d+)*$', control_id):
                file_path = os.path.join(reports_dir, file)
                control_files.append((control_id, file_path))
    
    # Sort by control ID
    control_files.sort(key=lambda x: natural_sort_key(x[0]))
    
    logging.info(f"Found {len(control_files)} control report files")
    for control_id, file_path in control_files:
        logging.debug(f"Control: {control_id} -> {os.path.basename(file_path)}")
    return control_files



def natural_sort_key(s):
    """
    Generate a sort key for natural sorting of control IDs.
    E.g., V1.1.1, V1.1.2, V1.10.1 instead of V1.1.1, V1.10.1, V1.1.2
    """
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', s)]

def group_controls_by_chapter(control_files, control_chapters):
    """
    Group control files by chapter.
    
    Args:
        control_files: List of (control_id, file_path) tuples
        control_chapters: Dictionary mapping control IDs to chapter names
        
    Returns:
        Dictionary mapping chapter names to lists of (control_id, file_path) tuples
    """
    chapter_groups = {}
    unknown_controls = []
    
    for control_id, file_path in control_files:
        chapter = control_chapters.get(control_id)
        
        if not chapter:
            unknown_controls.append(control_id)
            chapter = "Unknown Chapter"
            
        if chapter not in chapter_groups:
            chapter_groups[chapter] = []
            
        chapter_groups[chapter].append((control_id, file_path))
    
    # Log unknown controls
    if unknown_controls:
        logging.warning(f"Could not find chapter for {len(unknown_controls)} controls: {', '.join(unknown_controls)}")
    
    # Sort chapters by the first control ID in each chapter
    sorted_chapters = sorted(chapter_groups.keys(), 
                            key=lambda ch: natural_sort_key(chapter_groups[ch][0][0]) if chapter_groups[ch] else "")
    
    result = {ch: chapter_groups[ch] for ch in sorted_chapters}
    
    # Log chapter groupings
    for chapter, controls in result.items():
        control_ids = [c[0] for c in controls]
        logging.info(f"Chapter '{chapter}': {len(controls)} controls - {', '.join(control_ids[:5])}" + 
                    (f"... and {len(control_ids) - 5} more" if len(control_ids) > 5 else ""))
    
    return result


def insert_document(composite_doc, subdoc):
    """
    Insert the contents of one document into another.
    
    Args:
        composite_doc: The document to insert into
        subdoc: The document to insert
        
    Returns:
        The composite document with the subdoc inserted
    """
    # Skip the first paragraph if it's empty
    start_idx = 1 if subdoc.paragraphs and not subdoc.paragraphs[0].text.strip() else 0
    
    # Add paragraphs
    for p in subdoc.paragraphs[start_idx:]:
        new_p = composite_doc.add_paragraph()
        # Copy text and formatting
        for run in p.runs:
            new_run = new_p.add_run(run.text)
            new_run.bold = run.bold
            new_run.italic = run.italic
            new_run.underline = run.underline
            if run.font.color.rgb:
                new_run.font.color.rgb = run.font.color.rgb
            if run.font.name:
                new_run.font.name = run.font.name
            if run.font.size:
                new_run.font.size = run.font.size
        
        # Copy paragraph formatting
        if p.style:
            try:
                new_p.style = p.style
            except:
                logging.warning(f"Could not apply style {p.style.name}")
        
        # Copy paragraph alignment
        new_p.paragraph_format.alignment = p.paragraph_format.alignment
        
        # Copy indentation
        if p.paragraph_format.left_indent:
            new_p.paragraph_format.left_indent = p.paragraph_format.left_indent
        if p.paragraph_format.right_indent:
            new_p.paragraph_format.right_indent = p.paragraph_format.right_indent
        if p.paragraph_format.first_line_indent:
            new_p.paragraph_format.first_line_indent = p.paragraph_format.first_line_indent
    
    # Add tables
    for table in subdoc.tables:
        # Create a new table with the same dimensions
        new_table = composite_doc.add_table(rows=len(table.rows), cols=len(table.rows[0].cells))
        
        # Copy cell contents
        for i, row in enumerate(table.rows):
            for j, cell in enumerate(row.cells):
                new_table.rows[i].cells[j].text = cell.text
    
    return composite_doc
def combine_reports(template_file, output_file, chapter_groups):
    """
    Combine individual control reports into a single document by directly modifying the template.
    
    Args:
        template_file: Path to the template document
        output_file: Path to save the combined document
        chapter_groups: Dictionary mapping chapter names to lists of (control_id, file_path) tuples
    """
    try:
        # Import required modules
        import shutil
        
        # Create a copy of the template to work with
        shutil.copy2(template_file, output_file)
        
        # Load the document (which is now the copy of the template)
        doc = Document(output_file)
        logging.info(f"Using template document: {template_file}")
        
        # Create a map of style names to style objects in the target document
        style_map = {}
        for style in doc.styles:
            if style.name:
                style_map[style.name] = style
        
        logging.debug(f"Available styles in template: {list(style_map.keys())}")
        
        # Find the code example style
        code_style = None
        for style_name in ['Code Example', 'CodeExample', 'Code', 'SourceCode']:
            if style_name in style_map:
                code_style = style_map[style_name]
                logging.info(f"Found code style: {style_name}")
                break
        
        if not code_style:
            logging.warning("No code style found in template document")
        
        # Find the placeholder paragraph
        placeholder_para = None
        
        for para in doc.paragraphs:
            if "ASVS_REPORT_GOES_HERE" in para.text:
                placeholder_para = para
                break
        
        if not placeholder_para:
            logging.error("Placeholder text 'ASVS_REPORT_GOES_HERE' not found in template")
            return False
        
        # Clear the placeholder text
        placeholder_para.text = ""
        
        # Create a temporary document to build our content
        content_doc = Document()
        
        # Track paragraph styles, code blocks, and left indents
        para_styles = []
        code_blocks = []
        left_indents = []
        
        # Process each chapter
        is_first_chapter = True
        for chapter, controls in chapter_groups.items():
            if not is_first_chapter:
                # Add page break before chapter (except first)
                content_doc.add_page_break()
                # Track the page break paragraph
                para_styles.append(None)
                code_blocks.append(False)
                left_indents.append(None)
            else:
                is_first_chapter = False
                
            # Add chapter heading
            logging.info(f"Adding chapter: {chapter} with {len(controls)} controls")
            chapter_para = content_doc.add_paragraph(chapter)
            para_styles.append('Heading 2')
            code_blocks.append(False)
            left_indents.append(None)
            
            # Process each control
            for control_id, file_path in controls:
                try:
                    logging.debug(f"Adding control {control_id} from {file_path}")
                    control_doc = Document(file_path)
                    
                    # Add all paragraphs from the control document
                    for p in control_doc.paragraphs:
                        if not p.text.strip():  # Skip empty paragraphs
                            continue
                            
                        # Create a new paragraph
                        new_para = content_doc.add_paragraph()
                        
                        # Copy text and formatting
                        for run in p.runs:
                            new_run = new_para.add_run(run.text)
                            new_run.bold = run.bold
                            new_run.italic = run.italic
                            new_run.underline = run.underline
                            if run.font.color.rgb:
                                 new_run.font.color.rgb = run.font.color.rgb
                        
                        # Check if this is a code block
                        is_code_block = False
                        if p.style and p.style.name and ('code' in p.style.name.lower() or 'example' in p.style.name.lower()):
                            is_code_block = True
                            logging.debug(f"Found code block by style name: {p.text[:30]}")
                        elif p.runs and p.runs[0].font.name == 'Courier New':
                            is_code_block = True
                            logging.debug(f"Found code block by font: {p.text[:30]}")
                        
                        # Track if this is a code block
                        code_blocks.append(is_code_block)
                        
                        # Track the left indent
                        current_left_indent = p.paragraph_format.left_indent
                        left_indents.append(current_left_indent)
                        
                        # Track the style
                        if is_code_block:
                            # This is a code block
                            para_styles.append('Code Example')
                        elif p.style and p.style.name == 'Heading 3' and "ASVS Control ID:" not in p.text:
                            # Convert Heading 3 to Heading 4 except for ASVS Control ID
                            para_styles.append('Heading 4')
                        elif p.style:
                            # Use the original style
                            para_styles.append(p.style.name)
                        else:
                            # No style
                            para_styles.append(None)
                    
                    # Add a blank paragraph after each control for separation
                    blank_para = content_doc.add_paragraph()
                    para_styles.append(None)
                    code_blocks.append(False)
                    left_indents.append(None)
                    
                except Exception as e:
                    logging.error(f"Error processing control {control_id}: {e}")
                    import traceback
                    logging.error(traceback.format_exc())
        
        # Now insert all the content at the placeholder position
        # Get the XML element of the placeholder paragraph
        placeholder_element = placeholder_para._element
        
        # Get the parent of the placeholder element
        parent_element = placeholder_element.getparent()
        
        # Get the index of the placeholder in its parent
        placeholder_index = parent_element.index(placeholder_element)
        current_chapter = None
        inserted_elements = 0
        # Insert each paragraph from the content document before the placeholder
        for i, para in enumerate(content_doc.paragraphs):
            # Check if this is a chapter heading and not the first one
            if i < len(para_styles) and para_styles[i] == 'Heading 2':
                if current_chapter is not None:  # Not the first chapter
                    # Add a page break before this chapter
                    page_break_para = doc.add_paragraph()
                    page_break_run = page_break_para.add_run()
                    page_break_run.add_break(WD_BREAK.PAGE)
                    
                    # Get the XML element of the page break paragraph
                    page_break_element = page_break_para._element
                    
                    # Remove it from its current position
                    page_break_element.getparent().remove(page_break_element)
                    
                    # Insert it before the placeholder
                    parent_element.insert(placeholder_index + inserted_elements, page_break_element)
                    inserted_elements += 1
                
                current_chapter = para.text
            # Create a new paragraph in the destination document
            new_para = doc.add_paragraph()
            
            # Copy text and formatting
            for run in para.runs:
                new_run = new_para.add_run(run.text)
                new_run.bold = run.bold
                new_run.italic = run.italic
                new_run.underline = run.underline
                if run.font.color.rgb:
                    new_run.font.color.rgb = run.font.color.rgb
            
            # Get the style for this paragraph
            if i < len(para_styles):
                style_name = para_styles[i]
                is_code_block = code_blocks[i]
                left_indent = left_indents[i]
                
                # Apply left indent if available
                if left_indent:
                    new_para.paragraph_format.left_indent = left_indent
                    logging.debug(f"Applied left indent {left_indent} to paragraph {i}")
                
                # Special handling for code blocks
                if is_code_block and code_style:
                    try:
                        # Apply code style using the style ID
                        new_para._p.get_or_add_pPr().get_or_add_pStyle().val = code_style.style_id
                        logging.debug(f"Applied code style '{code_style.name}' to paragraph {i}")
                    except Exception as e:
                        logging.warning(f"Could not apply code style '{code_style.name}': {e}")
                
                # Apply regular style
                elif style_name and style_name in style_map:
                    try:
                        # Apply style using the style ID
                        new_para._p.get_or_add_pPr().get_or_add_pStyle().val = style_map[style_name].style_id
                        logging.debug(f"Applied style '{style_name}' to paragraph {i}")
                    except Exception as e:
                        logging.warning(f"Could not apply style '{style_name}': {e}")
                        try:
                            # Fallback to direct style assignment
                            new_para.style = style_name
                        except Exception as e:
                            logging.warning(f"Could not apply style '{style_name}' directly: {e}")
            
            # Copy paragraph formatting and indentation
            if para.paragraph_format.first_line_indent:
                new_para.paragraph_format.first_line_indent = para.paragraph_format.first_line_indent
            if para.paragraph_format.right_indent:
                new_para.paragraph_format.right_indent = para.paragraph_format.right_indent

            # Enhanced list and indentation handling
            if hasattr(para, '_p'):
                # First, try to identify if this is a list paragraph and what level it is
                list_level = 0
                is_list_para = False
                
                # Check if it has numbering properties
                if para._p.pPr is not None and hasattr(para._p.pPr, 'numPr') and para._p.pPr.numPr is not None:
                    logging.info("numbering properties")
                    is_list_para = True
                    # Try to extract the list level
                    if hasattr(para._p.pPr.numPr, 'ilvl') and para._p.pPr.numPr.ilvl is not None:
                        try:
                            list_level = int(para._p.pPr.numPr.ilvl.val)
                            logging.debug(f"Found list paragraph at level {list_level}")
                        except (ValueError, AttributeError):
                            pass
                
                # Also check style name for list indicators
                if para.style and para.style.name:
                    #logging.info("paragraph style exists")
                    if 'List' in para.style.name:
                        is_list_para = True
                        # Try to extract level from style name if it contains a number
                        level_match = re.search(r'List\s*(\d+)', para.style.name)
                        if level_match:
                            try:
                                list_level = int(level_match.group(1)) - 1  # 0-based level
                            except ValueError:
                                pass
                
                if is_list_para:
                    logging.info("found a list paragraph")
                    # Apply the appropriate indentation based on list level
                    # Standard Word indentation is typically 0.25" or 0.5" per level
                    indent_per_level = 0.25  # inches, adjust if your document uses different spacing
                    
                    # Set the left indent based on the list level
                    new_para.paragraph_format.left_indent = Inches(indent_per_level * (list_level + 1))
                    
                    # Copy the exact numbering information
                    if para._p.pPr is not None and hasattr(para._p.pPr, 'numPr') and para._p.pPr.numPr is not None:
                        if new_para._p.pPr is None:
                            new_para._p.get_or_add_pPr()
                        
                        # Remove any existing numbering
                        if hasattr(new_para._p.pPr, 'numPr') and new_para._p.pPr.numPr is not None:
                            new_para._p.pPr.remove(new_para._p.pPr.numPr)
                        
                        # Copy the numbering XML
                        new_para._p.pPr.append(para._p.pPr.numPr.deepcopy())
                else:
                    # For non-list paragraphs, we've already applied left_indent from our tracking
                    # so we don't need to do anything here
                    pass

            # Get the XML element of the new paragraph
            new_element = new_para._element
            
            # Remove it from its current position
            new_element.getparent().remove(new_element)
            
            # Insert it before the placeholder
            parent_element.insert(placeholder_index + inserted_elements, new_element)
            inserted_elements += 1
        # Remove the placeholder paragraph
        parent_element.remove(placeholder_element)
        
        # Save the document
        doc.save(output_file)
        logging.info(f"Saved combined document to {output_file}")
        return True
    
    except Exception as e:
        logging.error(f"Error combining reports: {e}")
        import traceback
        logging.error(traceback.format_exc())
        return False


def move_paragraph_before(paragraph_to_move, target_paragraph):
    """Move a paragraph before another paragraph."""
    if paragraph_to_move._p is None or target_paragraph._p is None:
        return
    
    p = paragraph_to_move._p
    target = target_paragraph._p
    
    # Remove from current location
    p.getparent().remove(p)
    
    # Insert before target
    target.getparent().insert(target.getparent().index(target), p)

def move_paragraph_after(paragraph_to_move, target_paragraph):
    """Move a paragraph after another paragraph."""
    if paragraph_to_move._p is None or target_paragraph._p is None:
        return
    
    p = paragraph_to_move._p
    target = target_paragraph._p
    
    # Remove from current location
    p.getparent().remove(p)
    
    # Insert after target
    target.getparent().insert(target.getparent().index(target) + 1, p)




def main():
    parser = argparse.ArgumentParser(description='Combine ASVS control reports into a single document')
    parser.add_argument('--template', required=True, help='Path to the template document')
    parser.add_argument('--reports', required=True, help='Path to directory containing control report files')
    parser.add_argument('--csv', required=True, help='Path to ASVS controls CSV file')
    parser.add_argument('--output', required=True, help='Path to save the combined document')
    parser.add_argument('--debug', action='store_true', help='Enable debug logging')
    args = parser.parse_args()
    
    # Set up logging
    setup_logging(debug=args.debug)
    
    # Expand user paths
    template_file = os.path.expanduser(args.template)
    reports_dir = os.path.expanduser(args.reports)
    csv_file = os.path.expanduser(args.csv)
    output_file = os.path.expanduser(args.output)
    
    # Load ASVS controls
    control_chapters = load_asvs_controls(csv_file)
    
    # Get control files
    control_files = get_control_files(reports_dir)
    
    # Group controls by chapter
    chapter_groups = group_controls_by_chapter(control_files, control_chapters)
    
    # Combine reports
    if combine_reports(template_file, output_file, chapter_groups):
        print(f"Successfully combined reports into {output_file}")
    else:
        print("Failed to combine reports")

if __name__ == "__main__":
    main()
