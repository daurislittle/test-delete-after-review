# Reporting

The reporting scripts generate comprehensive documents that summarize the findings from the Application Security Program Assessment (ASPA) and present the roadmap for improvement.

## Prerequisites
- QA'd ASPA findings
- Processed and QA'd ASPA Roadmap

## Reporting Steps

1. **ASPA Report Generation**
   1. Run `create_aspa_report.py` to create an Application Security Program Assessment report
   2. **Inputs**
      1. --findings-file [path/to/findings_file] = Path to JSON file containing findings
      2. --roadmap-file [path/to/roadmap_file] = Path to text file containing roadmap
      3. --output [path/to/output_file] = Path to output Word document
      4. --template [path/to/template_file] = Path to template Word document
   3. **Outputs**
      1. Word document containing:
         - Findings section with hierarchical structure
         - Roadmap section with phases, current state, recommendations, and implementation items
   4. **Note**
      - Requires Python libraries: json, argparse, re, docx
      - Cleans bullet points and formatting from input text
      - Skips 'attributes', 'notes', and 'id' fields in the findings

## Additional Notes
- The reporting phase consolidates the QA'd findings and roadmap into a structured, readable format
- The generated report serves as the final deliverable for the Application Security Program Assessment



2. **ASPA Refactored Report Generation**
   1. Run `generate_samm_report_llm.py` to create an Application Security Program Assessment report
   2. **Inputs**
      1. --findings-file [path/to/findings_file] = Path to JSON file containing findings
      2. --roadmap-file [path/to/roadmap_file] = Path to text file containing roadmap
      3. --output [path/to/output_file] = Path to output Word document
      4. --workspace-name [workspace] = Name of the existing workspace to use
      5. --template [path/to/template_file] = Path to template Word document (optional)
      6. --debug = Enable debug logging (optional)
   3. **Outputs**
      1. Word document containing:
         - Refactored findings section with Current State, Gaps, and Recommendations
         - Roadmap section with phases, current state, recommendations, and implementation items
   4. **Process**
      1. Retrieves workspace information from AnythingLLM
      2. Creates a new thread for refactoring in the specified workspace
      3. Processes findings using LLM to refactor into Current State, Gaps, and Recommendations
      4. Generates a structured report combining refactored findings and roadmap