import os
import json
import logging
import argparse
import glob
import uuid
import requests
import time
import datetime
import sys
import re
import tempfile
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

# Get API key from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}
# Add this function to help with cleaning text
def clean_bullet_text(text):
    """
    Remove any non-ASCII characters, bullets, or special characters from the beginning of text.
    Also removes any bullet points that might appear anywhere in the text.
    """
    if not text:
        return text
    
    # First, remove any bullet points that might appear anywhere
    text = re.sub(r'[•\*→⇒⁃◦▪▫◆◇○●◎◉◈\-]\s*', '', text)
    
    # Then clean the beginning of the text
    # This regex matches any non-ASCII character or common bullet symbols at the start
    cleaned = re.sub(r'^[^\x00-\x7F•\*→⇒⁃◦▪▫◆◇○●◎◉◈\-]*', '', text)
    
    # Also remove any arrow characters that might be used for bullets
    cleaned = re.sub(r'[→⇒➔➜➞➝➟➠➡➢➣➤➥➦➧➨➩➪➫➬➭➮➯]', '', cleaned)
    
    return cleaned.strip()

def generate_risk_summary(gap_text, workspace_slug, thread_slug):
    """
    Generate a risk summary for the identified gap including severity, impact, ease of exploit, and probability.
    
    Args:
        gap_text: The identified gap text
        workspace_slug: The workspace slug for API calls
        thread_slug: The thread slug for API calls
        
    Returns:
        Dictionary containing risk summary information
    """
    logging.debug(f"Generating risk summary for gap: {gap_text[:100]}...")
    
    # Construct the prompt for the LLM
    prompt = f"""
    Based on the following security gap in an application, please generate a detailed risk summary that includes:
    1. A brief explanation of the risk (1-2 sentences)
    2. Impact classification (Loss of Confidentiality, Loss of Integrity, Loss of Availability, Loss of Accountability)
    3. Ease of Exploit classification (Easy, Moderate, Difficult)
    4. Probability of Attack classification (High, Medium, Low)
    5. Overall Severity classification (Critical, High, Medium, Low)

    Please format your response exactly as follows without additional text, explanations, or bullet points:

    Risk Summary:
    [Brief explanation of the risk - just 1-2 sentences]
    Impact: [Impact classification]
    Ease of Exploit: [Ease of Exploit classification]
    Probability of Attack: [Probability classification]
    Severity: [Severity classification]

    Here is the security gap to analyze:
    {gap_text}
    """
    
    # Send the prompt to the LLM
    response = send_message_to_thread(workspace_slug, thread_slug, prompt)
    
    if not response:
        logging.warning("Failed to generate risk summary")
        return {
            "explanation": "Risk assessment could not be generated",
            "impact": "Unknown",
            "ease_of_exploit": "Unknown",
            "probability": "Unknown",
            "severity": "Unknown"
        }
    
    # Parse the response
    try:
        # Extract the risk summary section
        if "Risk Summary:" in response:
            risk_summary = response.split("Risk Summary:", 1)[1].strip()
        else:
            risk_summary = response.strip()
        
        # Remove any "---" lines
        risk_summary = re.sub(r'\n---+\n', '\n', risk_summary)
        
        # Extract individual components
        impact = "Unknown"
        ease_of_exploit = "Unknown"
        probability = "Unknown"
        severity = "Unknown"
        explanation = ""
        
        # Extract components with more thorough cleaning
        lines = risk_summary.split('\n')
        current_section = "explanation"
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            # Check for section markers
            if line.lower().startswith("impact:"):
                current_section = "impact"
                impact = line.split(":", 1)[1].strip()
            elif line.lower().startswith("ease of exploit:"):
                current_section = "ease_of_exploit"
                ease_of_exploit = line.split(":", 1)[1].strip()
            elif line.lower().startswith("probability of attack:"):
                current_section = "probability"
                probability = line.split(":", 1)[1].strip()
            elif line.lower().startswith("severity:"):
                current_section = "severity"
                severity = line.split(":", 1)[1].strip()
            elif current_section == "explanation":
                explanation += line + " "
        
        # Clean up the explanation
        explanation = explanation.strip()
        
        # Clean all fields using our clean_bullet_text function
        explanation = clean_bullet_text(explanation)
        impact = clean_bullet_text(impact)
        ease_of_exploit = clean_bullet_text(ease_of_exploit)
        probability = clean_bullet_text(probability)
        severity = clean_bullet_text(severity)
        
        return {
            "explanation": explanation,
            "impact": impact,
            "ease_of_exploit": ease_of_exploit,
            "probability": probability,
            "severity": severity
        }
    except Exception as e:
        logging.error(f"Error parsing risk summary: {e}")
        return {
            "explanation": "Error parsing risk assessment",
            "impact": "Unknown",
            "ease_of_exploit": "Unknown",
            "probability": "Unknown",
            "severity": "Unknown"
        }


def setup_logging(debug=True):
    """Set up logging configuration."""
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

def get_workspace_slug(workspace_name):
    """Get the workspace slug from the workspace name."""
    logging.debug(f"Attempting to get workspace slug for '{workspace_name}'")
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    try:
        logging.debug(f"Sending GET request to {api_url}")
        response = requests.get(api_url, headers=headers)
        logging.debug(f"Received response with status code: {response.status_code}")
        if response.status_code == 200:
            workspaces = response.json().get('workspaces', [])
            for workspace in workspaces:
                if workspace['name'] == workspace_name:
                    logging.debug(f"Found workspace slug: {workspace['slug']}")
                    return workspace['slug']
        logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
        logging.debug(f"Response content: {response.text}")
    except Exception as e:
        logging.error(f"Error getting workspace slug for '{workspace_name}': {e}")
    return None

def create_thread(workspace_slug, thread_name):
    """Create a new thread in the workspace."""
    logging.debug(f"Creating new thread '{thread_name}' in workspace '{workspace_slug}'")
    
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/new"
    
    thread_slug = f"{thread_name.lower().replace(' ', '-')}-{int(time.time())}"
    
    payload = {
        "name": thread_name,
        "slug": thread_slug
    }
    
    try:
        logging.debug(f"Sending POST request to {api_url} with payload: {payload}")
        response = requests.post(api_url, json=payload, headers=headers)
        logging.debug(f"Response status code: {response.status_code}")
        logging.debug(f"Response content: {response.text}")
        
        if response.status_code == 200:
            try:
                response_data = response.json()
                logging.debug(f"Successfully parsed response data: {response_data}")
                
                if 'thread' in response_data and response_data['thread']:
                    thread = response_data['thread']
                    thread_id = thread.get('id')
                    thread_slug = thread.get('slug')
                    
                    if thread_id and thread_slug:
                        logging.info(f"Successfully created thread '{thread_name}' with ID {thread_id} and slug {thread_slug}")
                        return thread_slug
                    else:
                        logging.error(f"Thread ID or slug not found in response: {response_data}")
                else:
                    logging.error(f"Thread data not found in response: {response_data}")
            except json.JSONDecodeError as e:
                logging.error(f"Failed to parse JSON response: {e}")
                logging.error(f"Raw response: {response.text}")
        else:
            logging.error(f"Failed to create thread. Status code: {response.status_code}")
            logging.error(f"Response content: {response.text}")
    except Exception as e:
        logging.error(f"Error creating thread: {e}")
    return None

def send_message_to_thread(workspace_slug, thread_slug, message, max_retries=5, initial_retry_delay=3, max_retry_delay=60):
    """
    Send a message to a thread and get the response with improved error handling and backoff.
    
    Args:
        workspace_slug: The workspace slug
        thread_slug: The thread slug
        message: The message to send
        max_retries: Maximum number of retry attempts
        initial_retry_delay: Initial delay between retries in seconds
        max_retry_delay: Maximum delay between retries in seconds
    
    Returns:
        The LLM response text or None if failed after retries
    """
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/{thread_slug}/chat"
    
    payload = {
        "message": message,
        "mode": "chat"
    }
    
    # If the message is very long, log only the beginning
    log_message = message[:100] + "..." if len(message) > 100 else message
    logging.debug(f"Sending message to thread: {log_message}")
    
    for attempt in range(max_retries):
        # Calculate backoff delay with exponential increase
        retry_delay = min(initial_retry_delay * (2 ** attempt), max_retry_delay)
        
        try:
            logging.debug(f"API request attempt {attempt + 1}/{max_retries}")
            response = requests.post(api_url, json=payload, headers=headers, timeout=300)
            
            # Log the response status
            logging.debug(f"Response status code: {response.status_code}")
            
            if response.status_code == 200:
                try:
                    response_data = response.json()
                    llm_output = response_data.get('textResponse', '')
                    
                    if not llm_output and 'error' in response_data:
                        error_msg = response_data.get('error', 'Unknown error')
                        logging.warning(f"API returned error: {error_msg}")
                        
                        # If it's a rate limit or server busy error, retry
                        if "rate" in error_msg.lower() or "busy" in error_msg.lower() or "capacity" in error_msg.lower():
                            logging.info(f"Rate limit or server busy. Retrying in {retry_delay} seconds...")
                            time.sleep(retry_delay)
                            continue
                        
                        raise Exception(f"API returned error: {error_msg}")
                    
                    # If we got a response, return it
                    if llm_output:
                        logging.debug("Successfully received response from LLM")
                        return llm_output
                    else:
                        logging.warning("Empty response received from API")
                        if attempt < max_retries - 1:
                            logging.info(f"Retrying in {retry_delay} seconds...")
                            time.sleep(retry_delay)
                            continue
                        else:
                            return None
                        
                except json.JSONDecodeError as e:
                    logging.error(f"Failed to parse JSON response: {e}")
                    logging.debug(f"Raw response: {response.text[:500]}")
                    
                    if attempt < max_retries - 1:
                        logging.info(f"Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                    else:
                        raise
                        
            elif response.status_code == 500:
                logging.warning(f"Received 500 error from server")
                
                # Try to parse the error message if possible
                try:
                    error_data = response.json()
                    error_msg = error_data.get('error', 'No error details provided')
                    logging.warning(f"Error details: {error_msg}")
                except:
                    logging.warning(f"Could not parse error response: {response.text[:200]}")
                
                if attempt < max_retries - 1:
                    logging.info(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                else:
                    logging.error(f"Failed after {max_retries} attempts with 500 error")
                    return None
                    
            elif response.status_code == 429:
                # Rate limit exceeded
                logging.warning("Rate limit exceeded (429)")
                
                # Check if there's a Retry-After header
                retry_after = response.headers.get('Retry-After')
                if retry_after:
                    try:
                        wait_time = int(retry_after)
                    except ValueError:
                        wait_time = retry_delay
                else:
                    wait_time = retry_delay
                
                logging.info(f"Waiting for {wait_time} seconds before retrying...")
                time.sleep(wait_time)
                
            else:
                # Other error status codes
                logging.error(f"API request failed with status code {response.status_code}")
                logging.debug(f"Response content: {response.text[:500]}")
                
                if attempt < max_retries - 1:
                    logging.info(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                else:
                    raise Exception(f"API request failed with status code {response.status_code}")
                    
        except requests.Timeout:
            logging.warning("Request timed out")
            
            if attempt < max_retries - 1:
                logging.info(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logging.error("Request timed out after all retry attempts")
                return None
                
        except requests.ConnectionError as e:
            logging.warning(f"Connection error: {e}")
            
            if attempt < max_retries - 1:
                logging.info(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logging.error("Connection error after all retry attempts")
                return None
                
        except Exception as e:
            logging.error(f"Unexpected error during API request: {e}")
            
            if attempt < max_retries - 1:
                logging.info(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logging.error(f"Failed after {max_retries} attempts due to unexpected error")
                return None
    
    # If we get here, all retries failed
    return None

def determine_overall_compliance(results):
    """Determine overall compliance from multiple assessment results."""
    if not results:
        return "Unknown"
    
    # Count the different pass/fail statuses
    status_counts = {
        "Pass": 0,
        "Fail": 0,
        "Partial": 0,
        "N/A": 0,
        "Not specified": 0
    }
    
    for result in results:
        status = result.get("pass_fail", "Not specified")
        status_counts[status] = status_counts.get(status, 0) + 1
    
    # Determine overall status
    if status_counts["Fail"] > 0:
        return "Fail"
    elif status_counts["Partial"] > 0:
        return "Partial"
    elif status_counts["Pass"] > 0:
        return "Pass"
    elif status_counts["N/A"] > 0:
        return "N/A"
    else:
        return "Unknown"

def process_bold_text(text):
    """Process bold text markers (**text**) in a string."""
    if not text:
        return text
        
    # Find all instances of **text**
    bold_pattern = re.compile(r'\*\*(.*?)\*\*')
    
    # Replace each instance with the text in bold
    result = ""
    last_end = 0
    
    for match in bold_pattern.finditer(text):
        # Add the text before this match
        result += text[last_end:match.start()]
        
        # Get the text inside the ** markers
        bold_text = match.group(1)
        
        # Add the bold text with HTML-like bold tags that we'll process later
        result += f"<b>{bold_text}</b>"
        
        # Update the last end position
        last_end = match.end()
    
    # Add any remaining text
    result += text[last_end:]
    
    return result

def extract_evidence_section(text):
    """
    Extract just the evidence section from a text, looking for patterns like 
    'Evidence supporting the assessment:' up to the next section.
    """
    if not text:
        return text
    
    # Look for the evidence section
    evidence_patterns = [
        "Evidence supporting the assessment:",
        "Evidence and Analysis:",
        "Evidence:",
        "Supporting Evidence:"
    ]
    
    for pattern in evidence_patterns:
        if pattern in text:
            # Found the start of evidence section
            evidence_start = text.find(pattern) + len(pattern)
            
            # Look for the end of the evidence section
            end_patterns = [
                "Specific areas of non-compliance",
                "Areas of non-compliance",
                "Areas of Non-Compliance",
                "Non-Compliance",
                "Gaps identified"
            ]
            
            evidence_end = None
            for end_pattern in end_patterns:
                if end_pattern in text[evidence_start:]:
                    pattern_pos = text.find(end_pattern, evidence_start)
                    if evidence_end is None or pattern_pos < evidence_end:
                        evidence_end = pattern_pos
            
            # If we didn't find a specific end pattern, look for the next numbered section
            if evidence_end is None:
                # Look for patterns like "1.", "2.", etc. at the start of a line
                numbered_sections = list(re.finditer(r'\n\d+\.', text[evidence_start:]))
                if numbered_sections:
                    # Get the position of the first numbered section after the evidence start
                    evidence_end = evidence_start + numbered_sections[0].start()
            
            # If we found the end, extract just the evidence section
            if evidence_end is not None:
                return text[evidence_start:evidence_end].strip()
    
    # If we didn't find an evidence section, return the original text
    return text

def print_available_styles(template_path):
    """Print all available styles in the template document."""
    try:
        if os.path.exists(template_path):
            template_doc = Document(template_path)
            
            # Filter out None values before sorting
            styles = [s.name for s in template_doc.styles if s.name is not None]
            styles.sort()
            
            print("\nAvailable styles in template document:")
            for style in styles:
                print(f"  - {style}")
            
            return styles
        else:
            print(f"Template file not found: {template_path}")
            return []
    except Exception as e:
        print(f"Error loading template styles: {e}")
        import traceback
        print(traceback.format_exc())
        return []

def apply_markdown_formatting(doc, text, code_style_name=None):
    """
    Apply markdown-like formatting to text and add to document.
    
    Args:
        doc: Document object
        text: Text to format
        code_style_name: Specific name of the code style to use (optional)
        
    Returns:
        Updated document with formatted text
    """
    if not text:
        return doc
    
    # Process the text line by line
    lines = text.split('\n')
    i = 0
    in_code_block = False
    code_lines = []
    
    while i < len(lines):
        line = lines[i].rstrip()
        
        # Check for code blocks
        if line.strip().startswith('```'):
            if not in_code_block:
                # Start of code block
                in_code_block = True
                code_lines = []
                i += 1
                continue
            else:
                # End of code block
                in_code_block = False
                
                # Add the code block with the appropriate style
                if code_lines:
                    code_text = '\n'.join(code_lines)
                    
                    # Try to apply the code style - use "Code Example" by default, or user-specified style
                    style_to_use = code_style_name or "Code Example"
                    try:
                        p = doc.add_paragraph(style=style_to_use)
                        p.add_run(code_text)
                        logging.debug(f"Applied '{style_to_use}' style to code block")
                    except Exception as e:
                        logging.warning(f"Failed to apply '{style_to_use}' style: {e}")
                        # Fallback to manual formatting
                        p = doc.add_paragraph()
                        run = p.add_run(code_text)
                        run.font.name = 'Courier New'
                        run.font.size = Pt(9)
                i += 1

                # Check if the next line is empty (would cause an extra paragraph)
                if i < len(lines) and not lines[i].strip():
                    # Skip the empty line if it's after a code block
                    i += 1
                continue
                            
        if in_code_block:
            # Collecting code lines
            code_lines.append(line)
            i += 1
            continue
        
        # Check for bullet points (lines starting with - or *)
        if line.strip().startswith('- ') or line.strip().startswith('* '):
            bullet_text = line.strip()[2:]  # Remove the '- ' or '* '
            
            # Process bold text in bullet point
            bullet_text = process_bold_text(bullet_text)
            
            try:
                p = doc.add_paragraph(style='List Bullet')
                p.add_run(bullet_text)
                logging.debug("Applied 'List Bullet' style")
            except Exception as e:
                logging.warning(f"Failed to apply List Bullet style: {e}")
                p = doc.add_paragraph()
                p.add_run('• ' + bullet_text)
            
            i += 1
            
            # Check if the next line is empty (would cause an extra paragraph)
            if i < len(lines) and not lines[i].strip():
                # Skip the empty line if the line after is another bullet point or the end
                if i + 1 < len(lines) and (lines[i+1].strip().startswith('- ') or 
                                          lines[i+1].strip().startswith('* ') or 
                                          lines[i+1].strip().startswith('```') or
                                          re.match(r'^\d+\.\s+', lines[i+1].strip())):
                    i += 1
            continue
        
        # Check for numbered lists (lines starting with 1., 2., etc.)
        match = re.match(r'^(\d+)\.\s+(.+)$', line.strip())
        if match:
            number = match.group(1)
            numbered_text = match.group(2)
            
            # Process bold text in numbered item
            numbered_text = process_bold_text(numbered_text)
            
            try:
                p = doc.add_paragraph(style='List Number')
                p.add_run(numbered_text)  # The style will handle the numbering
                logging.debug("Applied 'List Number' style")
            except Exception as e:
                logging.warning(f"Failed to apply List Number style: {e}")
                p = doc.add_paragraph()
                p.add_run(f"{number}. {numbered_text}")
            
            i += 1
            
            # Check if the next line is empty (would cause an extra paragraph)
            if i < len(lines) and not lines[i].strip():
                # Skip the empty line if the line after is another numbered item or the end
                if i + 1 < len(lines) and (re.match(r'^\d+\.\s+', lines[i+1].strip()) or 
                                          lines[i+1].strip().startswith('- ') or
                                          lines[i+1].strip().startswith('* ') or
                                          lines[i+1].strip().startswith('```')):
                    i += 1
            continue
        
        # Regular paragraph
        if line.strip():
            # Process the paragraph for bold text
            processed_line = process_bold_text(line)
            
            p = doc.add_paragraph()
            p.add_run(processed_line)
        else:
            # Empty line
            doc.add_paragraph()
        
        i += 1
    
    # Process any paragraphs with bold tags
    for paragraph in doc.paragraphs:
        if '<b>' in paragraph.text and '</b>' in paragraph.text:
            # Save the original text
            original_text = paragraph.text
            
            # Clear the paragraph
            for run in paragraph.runs:
                run.text = ""
            
            # Split by bold tags
            parts = re.split(r'(<b>.*?</b>)', original_text)
            
            for part in parts:
                bold_match = re.match(r'<b>(.*?)</b>', part)
                if bold_match:
                    # This is a bold section
                    bold_text = bold_match.group(1)
                    run = paragraph.add_run(bold_text)
                    run.bold = True
                elif part:
                    # Regular text
                    paragraph.add_run(part)
    
    return doc

def format_word_document(doc, control_id, control_description, level1, level2, level3, overall_compliance, methodology, strengths, gaps, recommendations, risk_summaries=None, code_style_name=None):
    """Format the Word document with the control report following the specified style."""
    # Add ASVS Control ID as Heading 3
    try:
        heading = doc.add_paragraph(style='Heading 3')
        heading.add_run("ASVS Control ID: ")
        heading.add_run(control_id)
    except Exception as e:
        logging.warning(f"Could not apply Heading 3 style: {e}")
        heading = doc.add_paragraph()
        heading.add_run("ASVS Control ID: ")
        heading.add_run(control_id).bold = True
    
    # Add Overall Control Compliance in the style of Severity Ranking
    try:
        heading = doc.add_paragraph(style='Heading 3')
        heading.add_run("Overall Control Compliance: ")
        
        # Add compliance with appropriate color
        compliance_run = heading.add_run(overall_compliance)
        if overall_compliance == "Pass":
            compliance_run.font.color.rgb = RGBColor(0, 128, 0)  # Green
        elif overall_compliance == "Partial":
            compliance_run.font.color.rgb = RGBColor(255, 140, 0)  # Orange
        elif overall_compliance == "Fail":
            compliance_run.font.color.rgb = RGBColor(255, 0, 0)  # Red
    except Exception as e:
        logging.warning(f"Could not apply Heading 3 style: {e}")
        heading = doc.add_paragraph()
        heading.add_run("Overall Control Compliance: ")
        compliance_run = heading.add_run(overall_compliance)
        compliance_run.bold = True
        if overall_compliance == "Pass":
            compliance_run.font.color.rgb = RGBColor(0, 128, 0)  # Green
        elif overall_compliance == "Partial":
            compliance_run.font.color.rgb = RGBColor(255, 140, 0)  # Orange
        elif overall_compliance == "Fail":
            compliance_run.font.color.rgb = RGBColor(255, 0, 0)  # Red
    
    # Add ASVS Description as Heading 3
    try:
        heading = doc.add_paragraph(style='Heading 3')
        heading.add_run("ASVS Description:")
    except Exception as e:
        logging.warning(f"Could not apply Heading 3 style: {e}")
        heading = doc.add_paragraph()
        heading.add_run("ASVS Description:").bold = True
        
    desc_para = doc.add_paragraph()
    desc_para.add_run(control_description)
    
    # Add ASVS Levels
    levels_para = doc.add_paragraph()
    # Add the label with Strong style
    strong_run = levels_para.add_run("ASVS Levels: ")
    strong_run.bold = True
    try:
        strong_run.style = 'Strong'
    except Exception as e:
        logging.debug(f"Could not apply Strong style: {e}")

    # Add the levels
    levels = []
    if level1:
        levels.append("Level 1")
    if level2:
        levels.append("Level 2")
    if level3:
        levels.append("Level 3")

    if levels:
        levels_text = ", ".join(levels)
    else:
        levels_text = "None specified"

    levels_para.add_run(levels_text)

    
    # Add Methodology as Heading 3
    try:
        heading = doc.add_paragraph(style='Heading 3')
        heading.add_run("Methodology for this Control:")
    except Exception as e:
        logging.warning(f"Could not apply Heading 3 style: {e}")
        heading = doc.add_paragraph()
        heading.add_run("Methodology for this Control:").bold = True
        
    doc = apply_markdown_formatting(doc, methodology, code_style_name)
    
    # Add Areas of Strength as Heading 3
    try:
        heading = doc.add_paragraph(style='Heading 3')
        heading.add_run("Areas of Strength:")
    except Exception as e:
        logging.warning(f"Could not apply Heading 3 style: {e}")
        heading = doc.add_paragraph()
        heading.add_run("Areas of Strength:").bold = True
        
    doc = apply_markdown_formatting(doc, strengths, code_style_name)
    
    # Add Gaps as Heading 3
    try:
        heading = doc.add_paragraph(style='Heading 3')
        heading.add_run("Gaps:")
    except Exception as e:
        logging.warning(f"Could not apply Heading 3 style: {e}")
        heading = doc.add_paragraph()
        heading.add_run("Gaps:").bold = True
    # Process gaps and add risk summaries
    if gaps and "No gaps identified" not in gaps.lower():
        # Split gaps into bullet points if they exist
        gap_items = []
        if "- " in gaps:
            # Process bullet points
            for line in gaps.split("\n"):
                if line.strip().startswith("- "):
                    gap_items.append(line.strip()[2:])
        else:
            # Just use the whole text as one gap
            gap_items = [gaps]
        
        # Process each gap
        for i, gap_item in enumerate(gap_items):
            if not gap_item.strip():
                continue
            
            # Process bold markdown in gap text
            gap_text = gap_item
            bold_pattern = re.compile(r'\*\*(.*?)\*\*')
            
            # Apply bold formatting
            parts = []
            last_end = 0
            for match in bold_pattern.finditer(gap_text):
                parts.append(gap_text[last_end:match.start()])
                parts.append((match.group(1), True))  # Tuple indicates text to be bolded
                last_end = match.end()
            parts.append(gap_text[last_end:])
            
            # Add the gap with proper formatting
            try:
                p = doc.add_paragraph(style='List Bullet')
                for part in parts:
                    if isinstance(part, tuple):
                        run = p.add_run(part[0])
                        run.bold = True
                    else:
                        p.add_run(part)
            except Exception as e:
                logging.warning(f"Could not apply List Bullet style: {e}")
                p = doc.add_paragraph()
                p.add_run('• ')
                for part in parts:
                    if isinstance(part, tuple):
                        run = p.add_run(part[0])
                        run.bold = True
                    else:
                        p.add_run(part)
            
            # Add risk summary if available
            if risk_summaries and i < len(risk_summaries):
                risk_summary = risk_summaries[i]
                
                # Add Risk Summary section with proper indentation
                try:
                    risk_para = doc.add_paragraph(style='List Paragraph')
                    risk_para.paragraph_format.left_indent = Inches(0.5)
                except Exception as e:
                    logging.warning(f"Could not apply List Paragraph style: {e}")
                    risk_para = doc.add_paragraph()
                    risk_para.paragraph_format.left_indent = Inches(0.5)
                
                risk_title = risk_para.add_run("Risk Summary\n")
                risk_title.bold = True
                risk_title.italic = True
                
                # Add explanation without extra line break
                explanation_text = risk_summary.get("explanation", "").strip()
                # Remove any bullet points at the beginning
                explanation_text = re.sub(r'^[•\*]\s*', '', explanation_text)
                risk_para.add_run(explanation_text)
                
                # Add impact, ease of exploit, probability in bullet format with proper indentation
                try:
                    # Impact
                    impact_para = doc.add_paragraph(style='List Paragraph')
                    impact_para.paragraph_format.left_indent = Inches(0.75)
                except Exception as e:
                    logging.warning(f"Could not apply List Paragraph style: {e}")
                    impact_para = doc.add_paragraph()
                    impact_para.paragraph_format.left_indent = Inches(0.75)

                # Manually add bullet point
                #impact_para.add_run("• ")
                impact_label = impact_para.add_run("Impact: ")
                impact_label.bold = True
                # Clean the impact text of any bullet characters
                impact_text = clean_bullet_text(risk_summary.get("impact", "Unknown"))
                impact_para.add_run(impact_text)

                try:
                    # Ease of Exploit
                    ease_para = doc.add_paragraph(style='List Paragraph')
                    ease_para.paragraph_format.left_indent = Inches(0.75)
                except Exception as e:
                    logging.warning(f"Could not apply List Paragraph style: {e}")
                    ease_para = doc.add_paragraph()
                    ease_para.paragraph_format.left_indent = Inches(0.75)

                # Manually add bullet point
                #ase_para.add_run("• ")
                ease_label = ease_para.add_run("Ease of Exploit: ")
                ease_label.bold = True
                # Clean the ease text of any bullet characters
                ease_text = clean_bullet_text(risk_summary.get("ease_of_exploit", "Unknown"))
                ease_para.add_run(ease_text)

                try:
                    # Probability of Attack
                    prob_para = doc.add_paragraph(style='List Paragraph')
                    prob_para.paragraph_format.left_indent = Inches(0.75)
                except Exception as e:
                    logging.warning(f"Could not apply List Paragraph style: {e}")
                    prob_para = doc.add_paragraph()
                    prob_para.paragraph_format.left_indent = Inches(0.75)

                # Manually add bullet point
                #prob_para.add_run("• ")
                prob_label = prob_para.add_run("Probability of Attack: ")
                prob_label.bold = True
                # Clean the probability text of any bullet characters
                prob_text = clean_bullet_text(risk_summary.get("probability", "Unknown"))
                prob_para.add_run(prob_text)

                try:
                    # Severity with appropriate color
                    severity_para = doc.add_paragraph(style='List Paragraph')
                    severity_para.paragraph_format.left_indent = Inches(0.75)
                    # Remove extra spacing after the severity paragraph
                    severity_para.paragraph_format.space_after = Pt(0)
                except Exception as e:
                    logging.warning(f"Could not apply List Paragraph style: {e}")
                    severity_para = doc.add_paragraph()
                    severity_para.paragraph_format.left_indent = Inches(0.75)
                    severity_para.paragraph_format.space_after = Pt(0)

                # Manually add bullet point
                #severity_para.add_run("• ")
                severity_label = severity_para.add_run("Severity: ")
                severity_label.bold = True

                # Clean the severity text of any bullet characters
                severity = clean_bullet_text(risk_summary.get("severity", "Unknown"))
                severity_run = severity_para.add_run(severity)
                severity_run.bold = True

                
                # Color code based on severity
                if "Critical" in severity:
                    severity_run.font.color.rgb = RGBColor(128, 0, 0)  # Dark Red
                elif "High" in severity:
                    severity_run.font.color.rgb = RGBColor(255, 0, 0)  # Red
                elif "Medium" in severity:
                    severity_run.font.color.rgb = RGBColor(255, 140, 0)  # Orange
                elif "Low" in severity:
                    severity_run.font.color.rgb = RGBColor(0, 128, 0)  # Green
    else:
        p = doc.add_paragraph()
        p.add_run("No gaps identified.")
    
    # Add Recommendations as Heading 3
    try:
        heading = doc.add_paragraph(style='Heading 3')
        heading.add_run("Recommendations:")
    except Exception as e:
        logging.warning(f"Could not apply Heading 3 style: {e}")
        heading = doc.add_paragraph()
        heading.add_run("Recommendations:").bold = True
        
    doc = apply_markdown_formatting(doc, recommendations, code_style_name)
    
    # Add Evidence as Heading 3
    try:
        heading = doc.add_paragraph(style='Heading 3')
        heading.add_run("Evidence:")
    except Exception as e:
        logging.warning(f"Could not apply Heading 3 style: {e}")
        heading = doc.add_paragraph()
        heading.add_run("Evidence:").bold = True
        
    evidence_para = doc.add_paragraph()
    evidence_para.add_run('Refer to the supplemental materials for detailed evidence.')
    
    return doc

def generate_control_report(control_file, output_dir, workspace_slug, thread_slug, template_path=None, code_style_name=None):
    """Generate a Word document report for a control with improved error handling and style formatting."""
    try:
        # Load the JSON data
        with open(control_file, 'r') as f:
            results = json.load(f)
        
        if not results:
            logging.warning(f"No results found in {control_file}")
            return False
        
        # Extract control ID and description from the first result
        control_id = results[0].get("asvs_control_id", "Unknown")
        control_description = results[0].get("control_description", "No description available")
        level1 = results[0].get("level1", False)
        level2 = results[0].get("level2", False)
        level3 = results[0].get("level3", False)
        
        # Define output filename
        output_file = os.path.join(output_dir, f"{control_id}_Report.docx")
        
        # Determine overall compliance
        overall_compliance = determine_overall_compliance(results)
        
        logging.info(f"Generating report for control {control_id}")
        
        # Process the evidence field for non-Discovery/Runtime sources
        for result in results:
            source = result.get("source", "")
            if source != "Discovery" and source != "Runtime":
                # For repository sources, try to extract just the evidence section
                evidence = result.get("evidence", "")
                extracted_evidence = extract_evidence_section(evidence)
                if extracted_evidence:
                    result["evidence"] = extracted_evidence
        
        # Try different approaches to get a response from the LLM
        methodology = ""
        strengths = ""
        gaps = ""
        recommendations = ""
        
        # First attempt: Send the full JSON and get all sections at once
        prompt = f"""
        I need to generate a comprehensive report for ASVS control {control_id}. Below is the JSON data containing evidence and assessments from different sources (Discovery, Runtime, and code repositories).

        ```json
        {json.dumps(results, indent=2)}
        ```

        Based on this data, please provide:

        1. A concise methodology paragraph explaining what was assessed (Discovery/SDLC, code review, runtime/ASA) and how the assessment was conducted.
        
        2. A detailed list of strengths found in the implementation of this control. Use bullet points (- ) for each strength.
        
        3. A comprehensive summary of gaps or areas of non-compliance. Use bullet points (- ) for each gap.
        
        4. Consolidated recommendations to address the identified gaps. Use bullet points (- ) for each recommendation.

        Format your response with clear headings for each section:
        
        ## Methodology
        [Your methodology paragraph here]
        
        ## Areas of Strength
        [Your strengths list here with bullet points]
        
        ## Gaps
        [Your gaps summary here with bullet points]
        
        ## Recommendations
        [Your consolidated recommendations here with bullet points]

        For code examples or technical details, please use markdown code blocks with triple backticks (```).
        For emphasis, use double asterisks (**important text**).
        """
        
        response = send_message_to_thread(workspace_slug, thread_slug, prompt)
        
        # If the first attempt failed, try a different approach with separate requests for each section
        if not response:
            logging.warning(f"Full request failed for {control_id}. Trying individual section requests.")
            
            # Attempt 2: Get methodology separately
            methodology_prompt = f"""
            For ASVS control {control_id}, I need a concise methodology paragraph explaining what was assessed and how.
            
            The control was assessed using these sources:
            {', '.join([result.get('source', 'Unknown') for result in results])}
            
            Based on this information, please write a brief methodology paragraph (3-5 sentences).
            """
            
            methodology = send_message_to_thread(workspace_slug, thread_slug, methodology_prompt) or "Methodology information not available due to processing error."
            
            # Get strengths separately
            strengths_prompt = f"""
            For ASVS control {control_id}, I need to identify the key strengths in the implementation.
            
            Control description: {control_description}
            
            Based on these assessment results:
            {json.dumps([{'source': r.get('source'), 'pass_fail': r.get('pass_fail'), 'evidence': r.get('evidence')[:500] + '...' if r.get('evidence') and len(r.get('evidence')) > 500 else r.get('evidence')} for r in results], indent=2)}
            
            Please list the key strengths in the implementation of this control. Format each strength as a bullet point starting with "- ".
            """
            
            strengths = send_message_to_thread(workspace_slug, thread_slug, strengths_prompt) or "Strengths information not available due to processing error."
            
            # Get gaps separately
            gaps_prompt = f"""
            For ASVS control {control_id}, I need to identify the gaps or areas of non-compliance.
            
            Control description: {control_description}
            Overall compliance: {overall_compliance}
            
            Based on these gaps from the assessments:
            {json.dumps([{'source': r.get('source'), 'pass_fail': r.get('pass_fail'), 'gaps': r.get('gaps')} for r in results], indent=2)}
            
            Please provide a comprehensive summary of the gaps or areas of non-compliance. Format each gap as a bullet point starting with "- ".
            """
            
            gaps = send_message_to_thread(workspace_slug, thread_slug, gaps_prompt) or "Gaps information not available due to processing error."
            
            # Get recommendations separately
            recommendations_prompt = f"""
            For ASVS control {control_id}, I need consolidated recommendations to address the identified gaps.
            
            Control description: {control_description}
            
            Based on these recommendations from the assessments:
            {json.dumps([{'source': r.get('source'), 'recommendations': r.get('recommendations')} for r in results], indent=2)}
            
            Please provide consolidated recommendations to address the identified gaps. Format each recommendation as a bullet point starting with "- ".
            """
            
            recommendations = send_message_to_thread(workspace_slug, thread_slug, recommendations_prompt) or "Recommendations not available due to processing error."
        else:
            # Extract sections from the response
            if "## Methodology" in response:
                methodology_parts = response.split("## Methodology", 1)[1].split("##", 1)
                methodology = methodology_parts[0].strip()
            else:
                methodology = "Methodology section could not be extracted from the response."
            
            if "## Areas of Strength" in response:
                strengths_parts = response.split("## Areas of Strength", 1)[1].split("##", 1)
                strengths = strengths_parts[0].strip()
            else:
                strengths = "Areas of Strength section could not be extracted from the response."
            
            if "## Gaps" in response:
                gaps_parts = response.split("## Gaps", 1)[1].split("##", 1)
                gaps = gaps_parts[0].strip()
            else:
                gaps = "Gaps section could not be extracted from the response."
            
            if "## Recommendations" in response:
                recommendations_parts = response.split("## Recommendations", 1)[1].split("##", 1)
                recommendations = recommendations_parts[0].strip()
            else:
                recommendations = "Recommendations section could not be extracted from the response."

        # Generate risk summaries for gaps
        risk_summaries = []
        if gaps and "No gaps identified" not in gaps.lower():
            logging.info(f"Generating risk summaries for {control_id} gaps")
            
            # Split gaps into bullet points if they exist
            gap_items = []
            if "- " in gaps:
                # Process bullet points
                for line in gaps.split("\n"):
                    if line.strip().startswith("- "):
                        gap_items.append(line.strip()[2:])
            else:
                # Just use the whole text as one gap
                gap_items = [gaps]
            
            # Generate risk summary for each gap
            for gap_item in gap_items:
                if gap_item.strip():
                    logging.debug(f"Processing gap: {gap_item[:100]}...")
                    risk_summary = generate_risk_summary(gap_item, workspace_slug, thread_slug)
                    risk_summaries.append(risk_summary)
                    logging.debug(f"Generated risk summary with severity: {risk_summary.get('severity', 'Unknown')}")
        else:
            logging.info(f"No gaps to generate risk summaries for {control_id}")
        
        # Export gaps and risk summaries to JSON
        output_json_path = control_file.replace('.json', '-with_gaps_and_severity.json')
        # If the control file is in a different directory, adjust the output path
        if os.path.dirname(control_file) != os.path.dirname(output_json_path):
            output_json_path = os.path.join(os.path.dirname(control_file), os.path.basename(output_json_path))
        
        # Create a copy of the original results with updated risk_level field
        updated_results = []
        for i, result in enumerate(results):
            updated_result = result.copy()
            
            # If we have gaps and risk summaries, update the risk_level field
            if i < len(risk_summaries) and risk_summaries:
                # Use the severity from the risk summary
                updated_result["risk_level"] = risk_summaries[i].get("severity", "Unknown")
                # Also add the full risk summary for reference
                updated_result["risk_summary"] = risk_summaries[i]
            
            updated_results.append(updated_result)
        
        # Save the updated JSON
        with open(output_json_path, 'w') as f:
            json.dump(updated_results, indent=2, fp=f)
        
        logging.info(f"Exported gaps and severity information to {output_json_path}")
        
        # Create a new document from the template if provided, otherwise create a blank document
        if template_path and os.path.exists(template_path):
            try:
                doc = Document(template_path)
                logging.info(f"Using template document: {template_path}")
            except Exception as e:
                logging.error(f"Error loading template document: {e}")
                doc = Document()
        else:
            doc = Document()
        
        # Format the document with all content
        doc = format_word_document(
            doc,
            control_id, 
            control_description, 
            level1, 
            level2, 
            level3,
            overall_compliance, 
            methodology, 
            strengths, 
            gaps, 
            recommendations, 
            risk_summaries, 
            code_style_name
        )
        
        # Save the document
        doc.save(output_file)
        logging.info(f"Generated report for {control_id} at {output_file}")
        
        return True
    
    except Exception as e:
        logging.error(f"Error generating report for {os.path.basename(control_file)}: {e}")
        import traceback
        logging.error(traceback.format_exc())
        return False


def main():
    parser = argparse.ArgumentParser(description='Generate ASVS control reports from JSON data')
    parser.add_argument('--input', required=True, help='Path to directory containing JSON files')
    parser.add_argument('--output', required=True, help='Path to output directory for Word documents')
    parser.add_argument('--workspace', default="ASVS-Report-Generation", help='AnythingLLM workspace name')
    parser.add_argument('--control', help='Specific control ID to process (optional)')
    parser.add_argument('--template', help='Path to Word document template for styles')
    parser.add_argument('--code-style', help='Name of the code style to use for code blocks')
    parser.add_argument('--debug', action='store_true', help='Enable debug logging')
    parser.add_argument('--force', action='store_true', help='Force processing even if output file already exists')
    parser.add_argument('--list-styles', action='store_true', help='List available styles in the template document and exit')
    args = parser.parse_args()
    
    # Set up logging
    setup_logging(debug=args.debug)
    
    # Expand user paths
    input_dir = os.path.expanduser(args.input)
    output_dir = os.path.expanduser(args.output)
    template_path = os.path.expanduser(args.template) if args.template else None
    
    # List styles in template if requested
    if args.list_styles and template_path:
        styles = print_available_styles(template_path)
        return
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Get workspace slug
    workspace_slug = get_workspace_slug(args.workspace)
    if not workspace_slug:
        logging.error(f"Workspace '{args.workspace}' not found. Please create it manually.")
        return
    
    # Create a thread for processing
    thread_name = f"ASVS-Report-Generation-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}"
    thread_slug = create_thread(workspace_slug, thread_name)
    if not thread_slug:
        logging.error("Failed to create thread. Exiting.")
        return
    
    # Find JSON files to process
    if args.control:
        json_files = [os.path.join(input_dir, f"{args.control}.json")]
        if not os.path.exists(json_files[0]):
            logging.error(f"No JSON file found for control {args.control}")
            return
    else:
        json_files = glob.glob(os.path.join(input_dir, "*.json"))
    
    logging.info(f"Found {len(json_files)} JSON files to process")
    
    # Process each JSON file
    successful = 0
    failed = 0
    skipped = 0
    
    for json_file in json_files:
        control_id = os.path.basename(json_file).replace(".json", "")
        output_file = os.path.join(output_dir, f"{control_id}_Report.docx")
        
        # Check if output file already exists
        if os.path.exists(output_file) and not args.force:
            print(f"Skipping control {control_id} - output file already exists")
            logging.info(f"Skipped {control_id} - output file already exists")
            skipped += 1
            continue
        
        print(f"Processing control {control_id}...")
        
        if generate_control_report(json_file, output_dir, workspace_slug, thread_slug, template_path, args.code_style):
            successful += 1
        else:
            failed += 1
    
    logging.info(f"Completed processing. Success: {successful}, Failed: {failed}, Skipped: {skipped}")
    print(f"Completed processing. Success: {successful}, Failed: {failed}, Skipped: {skipped}")
    print(f"Reports saved to {output_dir}")

if __name__ == "__main__":
    main()
