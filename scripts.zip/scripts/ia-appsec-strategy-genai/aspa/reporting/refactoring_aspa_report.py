import json
import argparse
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import os
import requests
import logging
import time
import sys

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

def setup_logging(debug):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

def get_workspace_slug(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        for workspace in workspaces:
            if workspace['name'] == workspace_name:
                return workspace['slug']
    logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
    return None

def create_new_thread(workspace_slug, thread_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/new"
    payload = {
        "name": thread_name,
    }

    response = requests.post(api_url, json=payload, headers=headers, timeout=120)
    if response.status_code == 200:
        response_text = json.loads(response.text)
        thread_slug = response_text['thread']['slug']
        logging.info(f"Created new thread {thread_name} with slug id: {thread_slug}")
        return thread_slug
    else:
        logging.error(f"Failed to create new thread {thread_name}: {response.status_code}")
        return None

def clean_bullet_text(text):
    if not text:
        return text
    cleaned = re.sub(r'(- |• |Item None - )', '', text)
    return cleaned.strip()

def load_json_file(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def send_message_to_llm(workspace_slug, thread_slug, message):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/{thread_slug}/chat"
    payload = {
        "message": message,
        "mode": "query"
    }
    
    max_retries = 3
    retry_delay = 3

    for attempt in range(max_retries):
        try:
            response = requests.post(api_url, json=payload, headers=headers, timeout=120)
            response.raise_for_status()
            return response.json()['textResponse']
        except requests.exceptions.RequestException as e:
            if attempt < max_retries - 1:
                logging.warning(f"Request failed. Retrying in {retry_delay} seconds... (Attempt {attempt + 1}/{max_retries})")
                time.sleep(retry_delay)
            else:
                raise Exception(f"Failed to send message to LLM after {max_retries} attempts: {str(e)}")

def consolidate_gaps(gaps):
    consolidated = {}
    for gap in gaps:
        gap_id, description = gap.split(":", 1) if ":" in gap else (gap, "")
        gap_id = gap_id.strip()
        description = description.strip()
        
        # Check if this description (or a similar one) already exists
        existing_key = next((k for k, v in consolidated.items() if description.lower() in v.lower()), None)
        
        if existing_key:
            consolidated[existing_key] = f"{consolidated[existing_key]}; {description}"
            consolidated[existing_key] = ", ".join([existing_key, gap_id])
        else:
            consolidated[gap_id] = description

    # Format the consolidated gaps
    formatted_gaps = [f"• {ids}: {desc}" for ids, desc in consolidated.items()]
    return formatted_gaps

def process_findings_with_llm(findings, workspace_slug, thread_slug):
    refactored_findings = {}
    for domain, practices in findings.items():
        refactored_findings[domain] = {}
        for practice, content in practices.items():
            prompt = f"""
            Refactor the following information for the {domain} domain, {practice} practice into a format with Current State, Gaps, and Recommendations:

            {json.dumps(content, indent=2)}

            Please structure the output as follows:
            Current State Details
            {domain} Domain
            {practice}
            Current State
            • [Bullet points summarizing the current state]
            Gaps
            • [Consolidated gaps, combining related issues into broader categories. Include original gap IDs at the beginning of each line, separated by commas.]
            Recommendations
            • [Detailed recommendation paragraph]
            o Addresses: [Gap ID(s) addressed by this recommendation]

            For the Gaps section, please consolidate related gaps into broader categories to reduce the total number of gaps. Ensure that the consolidated gaps still capture all the key issues from the original gaps.

            Ensure that all relevant information from the input is included in the output. For the Recommendations section, provide detailed, actionable recommendations in paragraph form, followed by the gap IDs they address.
            """
            try:
                llm_response = send_message_to_llm(workspace_slug, thread_slug, prompt)
                refactored_findings[domain][practice] = llm_response
                logging.info(f"Successfully processed {domain} - {practice}")
            except Exception as e:
                logging.error(f"Error processing {domain} - {practice}: {str(e)}")
                refactored_findings[domain][practice] = f"Error: {str(e)}"
            
            time.sleep(1)  # Add a small delay between requests to avoid rate limiting

    return refactored_findings

def parse_llm_output(output):
    sections = {}
    current_section = None
    current_recommendation = None
    for line in output.split('\n'):
        line = line.strip()
        if line in ['Current State', 'Gaps', 'Recommendations']:
            current_section = line
            sections[current_section] = []
        elif line.startswith('•') and current_section == 'Recommendations':
            if current_recommendation:
                sections[current_section].append(current_recommendation)
            current_recommendation = {'text': clean_bullet_text(line), 'addresses': []}
        elif line.startswith('o Addresses:') and current_recommendation:
            current_recommendation['addresses'] = [addr.strip() for addr in line.replace('o Addresses:', '').split(',')]
        elif line and current_section:
            if current_section == 'Recommendations' and current_recommendation:
                current_recommendation['text'] += ' ' + clean_bullet_text(line)
            else:
                sections[current_section].append(clean_bullet_text(line))
    
    if current_recommendation:
        sections['Recommendations'].append(current_recommendation)
    
    # Consolidate gaps if they haven't been consolidated by the LLM
    if 'Gaps' in sections:
        sections['Gaps'] = consolidate_gaps(sections['Gaps'])
    
    return sections

def add_refactored_findings_section(doc, refactored_findings):
    for domain, practices in refactored_findings.items():
        doc.add_heading(domain, level=1)
        for practice, content in practices.items():
            doc.add_heading(practice, level=2)
            parsed_content = parse_llm_output(content)
            
            if 'Current State' in parsed_content:
                doc.add_heading('Current State', level=3)
                for item in parsed_content['Current State']:
                    doc.add_paragraph(item, style='List Bullet')
            
            if 'Gaps' in parsed_content:
                doc.add_heading('Gaps', level=3)
                for item in parsed_content['Gaps']:
                    doc.add_paragraph(item)
            
            if 'Recommendations' in parsed_content:
                doc.add_heading('Recommendations', level=3)
                for item in parsed_content['Recommendations']:
                    p = doc.add_paragraph(item['text'], style='List Bullet')
                    if item['addresses']:
                        p.add_run(f"\no Addresses: {', '.join(item['addresses'])}")

def add_roadmap_section(doc, roadmap):
    doc.add_heading('Roadmap', level=1)
    phases = roadmap.split("Phase ")
    for phase in phases[1:]:  # Skip the first empty split
        phase_lines = phase.split("\n")
        phase_number = phase_lines[0].strip()
        doc.add_heading(f"Phase {phase_number}", level=2)
        
        current_item = None
        for line in phase_lines[2:]:  # Skip the "Phase X Roadmap" line
            cleaned_line = clean_bullet_text(line)
            if cleaned_line.endswith(")") and "(" in cleaned_line:
                # This is the title line with the id
                current_item = cleaned_line
                doc.add_heading(current_item, level=3)
            elif cleaned_line.startswith("Current State Summary:"):
                doc.add_paragraph("Current State:", style='Heading 4')
                doc.add_paragraph(cleaned_line.replace("Current State Summary:", "").strip())
            elif cleaned_line.startswith("Recommendation Summary:"):
                doc.add_paragraph("Recommendation:", style='Heading 4')
                doc.add_paragraph(cleaned_line.replace("Recommendation Summary:", "").strip())
            elif cleaned_line.startswith("Implementation Items:"):
                doc.add_paragraph("Implementation Items:", style='Heading 4')
            elif line.startswith("•"):
                doc.add_paragraph(cleaned_line, style='List Bullet')
            elif cleaned_line.startswith("Level of Investment:"):
                doc.add_paragraph(f"Level of Investment: {cleaned_line.split(':')[1].strip()}")
                doc.add_paragraph()  # Add an empty paragraph for spacing between items

def create_samm_report(roadmap, output_file, template_file=None, refactored_findings=None):
    if template_file:
        doc = Document(template_file)
        doc.add_page_break()
    else:
        doc = Document()
        doc.add_heading('Application Security Program Assessment Report', 0)

    # Add Refactored Findings section
    if refactored_findings:
        add_refactored_findings_section(doc, refactored_findings)

    # Add page break
    doc.add_page_break()

    # Add Roadmap section
    add_roadmap_section(doc, roadmap)

    # Save the document
    doc.save(output_file)

def main():
    parser = argparse.ArgumentParser(description='Generate Application Security Program Assessment report')
    parser.add_argument('--findings-file', required=True, help='Path to JSON file containing findings')
    parser.add_argument('--roadmap-file', required=True, help='Path to text file containing roadmap')
    parser.add_argument('--output', required=True, help='Path to output Word document')
    parser.add_argument('--template', help='Path to template Word document (optional)')
    parser.add_argument('--workspace-name', required=True, help='Name of the existing workspace to use')
    parser.add_argument('--debug', action='store_true', help='Enable debug logging')
    args = parser.parse_args()

    setup_logging(args.debug)

    # Get workspace slug
    workspace_slug = get_workspace_slug(args.workspace_name)
    if not workspace_slug:
        logging.error(f"Workspace '{args.workspace_name}' not found. Exiting.")
        sys.exit(1)
    logging.debug(f"Retrieved workspace slug: {workspace_slug}")

    # Create new Refactoring thread
    thread_slug = create_new_thread(workspace_slug, "Refactoring")
    if not thread_slug:
        logging.error("Failed to create Refactoring thread. Exiting.")
        sys.exit(1)
    logging.debug(f"Created new Refactoring thread with slug: {thread_slug}")

    # Load JSON files
    findings = load_json_file(args.findings_file)
    
    # Load roadmap text file
    with open(args.roadmap_file, 'r') as file:
        roadmap = file.read()

    # Process findings with LLM
    refactored_findings = process_findings_with_llm(findings, workspace_slug, thread_slug)

    # Create the report
    create_samm_report(roadmap, args.output, args.template, refactored_findings)

    print(f"Report generated: {args.output}")

if __name__ == "__main__":
    main()
