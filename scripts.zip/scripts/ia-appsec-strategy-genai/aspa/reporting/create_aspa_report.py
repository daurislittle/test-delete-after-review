import json
import argparse
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

def clean_bullet_text(text):
    """
    Remove instances of "- ", "• ", and "Item None - " from the text.
    """
    if not text:
        return text
    
    # Remove "- ", "• ", and "Item None - " from anywhere in the text
    cleaned = re.sub(r'(- |• |Item None - )', '', text)
    
    return cleaned.strip()

def load_json_file(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def add_findings_section(doc, findings):
    def process_item(item, level):
        if isinstance(item, dict):
            for key, value in item.items():
                if key.startswith('G-'):  # This assumes activity keys start with 'G-'
                    doc.add_heading(clean_bullet_text(key), level=level)
                    process_item(value, level+1)
                elif isinstance(value, dict):
                    doc.add_heading(clean_bullet_text(key), level=level)
                    process_item(value, level+1)
                elif isinstance(value, list):
                    if key.lower() not in ['attributes', 'notes']:  # Skip 'attributes' and 'notes'
                        doc.add_heading(clean_bullet_text(key), level=level)
                        for list_item in value:
                            if isinstance(list_item, dict):
                                for sub_key, sub_value in list_item.items():
                                    if sub_key.lower() != 'id':  # Skip 'id' field in recommendations
                                        p = doc.add_paragraph(style='List Bullet')
                                        p.add_run(f"{clean_bullet_text(sub_key)}: ").bold = True
                                        p.add_run(clean_bullet_text(str(sub_value)))
                            else:
                                doc.add_paragraph(clean_bullet_text(str(list_item)), style='List Bullet')
                else:
                    if key.lower() not in ['attributes', 'notes']:  # Skip 'attributes' and 'notes'
                        p = doc.add_paragraph()
                        p.add_run(f"{clean_bullet_text(key)}: ").bold = True
                        p.add_run(clean_bullet_text(str(value)))
        elif isinstance(item, list):
            for list_item in item:
                doc.add_paragraph(clean_bullet_text(str(list_item)), style='List Bullet')
        else:
            doc.add_paragraph(clean_bullet_text(str(item)))

    process_item(findings, 2)

def add_roadmap_section(doc, roadmap):
    doc.add_heading('Roadmap', level=1)
    phases = roadmap.split("Phase ")
    for phase in phases[1:]:  # Skip the first empty split
        phase_lines = phase.split("\n")
        phase_number = phase_lines[0].strip()
        doc.add_heading(f"Phase {phase_number}", level=2)
        
        current_item = None
        for line in phase_lines[2:]:  # Skip the "Phase X Roadmap" line
            cleaned_line = clean_bullet_text(line)
            if cleaned_line.endswith(")") and "(" in cleaned_line:
                # This is the title line with the id
                current_item = cleaned_line
                doc.add_heading(current_item, level=3)
            elif cleaned_line.startswith("Current State Summary:"):
                doc.add_paragraph("Current State:", style='Heading 4')
                doc.add_paragraph(cleaned_line.replace("Current State Summary:", "").strip())
            elif cleaned_line.startswith("Recommendation Summary:"):
                doc.add_paragraph("Recommendation:", style='Heading 4')
                doc.add_paragraph(cleaned_line.replace("Recommendation Summary:", "").strip())
            elif cleaned_line.startswith("Implementation Items:"):
                doc.add_paragraph("Implementation Items:", style='Heading 4')
            elif line.startswith("•"):
                doc.add_paragraph(cleaned_line, style='List Bullet')
            elif cleaned_line.startswith("Level of Investment:"):
                doc.add_paragraph(f"Level of Investment: {cleaned_line.split(':')[1].strip()}")
                doc.add_paragraph()  # Add an empty paragraph for spacing between items


def create_samm_report(findings, roadmap, output_file, template_file=None):
    if template_file:
        doc = Document(template_file)
        doc.add_page_break()
    else:
        doc = Document()
        doc.add_heading('Application Security Program Assessment Report', 0)

    # Add Findings section
    add_findings_section(doc, findings)

    # Add page break
    doc.add_page_break()

    # Add Roadmap section
    add_roadmap_section(doc, roadmap)

    # Save the document
    doc.save(output_file)

def main():
    parser = argparse.ArgumentParser(description='Generate Application Security Program Assessment report')
    parser.add_argument('--findings-file', required=True, help='Path to JSON file containing findings')
    parser.add_argument('--roadmap-file', required=True, help='Path to text file containing roadmap')
    parser.add_argument('--output', required=True, help='Path to output Word document')
    parser.add_argument('--template', required=True, help='Path to template Word document')
    args = parser.parse_args()

    # Load JSON files
    findings = load_json_file(args.findings_file)
    
    # Load roadmap text file
    with open(args.roadmap_file, 'r') as file:
        roadmap = file.read()

    # Create the report
    create_samm_report(findings, roadmap, args.output, args.template)

    print(f"Report generated: {args.output}")


if __name__ == "__main__":
    main()
