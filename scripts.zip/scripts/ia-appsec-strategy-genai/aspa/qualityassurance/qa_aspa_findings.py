#!/usr/bin/env python3

"""
QA_ASPA_findings_anything.py 

This script performs Quality Assurance on findings using the OWASP SAMM model.
It creates a new QA thread in the given workspace to isolate QA processing.
It uses AnythingLLM to analyze the findings and generate a consolidated QA report.

Usage: ./QA_ASPA_findings_anything.py --framework-file <path-to-framework-file> --findings-file <path-to-findings-file> --workspace-name <existing-workspace> --output-file <path-to-output-file> [--debug]

"""

import argparse
import datetime
import os
import logging
import sys
import time
import requests
import json
import copy

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

QA_THREAD_NAME = "QA-thread"

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

def setup_logging(debug):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

LLM_PROMPT_TEMPLATE = '''Perform a quality assurance assessment of the following analysis based on the OWASP SAMM model.
Compare the notes, gaps, and recommendations in the finding file with the provided framework question and attributes.

Framework:
Domain: {domain}
Security Practice: {practice}
Security Stream: {stream}
Question ID: {question_id}

Question: {question}

Attributes:
{attributes}

Finding:
{finding_data}

Please provide your analysis in valid JSON format using the following structure:

{{
    "alignment": "Aligns" or "Does NOT Align",
    "explanation": "Briefly explain why the finding aligns or does not align with the OWASP SAMM model."
}}

If the finding does not align with the framework is incorrect or incomplete, include a "recommendations" field like this:

{{
    "recommendations": [
        "Recommendation 1",
        "Recommendation 2",
        ...
    ]
}}

Ensure your response is in valid JSON format for easy parsing. Do not include any text outside of the JSON structure.'''

def get_workspace_slug(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        for workspace in workspaces:
            if workspace['name'] == workspace_name:
                return workspace['slug']
    logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
    return None

def load_framework(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def load_findings(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def process_question(domain, practice, stream, question_id, question_data, finding_data, workspace_slug, qa_slug):
    question = question_data.get('question', 'No question provided')
    attributes = question_data.get('attributes', [])
    
    llm_prompt = LLM_PROMPT_TEMPLATE.format(
        domain=domain,
        practice=practice,
        stream=stream,
        question_id=question_id,
        question=question,
        attributes=json.dumps(attributes, indent=2),
        finding_data=json.dumps(finding_data, indent=2)
    )

    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/{qa_slug}/chat"
    payload = {
        "message": llm_prompt,
        "mode": "query"
    }

    output = ""
    request_delay = 1
    max_retries = 3
    retry_delay = 3

    logging.info(f"Waiting {request_delay} seconds before sending request...")
    time.sleep(request_delay)

    logging.debug(f"Sending the following prompt to LLM:\n{llm_prompt}")

    for attempt in range(max_retries):
        logging.debug(f"Sending request to Anything-LLM API (Attempt {attempt + 1}/{max_retries})")
        try:
            response = requests.post(api_url, json=payload, headers=headers, timeout=120)
            
            if response.status_code == 200:
                llm_output = response.json()['textResponse']
                logging.debug(f"Received response from LLM:\n{llm_output}")
                output = llm_output.strip()
                break
            elif response.status_code == 500:
                if attempt < max_retries - 1:
                    logging.warning(f"Received 500 error. Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                else:
                    logging.error(f"Anything-LLM API request failed after {max_retries} attempts")
                    output = json.dumps({
                        "alignment": "Unknown",
                        "explanation": f"Error: API request failed after {max_retries} attempts"
                    })
            else:
                logging.error(f"Anything-LLM API request failed with status code {response.status_code}")
                logging.error(f"Response: {response.text}")
                output = json.dumps({
                    "alignment": "Unknown",
                    "explanation": f"Error: API request failed with status code {response.status_code}"
                })
                break
        except requests.exceptions.RequestException as e:
            logging.error(f"Request exception occurred: {str(e)}")
            if attempt < max_retries - 1:
                logging.warning(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                output = json.dumps({
                    "alignment": "Unknown",
                    "explanation": f"Error: {str(e)}"
                })

    try:
        qa_result = json.loads(output)
        return qa_result
    except json.JSONDecodeError:
        logging.error(f"Error decoding JSON response for question {question_id}")
        return {
            "alignment": "Unknown",
            "explanation": "Error decoding JSON response"
        }

def create_new_QA_thread(workspace_slug, thread_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/new"
    payload = {
        "name": thread_name,
    }

    response = requests.post(api_url, json=payload, headers=headers, timeout=120)
    if response.status_code == 200:
        response_text = json.loads(response.text)
        qa_slug = response_text['thread']['slug']
        logging.info(f"Created new QA thread {thread_name} with slug id: {qa_slug}")
        return qa_slug
    else:
        logging.error(f"Failed to create new QA thread {thread_name}: {response.status_code}")
        return None

def main():
    parser = argparse.ArgumentParser(description="Perform QA on findings to ensure alignment with the OWASP SAMM model.")
    parser.add_argument("--framework-file", required=True, help="Path to the framework JSON file")
    parser.add_argument("--findings-file", required=True, help="Path to the findings JSON file")
    parser.add_argument("--workspace-name", required=True, help="Name of the existing workspace to use")
    parser.add_argument("--output-file", required=True, help="Path to the output JSON file")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    setup_logging(args.debug)

    if not os.path.isfile(args.framework_file):
        logging.error(f"Error: Framework file specified {args.framework_file} must be a valid file.")
        sys.exit(1)

    if not os.path.isfile(args.findings_file):
        logging.error(f"Error: Findings file specified {args.findings_file} must be a valid file.")
        sys.exit(1)

    start_time = time.time()

    # Load framework and findings
    framework = load_framework(args.framework_file)
    findings = load_findings(args.findings_file)

    # Get workspace slug
    workspace_slug = get_workspace_slug(args.workspace_name)
    if not workspace_slug:
        logging.error(f"Workspace '{args.workspace_name}' not found. Exiting.")
        sys.exit(1)
    logging.debug(f"Retrieved workspace slug: {workspace_slug}")

    # Create new QA thread
    qa_slug = create_new_QA_thread(workspace_slug=workspace_slug, thread_name=QA_THREAD_NAME)
    if not qa_slug:
        logging.error("Failed to create QA thread, exiting")
        sys.exit(1)

    # Initialize output data structure
    output_data = {}

    # Process questions and findings
    for domain, practices in framework.items():
        output_data[domain] = {}
        for practice, streams in practices.items():
            output_data[domain][practice] = {}
            for stream, questions in streams.items():
                output_data[domain][practice][stream] = {}
                for question_id, question_data in questions.items():
                    logging.info(f"Processing question: {question_id}")
                    finding_data = findings.get(domain, {}).get(practice, {}).get(stream, {}).get(question_id, {})
                    
                    if not finding_data:
                        qa_result = {
                            "alignment": "Incomplete",
                            "explanation": "No finding data available for this question.",
                            "recommendations": ["Provide notes, gaps, and recommendations for this question."]
                        }
                    else:
                        qa_result = process_question(domain, practice, stream, question_id, question_data, finding_data, workspace_slug, qa_slug)
                    
                    output_data[domain][practice][stream][question_id] = qa_result
                    
                    # Save the updated output after each question
                    with open(args.output_file, 'w') as f:
                        json.dump(output_data, f, indent=2)
                    
                    time.sleep(1)  # Add a small delay between requests to avoid rate limiting

    end_time = time.time()
    total_time = end_time - start_time
    runtime = str(datetime.timedelta(seconds=int(total_time)))
    print(f"QA process completed")
    print(f"Total run time: {runtime}")

if __name__ == "__main__":
    main()
