# Quality Assurance

The quality assurance scripts ensure the accuracy and reliability of the application security program assessment (ASPA) results before proceeding to roadmap generation and reporting.

## Prerequisites
- Processed ASPA results (and scored findings if maturity scoring was performed)
- Processed ASPA RoadMap

## QA Steps
1. **QA Process**
   1. Run `qa_aspa_findings.py`
   2. **Inputs**
      1. --framework-file [path/to/SAMM/framework_file] = Path to the SAMM framework file
      2. --findings-file [path/to/processed_results] = Path to processed ASPA findings file
      3. --workspace-name [workspace] = Name of the existing workspace to use
      4. --output-file [path/to/output_file].json = Path for the output file with QA results
   3. **Outputs**
      1. QA results for each finding
      2. Summary of QA results in JSON and CSV formats

2. **QA ASPA Findings Benchmark** 
   1. Run `aspa_findings_benchmark.py`
   2. **Inputs**
      1. --findings-file [path/to/findings_file] = Path to the findings file to benchmark
      2. --workspace-name [workspace] = Name of the existing workspace to use
      3. --output-file [path/to/output/file] = Path for the output file with benchmark results
   3. **Outputs**
      1. Comparison of findings against predefined benchmarks
      2. Consistency and accuracy validation results

3. **Roadmap QA**
   1. Run `qa_roadmap_aspa_whole.py` to perform QA on the entire roadmap
   2. **Inputs**
      1. --roadmap-file [path/to/roadmap_file] = Path to the roadmap text file
      2. --workspace-name [workspace] = Name of the existing workspace to use
      3. --output-file [path/to/output_file] = Path to the output JSON file
      4. --debug (optional) = Enable debug logging
   3. **Outputs**
      1. JSON file containing QA analysis of the roadmap, including:
         - Alignment assessment
         - Risk-based prioritization evaluation
         - Consideration of dependencies
         - Recommendations for improvement


## Additional Notes
- The QA phase validates the consistency and accuracy of the ASPA results
- QA must be completed on the processed ASPA results before proceeding to Roadmap Generation
- The QA'd findings serve as inputs for the final Reporting phase
