#!/usr/bin/env python3

"""
This script performs Quality Assurance on an OWASP SAMM RoadMap.
It creates a new QA thread in the given workspace to isolate QA processing.
It uses AnythingLLM to analyze the roadmap and generate a consolidated QA report.

Usage: qa_roadmap_aspa_whole.py --roadmap-file <path-to-roadmap-file> --workspace-name <existing-workspace> --output-file <path-to-output-file> [--debug]

"""

import argparse
import datetime
import os
import logging
import sys
import time
import requests
import json

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

QA_THREAD_NAME = "QA-SAMM-RoadMap-thread"

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

def setup_logging(debug):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

LLM_PROMPT_TEMPLATE = '''Perform a quality assurance assessment of the following OWASP SAMM RoadMap.
Compare the roadmap with the information in the "notes_" and "transcript_" files in the workspace, including current state, gaps, and recommendations.

RoadMap:
{roadmap}

Please provide your analysis in valid JSON format using the following structure:

{{
    "alignment": "Aligns" or "Does NOT Align",
    "explanation": "Briefly explain why the roadmap aligns or does not align with the information in the notes and transcripts.",
    "risk_based_prioritization": "Yes" or "No",
    "prioritization_explanation": "Explain how well the roadmap prioritizes actions based on risk, current initiatives, and ease of implementation.",
    "dependencies_considered": "Yes" or "No",
    "dependencies_explanation": "Explain how well the roadmap considers dependencies between actions (what needs to be done first).",
    "recommendations": [
        "Recommendation 1",
        "Recommendation 2",
        ...
    ]
}}

Ensure your response is in valid JSON format for easy parsing. Do not include any text outside of the JSON structure.'''

def get_workspace_slug(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        for workspace in workspaces:
            if workspace['name'] == workspace_name:
                return workspace['slug']
    logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
    return None

def load_file(file_path):
    with open(file_path, 'r') as file:
        return file.read()

def process_roadmap(roadmap, workspace_slug, qa_slug):
    llm_prompt = LLM_PROMPT_TEMPLATE.format(roadmap=roadmap)

    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/{qa_slug}/chat"
    payload = {
        "message": llm_prompt,
        "mode": "query"
    }

    output = ""
    request_delay = 1
    max_retries = 3
    retry_delay = 3

    logging.info(f"Waiting {request_delay} seconds before sending request...")
    time.sleep(request_delay)

    logging.debug(f"Sending the following prompt to LLM:\n{llm_prompt}")

    for attempt in range(max_retries):
        logging.debug(f"Sending request to Anything-LLM API (Attempt {attempt + 1}/{max_retries})")
        try:
            response = requests.post(api_url, json=payload, headers=headers, timeout=120)
            
            if response.status_code == 200:
                llm_output = response.json()['textResponse']
                logging.debug(f"Received response from LLM:\n{llm_output}")
                output = llm_output.strip()
                break
            elif response.status_code == 500:
                if attempt < max_retries - 1:
                    logging.warning(f"Received 500 error. Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                else:
                    logging.error(f"Anything-LLM API request failed after {max_retries} attempts")
                    output = json.dumps({
                        "alignment": "Unknown",
                        "explanation": f"Error: API request failed after {max_retries} attempts"
                    })
            else:
                logging.error(f"Anything-LLM API request failed with status code {response.status_code}")
                logging.error(f"Response: {response.text}")
                output = json.dumps({
                    "alignment": "Unknown",
                    "explanation": f"Error: API request failed with status code {response.status_code}"
                })
                break
        except requests.exceptions.RequestException as e:
            logging.error(f"Request exception occurred: {str(e)}")
            if attempt < max_retries - 1:
                logging.warning(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                output = json.dumps({
                    "alignment": "Unknown",
                    "explanation": f"Error: {str(e)}"
                })

    try:
        qa_result = json.loads(output)
        return qa_result
    except json.JSONDecodeError:
        logging.error(f"Error decoding JSON response")
        return {
            "alignment": "Unknown",
            "explanation": "Error decoding JSON response"
        }

def create_new_QA_thread(workspace_slug, thread_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/new"
    payload = {
        "name": thread_name,
    }

    response = requests.post(api_url, json=payload, headers=headers, timeout=120)
    if response.status_code == 200:
        response_text = json.loads(response.text)
        qa_slug = response_text['thread']['slug']
        logging.info(f"Created new QA thread {thread_name} with slug id: {qa_slug}")
        return qa_slug
    else:
        logging.error(f"Failed to create new QA thread {thread_name}: {response.status_code}")
        return None

def main():
    parser = argparse.ArgumentParser(description="Perform QA on OWASP SAMM RoadMap.")
    parser.add_argument("--roadmap-file", required=True, help="Path to the roadmap text file")
    parser.add_argument("--workspace-name", required=True, help="Name of the existing workspace to use")
    parser.add_argument("--output-file", required=True, help="Path to the output JSON file")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    setup_logging(args.debug)

    if not os.path.isfile(args.roadmap_file):
        logging.error(f"Error: Roadmap file specified {args.roadmap_file} must be a valid file.")
        sys.exit(1)

    start_time = time.time()

    # Load roadmap
    roadmap = load_file(args.roadmap_file)

    # Get workspace slug
    workspace_slug = get_workspace_slug(args.workspace_name)
    if not workspace_slug:
        logging.error(f"Workspace '{args.workspace_name}' not found. Exiting.")
        sys.exit(1)
    logging.debug(f"Retrieved workspace slug: {workspace_slug}")

    # Create new QA thread
    qa_slug = create_new_QA_thread(workspace_slug=workspace_slug, thread_name=QA_THREAD_NAME)
    if not qa_slug:
        logging.error("Failed to create QA thread, exiting")
        sys.exit(1)

    # Process roadmap
    qa_result = process_roadmap(roadmap, workspace_slug, qa_slug)

    # Save the output
    with open(args.output_file, 'w') as f:
        json.dump(qa_result, f, indent=2)

    end_time = time.time()
    total_time = end_time - start_time
    runtime = str(datetime.timedelta(seconds=int(total_time)))
    print(f"QA process completed")
    print(f"Total run time: {runtime}")

if __name__ == "__main__":
    main()
