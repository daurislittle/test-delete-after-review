#!/usr/bin/env python3

"""
QA_Findings_anything.py 

This script creates a new QA thread in the given workspace to isolate QA processing previous analysis work.
This script retrieves a processed finding and bundles it along w/ the original source code file and sends it to AnythingLLM. 
The prompt is structured so that it uses the embedded codebase for full codebase context. 
The prompt is instructed to perform QA on the finding to ensure it's accurate.

Usage: ./qa_scr_findings_anything.py --processed-findings <path-to-processed-semgrep> --workspace-name <existing-workspace> [--debug]

"""

import argparse
import datetime
import os
import logging
import sys
import time
import requests
import json
import csv

EXCLUDED_FILES = [
    ".env", ".git", ".zip", ".ico", ".jpg", ".pdf", ".svg", ".woff", ".woff2", ".png", ".jpeg", ".gif", ".bmp", 
    ".tiff", ".dll", ".webp", ".exe", ".pdb", ".DS_Store", ".cache"
]

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

QA_THREAD_NAME = "QA-thread"

# Set the maximum number of characters for smart truncation
MAX_FINDING_LINES_LENGTH = 5000  # Maximum length for the 'lines' field in the finding JSON
MAX_SOURCE_CODE_LENGTH = 200000    # Maximum length for the truncated source code

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

def setup_logging(debug):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

LLM_PROMPT_TEMPLATE = '''Perform a quality assurance assessment of the following analysis. This analysis was for a Semgrep vulnerability.
Due to prompt size limitations, you will have only the applicable section of original source code file in the prompt.
To aid your assessment use the context of the provided codebase embedded in the workspace. 
The codebase is organized into sections marked by <<<FILE: >>> tags, with each file's content following its tag until the next file tag or an <<<END FILE>>> marker.
Included below to be used in the assessment are the original Semgrep finding, the relevant source code section (applicable section of the original source code file) and the previous analysis.
Focus your analysis on the relevant code section. 

Semgrep Finding, which includes the path of the file in question:
{finding_json}
Relevant code section (focus your analysis here):
{specific_code}
Previous analysis:
{previous_llm_output}

Please provide your analysis in valid JSON format using the following structure:

{{
    "Prior Analysis Accuracy": "YES or NO",
    "Vulnerability Assessment": "TRUE or FALSE",
    "Justification": "Provide a brief explanation for your assessment, including key factors that influenced your decision"
}}

Ensure your response is in valid JSON format for easy parsing. Do not include any text outside of the JSON structure.'''

def get_workspace_slug(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        for workspace in workspaces:
            if workspace['name'] == workspace_name:
                return workspace['slug']
    logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
    return None

def truncate_finding_json(finding, max_lines_length):
    if 'extra' in finding and 'lines' in finding['extra']:
        lines = finding['extra']['lines']
        if len(lines) > max_lines_length:
            # Truncate the lines field
            truncated_lines = lines[:max_lines_length - 3] + '...'
            finding['extra']['lines'] = truncated_lines
    
    return json.dumps(finding)

def get_finding_artifacts(finding_path):
    # get the actual finding json file
    with open(os.path.join(finding_path, "finding.json"), 'r') as file:
        finding_json = json.load(file)
        # Truncate the finding JSON
        truncated_finding_json = truncate_finding_json(finding_json, MAX_FINDING_LINES_LENGTH)

    with open(os.path.join(finding_path, "specific_code.txt"), 'r') as file:
        specific_code = file.read()

    # get the previous llm output
    with open(os.path.join(finding_path, "llm_output.txt"), 'r') as file:
        previous_llm_output = file.read()

    return truncated_finding_json, specific_code, previous_llm_output

def load_qa_state(findings_dir):
    qa_state_file = os.path.join(findings_dir, "QA_state.json")
    if os.path.exists(qa_state_file):
        with open(qa_state_file, 'r') as f:
            return json.load(f)
    return {"processed_findings": [], "failed_findings": []}

def save_qa_state(findings_dir, qa_state):
    qa_state_file = os.path.join(findings_dir, "QA_state.json")
    with open(qa_state_file, 'w') as f:
        json.dump(qa_state, f, indent=2)

def load_json_rollup(file_path):
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            return {item['finding_id']: item for item in json.load(f)}
    return {}

def save_json_rollup(file_path, data):
    sorted_data = sorted(data.values(), key=lambda x: x['finding_id'])
    with open(file_path, 'w') as f:
        json.dump(sorted_data, f, indent=2)

def json_to_csv(json_data, csv_file_path):
    with open(csv_file_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=["finding_id", "Prior Analysis Accuracy", "Vulnerability Assessment", "Justification"])
        writer.writeheader()
        for item in json_data:
            writer.writerow(item)

def process_findings(findings_dir, workspace_slug, qa_slug, debug=False):
    qa_state = load_qa_state(findings_dir)
    json_rollup_file = os.path.join(findings_dir, "QA_summary_rollup.json")
    csv_rollup_file = os.path.join(findings_dir, "QA_summary_rollup.csv")
    
    json_rollup = load_json_rollup(json_rollup_file)

    for item in os.listdir(findings_dir):
        item_path = os.path.join(findings_dir, item)
        if os.path.isdir(item_path) and not item.startswith('.'): 
            finding_id = item

            if finding_id in qa_state["processed_findings"]:
                logging.info(f"Skipping already processed finding: {finding_id}")
                continue

            logging.info(f"Performing QA of finding {finding_id}")

            try:
                finding_json, specific_code, previous_llm_output = get_finding_artifacts(finding_path=item_path)

                llm_prompt, output = send_prompt_to_llm(workspace_slug=workspace_slug, qa_slug=qa_slug, finding_json=finding_json, specific_code=specific_code, previous_llm_output=previous_llm_output)

                # Parse the JSON output
                qa_result = json.loads(output)
                qa_result['finding_id'] = finding_id

                # Update JSON rollup
                json_rollup[finding_id] = qa_result

                output_file = os.path.join(findings_dir, finding_id, "QA_summary.json")
                with open(output_file, 'w') as f:
                    json.dump(qa_result, f, indent=2)

                output_file = os.path.join(findings_dir, finding_id, "QA_llm_prompt.txt")
                with open(output_file, 'w') as f:
                    f.write(llm_prompt)

                qa_state["processed_findings"].append(finding_id)
                if finding_id in qa_state["failed_findings"]:
                    qa_state["failed_findings"].remove(finding_id)
                save_qa_state(findings_dir, qa_state)

            except Exception as e:
                logging.error(f"Error processing finding {finding_id}: {str(e)}")
                if finding_id not in qa_state["failed_findings"]:
                    qa_state["failed_findings"].append(finding_id)
                save_qa_state(findings_dir, qa_state)

    # Save JSON rollup
    save_json_rollup(json_rollup_file, json_rollup)

    # Create CSV from JSON rollup
    json_to_csv(sorted(json_rollup.values(), key=lambda x: x['finding_id']), csv_rollup_file)

    logging.info(f"Successfully updated QA_summary_rollup.json at: {json_rollup_file}")
    logging.info(f"Successfully created QA_summary_rollup.csv at: {csv_rollup_file}")

def send_prompt_to_llm(workspace_slug, qa_slug, finding_json, specific_code, previous_llm_output, request_delay=1, max_retries=3, retry_delay=3):
    llm_prompt = LLM_PROMPT_TEMPLATE.format(
        finding_json=finding_json,
        specific_code=specific_code,
        previous_llm_output=previous_llm_output
    )

    output = ""
            
    # Use Anything-LLM API with delay and retry logic
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/{qa_slug}/chat"
    payload = {
        "mode": "query",
        "message": llm_prompt
    }

    # Delay before making the request
    logging.info(f"Waiting {request_delay} seconds before sending request...")
    time.sleep(request_delay)

    logging.debug(f"Sending the following prompt to LLM:\n{llm_prompt}")
    logging.debug(f"Payload being sent to LLM API: {json.dumps(payload, indent=2)}")

    for attempt in range(max_retries):
        logging.info(f"Sending request to Anything-LLM API (Attempt {attempt + 1}/{max_retries})")
        response = requests.post(api_url, json=payload, headers=headers, timeout=120)
        
        if response.status_code == 200:
            llm_output = response.json()['textResponse']
            logging.debug(f"Received response from LLM:\n{llm_output}")
            output = llm_output.replace("'''","").replace("json", "").replace("\n","")
            break
        elif response.status_code == 500:
            if attempt < max_retries - 1:
                logging.warning(f"Received 500 error. Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                logging.error(f"Anything-LLM API request failed after {max_retries} attempts")
                output += f"\nError during LLM analysis: API request failed after {max_retries} attempts\n"
                output += f"Final response: {response.text}\n"
                logging.error(f"Final response: {response.text}")
        else:
            logging.error(f"Anything-LLM API request failed with status code {response.status_code}")
            logging.error(f"Response: {response.text}")
            logging.debug(f"Request payload that caused the error: {json.dumps(payload, indent=2)}")
            output += f"\nError during LLM analysis: API request failed with status code {response.status_code}\n"
            output += f"Response: {response.text}\n"
            break

    return llm_prompt, output

def create_new_QA_thread(workspace_slug, thread_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/thread/new"
    payload = {
        "name": thread_name,
    }

    response = requests.post(api_url, json=payload, headers=headers, timeout=120)
    # NOTE: this API will return a 200 even when it creates a thread with a duplicate name since the slug is unique.
    if response.status_code == 200:
        response_text = json.loads(response.text)
        qa_slug = response_text['thread']['slug']
        logging.info(f"Created new QA thread {thread_name} with slug id: {qa_slug}")
        return qa_slug
    else:
        logging.error(f"Failed to created new QA thread {thread_name}: {response.status_code}")
        return False

def main():
    parser = argparse.ArgumentParser(description="Perform QA on previous findings to ensure accuracy.")
    parser.add_argument("--findings-dir", required=True, help="Path to processed Semgrep findings directory")
    parser.add_argument("--workspace-name", required=True, help="Name of the existing workspace to use")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    setup_logging(args.debug)

    if not os.path.isdir(args.findings_dir):
        logging.error(f"Error: Findings directory specifed {args.findings_dir} must be a valid directory.")
        sys.exit(1)

    start_time = time.time()

    # Get workspace slug
    workspace_slug = get_workspace_slug(args.workspace_name)
    if not workspace_slug:
        logging.error(f"Workspace '{args.workspace_name}' not found. Exiting.")
        sys.exit(1)
    logging.debug(f"Retrieved workspace slug: {workspace_slug}")

    # Create new thread for this QA task so it is isolated from the prior thread
    qa_slug = create_new_QA_thread(workspace_slug=workspace_slug, thread_name=QA_THREAD_NAME)
    if not(qa_slug):
        logging.error("Failed to create QA thread, exiting")
        sys.exit(1)

    # QA the processed findings
    process_findings(args.findings_dir, workspace_slug=workspace_slug, qa_slug=qa_slug, debug=True)

    end_time = time.time()
    total_time = end_time - start_time
    runtime = str(datetime.timedelta(seconds=int(total_time)))
    print(f"QA process completed")
    print(f"Total run time: {runtime}")

if __name__ == "__main__":
    main()
