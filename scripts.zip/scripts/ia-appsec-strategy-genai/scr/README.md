# Secure Code Review
The scripts in this repo support automation of secure code review (SCR) using Semgrep and Anything LLM.  
The SCR workflow is comprised of 4 processes, each process is described in detail below:
1. Preprocessing
2. Processing
3. Quality Assurance
4. Reporting

Please refer to the following flowchart for a visual outline of the workflow:
[SCR Lucidchart flow diagram](https://lucid.app/lucidchart/599a1ee8-0827-48fd-bfa5-eeba6166a562/edit?viewport_loc=43%2C-196%2C3298%2C1796%2C0_0&invitationId=inv_0df103d9-4b55-4bd4-b79e-5bba64304a00)

## Preprocessing
The preprocessing scripts prepare a code base for upload to Anything LLM, then create the workspace in Anything LLM and upload the prepared code files.

### Prequisites
- Semgrep 
- Anything LLM 
- python-magic: pip3 install python-magic

### Setup:  
- Prepare your directory structure as described below prior to running any scripts. 
   >       input_directory/
   >         repo1/
   >            [files and subdirectories] 
   >         repo2/
   >            [files and subdirectories] 
   >         ...
- For very large codebases, consider breaking the codebase into manageable groups. This will vary according to the size of the codebase but 1 to 3 repos is a good starting point. Doing this upfront helps ensure consistency throughout the workflow. Each group of repos needs to follow the directory structure outlined above since each group will need to run through the steps below.
- Generate a SEMGREP_APP_TOKEN if you don't already have one. This will cause semgrep to use pro rules in addition to community rules. If a large codebase has been broken down into groups, run semgrep on each group. 
- Create environment variables for the Anything LLM API:
  - ANYTHING_LLM_BASE_URL=http://localhost:3001
  - ANYTHING_LLM_API_KEY

### Preprocessing Steps
1. Run semgrep on the codebase. 
   1. semgrep scan --config auto --pro --json --no-git-ignore [src_codebase] >> [semgrep_output_filename].json
2. Run script llm_codebase_preparer.py
   1. This script expects an empty root directory. In the directory structure outlined above input_directory should have only subdirectories and no files
   2. **Input**
      1. Path to the input_directory described above.
   3. **Output**
      1. This script creates a directory at the same level as input_directory and appends "_chunks" to the name of the root and all subdirectories.
         >       input_directory_chunks/
         >         repo1_chunks/
         >           chunk1.txt
         >           chunk2.txt
         >           ...
         >         repo2_chunks/
         >           chunk1.txt
         >           chunk2.txt
         >           ...
         >          ...
   4. Example:   
      Starting with a directory structure that looks like the following:   
      ![image](/scr/docs/images/codebase_preparer_before.png)   

      Where the example directories map to the setup described above as follows: 
      - scr-demo = input_directory
        - vulnerable-node-1 = repo1
        - vulnerable-node-2 = repo2   
  
      Using this command:   
      > ./llm_codebase_preparer.py /[YourPath]/scr-demo              

      The resulting directory structure will look like this:   
      ![image](/scr/docs/images/codebase_preparer_after.png)   


3. Run script llm_codebase_verifier.py
   1. This script verifies the integrity of the chunked files created by llm_codebase_preparer by comparing the original files with their chunked versions to ensure all content is preserved.
   2. **Inputs**
      1. --source-dir = The same path used for llm_codebase_preparer (input_directory) above
      2. --chunk-dir = Path to the "_chunks" directory that was created by llm_codebase_preparer
   3. **Output**
      1. Summary of the verification process, printed to stdout. Check the output for any missing or mismatched files. 
      2. Check the output and address any discrepancies before moving on.
   4. Example:   
      Continuing from the example above for preprocessing, use the following command:
      > ./llm_codebase_verifier.py --source-dir /[YourPath]/scr-demo --chunk-dir /[YourPath]/scr-demo_chunks  

4. Run script prep_anything_workspace.py
   1. The script creates the workspace in Anything LLM, then uploads the chunk files and embeds them in the workspace.
   2. If a large codebase has been broken down into groups, create a separate workspace for each group.
   3. **Inputs**
      1. --workspace-name = Name of the workspace to create. The script will error out if the workspace already exists.
      2. --artifacts-dir = Path to the "_chunks" directory
      3. --system-prompt = Prompt for Anything LLM. There is a standard prompt available in this repository at [/scr/preprocessing/system_prompts/scr_prompt.txt](/scr/preprocessing/system_prompts/scr_prompt.txt)
   4. **Outputs**
      1. New workspace in Anything LLM
      2. Code chunk files uploaded and embedded into the newly created workspace
   5. Example:    
      Continuing with the same example, use the following command:
      > ./prep_anything_workspace.py --workspace-name [NewWorkspaceName] --artifacts-dir /[YourPath]/scr-demo_chunks --system-prompt [LLM Prompt]

## Processing

### Prerequisites
- Anything LLM workspace with code chunk files embedded
- Semgrep output JSON file as described in step 1 of Preprocessing
- Original source code

### Processing Steps
1. Run script process_semgrep_anything.py
   1. This script iterates through the semgrep output json, combining it with the relevant source code section, and prompts Anything LLM to analyze the Semgrep finding.
   2. Note that this script tracks its processing state so if it is interrupted before completing, simply rerun it and it will skip previously processed findings.
   3. **Inputs**
      1. --base-dir = Base directory of the source code
      2. --input = Path to the Semgrep JSON file
      3. --workspace-name = Name of the existing workspace to use
      4. --output-dir = Directory to store processed findings  
      5. --debug = Enable debug logging
   4. **Outputs**
      1. A series of subdirectories is created under the directory specified by the --output-dir parameter. Each subdirectory contains a set of files that capture the results of the analysis:
         1. finding.json = Semgrep finding
         2. llm_output.txt = Output received from the Anything LLM API
         3. llm_request.txt = Prompt sent to the Anything LLM API
         4. specific_code.txt = Relevant section of source code
         5. summary.txt = Summary of the analysis formatted for readability
   5. Example:   
      Continuing with the same example, use the following command:
      > ./process_semgrep_anything.py \  
      > --base-dir /[YourPath]/scr-demo \  
      > --input /[PathToSemgrepFile]/scr-demo-semgrep.json \  
      > --workspace-name [YourWorkspaceName] \  
      > --output-dir /[YourPath]/scr-demo-findings  

      ![image](/scr/docs/images/scr-demo-folders.png)

## Quality Assurance

### Prequisites: 
Having the results from process_semgrep_anything is a prequisite for QA_findings_anything.

### QA Steps
1. Run the script qa_scr_findings_anything.py
   1. The script in this folder uses Anything LLM to perform QA on the results from process_semgrep_anything.py 
   2. **Inputs**
      1. --findings-dir = Path to processed Semgrep findings directory
      2. --workspace-name = Name of the existing workspace to use
   3. **Outputs**
      1. 2 files are created in each finding folder, alongside the results from process_semgrep_anything:
         1. QA_summary.json has the results of the QA process
         2. QA_llm_prompt.txt has the prompt that was used
      2. 2 files are created in the parent folder of the individual folders:
         1. QA_summary_rollup.json has the complete list of all the individual QA-summary files described above
         2. QA_summary_rollup.csv has the same content but in csv format to support readability
   4. Example:   
      Continuing with the same example:
      > ./qa_scr_findings_anything.py --findings-dir /[YourPath]/scr-demo-findings --workspace-name [YourWorkspaceName]   
2. After completing the QA process your directory structure will look like this: (several findings subdirectories omitted for brevity)   
   ![image](/scr/docs/images/scr-demo-folders-final.png) 

## Reporting
Reporting is in development and is expected to release in Q2 2025. 
