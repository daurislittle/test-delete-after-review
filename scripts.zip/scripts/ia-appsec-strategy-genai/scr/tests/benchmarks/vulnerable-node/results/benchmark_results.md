# SCR Automation Benchmarks

## Semgrep

┌─────────────┐

│ Scan Status │

└─────────────┘

&nbsp; Scanning 54 files with 2352 Code rules:

&nbsp;

&nbsp; Language      Rules   Files          Origin      Rules

&nbsp;─────────────────────────────        ───────────────────

&nbsp; &lt;multilang&gt;      51      53          Pro rules    1292

&nbsp; js              317      12          Community    1060

&nbsp; dockerfile        5       2

&nbsp; yaml             31       1

&nbsp; json              4       1

&nbsp;

┌──────────────┐

│ Scan Summary │

└──────────────┘

Some files were skipped or only partially analyzed.

&nbsp; Partially scanned: 1 files only partially analyzed due to parsing or internal Semgrep errors

&nbsp; Scan skipped: 1 files matching .semgrepignore patterns

&nbsp; For a full list of skipped files, run semgrep with the --verbose flag.

&nbsp;

Ran 405 rules on 53 files: 43 findings.

NOTE: Semgrep missed 4 known SQL Injection flaws

## Codebase_preparer

Completed in less than 1 second

Chunks created for src in directory: /Users/mike.triplett/projects/SCR-automation/vulnerable-node_chunks/src_chunks

Chunking completed

Total run time: 0:00:00

## Codebase_verifier

Completed in less than 1 second

Scanning original directory...

Parsing chunk files...

Comparing files...

&nbsp;

\=== LLM Codebase Verifier Report ===

&nbsp;

Total files in original directory: 17

Total files in chunked files: 17

Missing files: 0

Extra files: 0

Mismatched files: 0

&nbsp;

All files verified successfully!

Verification completed

Total run time: 0:00:00

## Prep_anything_workspace

Completed in 7 seconds

Created workspace: vulnerable-node (slug: vulnerable-node)

Workspace settings applied during creation: openAiTemp=0.5, openAiHistory=5, similarityThreshold=0.25, topN=200, chatMode=query

2025-02-12 17:32:51,781 - INFO - Created document folder: vulnerable-node

Successfully uploaded and moved: chunk1.txt-25cb049b-7457-409d-9da8-28490e39bcd2.json

Uploaded and moved 1 out of 1 files.

Starting embedding process for 1 files...

Successfully updated embeddings for 1 files

Embedding process completed successfully for 1 files.

Workspace 'vulnerable-node' (slug: vulnerable-node) created and populated successfully.

Total run time: 0:00:07

## Process_semgrep_anything

Completed in 25 minutes

Processing 43 findings from /Users/mike.triplett/projects/SCR-automation/vulnerable-node-semgrep/vulnerable-node-semgrep.json

2025-02-12 18:53:17,165 - INFO - Processing finding 1/43: src_Dockerfile:22:1_dockerfile.security.missing-user.missing-user

2025-02-12 18:53:17,166 - INFO - Chars: Original Source: 330 | Truncated Source: N/A | Original JSON: 1788 | Truncated JSON: N/A | Total Prompt: 4409

2025-02-12 18:53:17,166 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:53:17,166 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:53:41,106 - INFO - Successfully processed finding: src_Dockerfile:22:1_dockerfile.security.missing-user.missing-user

2025-02-12 18:53:41,106 - INFO - Processing finding 2/43: src_app.js:16:5_javascript.express.security.audit.express-check-csurf-middleware-usage.express-check-csurf-middleware-usage

2025-02-12 18:53:41,109 - INFO - Chars: Original Source: 2220 | Truncated Source: N/A | Original JSON: 2213 | Truncated JSON: N/A | Total Prompt: 6724

2025-02-12 18:53:41,109 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:53:41,109 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:54:10,071 - INFO - Successfully processed finding: src_app.js:16:5_javascript.express.security.audit.express-check-csurf-middleware-usage.express-check-csurf-middleware-usage

2025-02-12 18:54:10,071 - INFO - Processing finding 3/43: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-default-name

2025-02-12 18:54:10,073 - INFO - Chars: Original Source: 2220 | Truncated Source: N/A | Original JSON: 2136 | Truncated JSON: N/A | Total Prompt: 6647

2025-02-12 18:54:10,073 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:54:10,073 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:54:39,364 - INFO - Successfully processed finding: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-default-name

2025-02-12 18:54:39,364 - INFO - Processing finding 4/43: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-no-domain

2025-02-12 18:54:39,366 - INFO - Chars: Original Source: 2220 | Truncated Source: N/A | Original JSON: 2102 | Truncated JSON: N/A | Total Prompt: 6613

2025-02-12 18:54:39,366 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:54:39,366 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:55:10,751 - INFO - Successfully processed finding: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-no-domain

2025-02-12 18:55:10,751 - INFO - Processing finding 5/43: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-no-expires

2025-02-12 18:55:10,754 - INFO - Chars: Original Source: 2220 | Truncated Source: N/A | Original JSON: 1982 | Truncated JSON: N/A | Total Prompt: 6493

2025-02-12 18:55:10,754 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:55:10,754 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:55:44,301 - INFO - Successfully processed finding: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-no-expires

2025-02-12 18:55:44,301 - INFO - Processing finding 6/43: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-no-httponly

2025-02-12 18:55:44,303 - INFO - Chars: Original Source: 2220 | Truncated Source: N/A | Original JSON: 2061 | Truncated JSON: N/A | Total Prompt: 6572

2025-02-12 18:55:44,303 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:55:44,303 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:56:17,313 - INFO - Successfully processed finding: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-no-httponly

2025-02-12 18:56:17,313 - INFO - Processing finding 7/43: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-no-path

2025-02-12 18:56:17,316 - INFO - Chars: Original Source: 2220 | Truncated Source: N/A | Original JSON: 2060 | Truncated JSON: N/A | Total Prompt: 6571

2025-02-12 18:56:17,316 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:56:17,316 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:56:53,296 - INFO - Successfully processed finding: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-no-path

2025-02-12 18:56:53,297 - INFO - Processing finding 8/43: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-no-secure

2025-02-12 18:56:53,299 - INFO - Chars: Original Source: 2220 | Truncated Source: N/A | Original JSON: 1981 | Truncated JSON: N/A | Total Prompt: 6492

2025-02-12 18:56:53,299 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:56:53,299 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:57:26,769 - INFO - Successfully processed finding: src_app.js:43:9_javascript.express.security.audit.express-cookie-settings.express-cookie-session-no-secure

2025-02-12 18:57:26,769 - INFO - Processing finding 9/43: src_app.js:44:3_javascript.express.security.audit.express-session-hardcoded-secret.express-session-hardcoded-secret

2025-02-12 18:57:26,771 - INFO - Chars: Original Source: 2220 | Truncated Source: N/A | Original JSON: 2473 | Truncated JSON: N/A | Total Prompt: 6984

2025-02-12 18:57:26,771 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:57:26,771 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:57:55,526 - INFO - Successfully processed finding: src_app.js:44:3_javascript.express.security.audit.express-session-hardcoded-secret.express-session-hardcoded-secret

2025-02-12 18:57:55,526 - INFO - Processing finding 10/43: js_jquery.js:2:14226_javascript.lang.security.audit.detect-non-literal-regexp.detect-non-literal-regexp

2025-02-12 18:57:55,530 - INFO - Chars: Original Source: 95785 | Truncated Source: N/A | Original JSON: 35794 | Truncated JSON: 8014 | Total Prompt: 106090

2025-02-12 18:57:55,530 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:57:55,530 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:58:25,924 - INFO - Successfully processed finding: js_jquery.js:2:14226_javascript.lang.security.audit.detect-non-literal-regexp.detect-non-literal-regexp

2025-02-12 18:58:25,924 - INFO - Processing finding 11/43: js_jquery.js:2:15003_javascript.lang.security.audit.prototype-pollution.prototype-pollution-loop.prototype-pollution-loop

2025-02-12 18:58:25,927 - INFO - Chars: Original Source: 95785 | Truncated Source: N/A | Original JSON: 35620 | Truncated JSON: 7840 | Total Prompt: 105916

2025-02-12 18:58:25,928 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:58:25,928 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:59:02,313 - INFO - Successfully processed finding: js_jquery.js:2:15003_javascript.lang.security.audit.prototype-pollution.prototype-pollution-loop.prototype-pollution-loop

2025-02-12 18:59:02,313 - INFO - Processing finding 12/43: routes_login.js:36:26_javascript.express.open-redirect-deepsemgrep.open-redirect-deepsemgrep

2025-02-12 18:59:02,316 - INFO - Chars: Original Source: 1268 | Truncated Source: N/A | Original JSON: 3313 | Truncated JSON: N/A | Total Prompt: 6872

2025-02-12 18:59:02,316 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:59:02,316 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 18:59:38,312 - INFO - Successfully processed finding: routes_login.js:36:26_javascript.express.open-redirect-deepsemgrep.open-redirect-deepsemgrep

2025-02-12 18:59:38,312 - INFO - Processing finding 13/43: routes_login.js:36:26_javascript.express.security.audit.express-open-redirect.express-open-redirect

2025-02-12 18:59:38,314 - INFO - Chars: Original Source: 1268 | Truncated Source: N/A | Original JSON: 3269 | Truncated JSON: N/A | Total Prompt: 6828

2025-02-12 18:59:38,314 - INFO - Waiting 0 seconds before sending request...

2025-02-12 18:59:38,314 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:00:15,962 - INFO - Successfully processed finding: routes_login.js:36:26_javascript.express.security.audit.express-open-redirect.express-open-redirect

2025-02-12 19:00:15,962 - INFO - Processing finding 14/43: views_bought_products.ejs:26:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:00:15,965 - INFO - Chars: Original Source: 1027 | Truncated Source: N/A | Original JSON: 2071 | Truncated JSON: N/A | Total Prompt: 5389

2025-02-12 19:00:15,965 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:00:15,965 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:00:56,131 - INFO - Successfully processed finding: views_bought_products.ejs:26:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:00:56,131 - INFO - Processing finding 15/43: views_bought_products.ejs:27:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:00:56,133 - INFO - Chars: Original Source: 1027 | Truncated Source: N/A | Original JSON: 2073 | Truncated JSON: N/A | Total Prompt: 5391

2025-02-12 19:00:56,133 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:00:56,133 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:01:37,257 - INFO - Successfully processed finding: views_bought_products.ejs:27:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:01:37,257 - INFO - Processing finding 16/43: views_bought_products.ejs:28:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:01:37,259 - INFO - Chars: Original Source: 1027 | Truncated Source: N/A | Original JSON: 2065 | Truncated JSON: N/A | Total Prompt: 5383

2025-02-12 19:01:37,259 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:01:37,259 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:02:25,064 - INFO - Successfully processed finding: views_bought_products.ejs:28:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:02:25,064 - INFO - Processing finding 17/43: views_bought_products.ejs:29:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:02:25,065 - INFO - Chars: Original Source: 1027 | Truncated Source: N/A | Original JSON: 2066 | Truncated JSON: N/A | Total Prompt: 5384

2025-02-12 19:02:25,065 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:02:25,065 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:02:57,470 - INFO - Successfully processed finding: views_bought_products.ejs:29:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:02:57,471 - INFO - Processing finding 18/43: views_bought_products.ejs:30:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:02:57,473 - INFO - Chars: Original Source: 1027 | Truncated Source: N/A | Original JSON: 2070 | Truncated JSON: N/A | Total Prompt: 5388

2025-02-12 19:02:57,473 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:02:57,473 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:03:30,288 - INFO - Successfully processed finding: views_bought_products.ejs:30:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:03:30,289 - INFO - Processing finding 19/43: views_bought_products.ejs:31:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:03:30,293 - INFO - Chars: Original Source: 1027 | Truncated Source: N/A | Original JSON: 2068 | Truncated JSON: N/A | Total Prompt: 5386

2025-02-12 19:03:30,293 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:03:30,293 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:04:00,446 - INFO - Successfully processed finding: views_bought_products.ejs:31:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:04:00,446 - INFO - Processing finding 20/43: views_bought_products.ejs:32:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:04:00,452 - INFO - Chars: Original Source: 1027 | Truncated Source: N/A | Original JSON: 2072 | Truncated JSON: N/A | Total Prompt: 5390

2025-02-12 19:04:00,453 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:04:00,453 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:04:31,304 - INFO - Successfully processed finding: views_bought_products.ejs:32:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:04:31,304 - INFO - Processing finding 21/43: views_content.ejs:52:5_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:04:31,307 - INFO - Chars: Original Source: 2193 | Truncated Source: N/A | Original JSON: 2029 | Truncated JSON: N/A | Total Prompt: 6513

2025-02-12 19:04:31,307 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:04:31,307 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:05:01,831 - INFO - Successfully processed finding: views_content.ejs:52:5_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:05:01,832 - INFO - Processing finding 22/43: views_layout.ejs:37:1_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:05:01,836 - INFO - Chars: Original Source: 3363 | Truncated Source: N/A | Original JSON: 2022 | Truncated JSON: N/A | Total Prompt: 7676

2025-02-12 19:05:01,836 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:05:01,836 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:05:34,896 - INFO - Successfully processed finding: views_layout.ejs:37:1_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:05:34,896 - INFO - Processing finding 23/43: views_login.ejs:17:94_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:05:34,908 - INFO - Chars: Original Source: 1180 | Truncated Source: N/A | Original JSON: 2133 | Truncated JSON: N/A | Total Prompt: 5604

2025-02-12 19:05:34,908 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:05:34,908 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:06:06,981 - INFO - Successfully processed finding: views_login.ejs:17:94_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:06:06,982 - INFO - Processing finding 24/43: views_login.ejs:22:46_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:06:06,984 - INFO - Chars: Original Source: 1180 | Truncated Source: N/A | Original JSON: 2080 | Truncated JSON: N/A | Total Prompt: 5551

2025-02-12 19:06:06,984 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:06:06,984 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:06:39,956 - INFO - Successfully processed finding: views_login.ejs:22:46_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:06:39,957 - INFO - Processing finding 25/43: views_product_detail.ejs:8:54_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:06:39,960 - INFO - Chars: Original Source: 3997 | Truncated Source: N/A | Original JSON: 2104 | Truncated JSON: N/A | Total Prompt: 8392

2025-02-12 19:06:39,960 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:06:39,960 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:07:12,389 - INFO - Successfully processed finding: views_product_detail.ejs:8:54_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:07:12,389 - INFO - Processing finding 26/43: views_product_detail.ejs:10:40_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:07:12,393 - INFO - Chars: Original Source: 3997 | Truncated Source: N/A | Original JSON: 2093 | Truncated JSON: N/A | Total Prompt: 8381

2025-02-12 19:07:12,393 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:07:12,393 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:07:45,178 - INFO - Successfully processed finding: views_product_detail.ejs:10:40_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:07:45,178 - INFO - Processing finding 27/43: views_product_detail.ejs:11:33_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:07:45,181 - INFO - Chars: Original Source: 3997 | Truncated Source: N/A | Original JSON: 2081 | Truncated JSON: N/A | Total Prompt: 8369

2025-02-12 19:07:45,181 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:07:45,181 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:08:18,938 - INFO - Successfully processed finding: views_product_detail.ejs:11:33_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:08:18,939 - INFO - Processing finding 28/43: views_product_detail.ejs:12:20_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:08:18,941 - INFO - Chars: Original Source: 3997 | Truncated Source: N/A | Original JSON: 2068 | Truncated JSON: N/A | Total Prompt: 8356

2025-02-12 19:08:18,941 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:08:18,941 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:08:56,411 - INFO - Successfully processed finding: views_product_detail.ejs:12:20_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:08:56,411 - INFO - Processing finding 29/43: views_product_detail.ejs:48:100_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:08:56,414 - INFO - Chars: Original Source: 3997 | Truncated Source: N/A | Original JSON: 2174 | Truncated JSON: N/A | Total Prompt: 8462

2025-02-12 19:08:56,414 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:08:56,414 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:09:29,215 - INFO - Successfully processed finding: views_product_detail.ejs:48:100_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:09:29,215 - INFO - Processing finding 30/43: views_product_detail.ejs:50:108_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:09:29,217 - INFO - Chars: Original Source: 3997 | Truncated Source: N/A | Original JSON: 2164 | Truncated JSON: N/A | Total Prompt: 8452

2025-02-12 19:09:29,217 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:09:29,217 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:10:02,359 - INFO - Successfully processed finding: views_product_detail.ejs:50:108_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:10:02,359 - INFO - Processing finding 31/43: views_product_detail.ejs:51:112_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:10:02,362 - INFO - Chars: Original Source: 3997 | Truncated Source: N/A | Original JSON: 2170 | Truncated JSON: N/A | Total Prompt: 8458

2025-02-12 19:10:02,362 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:10:02,362 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:10:36,262 - INFO - Successfully processed finding: views_product_detail.ejs:51:112_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:10:36,262 - INFO - Processing finding 32/43: views_products.ejs:16:46_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:10:36,265 - INFO - Chars: Original Source: 866 | Truncated Source: N/A | Original JSON: 2131 | Truncated JSON: N/A | Total Prompt: 5288

2025-02-12 19:10:36,266 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:10:36,266 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:11:10,625 - INFO - Successfully processed finding: views_products.ejs:16:46_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:11:10,625 - INFO - Processing finding 33/43: views_products.ejs:16:81_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:11:10,628 - INFO - Chars: Original Source: 866 | Truncated Source: N/A | Original JSON: 2131 | Truncated JSON: N/A | Total Prompt: 5288

2025-02-12 19:11:10,628 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:11:10,628 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:11:47,830 - INFO - Successfully processed finding: views_products.ejs:16:81_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:11:47,831 - INFO - Processing finding 34/43: views_products.ejs:18:44_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:11:47,834 - INFO - Chars: Original Source: 866 | Truncated Source: N/A | Original JSON: 2088 | Truncated JSON: N/A | Total Prompt: 5245

2025-02-12 19:11:47,834 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:11:47,834 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:12:20,558 - INFO - Successfully processed finding: views_products.ejs:18:44_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:12:20,558 - INFO - Processing finding 35/43: views_products.ejs:19:54_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:12:20,561 - INFO - Chars: Original Source: 866 | Truncated Source: N/A | Original JSON: 2107 | Truncated JSON: N/A | Total Prompt: 5264

2025-02-12 19:12:20,561 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:12:20,561 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:12:56,803 - INFO - Successfully processed finding: views_products.ejs:19:54_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:12:56,803 - INFO - Processing finding 36/43: views_products.ejs:19:71_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:12:56,806 - INFO - Chars: Original Source: 866 | Truncated Source: N/A | Original JSON: 2107 | Truncated JSON: N/A | Total Prompt: 5264

2025-02-12 19:12:56,806 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:12:56,806 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:13:35,604 - INFO - Successfully processed finding: views_products.ejs:19:71_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:13:35,604 - INFO - Processing finding 37/43: views_products.ejs:21:24_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:13:35,607 - INFO - Chars: Original Source: 866 | Truncated Source: N/A | Original JSON: 2065 | Truncated JSON: N/A | Total Prompt: 5222

2025-02-12 19:13:35,607 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:13:35,607 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:14:14,158 - INFO - Successfully processed finding: views_products.ejs:21:24_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:14:14,158 - INFO - Processing finding 38/43: views_search.ejs:3:18_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:14:14,161 - INFO - Chars: Original Source: 873 | Truncated Source: N/A | Original JSON: 2041 | Truncated JSON: N/A | Total Prompt: 5205

2025-02-12 19:14:14,161 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:14:14,161 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:14:48,772 - INFO - Successfully processed finding: views_search.ejs:3:18_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:14:48,773 - INFO - Processing finding 39/43: views_search.ejs:23:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:14:48,776 - INFO - Chars: Original Source: 873 | Truncated Source: N/A | Original JSON: 2045 | Truncated JSON: N/A | Total Prompt: 5209

2025-02-12 19:14:48,776 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:14:48,776 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:15:15,918 - INFO - Successfully processed finding: views_search.ejs:23:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:15:15,918 - INFO - Processing finding 40/43: views_search.ejs:24:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:15:15,920 - INFO - Chars: Original Source: 873 | Truncated Source: N/A | Original JSON: 2056 | Truncated JSON: N/A | Total Prompt: 5220

2025-02-12 19:15:15,921 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:15:15,921 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:15:51,887 - INFO - Successfully processed finding: views_search.ejs:24:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:15:51,888 - INFO - Processing finding 41/43: views_search.ejs:25:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:15:51,890 - INFO - Chars: Original Source: 873 | Truncated Source: N/A | Original JSON: 2063 | Truncated JSON: N/A | Total Prompt: 5227

2025-02-12 19:15:51,890 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:15:51,890 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:16:33,295 - INFO - Successfully processed finding: views_search.ejs:25:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:16:33,295 - INFO - Processing finding 42/43: views_search.ejs:26:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:16:33,297 - INFO - Chars: Original Source: 873 | Truncated Source: N/A | Original JSON: 2057 | Truncated JSON: N/A | Total Prompt: 5221

2025-02-12 19:16:33,297 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:16:33,297 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:17:11,072 - INFO - Successfully processed finding: views_search.ejs:26:17_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:17:11,073 - INFO - Processing finding 43/43: views_search.ejs:27:46_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

2025-02-12 19:17:11,075 - INFO - Chars: Original Source: 873 | Truncated Source: N/A | Original JSON: 2124 | Truncated JSON: N/A | Total Prompt: 5288

2025-02-12 19:17:11,075 - INFO - Waiting 0 seconds before sending request...

2025-02-12 19:17:11,075 - INFO - Sending request to Anything-LLM API (Attempt 1/3)

2025-02-12 19:17:41,147 - INFO - Successfully processed finding: views_search.ejs:27:46_javascript.express.security.audit.xss.ejs.explicit-unescape.template-explicit-unescape

&nbsp;

Processing complete. Results saved in /Users/mike.triplett/projects/SCR-automation/process-semgrep-output

&nbsp;

Summary:

Total findings: 43

Processed findings: 43

Skipped findings: 0

Failed findings: 0

Total run time: 0:24:24