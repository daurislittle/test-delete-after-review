# Test files for scr-genai

 ## The benchmarks folder contains benchmarking tests against open source apps created for security testing that have known vulnerabilities.

#### Each benchmark folder contains the source code used to benchmark and the results of the benchmark testing.

### Benchmarks included

| App Name | Repository |
| -------- | ---------- | 
| Vulnerable-node | [GitHub repo](https://github.com/cr0hn/vulnerable-node) |
