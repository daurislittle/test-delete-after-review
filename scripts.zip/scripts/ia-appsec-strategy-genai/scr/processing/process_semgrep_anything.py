#!/usr/bin/env python3

import argparse
import os
import logging
import requests
import json
import time
import datetime
import traceback
from collections import defaultdict

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

# Set the maximum number of characters for smart truncation
MAX_FINDING_LINES_LENGTH = 5000  # Maximum length for the 'lines' field in the finding JSON
MAX_SOURCE_CODE_LENGTH = 200000    # Maximum length for the truncated source code

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

def setup_logging(debug):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

LLM_PROMPT_TEMPLATE = """Analyze the following Semgrep vulnerability finding and relevant code section in the context of the provided codebase. 
The codebase is organized into sections marked by <<<FILE: >>> tags, with each file's content following its tag until the next file tag or an <<<END FILE>>> marker.

Semgrep Finding, which includes the path of the file in question:
{finding_json}

Code mentioned in the Semgrep finding (focus your analysis here):
{specific_code}

Please provide your analysis:
1. Is this a true positive or false positive? (True, False)
2. If it's a true positive, what is the actual severity (Low, Medium, High, Critical)?
3. Concisely explain the vulnerability or why it's a false positive, referring specifically to the code section identified by Semgrep.
4. If it's a true positive, suggest a targeted remediation approach for the specific issue.

Important: You are required to "walk the code" and review other related files (if necessary) to fully determine if the vulnerability is legitimate. This means you should:
- Trace function calls, method invocations, and variable uses through different parts of the codebase.
- Examine how data flows between different components or files.
- Check for any sanitization, validation, or security measures that might be in place in other parts of the code.

If you need to reference other parts of the codebase:
- You'll find the relevant files using its <<<FILE: >>> tag.
- Provide line numbers and code snippets from other relevant files, if necessary (from tracing a function for example).
- When given a full input filepath, perform a fuzzy match to find the closest matching file surrounded by <<< >>> brackets in the provided context.
- Ignore differences in directory depth when fuzzy matching.
- Fuzzy match example: If the input is 'src/merp/src/app/shared/components/video-recording/video-recording.component.ts', it should match to '<<<FILE:src/app/shared/components/video-recording/video-recording.component.spec.ts>>>' despite differences in the initial path.

Your thorough code walk-through and analysis are crucial for accurately assessing the security finding. Our output will be provided to development and security teams so please provide clear, concise explanations of your thought process and any additional code you examined during your analysis.
"""

def get_workspace_slug(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        for workspace in workspaces:
            if workspace['name'] == workspace_name:
                return workspace['slug']
    logging.error(f"Failed to find workspace '{workspace_name}'. Status code: {response.status_code}")
    return None

def load_semgrep_results(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def analyze_findings(data):
    findings = data['results']
    
    severity_categories = defaultdict(list)
    check_categories = defaultdict(list)
    file_categories = defaultdict(list)
    
    for finding in findings:
        severity = finding['extra']['severity']
        check_id = finding['check_id']
        file_path = finding['path']
        
        severity_categories[severity].append(finding)
        check_categories[check_id].append(finding)
        file_categories[file_path].append(finding)
    
    return severity_categories, check_categories, file_categories

def create_finding_id(file_path, line, column, check_id):
    base_name = os.path.basename(file_path)
    dir_name = os.path.dirname(file_path)
    
    if dir_name and not dir_name.endswith('repo'):  # Only prepend dir_name if it's not the root "repo" directory
        base_name = f"{os.path.basename(dir_name)}_{base_name}"
    
    return f"{base_name}:{line}:{column}_{check_id}"

def get_file_content(file_path, base_dir):
    full_path = os.path.join(base_dir, file_path)
    encodings = ['utf-8', 'iso-8859-1', 'cp1252', 'windows-1252']
    
    for encoding in encodings:
        try:
            with open(full_path, 'r', encoding=encoding) as file:
                content = file.read()
            logging.debug(f"Successfully read file {file_path} with encoding {encoding}")
            return content
        except UnicodeDecodeError:
            logging.debug(f"Failed to read {file_path} with encoding {encoding}")
        except Exception as e:
            logging.error(f"Error reading file {file_path}: {str(e)}")
            return ""

def smart_truncate(file_content, start_line, end_line, max_chars=MAX_SOURCE_CODE_LENGTH):
    lines = file_content.splitlines()
    
    # Find the start and end character positions
    start_char = sum(len(line) + 1 for line in lines[:start_line - 1])
    end_char = sum(len(line) + 1 for line in lines[:end_line])
    
    finding_size = end_char - start_char
    
    logging.debug(f"Original content size: {len(file_content)} chars")
    logging.debug(f"Finding size: {finding_size} chars")
    
    if finding_size >= max_chars:
        # If the finding is larger than max_chars, center it within the max_chars
        start = max(0, start_char + (finding_size - max_chars) // 2)
        end = start + max_chars
    else:
        # Calculate context sizes
        remaining_chars = max_chars - finding_size
        context_before = min(start_char, remaining_chars // 2)
        context_after = min(len(file_content) - end_char, remaining_chars - context_before)
        
        # Adjust context_before if we have extra space after
        if context_after < (remaining_chars - context_before):
            context_before += remaining_chars - context_before - context_after
        
        start = max(0, start_char - context_before)
        end = min(len(file_content), end_char + context_after)
    
    truncated_content = file_content[start:end]
    logging.debug(f"Truncated content size: {len(truncated_content)} chars")
    
    if len(truncated_content) > max_chars:
        logging.warning(f"Truncated content exceeds max_chars. Forcefully truncating to {max_chars} chars.")
        truncated_content = truncated_content[:max_chars]
    
    return truncated_content

def load_processing_state(output_dir):
    state_file = os.path.join(output_dir, "processing_state.json")
    if os.path.exists(state_file):
        with open(state_file, 'r') as f:
            return json.load(f)
    return {"processed_findings": [], "failed_findings": []}

def save_processing_state(output_dir, state):
    state_file = os.path.join(output_dir, "processing_state.json")
    with open(state_file, 'w') as f:
        json.dump(state, f, indent=2)

def process_finding(finding, base_dir, file_path, output_dir, workspace_slug, state, total_findings, current_finding, request_delay=0, max_retries=3, retry_delay=3):
    finding_id = create_finding_id(file_path, finding['start']['line'], finding['start']['col'], finding['check_id'])
    
    if finding_id in state["processed_findings"]:
        logging.info(f"Skipping already processed finding {current_finding}/{total_findings}: {finding_id}")
        return "skipped"
    
    logging.info(f"Processing finding {current_finding}/{total_findings}: {finding_id}")

    finding_dir = os.path.join(output_dir, finding_id)
    os.makedirs(finding_dir, exist_ok=True)

    output = f"Finding ID: {finding_id}\n"
    output += f"File: {file_path}\n"
    output += f"Check ID: {finding['check_id']}\n"
    output += f"Severity: {finding['extra']['severity']}\n"
    output += f"Start Line: {finding['start']['line']}\n"
    output += f"End Line: {finding['end']['line']}\n"
    output += f"Message: {finding['extra']['message']}\n"

    # Save finding JSON
    finding_file_path = os.path.join(finding_dir, "finding.json")
    with open(finding_file_path, 'w') as f:
        json.dump(finding, f, indent=2)

    # Extract and save specific content using smart truncation
    file_content = get_file_content(file_path, base_dir)
    original_source_size = len(file_content)
    
    specific_code = smart_truncate(
        file_content,
        finding['start']['line'],
        finding['end']['line'],
        MAX_SOURCE_CODE_LENGTH
    )
    truncated_source_size = len(specific_code)
    
    specific_code_path = os.path.join(finding_dir, "specific_code.txt")
    with open(specific_code_path, 'w') as f:
        f.write(specific_code)

    try:
        # Get original JSON size
        original_json = json.dumps(finding)
        original_json_size = len(original_json)

        # Truncate the finding JSON
        truncated_finding_json = truncate_finding_json(finding, MAX_FINDING_LINES_LENGTH)
        truncated_json_size = len(truncated_finding_json)
        
        llm_prompt = LLM_PROMPT_TEMPLATE.format(
            finding_json=truncated_finding_json,
            specific_code=specific_code
        )
        total_prompt_size = len(llm_prompt)
        
        # Save LLM request prompt
        llm_request_path = os.path.join(finding_dir, "llm_request.txt")
        with open(llm_request_path, 'w') as f:
            f.write(llm_prompt)
        
        # Prepare the log message
        log_parts = [
            f"Original Source: {original_source_size}",
            f"Truncated Source: {'N/A' if truncated_source_size == original_source_size else truncated_source_size}",
            f"Original JSON: {original_json_size}",
            f"Truncated JSON: {'N/A' if truncated_json_size == original_json_size else truncated_json_size}",
            f"Total Prompt: {total_prompt_size}"
        ]
        log_message = " | ".join(log_parts)
        logging.info(f"Chars: {log_message}")

        # Use Anything-LLM API with delay and retry logic
        api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/chat"
        payload = {
            "message": llm_prompt,
            "mode": "chat"
        }
        
        # Delay before making the request
        logging.info(f"Waiting {request_delay} seconds before sending request...")
        time.sleep(request_delay)

        for attempt in range(max_retries):
            logging.info(f"Sending request to Anything-LLM API (Attempt {attempt + 1}/{max_retries})")
            if logging.getLogger().isEnabledFor(logging.DEBUG):
                logging.debug(f"Request payload: {json.dumps(payload, indent=2)}")
            
            try:
                response = requests.post(api_url, json=payload, headers=headers)
                
                if response.status_code == 200:
                    llm_output = response.json()['textResponse']
                    output += "\nLLM Analysis:\n"
                    output += llm_output
                    break
                elif response.status_code == 500:
                    logging.error(f"Received 500 error. Response content: {response.text}")
                    logging.error(f"Response headers: {response.headers}")
                    if attempt < max_retries - 1:
                        logging.warning(f"Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                    else:
                        raise Exception(f"Anything-LLM API request failed after {max_retries} attempts. Last response: {response.text}")
                else:
                    raise Exception(f"Anything-LLM API request failed with status code {response.status_code}. Response: {response.text}")
            
            except requests.exceptions.RequestException as e:
                logging.error(f"Request exception occurred: {str(e)}")
                if attempt < max_retries - 1:
                    logging.warning(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                else:
                    raise

        # Save LLM output
        llm_output_path = os.path.join(finding_dir, "llm_output.txt")
        with open(llm_output_path, 'w') as f:
            f.write(llm_output)

        # Save summary
        summary_path = os.path.join(finding_dir, "summary.txt")
        with open(summary_path, 'w') as f:
            f.write(output)

        # Update state
        state["processed_findings"].append(finding_id)
        save_processing_state(output_dir, state)

        logging.info(f"Successfully processed finding: {finding_id}")
        return "processed"

    except Exception as e:
        logging.error(f"Error processing finding {finding_id}: {str(e)}")
        logging.debug(f"Exception traceback: {traceback.format_exc()}")
        error_file = os.path.join(finding_dir, "processing_ERROR.json")
        with open(error_file, 'w') as f:
            json.dump({"error": str(e), "traceback": traceback.format_exc()}, f, indent=2)
        state["failed_findings"].append(finding_id)
        save_processing_state(output_dir, state)
        return "failed"

def truncate_finding_json(finding, max_lines_length):
    if 'extra' in finding and 'lines' in finding['extra']:
        lines = finding['extra']['lines']
        if len(lines) > max_lines_length:
            # Truncate the lines field
            truncated_lines = lines[:max_lines_length - 3] + '...'
            finding['extra']['lines'] = truncated_lines
    
    return json.dumps(finding)

def process_findings(file_categories, output_dir, base_dir, workspace_slug, state):
    total_findings = sum(len(findings) for findings in file_categories.values())
    processed_count = 0
    skipped_count = 0
    failed_count = 0
    current_finding = 0

    for file_path, findings in file_categories.items():
        for finding in findings:
            current_finding += 1
            result = process_finding(finding, base_dir, file_path, output_dir, workspace_slug, state, total_findings, current_finding)
            if result == "processed":
                processed_count += 1
            elif result == "skipped":
                skipped_count += 1
            elif result == "failed":
                failed_count += 1

    return processed_count, skipped_count, failed_count

def main():
    parser = argparse.ArgumentParser(description="Process Semgrep findings using LLM analysis")
    parser.add_argument("--base-dir", required=True, help="Base directory of the source code")
    parser.add_argument("--input", required=True, help="Path to the Semgrep JSON file")
    parser.add_argument("--workspace-name", required=True, help="Name of the existing workspace to use")
    parser.add_argument("--output-dir", required=True, help="Directory to store processed findings")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    setup_logging(args.debug)

    start_time = time.time()

    # Load Semgrep results
    data = load_semgrep_results(args.input)
    _, _, file_categories = analyze_findings(data)

    total_findings = sum(len(findings) for findings in file_categories.values())
    print(f"Processing {total_findings} findings from {args.input}")

    # Get workspace slug
    workspace_slug = get_workspace_slug(args.workspace_name)
    if not workspace_slug:
        logging.error(f"Workspace '{args.workspace_name}' not found. Exiting.")
        return

    # Load the processing state
    state = load_processing_state(args.output_dir)

    # Process findings
    processed_count, skipped_count, failed_count = process_findings(file_categories, args.output_dir, args.base_dir, workspace_slug, state)

    end_time = time.time()
    total_time = end_time - start_time
    runtime = str(datetime.timedelta(seconds=int(total_time)))

    print(f"\nProcessing complete. Results saved in {args.output_dir}")
    print("\nSummary:")
    print(f"Total findings: {total_findings}")
    print(f"Processed findings: {processed_count}")
    print(f"Skipped findings: {skipped_count}")
    print(f"Failed findings: {failed_count}")
    print(f"Total run time: {runtime}")

if __name__ == "__main__":
    main()
