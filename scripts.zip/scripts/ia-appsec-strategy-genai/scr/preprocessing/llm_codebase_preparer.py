#!/usr/bin/env python3

"""
LLM Codebase Preparer

This script processes a given directory containing multiple repositories and creates
chunked text files for each repository. It's designed to prepare codebases for
large language model (LLM) ingestion.

Directory structure:
input_directory/
├── repo1/
│   └── [files and subdirectories]
├── repo2/
│   └── [files and subdirectories]
└── ...

output:
input_directory_chunks/
├── repo1_chunks/
│   ├── chunk1.txt
│   ├── chunk2.txt
│   └── ...
├── repo2_chunks/
│   ├── chunk1.txt
│   ├── chunk2.txt
│   └── ...
└── ...

Usage: ./llm_codebase_preparer.py <directory> [--debug]
"""

import datetime
import os
import sys
import time
import magic

EXCLUDED_FILES = (
    ".env", ".git", ".zip", ".ico", ".jpg", ".pdf", ".svg", ".woff", ".woff2", ".png", ".jpeg", ".gif", 
    ".bmp", ".tiff", ".dll", ".webp", ".exe", ".pdb", ".DS_Store", ".cache", ".webm", ".ogg", ".a01", ".crx", 
    ".docx", ".csv", ".xlsx", ".eot", ".gif_delete_this", ".h84state", ".jks", ".mem", ".mp3", ".opus", ".otf", 
    ".png_delete_this", ".swf", ".ttf", ".unity3d", ".wasm", ".wav", ".dat", ".spx", ".db", ".idea", ".vscode", ".xcf"
)
CHUNK_SIZE = 500000

def is_binary_file(filepath, debug=False):
    if os.path.getsize(filepath) == 0:
        if debug:
            print(f"DEBUG: File: {filepath} is empty and will be skipped.")
        return True

    mime = magic.Magic(mime=True)
    try:
        file_type = mime.from_file(filepath)
        is_binary = not (file_type.startswith("text/") or file_type in ("application/javascript", "application/json", "application/xml", "application/x-shellscript"))
        if debug:
            print(f"DEBUG: File: {filepath}, MIME Type: {file_type}, Is Binary: {is_binary}")
        return is_binary
    except Exception as e:
        if debug:
            print(f"DEBUG: Error checking file type for {filepath}: {e}")
        return True

def get_file_extension(filepath):
    return os.path.splitext(filepath)[1].lower()

def is_excluded(file_path, exclusions):
    return any(file_path.endswith(pattern) or pattern in file_path.split(os.sep) for pattern in exclusions)

def normalize_line_endings(content):
    return content.replace('\r\n', '\n').replace('\r', '\n')

def read_file_with_fallback_encodings(file_path, debug=False):
    encodings = ['utf-8', 'iso-8859-1', 'windows-1252']
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as file:
                content = file.read()
            if debug:
                print(f"DEBUG: Successfully read {file_path} with {encoding} encoding")
            return content
        except UnicodeDecodeError:
            if debug:
                print(f"DEBUG: Failed to read {file_path} with {encoding} encoding")
    
    print(f"Error: Unable to read {file_path} with any supported encoding")
    return None

def create_sectioned_file_with_chunks(repo_dir, output_dir, exclusions=None, debug=False):
    os.makedirs(output_dir, exist_ok=True)

    current_chunk = 1
    current_size = 0
    binary_extensions = set()
    encoding_error_files = []
    output_file = os.path.join(output_dir, f"chunk{current_chunk}.txt")
    out_file = open(output_file, 'w', encoding='utf-8')
    files_chunked = 0

    for dirpath, dirnames, filenames in os.walk(repo_dir):
        dirnames[:] = [d for d in dirnames if not d.startswith('.')]

        for filename in filenames:
            full_path = os.path.join(dirpath, filename)
            relative_path = os.path.relpath(full_path, repo_dir)

            if is_excluded(relative_path, exclusions):
                if debug:
                    print(f"DEBUG: Skipping excluded file: {relative_path}")
                continue

            if is_binary_file(full_path, debug=debug):
                if os.path.getsize(full_path) > 0:
                    ext = get_file_extension(full_path)
                    if ext and ext not in binary_extensions:
                        binary_extensions.add(ext)
                if debug:
                    print(f"DEBUG: Marked as binary: {relative_path}")
                continue

            try:
                content = read_file_with_fallback_encodings(full_path, debug)
                if content is None:
                    encoding_error_files.append(relative_path)
                    print(f"Error: Unable to read file due to encoding issues: {relative_path}")
                    continue

                content = normalize_line_endings(content)
                section = f"<<<FILE:{relative_path}>>>\n{content}<<<END FILE>>>\n\n"
                section_size = len(section.encode('utf-8'))  # Get the size in bytes

                if current_size + section_size > CHUNK_SIZE:
                    out_file.close()
                    current_chunk += 1
                    output_file = os.path.join(output_dir, f"chunk{current_chunk}.txt")
                    out_file = open(output_file, 'w', encoding='utf-8')
                    current_size = 0

                out_file.write(section)
                current_size += section_size
                files_chunked += 1
            except Exception as e:
                print(f"Error processing file {relative_path}: {e}")
                encoding_error_files.append(relative_path)

    out_file.close()

    if binary_extensions:
        print(f"\nNotice: The following file extensions were detected in binary files for {os.path.basename(repo_dir)}:")
        for ext in sorted(binary_extensions):
            print(f"  - {ext}")
        print("\nConsider adding these extensions to the exclusion list for future runs.")

    if encoding_error_files:
        print(f"\nWarning: The following files could not be processed due to encoding issues:")
        for file in encoding_error_files:
            print(f"  - {file}")
        print("\nConsider reviewing these files manually.")

    print(f"\nChunks created for {os.path.basename(repo_dir)} in directory: {output_dir}")
    print(f"Total files chunked: {files_chunked}")
    return files_chunked

def process_repositories(root_dir, debug=False):
    main_output_dir = f"{os.path.basename(root_dir)}_chunks"
    main_output_dir = os.path.join(os.path.dirname(root_dir), main_output_dir)
    os.makedirs(main_output_dir, exist_ok=True)

    total_files_chunked = 0

    for item in os.listdir(root_dir):
        item_path = os.path.join(root_dir, item)
        if os.path.isdir(item_path) and not item.startswith('.'):
            repo_output_dir = os.path.join(main_output_dir, f"{item}_chunks")
            files_chunked = create_sectioned_file_with_chunks(item_path, repo_output_dir, EXCLUDED_FILES, debug=debug)
            total_files_chunked += files_chunked

    return total_files_chunked

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: ./llm_codebase_preparer.py <directory> [--debug]")
        sys.exit(1)

    root_directory = sys.argv[1]
    debug = "--debug" in sys.argv

    if not os.path.isdir(root_directory):
        print(f"Error: {root_directory} is not a valid directory.")
        sys.exit(1)

    start_time = time.time()

    total_files_chunked = process_repositories(root_directory, debug=debug)

    end_time = time.time()
    total_time = end_time - start_time
    runtime = str(datetime.timedelta(seconds=int(total_time)))
    print(f"Chunking completed")
    print(f"Total files chunked: {total_files_chunked}")
    print(f"Total run time: {runtime}")
