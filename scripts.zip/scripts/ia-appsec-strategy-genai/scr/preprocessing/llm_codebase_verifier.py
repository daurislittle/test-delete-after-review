#!/usr/bin/env python3

"""
LLM Codebase Verifier

This script verifies the integrity of chunked files created by the LLM Codebase Preparer.
It compares the original files with their chunked versions to ensure all content is preserved.

Usage: ./llm_codebase_verifier.py --source-dir <source_directory> --chunk-dir <chunked_directory> [--debug]

Output: A report detailing any mismatches, missing files, or extra files found in the chunks.
"""

import datetime
import os
import sys
import time
import magic
import argparse
import difflib

EXCLUDED_FILES = (
    ".env", ".git", ".zip", ".ico", ".jpg", ".pdf", ".svg", ".woff", ".woff2", ".png", ".jpeg", ".gif", 
    ".bmp", ".tiff", ".dll", ".webp", ".exe", ".pdb", ".DS_Store", ".cache", ".webm", ".ogg", ".a01", ".crx", 
    ".docx", ".csv", ".xlsx", ".eot", ".gif_delete_this", ".h84state", ".jks", ".mem", ".mp3", ".opus", ".otf", 
    ".png_delete_this", ".swf", ".ttf", ".unity3d", ".wasm", ".wav", ".dat", ".spx", ".db", ".idea", ".vscode", ".xcf"
)

def is_binary_file(filepath, debug=False):
    if os.path.getsize(filepath) == 0:
        return True
    mime = magic.Magic(mime=True)
    try:
        file_type = mime.from_file(filepath)
        is_binary = not (file_type.startswith("text/") or file_type in ("application/javascript", "application/json", "application/xml", "application/x-shellscript"))
        return is_binary
    except Exception as e:
        if debug:
            print(f"DEBUG: Error checking file type for {filepath}: {e}")
        return True

def is_excluded(file_path):
    return any(file_path.endswith(pattern) or pattern in file_path.split(os.sep) for pattern in EXCLUDED_FILES)

def normalize_line_endings(content):
    return content.replace('\r\n', '\n').replace('\r', '\n')

def scan_original_directory(root_dir, debug=False):
    file_map = {}
    for repo_dir in os.listdir(root_dir):
        repo_path = os.path.join(root_dir, repo_dir)
        if os.path.isdir(repo_path) and not repo_dir.startswith('.'):
            if debug:
                print(f"DEBUG: Scanning repo directory: {repo_dir}")
            for dirpath, _, filenames in os.walk(repo_path):
                for filename in filenames:
                    full_path = os.path.join(dirpath, filename)
                    relative_path = os.path.relpath(full_path, root_dir)
                    if is_excluded(relative_path):
                        if debug:
                            print(f"DEBUG: Skipping excluded file: {relative_path}")
                        continue
                    if os.path.getsize(full_path) == 0:
                        if debug:
                            print(f"DEBUG: Skipping 0 byte file: {relative_path}")
                        continue
                    if not is_binary_file(full_path, debug):
                        try:
                            with open(full_path, 'r', encoding='utf-8') as f:
                                content = f.read()
                        except UnicodeDecodeError:
                            try:
                                with open(full_path, 'r', encoding='iso-8859-1') as f:
                                    content = f.read()
                            except UnicodeDecodeError:
                                if debug:
                                    print(f"DEBUG: Unable to decode file: {relative_path}")
                                continue
                        file_map[relative_path] = normalize_line_endings(content)
                        if debug:
                            print(f"DEBUG: Added original file: {relative_path}")
    if debug:
        print(f"DEBUG: Total files scanned in original directory: {len(file_map)}")
    return file_map

def parse_chunk_files(chunk_dir, debug=False):
    file_map = {}
    if debug:
        print(f"DEBUG: Scanning main chunk directory: {chunk_dir}")
    
    for repo_chunk_dir in os.listdir(chunk_dir):
        repo_chunk_path = os.path.join(chunk_dir, repo_chunk_dir)
        if os.path.isdir(repo_chunk_path) and repo_chunk_dir.endswith('_chunks'):
            repo_name = repo_chunk_dir.replace('_chunks', '')
            if debug:
                print(f"DEBUG: Processing repo chunk directory: {repo_chunk_dir}")
            
            for chunk_file in os.listdir(repo_chunk_path):
                if chunk_file.startswith("chunk") and chunk_file.endswith(".txt"):
                    full_path = os.path.join(repo_chunk_path, chunk_file)
                    if debug:
                        print(f"DEBUG: Processing chunk file: {full_path}")
                    try:
                        with open(full_path, 'r', encoding='utf-8') as f:
                            content = f.read()
                    except UnicodeDecodeError:
                        try:
                            with open(full_path, 'r', encoding='iso-8859-1') as f:
                                content = f.read()
                        except UnicodeDecodeError:
                            if debug:
                                print(f"DEBUG: Unable to decode chunk file: {full_path}")
                            continue
                    
                    # Split the content into individual files
                    file_sections = content.split("<<<FILE:")
                    for file_section in file_sections[1:]:  # Skip the first empty split
                        file_path, _, file_content = file_section.partition(">>>\n")
                        file_path = file_path.strip()
                        file_content = file_content.split("<<<END FILE>>>")[0]
                        
                        if not file_content:  # Skip empty files
                            if debug:
                                print(f"DEBUG: Skipping empty file in chunks: {file_path}")
                            continue
                        
                        full_file_path = os.path.join(repo_name, file_path)
                        file_map[full_file_path] = normalize_line_endings(file_content)
                        if debug:
                            print(f"DEBUG: Added chunked file: {full_file_path}")
    
    if debug:
        print(f"DEBUG: Total files parsed from all chunks: {len(file_map)}")
    return file_map

def compare_files(original_map, chunked_map, debug=False):
    results = {
        "missing_files": [],
        "extra_files": [],
        "mismatched_files": []
    }
    
    for file_path, original_content in original_map.items():
        if file_path not in chunked_map:
            results["missing_files"].append(file_path)
            if debug:
                print(f"DEBUG: Missing file: {file_path}")
        elif original_content != chunked_map[file_path]:
            results["mismatched_files"].append(file_path)
            if debug:
                print(f"DEBUG: Mismatched file: {file_path}")
                print("Original content:")
                print(repr(original_content))
                print("Chunked content:")
                print(repr(chunked_map[file_path]))
                diff = list(difflib.unified_diff(
                    original_content.splitlines(keepends=True),
                    chunked_map[file_path].splitlines(keepends=True),
                    fromfile='original',
                    tofile='chunked'
                ))
                print("".join(diff))
        elif debug:
            print(f"DEBUG: File matches: {file_path}")
    
    for file_path in chunked_map:
        if file_path not in original_map:
            results["extra_files"].append(file_path)
            if debug:
                print(f"DEBUG: Extra file: {file_path}")
    
    return results

def generate_report(comparison_results, original_count, chunked_count):
    print("\n=== LLM Codebase Verifier Report ===\n")
    print(f"Total files in original directory: {original_count}")
    print(f"Total files in chunked files: {chunked_count}")
    print(f"Missing files: {len(comparison_results['missing_files'])}")
    print(f"Extra files: {len(comparison_results['extra_files'])}")
    print(f"Mismatched files: {len(comparison_results['mismatched_files'])}")
    
    if comparison_results['missing_files']:
        print("\nMissing files:")
        for file in comparison_results['missing_files']:
            print(f"  - {file}")
    
    if comparison_results['extra_files']:
        print("\nExtra files:")
        for file in comparison_results['extra_files']:
            print(f"  - {file}")
    
    if comparison_results['mismatched_files']:
        print("\nMismatched files:")
        for file in comparison_results['mismatched_files']:
            print(f"  - {file}")
    
    if not any(comparison_results.values()):
        print("\nAll files verified successfully!")

def main():
    parser = argparse.ArgumentParser(description="Verify chunked codebase against the original source.")
    parser.add_argument("--source-dir", required=True, help="Path to the original source directory")
    parser.add_argument("--chunk-dir", required=True, help="Path to the directory containing chunked files")
    parser.add_argument("--debug", action="store_true", help="Enable debug output")
    args = parser.parse_args()

    if not os.path.isdir(args.source_dir) or not os.path.isdir(args.chunk_dir):
        print("Error: Both source and chunk directories must be valid directories.")
        sys.exit(1)

    start_time = time.time()

    print("Scanning original directory...")
    original_map = scan_original_directory(args.source_dir, args.debug)
    
    print("Parsing chunk files...")
    chunked_map = parse_chunk_files(args.chunk_dir, args.debug)
    
    print("Comparing files...")
    results = compare_files(original_map, chunked_map, args.debug)
    
    generate_report(results, len(original_map), len(chunked_map))

    end_time = time.time()
    total_time = end_time - start_time
    runtime = str(datetime.timedelta(seconds=int(total_time)))
    print(f"Verification completed")
    print(f"Total run time: {runtime}")

if __name__ == "__main__":
    main()
