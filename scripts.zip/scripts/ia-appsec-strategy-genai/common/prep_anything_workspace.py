#!/usr/bin/env python3

import argparse
import datetime
import os
import logging
import requests
import json
import time
import random
import string
import sys

# Get API key and base URL from environment variables
ANYTHING_LLM_API_KEY = os.environ.get('ANYTHING_LLM_API_KEY')
ANYTHING_LLM_BASE_URL = os.environ.get('ANYTHING_LLM_BASE_URL', 'http://localhost:3001')

if not ANYTHING_LLM_API_KEY:
    raise ValueError("ANYTHING_LLM_API_KEY not found in environment variables.")

# Handle lame macos junk
EXCLUDED_FILES = ['.DS_Store']

# Set up the API headers
headers = {
    'Authorization': f'Bearer {ANYTHING_LLM_API_KEY}',
    'Content-Type': 'application/json'
}

def read_prompt_file(file_path):
    if not os.path.exists(file_path):
        logging.error(f"The specified prompt file does not exist: {file_path}")
        sys.exit(1)
    
    try:
        with open(file_path, 'r') as file:
            prompt = file.read().strip()
        if not prompt:
            logging.error(f"The prompt file is empty: {file_path}")
            sys.exit(1)
        return prompt
    except IOError as e:
        logging.error(f"Error reading the prompt file: {e}")
        sys.exit(1)

def setup_logging(debug):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')

def check_workspace_exists(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspaces"
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        workspaces = response.json().get('workspaces', [])
        return any(workspace['name'] == workspace_name for workspace in workspaces)
    else:
        logging.error(f"Failed to retrieve workspaces. Status code: {response.status_code}")
        logging.error(f"Response: {response.text}")
        raise Exception("Failed to check if workspace exists")

def create_workspace(workspace_name, system_prompt):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/new"
    payload = {
        "name": workspace_name,
        "openAiTemp": 0.5,
        "openAiHistory": 5,
        "similarityThreshold": .25,
        "topN": 200,
        "chatMode": "query",
        "openAiPrompt": system_prompt
    }
    
    logging.debug(f"Create workspace API call: POST {api_url}")
    logging.debug(f"Create workspace payload: {json.dumps(payload, indent=2)}")
    
    response = requests.post(api_url, json=payload, headers=headers)
    logging.debug(f"Create workspace response: {response.status_code} {response.text}")

    if response.status_code == 200:
        workspace_data = response.json()['workspace']
        workspace_slug = workspace_data['slug']
        print(f"Created workspace: {workspace_name} (slug: {workspace_slug})")
        print(f"Workspace settings applied during creation: openAiTemp={payload['openAiTemp']}, "
              f"openAiHistory={payload['openAiHistory']}, similarityThreshold={payload['similarityThreshold']}, "
              f"topN={payload['topN']}, chatMode={payload['chatMode']}")
        return workspace_slug
    else:
        logging.error(f"Failed to create workspace. Status code: {response.status_code}")
        logging.error(f"Response: {response.text}")
        return None

def create_document_folder(workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/document/create-folder"
    payload = {"name": workspace_name}
    response = requests.post(api_url, json=payload, headers=headers)
    if response.status_code == 200:
        logging.info(f"Created document folder: {workspace_name}")
        return True
    else:
        logging.error(f"Failed to create document folder. Status code: {response.status_code}")
        logging.error(f"Response: {response.text}")
        return False

def upload_and_move_file(file_path, workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/document/upload"
    with open(file_path, 'rb') as file:
        files = {'file': (os.path.basename(file_path), file)}
        response = requests.post(api_url, files=files, headers={'Authorization': headers['Authorization']})
    
    logging.debug(f"Full API response for {file_path}:")
    logging.debug(response.text)
    
    if response.status_code == 200:
        logging.debug(f"Uploaded file: {file_path}")
        try:
            upload_response = response.json()
            logging.debug(f"Parsed JSON response: {json.dumps(upload_response, indent=2)}")
            if 'documents' in upload_response and len(upload_response['documents']) > 0:
                document = upload_response['documents'][0]
                if 'location' in document:
                    document_name = os.path.basename(document['location'])
                    move_file(document_name, workspace_name)
                    return document_name
                else:
                    raise KeyError("'location' not found in document")
            else:
                raise KeyError("No documents found in response")
        except (KeyError, IndexError) as e:
            logging.error(f"Unexpected response structure for file {file_path}. Error: {str(e)}")
            logging.debug(f"Response content: {response.text}")
            raise Exception(f"Failed to parse upload response for {file_path}")
    else:
        logging.error(f"Failed to upload file {file_path}. Status code: {response.status_code}")
        logging.debug(f"Response content: {response.text}")
        raise Exception(f"Server Error: {response.text}")

def move_file(file_name, workspace_name):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/document/move-files"
    payload = {
        "files": [
            {
                "from": f"custom-documents/{file_name}",
                "to": f"{workspace_name}/{file_name}"
            }
        ]
    }
    response = requests.post(api_url, json=payload, headers=headers)
    if response.status_code != 200:
        logging.error(f"Failed to move file {file_name}. Status code: {response.status_code}")
        logging.debug(f"Response content: {response.text}")
        raise Exception(f"Failed to move file {file_name}")
    else:
        logging.debug(f"Successfully moved file {file_name} to {workspace_name}")

def update_workspace_embeddings(workspace_slug, file_names):
    api_url = f"{ANYTHING_LLM_BASE_URL}/api/v1/workspace/{workspace_slug}/update-embeddings"
    payload = {
        "adds": file_names,
        "deletes": []
    }
    response = requests.post(api_url, json=payload, headers=headers)
    if response.status_code != 200:
        logging.error(f"Failed to update embeddings. Status code: {response.status_code}")
        logging.debug(f"Response content: {response.text}")
        raise Exception("Failed to update embeddings")
    else:
        print(f"Successfully updated embeddings for {len(file_names)} files")

def upload_codebase(root_dir, workspace_name, workspace_slug):
    successfully_moved_files = []
    total_files = 0
    for root, dirs, files in os.walk(root_dir):
        for file in files:
            if file in EXCLUDED_FILES:  # Skip excluded files
                continue
            total_files += 1
            file_path = os.path.join(root, file)
            try:
                moved_file_name = upload_and_move_file(file_path, workspace_name)
                successfully_moved_files.append(f"{workspace_name}/{moved_file_name}")
                print(f"Successfully uploaded and moved: {moved_file_name}")
            except Exception as e:
                logging.error(f"Error processing file {file_path}: {str(e)}")
                # Continue with the next file instead of raising an exception
    
    print(f"Uploaded and moved {len(successfully_moved_files)} out of {total_files} files.")
    
    if successfully_moved_files:
        print(f"Starting embedding process for {len(successfully_moved_files)} files...")
        try:
            update_workspace_embeddings(workspace_slug, successfully_moved_files)
            print(f"Embedding process completed successfully for {len(successfully_moved_files)} files.")
        except Exception as e:
            logging.error(f"Error updating embeddings: {str(e)}")
            print(f"Error occurred during embedding process: {str(e)}")
    else:
        print("No files were successfully uploaded and moved. Skipping embedding update.")

def check_directory_exists(directory):
    if not os.path.isdir(directory):
        logging.error(f"The specified chunk directory does not exist: {directory}")
        return False
    return True

def main():
    parser = argparse.ArgumentParser(description="Prepare a workspace for Semgrep analysis")
    parser.add_argument("--workspace-name", required=True, help="Name of the workspace to create")
    parser.add_argument("--artifacts-dir", required=True, help="Path to the artifacts directory")
    parser.add_argument("--system-prompt", required=True, help="Path to the file containing the system prompt")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    setup_logging(args.debug)

    start_time = time.time()

    # Read the prompt file
    system_prompt = read_prompt_file(args.system_prompt)

    # Check if the chunk directory exists
    if not check_directory_exists(args.artifacts_dir):
        return

    # Check if workspace already exists
    if check_workspace_exists(args.workspace_name):
        logging.error(f"Workspace '{args.workspace_name}' already exists. Please choose a different name.")
        return

    workspace_slug = create_workspace(args.workspace_name, system_prompt)
    if not workspace_slug:
        logging.error("Failed to create workspace. Exiting.")
        return

    if not create_document_folder(args.workspace_name):
        logging.error("Failed to create document folder. Exiting.")
        return

    upload_codebase(args.artifacts_dir, args.workspace_name, workspace_slug)

    print(f"Workspace '{args.workspace_name}' (slug: {workspace_slug}) created and populated successfully.")

    end_time = time.time()
    total_time = end_time - start_time
    runtime = str(datetime.timedelta(seconds=int(total_time)))
    print(f"Total run time: {runtime}")

if __name__ == "__main__":
    main()
