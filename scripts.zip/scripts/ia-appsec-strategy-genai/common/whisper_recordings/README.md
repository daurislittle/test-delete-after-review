# Pyannote.audio Setup Instructions

# Note: Whisper, ffmpeg, and whisper model should already be installed

## 1. Set up Python Virtual Environment
   a. python3 -m venv my_env
   b. source my_env/bin/activate

## 2. Install pyannote.audio and Dependencies
    - pip install pyannote.audio 

        If installation fails, install these prerequisites:
        - cmake, protobuf, sentencepiece, setuptools, wheel

## 3. Prepare Model Files
a. Create a local directory for models:

b. Download and place the following files in the 'models' directory:
    
- Rename "wespeaker-voxceleb-resnet34-LM to pyannote_model_wespeaker-voxceleb-resnet34-LM.bin"
- Rename "segmentation-3.0" to "pyannote_model_segmentation-3.0.bin"


Tree: 
├── models
│   ├── pyannote_diarization_config.yaml
│   ├── pyannote_model_segmentation-3.0.bin
│   └── pyannote_model_wespeaker-voxceleb-resnet34-LM.bin
├── whisper_diarization.py

## 4. Configure Pyannote Diarization
Create a configuration file in the 'models' directory:


Config file contents:
```
version: 3.1.0

  

pipeline:

name: pyannote.audio.pipelines.SpeakerDiarization

params:

clustering: AgglomerativeClustering

# embedding: pyannote/wespeaker-voxceleb-resnet34-LM # if you want to use the HF model

embedding: models/pyannote_model_wespeaker-voxceleb-resnet34-LM.bin # if you want to use the local model

embedding_batch_size: 32

embedding_exclude_overlap: true

# segmentation: pyannote/segmentation-3.0 # if you want to use the HF model

segmentation: models/pyannote_model_segmentation-3.0.bin # if you want to use the local model

segmentation_batch_size: 32

  

params:

clustering:

method: centroid

min_cluster_size: 12

threshold: 0.7045654963945799

segmentation:

min_duration_off: 0.0
```

