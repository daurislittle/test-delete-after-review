#!/usr/bin/env python3

# Print startup message immediately before any imports
import sys
import time
from datetime import datetime

# Immediate startup message without waiting for other imports
timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(f"{timestamp} - INFO  - Script initializing...", flush=True)

# Continue with regular imports
import os
import argparse
import json
import subprocess
import traceback
from typing import Dict, Any
from datetime import timedelta
from pathlib import Path
print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - INFO  - Loading libraries...", flush=True)

# These imports might take time
try:
    from pyannote.audio import Pipeline
    from pyannote.core import Segment
    import torch
    import warnings
    print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - INFO  - Libraries loaded successfully", flush=True)
except ImportError as e:
    print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - ERROR - Error loading libraries: {str(e)}", flush=True)
    sys.exit(1)

# Suppress specific PyTorch warnings
warnings.filterwarnings("ignore", category=UserWarning, module="pyannote.audio.models.blocks.pooling")

# Default number of threads to use
DEFAULT_THREADS = 12

def log(message: str, level: str = "INFO", file=None):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"{timestamp} - {level:<5} - {message}"
    print(log_message, flush=True)
    if file:
        with open(file, 'a') as f:
            f.write(log_message + '\n')

def get_processed_files(state_file: str) -> Dict[str, Dict[str, bool]]:
    if os.path.exists(state_file):
        with open(state_file, 'r') as f:
            data = json.load(f)
            # Handle legacy format (list of strings)
            if isinstance(data, list):
                return {file: {"processed_with_diarization": False, "processed_without_diarization": True} for file in data}
            # Handle intermediate format with single "diarized" flag
            if any("diarized" in file_data for file_data in data.values() if isinstance(file_data, dict)):
                result = {}
                for file, file_data in data.items():
                    if isinstance(file_data, dict) and "diarized" in file_data:
                        is_diarized = file_data["diarized"]
                        result[file] = {
                            "processed_with_diarization": is_diarized,
                            "processed_without_diarization": not is_diarized
                        }
                    else:
                        # Default for unknown format
                        result[file] = {"processed_with_diarization": False, "processed_without_diarization": True}
                return result
            # Already using new format
            return data
    return {}

def update_processed_files(state_file: str, file_updates: Dict[str, Dict[str, bool]]):
    # First, read the existing state file if it exists
    existing_data = {}
    if os.path.exists(state_file):
        try:
            with open(state_file, 'r') as f:
                existing_data = get_processed_files(state_file)  # This will handle format conversion
        except Exception as e:
            log(f"Error reading existing state file: {e}", "WARNING")
            # Continue with empty existing data if there was an error
    
    # Merge the existing data with the new processed files
    for filename, info in file_updates.items():
        if filename not in existing_data:
            existing_data[filename] = {"processed_with_diarization": False, "processed_without_diarization": False}
        
        # Update the specific diarization state that was processed
        if "processed_with_diarization" in info:
            existing_data[filename]["processed_with_diarization"] = info["processed_with_diarization"]
        if "processed_without_diarization" in info:
            existing_data[filename]["processed_without_diarization"] = info["processed_without_diarization"]
    
    # Write the merged data back to the state file
    try:
        with open(state_file, 'w') as f:
            json.dump(existing_data, f)
        return True
    except Exception as e:
        log(f"Error updating state file: {e}", "ERROR")
        return False

def preprocess_audio(input_file: str, output_file: str, log_file: str):
    if os.path.exists(output_file):
        try:
            os.remove(output_file)
            log(f"Deleted existing preprocessed audio file: {output_file}", file=log_file)
        except OSError as e:
            log(f"Error deleting existing preprocessed audio file {output_file}: {e}", "ERROR", file=log_file)
            return False
    command = [
        "ffmpeg",
        "-i", input_file,
        "-ar", "16000",
        "-ac", "2",  # Always create stereo
        "-c:a", "pcm_s16le",
        output_file
    ]
    with open(log_file, 'a') as f:
        subprocess.run(command, check=True, stdout=f, stderr=subprocess.STDOUT)
    return True

def load_pipeline_from_pretrained(path_to_config: str | Path) -> Pipeline:
    path_to_config = Path(path_to_config)
    print(f"Loading pyannote pipeline from {path_to_config}...")
    cwd = Path.cwd().resolve()
    cd_to = path_to_config.parent.parent.resolve()
    print(f"Changing working directory to {cd_to}")
    os.chdir(cd_to)
    pipeline = Pipeline.from_pretrained(path_to_config)
    print(f"Changing working directory back to {cwd}")
    os.chdir(cwd)
    return pipeline

def perform_diarization(audio_file: str, pipeline: Pipeline):
    log(f"Starting diarization for {audio_file}")
    diarization = pipeline(audio_file)
    log(f"Diarization completed for {audio_file}")
    return diarization

def timestamp_to_seconds(timestamp):
    h, m, s = timestamp.split(':')
    return int(h) * 3600 + int(m) * 60 + float(s)

def transcribe_and_diarize_audio(input_file: str, output_file: str, model_path: str, diarization_pipeline: Pipeline, log_file: str):
    start_time = time.time()
    
    # Transcribe the audio
    log(f"Starting transcription for {input_file}", file=log_file)
    command = [
        "whisper-cli",
        "-m", model_path,
        "-f", input_file,
        "-t", str(DEFAULT_THREADS)
    ]

    try:
        with open(log_file, 'a') as log_f:
            result = subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=log_f, text=True)

        lines = result.stdout.split('\n')
        transcription_start = next(i for i, line in enumerate(lines) if line.strip().startswith('['))
        cleaned_lines = []

        # If diarization is enabled (pipeline provided)
        if diarization_pipeline:
            log(f"Starting diarization for {input_file}", file=log_file)
            diarization = perform_diarization(input_file, diarization_pipeline)
            diarization_time = time.time() - start_time
            log(f"Diarization completed for {input_file} in {diarization_time:.2f} seconds", file=log_file)
            
            # Debugging information
            log(f"Diarization result structure: {type(diarization)}", file=log_file)
            log(f"Diarization result content: {diarization}", file=log_file)
            
            speaker_labels = ["GPS", "Client"]
            speaker_mapping = {}

            for line in lines[transcription_start:]:
                if line.strip():
                    try:
                        timestamp, content = line.split(']', 1)
                        start_time_str, end_time_str = timestamp.strip('[').split(' --> ')
                        start_time_sec = timestamp_to_seconds(start_time_str)
                        end_time_sec = timestamp_to_seconds(end_time_str)
                        
                        segment = Segment(start_time_sec, end_time_sec)
                        speaker_index = diarization.argmax(segment)
                        
                        if speaker_index not in speaker_mapping:
                            if len(speaker_mapping) < len(speaker_labels):
                                speaker_mapping[speaker_index] = speaker_labels[len(speaker_mapping)]
                            else:
                                speaker_mapping[speaker_index] = f"SPEAKER_{speaker_index}"
                        
                        speaker_label = speaker_mapping[speaker_index]
                        
                        cleaned_lines.append(f"[{speaker_label}] {content.strip()}")
                    except Exception as e:
                        log(f"Error processing line: {line}. Error: {str(e)}", "WARNING", file=log_file)
                        cleaned_lines.append(f"[UNKNOWN_SPEAKER] {line.strip()}")
        else:
            # Without diarization, just keep the original timestamps
            for line in lines[transcription_start:]:
                if line.strip():
                    cleaned_lines.append(line.strip())

        cleaned_output = '\n'.join(cleaned_lines)

        with open(output_file + ".txt", 'w') as out_f:
            out_f.write(cleaned_output)

        transcription_time = time.time() - start_time
        log(f"Processing completed for {input_file} in {transcription_time:.2f} seconds", file=log_file)
        return True
    except subprocess.CalledProcessError as e:
        log(f"Error transcribing {input_file}. Return code: {e.returncode}", "ERROR", file=log_file)
        return False
    except Exception as e:
        log(f"Unexpected error processing {input_file}: {str(e)}", "ERROR", file=log_file)
        return False

def main(input_dir: str, output_dir: str, processing_dir: str, model_path: str, enable_diarization: bool, diarization_config: str):
    state_file = os.path.join(output_dir, "processed_files.json")
    try:
        processed_files = get_processed_files(state_file)
    except Exception as e:
        log(f"Error reading state file: {e}", "ERROR")
        processed_files = {}

    try:
        files_to_process = [
            f for f in os.listdir(input_dir)
            if f.endswith(('.mp4', '.mov', '.wav'))
        ]
    except OSError as e:
        log(f"Error reading input directory: {e}", "ERROR")
        return

    # Filter files based on diarization processing state
    files_to_process = [
        f for f in files_to_process 
        if f not in processed_files or 
        (enable_diarization and not processed_files[f].get("processed_with_diarization", False)) or
        (not enable_diarization and not processed_files[f].get("processed_without_diarization", False))
    ]
    
    log(f"Found {len(files_to_process)} files to process")

    if enable_diarization:
        diarization_pipeline = load_pipeline_from_pretrained(diarization_config)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        diarization_pipeline.to(device)
    else:
        diarization_pipeline = None

    for file in files_to_process:
        start_time = time.time()
        input_path = os.path.join(input_dir, file)
        base_name = os.path.splitext(file)[0]
        wav_path = os.path.join(processing_dir, f"{base_name}.wav")
        
        # Add "diarized" to output filename if diarization is enabled
        output_filename = f"transcript_diarized_{base_name}" if enable_diarization else f"transcript_{base_name}"
        output_path = os.path.join(output_dir, output_filename)
        
        log_file = os.path.join(processing_dir, f"{base_name}{'_diarized' if enable_diarization else ''}.log")

        if os.path.exists(output_path + ".txt"):
            log(f"Output file already exists at {output_path}.txt. Skipping.", "WARNING")
            # Create a new entry for this file with the appropriate diarization flag
            if enable_diarization:
                file_update = {file: {"processed_with_diarization": True}}
            else:
                file_update = {file: {"processed_without_diarization": True}}
            
            try:
                update_processed_files(state_file, file_update)
            except Exception as e:
                log(f"Error updating state file: {str(e)}", "ERROR")
            continue

        try:
            log(f"Processing {file} {'with' if enable_diarization else 'without'} diarization")
            log(f"Preprocessing {file}", file=log_file)
            if not preprocess_audio(input_path, wav_path, log_file):
                log(f"Failed to preprocess {file}", "ERROR")
                continue
                
            log(f"{'Transcribing and diarizing' if enable_diarization else 'Transcribing'} {os.path.basename(wav_path)}", file=log_file)
            success = transcribe_and_diarize_audio(wav_path, output_path, model_path, diarization_pipeline, log_file)
            
            if success:
                # Create a new entry for this file with the appropriate diarization flag
                if enable_diarization:
                    file_update = {file: {"processed_with_diarization": True}}
                else:
                    file_update = {file: {"processed_without_diarization": True}}
                
                try:
                    update_processed_files(state_file, file_update)
                except Exception as e:
                    log(f"Error updating state file: {str(e)}", "ERROR", file=log_file)
                    
                log(f"Successfully processed {file}")
            else:
                log(f"Failed to process {file}", "WARNING")
                
            log(f"Intermediate WAV file saved at {wav_path}", file=log_file)
            log(f"Log file saved at {log_file}")
            
        except Exception as e:
            log(f"Error processing {file}: {str(e)}", "ERROR", file=log_file)
            log(f"Traceback: {traceback.format_exc()}", "ERROR", file=log_file)
            
        end_time = time.time()
        processing_time = timedelta(seconds=int(end_time - start_time))
        log(f"Total processing time for {file}: {processing_time}")

    log("Processing complete")

if __name__ == "__main__":
    # Check if no arguments were provided and show help if that's the case
    if len(sys.argv) == 1:
        log("No arguments provided. Use -h or --help for usage information.", "ERROR")
        sys.exit(1)
        
    parser = argparse.ArgumentParser(
        description="Process video files and create transcripts with speaker diarization.",
        epilog="""
        Model Information:
        To use this script, you need to download a ggml format model for whisper.cpp and a Pyannote diarization model.

        Whisper Model:
        Visit https://huggingface.co/ggerganov/whisper.cpp
        Once you have downloaded a model, specify its path using the --model argument.

        Pyannote Diarization Model:
        Follow the instructions at https://github.com/pyannote/pyannote-audio to download and set up the Pyannote model.
        Specify the path to the Pyannote configuration file using the --diarization-config argument.

        Installation:
        Ensure whisper.cpp, ffmpeg, and pyannote.audio are installed:
        brew install whisper-cpp ffmpeg
        pip install pyannote.audio

        Usage example:
        python3 whisper_recordings.py --input-dir /path/to/videos --output-dir /path/to/output --processing-dir /path/to/processing --model /path/to/ggml-large-v3-turbo.bin --enable-diarization --diarization-config /path/to/pyannote_diarization_config.yaml
        """,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument("--input-dir", required=True, help="Directory containing input video files")
    parser.add_argument("--output-dir", required=True, help="Directory to save output transcript files")
    parser.add_argument("--processing-dir", required=True, help="Directory to store intermediate WAV files and logs")
    parser.add_argument("--model", required=True, help="Path to the whisper.cpp model file (ggml format)")
    parser.add_argument("--enable-diarization", action="store_true", help="Enable speaker diarization")
    parser.add_argument("--diarization-config", help="Path to the Pyannote diarization config file (required if --enable-diarization is used)")
    
    args = parser.parse_args()
    
    # Check if diarization is enabled but config is not provided
    if args.enable_diarization and not args.diarization_config:
        parser.error("--diarization-config is required when --enable-diarization is used")

    for dir_path in [args.input_dir, args.output_dir, args.processing_dir]:
        if not os.path.exists(dir_path):
            try:
                os.makedirs(dir_path)
                log(f"Created directory: {dir_path}")
            except OSError as e:
                log(f"Failed to create directory '{dir_path}': {e}", "ERROR")
                sys.exit(1)

    main(args.input_dir, args.output_dir, args.processing_dir, args.model, args.enable_diarization, args.diarization_config)
