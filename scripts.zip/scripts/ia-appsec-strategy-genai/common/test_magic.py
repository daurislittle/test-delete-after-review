try:
    import magic
    print("✅ python-magic is installed and importable!")
except ImportError as e:
    print("❌ Could not import python-magic:")
    print(e)

