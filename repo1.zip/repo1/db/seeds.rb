# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
#

is_admin = Permission.find_or_create_by!(name:"is_admin")

role = Role.find_or_create_by!(name: 'Administrator')
role.permissions << is_admin unless role.permissions.include? is_admin

role.save

wbs_view       = Permission.find_or_create_by!(name:"wbs_view")
wbs_view_own   = Permission.find_or_create_by!(name:'wbs_view_own')
wbs_create     = Permission.find_or_create_by!(name:"wbs_create")
wbs_edit       = Permission.find_or_create_by!(name:"wbs_edit")
wbs_delete     = Permission.find_or_create_by!(name:"wbs_delete")
wbs_edit_own   = Permission.find_or_create_by!(name:"wbs_edit_own")
wbs_delete_own = Permission.find_or_create_by!(name:"wbs_delete_own")

wbs_create_template = Permission.find_or_create_by!(name:'wbs_template_create')
wbs_edit_template = Permission.find_or_create_by!(name:'wbs_template_edit')
wbs_edit_template_own = Permission.find_or_create_by!(name:'wbs_template_edit_own')
wbs_delete_template = Permission.find_or_create_by!(name:'wbs_template_delete')
wbs_delete_template_own = Permission.find_or_create_by!(name:'wbs_template_delete_own')

role = Role.find_or_create_by!(name: 'Scoping')
role.permissions << wbs_view_own unless role.permissions.include? wbs_view_own
role.permissions << wbs_create unless role.permissions.include? wbs_create
role.permissions << wbs_edit_own unless role.permissions.include? wbs_edit_own
role.permissions << wbs_delete_own unless role.permissions.include? wbs_delete_own
role.permissions << wbs_create_template unless role.permissions.include? wbs_create_template
role.permissions << wbs_edit_template_own unless role.permissions.include? wbs_edit_template_own
role.permissions << wbs_delete_template_own unless role.permissions.include? wbs_delete_template_own
role.save

role = Role.find_or_create_by!(name: 'Scoping Administrator')
role.permissions << wbs_view unless role.permissions.include? wbs_view
role.permissions << wbs_create unless role.permissions.include? wbs_create
role.permissions << wbs_edit unless role.permissions.include? wbs_edit
role.permissions << wbs_delete unless role.permissions.include? wbs_delete
role.permissions << wbs_create_template unless role.permissions.include? wbs_create_template
role.permissions << wbs_edit_template unless role.permissions.include? wbs_edit_template
role.permissions << wbs_delete_template unless role.permissions.include? wbs_delete_template
role.save

role = Role.find_or_create_by!(name: "PSG")
role.permissions << wbs_view unless role.permissions.include? wbs_view

role = Role.find_or_create_by!(name: "PMO")
role.permissions << wbs_view unless role.permissions.include? wbs_view

gsa = GsaLaborCategory.find_or_create_by(name: 'Cloud Security Consultant')
gsa.update(
  gsa_floor_price: 180.76,
  federal_max_price: 180.76,
  description:'<b>GSA SIN 518210C:</b> Assists more experienced consultants in analyzing and defining cloud '\
              'security requirements. Assists in performing risk analysis and security audit services and in '\
              'developing analytical reports. May assist in performing in one or more of the following areas: '\
              'risk assessment methods and procedures; security of system software generation; security of '\
              'computer hardware; operating system utility/support software; disaster recovery, incident '\
              'response, application assessment, vulnerability threat management, cloud security, penetration '\
              'testing and contingency planning; support the development of security policies and procedures.'\
              '<br>Requires: BA/BS and 2 years of experience, Ph.D. and 0 years of experience, MA/MS and 0 '\
              'years of experience, AA/AS and 4 years of experience, HS/GED and 6 years of experience, or '\
              'Professional Certification (s) in the related IT field and 4 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Cloud Senior Security Consultant')
gsa.update(
  gsa_floor_price: 194.66,
  federal_max_price: 194.66,
  description:'<b>GSA SIN 518210C:</b> Analyzes and defines cloud security requirements and designs, develops, '\
              'engineers, and implements solutions. Performs risk analysis and security audit services, '\
              'developing analytical reports as required. May be required to perform in one or more of the '\
              'following areas: risk assessment methods and procedures; security of system software generation; '\
              'security of computer hardware; operating system utility/support software; disaster recovery, '\
              'incident response, application assessment, vulnerability threat management, cloud security, '\
              'penetration testing and contingency planning; development of security policies and procedures. '\
              'May be responsible for leading a team in performing these services.<br>Requires: BA/BS and 3 '\
              'years of experience, Ph.D. and 0 years of experience, MA/MS and 1 year of experience, AA/AS and '\
              '5 years of experience, HS/GED and 7 years of experience, or Professional Certification (s) in '\
              'the related IT field and 5 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Cloud Managing Security Consultant')
gsa.update(
  gsa_floor_price: 208.56,
  federal_max_price: 208.56,
  description:'<b>GSA SIN 518210C:</b> Directs the consulting teams in the delivery of cloud information '\
              'security, cloud information security systems, and/or cloud computer security requirements. '\
              'Designs, develops, engineers, and implements security solutions. Gathers and organizes technical '\
              'information about an organization’s mission, goals, and needs; existing security products; and '\
              'ongoing programs. Develops, analyzes, and implements cloud security architecture(s) as '\
              'appropriate. Performs risk analysis and security audit services, develops analytical reports as '\
              'required. May be required to perform in one or more of the following areas: risk assessment '\
              'methods and procedures; security of system software generation; security of computer hardware; '\
              'operating system utility/support software; disaster recovery, incident response, application '\
              'assessment, vulnerability threat management, cloud security, penetration testing, and '\
              'contingency planning; telecommunications security; development of security policies and '\
              'procedures. Responsible for leading a team in performing these services.<br>Requires: BA/BS and '\
              '5 years of experience, Ph.D. and 1 year of experience, MA/MS and 3 years of experience, AA/AS '\
              'and 7 years of experience, HS/GED and 9 years of experience, or Professional Certification (s) '\
              'in the related IT field and 7 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Cloud Senior Security Architect')
gsa.update(
  gsa_floor_price: 231.74,
  federal_max_price: 231.74,
  description:'<b>GSA SIN 518210C:</b> Responsible for the analysis, development, and design of the cloud '\
              'enterprise information architecture by determining security requirements; planning, '\
              'implementing, and testing security systems; preparing security standards, policies, and '\
              'procedures; mentoring team members.<br>Requires: BA/BS and 5 years of experience, Ph.D. and 1 '\
              'year of experience, MA/MS and 3 years of experience, AA/AS and 7 years of experience, HS/GED '\
              'and 9 years of experience, or Professional Certification (s) in the related IT field and 7 years '\
              'of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Cloud Project Manager')
gsa.update(
  gsa_floor_price: 180.76,
  federal_max_price: 180.76,
  description:'<b>GSA SIN 518210C:</b> Coordinates resources to a cloud technical project or portions of a '\
              'technical Program to manage deliverables, burn rate, and other task related across a specific '\
              'project, Work with the government Contracting Officer, the COTR, government management personnel, '\
              'and client agency representatives. Under the guidance of the client representative, is '\
              'responsible for the coordination of a specific project and ensures that the technical solutions '\
              'and schedules in the project are implemented in a timely manner.<br>Requires: BA/BS and 2 years '\
              'of experience, Ph.D. and 0 years of experience, MA/MS and 0 years of experience, AA/AS and 4 '\
              'years of experience, HS/GED and 6 years of experience, or Professional Certification (s) in the '\
              'related IT field and 4 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Sr. SME')
gsa.update(
  gsa_floor_price: 253.90,
  federal_max_price: 253.90,
  description:'<b>GSA SIN 54151S:</b> Confers with client management and leads in the outline and development '\
              'of a client’s strategic information security and information technology business goals and IT '\
              'strategy. Analyzes client requirements and recommends development or acquisition strategies. '\
              'Assists clients in developing strategic plans and concepts. Advises client on the impact of new '\
              'legislation or new technologies that are relevant to their agency. Demonstrates exceptional '\
              'oral and written communication skills. Possesses requisite knowledge and expertise so recognized '\
              'in the professional community that the individual is considered "expert" in the technical'\
              '/specialty area being addressed.<br>Requires: BA/BS and 12 years of experience, Ph.D. and 8 '\
              'years of experience, MA/MS and 10 years of experience, AA/AS and 14 years of experience, HS/GED '\
              'and 16 years of experience, or Professional Certification (s) in the related IT field and 14 '\
              'years of experience.',
  description2:'<b>GSA SIN 54151HACS:</b> Confers with client\'s senior security management team and leads in '\
              'the outline and development of a client\'s strategic Information Assurance systems plans, '\
              'information security technology business goals and the client\'s cybersecurity management '\
              'strategy. Analyzes and assesses client cybersecurity systems and architecture requirements and '\
              'recommends development or acquisition strategies for security solutions. Assists clients in '\
              'developing strategic cybersecurity plans and concepts. Advises client on the impact of new '\
              'cybersecurity legislation, mandates, regulations, or new technologies and industry best-practices '\
              'that are relevant to their agency. Demonstrates exceptional oral and written communication '\
              'skills. Possesses requisite knowledge and expertise so recognized in the professional '\
              'cybersecurity community that the individual is considered "expert" in the Information Assurance '\
              'area being addressed.<br>Requires: BA/BS and 12 years of experience, Ph.D. and 8 years of '\
              'experience, MA/MS and 10 years of experience, AA/AS and 14 years of experience, HS/GED and 16 '\
              'years of experience, or Professional Certification (s) in the related IT field and 14 years of '\
              'experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'SME')
gsa.update(
  gsa_floor_price: 199.94,
  federal_max_price: 199.94,
  description:'<b>GSA SIN 54151S:</b> Provides insight and guidance to the client regarding their strategic '\
              'information security and information technology business goals and IT strategy. Analyzes client '\
              'requirements and recommends development or acquisition strategies. Assists clients in developing '\
              'strategic plans and concepts. Advises client on the impact of new legislation or new '\
              'technologies that are relevant to their agency. Demonstrates exceptional oral and written '\
              'communication skills. Possesses requisite knowledge and expertise so recognized in the '\
              'professional community that the individual is considered "expert" in the technical/specialty '\
              'area being addressed.<br>Requires: BA/BS and 10 years of experience, Ph.D. and 6 years of '\
              'experience, MA/MS and 8 years of experience, AA/AS and 12 years of experience, HS/GED and 14 '\
              'years of experience, or Professional Certification (s) in the related IT field and 12 years of '\
              'experience.',
  description2:'<b>GSA SIN 54151HACS:</b> Provides insight and guidance to the client regarding their strategic '\
              'Information Assurance systems plans, information security technology business goals and the '\
              'client\'s cybersecurity management strategy. Analyzes and assesses client cybersecurity systems '\
              'and architecture requirements and recommends development or acquisition strategies for security '\
              'solutions. Assists clients in developing strategic cybersecurity plans and concepts. Advises '\
              'client on the impact of new cybersecurity legislation, mandates, regulations or new '\
              'technologies and industry best-practices that are relevant to their agency. Demonstrates superior '\
              'oral and written communication skills. Possesses requisite knowledge and expertise so recognized '\
              'in the professional cybersecurity community that the individual is considered "expert" in the '\
              'Information Assurance area being addressed.<br>Requires: BA/BS and 10 years of experience, '\
              'Ph.D. and 6 years of experience, MA/MS and 8 years of experience, AA/AS and 12 years of '\
              'experience, HS/GED and 14 years of experience, or Professional Certification (s) in the related '\
              'IT field and 12 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Project Manager')
gsa.update(
  gsa_floor_price: 172.29,
  federal_max_price: 172.29,
  description:'<b>GSA SIN 54151S:</b> Plans and directs a highly technical project (or a group of related '\
              'tasks) and assists in working with the government Contracting Officer, the COTR, government '\
              'management personnel, and client agency representatives. Under the guidance of the client '\
              'representative, is responsible for the overall management of specific Task Orders and ensures '\
              'that the technical solutions and schedules in the Task Order are implemented in a timely '\
              'manner.<br>Requires: BA/BS and 10 years of experience, Ph.D. and 6 years of experience, MA/MS and '\
              '8 years of experience, AA/AS and 12 years of experience, HS/GED and 14 years of experience, or '\
              'Professional Certification (s) in the related IT field and 12 years of experience.',
  description2:'<b>GSA SIN 54151HACS:</b> Plans and directs Information Assurance programs or projects (or a group '\
              'of related Cybersecurity tasks) and assists in working with the government Contracting Officer, '\
              'the COTR, government management personnel (CISO, ISSM), and client security representatives. Under '\
              'the guidance of the client representative, is responsible for the overall management of specific '\
              'security-based Task Orders and ensures that the Information Assurance security solutions and '\
              'schedules in the Task Order are implemented in a timely manner.<br>Requires: BA/BS and 10 years of '\
              'experience, Ph.D. and 6 years of experience, MA/MS and 8 years of experience, AA/AS and 12 years '\
              'of experience, HS/GED and 14 years of experience, or Professional Certification (s) in the related '\
              'IT field and 12 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Senior Project Manager')
gsa.update(
  gsa_floor_price: 201.00,
  federal_max_price: 175.50,
  description:'Plans and directs highly technical projects or portion(s) of a technical program to manage '\
              'deliverables, burn rate, cost, and other task related across the spectrum, Work with the government '\
              'Contracting Officer, the COTR, government management personnel, and client agency representatives. '\
              'Under the guidance of the client representative, is responsible for the management of a specific '\
              'project and ensures that the technical solutions and schedules in the project are implemented in a '\
              'timely manner.<br>Requires: HS diploma and 10 years experience, or BS/BA degree and 5 years experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Managing Security Consultant')
gsa.update(
  gsa_floor_price: 181.36,
  federal_max_price: 181.36,
  description:'<b>GSA SIN 54151S:</b> Directs the consulting teams in the delivery of information security, information security systems, and/or '\
              'computer security requirements. Designs, develops, engineers, and implements security solutions. '\
              'Gathers and organizes technical information about an organization’s mission, goals, and needs; existing '\
              'security products; and ongoing programs. Develops, analyzes, and implements security architecture(s) as '\
              'appropriate. Performs risk analysis and security audit services, develops analytical reports as required. '\
              'May be required to perform in one or more of the following areas: risk assessment methods and '\
              'procedures; security of system software generation; security of computer hardware; operating system '\
              'utility/support software; disaster recovery, incident response, application assessment, vulnerability threat '\
              'management, cloud security, and contingency planning; telecommunications security; development of '\
              'security policies and procedures. May be responsible for leading a team in performing these services. '\
              '<br>Requires: BA/BS and 10 years of experience, Ph.D. and 6 years of experience, MA/MS and 8 years of '\
              'experience, AA/AS and 12 years of experience, HS/GED and 14 years of experience, or Professional '\
              'Certification (s) in the related IT field and 12 years of experience.',
  description2:'<b>GSA SIN 54151HACS:</b> Directs the Cybersecurity and IA teams in the delivery of information '\
              'security, information security systems, and/or computer security requirements. Architects, '\
              'assesses, develops, engineers, and implements Cybersecurity solutions. Retrieves, gathers, and '\
              'organizes technical information about an organization’s risks, vulnerabilities, and exposures '\
              'within the existing security products, networks, applications, and programs. Develops, analyzes, '\
              'and implements Cybersecurity architecture(s) as appropriate. Performs risk analysis assessments, '\
              'conducts Cybersecurity governance and compliance services, develops analytical and technical '\
              'reports as required. May be required to perform in one or more of the following areas: risk and '\
              'vulnerability assessments; cyber hunting activities; conducting penetration testing and scanning; '\
              'assessment of system security for compliance; security of computer network hardware; operating '\
              'system utility/support software; disaster recovery; incident response and digital forensics; '\
              'application assessment; vulnerability threat management; cloud security; contingency planning; '\
              'social engineering; and the development of security policies and procedures. May be responsible '\
              'for leading a team in performing these services.<br>Requires: BA/BS and 10 years of experience, '\
              'Ph.D. and 6 years of experience, MA/MS and 8 years of experience, AA/AS and 12 years of '\
              'experience, HS/GED and 14 years of experience, or Professional Certification (s) in the related '\
              'IT field and 12 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Managing Security Architect')
gsa.update(
  gsa_floor_price: 208.00,
  federal_max_price: 181.36,
  description:'Responsible for managing the analysis, development and design of the enterprise information '\
              'architecture by determining security requirements; planning, implementing, and testing security '\
              'systems; preparing security standards, policies, and procedures; Managing Security Architecture '\
              'review across multiple enterprise network/Enclaves and map reviews to required standards. '\
              'Understands different threat actors and able to conduct a threat modeling review for said system or '\
              'systems. Responsible for mentoring a team in performing these services.<br>Requires: HS diploma and 12 '\
              'years experience, or BS/BA degree and 7 years experience, or MS degree and 5 years experience, or '\
              'PhD degree and 1 years experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Managing Security Analyst')
gsa.update(
  gsa_floor_price: 208.00,
  federal_max_price: 181.36,
  description:'Directs the Analyst teams in the delivery of Security Operation Centers and/or mapping SOC '\
              'operations to secrity standards requirements. Designs, develops, and implements security operation '\
              'centers and strategy. Gathers and organizes technical information about an organization’s mission, '\
              'goals, and needs; existing security standards and mandates; and ongoing programs. Develops, '\
              'analyzes, and implements security mandate(s) as appropriate. Performs risk analysis and security '\
              'audit services, develops analytical reports as required. May be required to perform in one or more '\
              'of the following areas: Network Security Monitoring, Cyber Threat Intelligence, Malware Analysis, '\
              'DFIR services, Advance Analytics, Cyber Hunt, Countermeasure development, Cyber Fusion Analysis, '\
              'incident management, Insider Threat Analysis, eDiscovery Analysis, and/or Threat Emulation '\
              'Services.<br>Requires: HS diploma and 10 years experience, or BS/BA degree and 5 years experience, or '\
              'MS degree and 2 years experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Senior Security Consultant')
gsa.update(
  gsa_floor_price: 163.22,
  federal_max_price: 163.22,
  description:'<b>GSA SIN 54151S:</b> Analyzes and defines security requirements and designs, develops, '\
              'engineers, and implements solutions. Performs risk analysis and security audit services, '\
              'developing analytical reports as required. May be required to perform in one or more of the '\
              'following areas: risk assessment methods and procedures; security of system software generation; '\
              'security of computer hardware; operating system utility/support software; disaster recovery and '\
              'contingency planning; telecommunications security; development of security policies and '\
              'procedures.<br>Requires: BA/BS and 3 years of experience, Ph.D. and 0 years of experience, MA/MS '\
              'and 1 year of experience, AA/AS and 5 years of experience, HS/GED and 7 years of experience, or '\
              'Professional Certification (s) in the related IT field and 5 years of experience.',
  description2:'<b>GSA SIN 54151HACS:</b> Analyzes and defines security requirements and designs, develops, '\
              'engineers, and implements solutions. Performs risk analysis and security audit services, '\
              'developing analytical reports as required. May be required to perform in one or more of the '\
              'following areas: risk and vulnerability assessments; cyber hunting activities; conducting '\
              'penetration testing and scanning; assessment of system security for compliance; security of '\
              'computer network hardware; operating system utility/support software; disaster recovery; '\
              'incident response and digital forensics; application assessment; vulnerability threat management; '\
              'cloud security; contingency planning; social engineering; and the development of security '\
              'policies and procedures.<br>Requires: BA/BS and 3 years of experience, Ph.D. and 0 years of '\
              'experience, MA/MS and 1 year of experience, AA/AS and 5 years of experience, HS/GED and 7 years '\
              'of experience, or Professional Certification (s) in the related IT field and 5 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Senior Security Architect')
gsa.update(
  gsa_floor_price: 192.00,
  federal_max_price: 167.76,
  description:'Responsible for the analysis, development and design of the enterprise information architecture by '\
              'determining security requirements; planning, implementing, and testing security systems; preparing '\
              'security standards, policies, and procedures; Security Architecture review across a enterprise '\
              'network and map review to required standards. Understands different threat actors and able to '\
              'conduct a threat modeling review for said system or systems. May be responsible mentoring a team in '\
              'performing these services.<br>Requires: HS diploma and 8 years experience, or BS/BA degree and 5 years '\
              'experience, or MS degree and 2 years experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Senior Security Analyst')
gsa.update(
  gsa_floor_price: 187.00,
  federal_max_price: 163.22,
  description:'Leads team in analyzing and defining security requirements and designs, develops, and implements '\
              'security operations strategy and mandates. Performs SOC analysis and security services, developing '\
              'analytical reports as required. May be required to perform in one or more of the following areas: '\
              'Network Security Monitoring, Cyber Threat Intelligence, Malware Analysis, DFIR services, Advance '\
              'Analytics, Cyber Hunt, Countermeasure development, Cyber Fusion Analysis, incident management, '\
              'Insider Threat Analysis, eDiscovery Analysis, and/or Threat Emulation Services.<br>Requires: HS '\
              'diploma and 7 years experience, or BS/BA degree and 3 years experience, or MS degree and 1 years '\
              'experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Security Analyst')
gsa.update(
  gsa_floor_price: 149.62,
  federal_max_price: 149.62,
  description:'<b>GSA SIN 54151S:</b> Assisting member of a team for delivering on a specific task of a '\
              'small/simple projects individually and large projects as a team member with oversight and '\
              'continual skill development.<br>Requires: BA/BS and 0 to 2 years of experience, Ph.D. and 0 '\
              'years of experience, MA/MS and 0 years of experience, AA/AS and 2 to 4 years of experience, '\
              'HS/GED and 4 to 6 years of experience, or Professional Certification (s) in the related IT '\
              'field and 2 to 4 years of experience.',
  description2:'<b>GSA SIN 54151HACS:</b> Assisting member of a team for delivering on a specific Cybersecurity '\
              'task of a small/simple projects individually and large projects as a team member with oversight '\
              'and continual skill development.<br>Requires: BA/BS and 0 to 2 years of experience, Ph.D. and 0 '\
              'years of experience, MA/MS and 0 years of experience, AA/AS and 2 to 4 years of experience, '\
              'HS/GED and 4 to 6 years of experience, or Professional Certification (s) in the related IT '\
              'field and 2 to 4 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Associate Security Analyst')
gsa.update(
  gsa_floor_price: 165.00,
  federal_max_price: 144.00,
  description:'Assists more experienced analyst in analyzing and monitoring security incidents. Assists in '\
              'performing security analysis and SOC operation services and in developing analytical reports. May '\
              'assist in performing in one or more of the following areas: Network Security Monitoring, Cyber '\
              'Threat Intelligence, Malware Analysis, DFIR services, Advance Analytics, Cyber Hunt, Countermeasure '\
              'development, Cyber Fusion Analysis, incident management, Insider Threat Analysis, eDiscovery '\
              'Analysis, and/or Threat Emulation Services.<br>Requires: HS diploma and 1 year experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Security Consultant')
gsa.update(
  gsa_floor_price: 154.16,
  federal_max_price: 154.16,
  description:'<b>GSA SIN 54151S:</b> Assists more experienced consultants in analyzing and defining security '\
              'requirements. Assists in performing risk analysis and security audit services and in developing '\
              'analytical reports. May assist in performing in one or more of the following areas: risk '\
              'assessment methods and procedures; security of system software generation; security of computer '\
              'hardware; operating system utility/support software; disaster recovery and contingency planning; '\
              'telecommunications security; development of security policies and procedures.<br>Requires: BA/BS '\
              'and 2 years of experience, Ph.D. and 0 years of experience, MA/MS and 0 years of experience, '\
              'AA/AS and 4 years of experience, HS/GED and 6 years of experience, or Professional Certification '\
              '(s) in the related IT field and 4 years of experience.',
  description2:'<b>GSA SIN 54151HACS:</b> Assists more experienced consultants in analyzing and defining security '\
              'requirements. Assists in performing risk analysis and security audit services and in developing '\
              'analytical reports. May assist in performing in one or more of the following areas: Risk and '\
              'Vulnerability Assessments; Cyber Hunting activities; conducting Penetration Testing and scanning; '\
              'assessment of system security for compliance of applications; security of computer network '\
              'hardware; operating system utility/support software; disaster recovery; incident response and '\
              'digital forensics; application assessment; vulnerability threat management; cloud security; '\
              'contingency planning; social engineering; and the development of security policies and '\
              'procedures.<br>Requires: BA/BS and 2 years of experience, Ph.D. and 0 years of experience, '\
              'MA/MS and 0 years of experience, AA/AS and 4 years of experience, HS/GED and 6 years of '\
              'experience, or Professional Certification (s) in the related IT field and 4 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Associate Security Consultant')
gsa.update(
  gsa_floor_price: 165.00,
  federal_max_price: 144.00,
  description:'Assists more experienced consultants in the implementation and optimization of IT infrastructure '\
              'security solutions. Assists in performing the engineers with complex integration and implementation '\
              'of network security stack based devices. May assist in performing in one or more of the following '\
              'areas: risk assessment methods and procedures; security of system software generation; security of '\
              'computer hardware; operating system utility/support software; disaster recovery, incident response, '\
              'application assessment, vulnerability threat management, cloud security, penetration testing and '\
              'contingency planning.<br>Requires: HS diploma and 1 year experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Managing Security Engineer')
gsa.update(
  gsa_floor_price: 181.36,
  federal_max_price: 181.36,
  description:'<b>GSA SIN 54151S:</b> Directs the engineering teams in the delivery of information security '\
              'product solutions, information security systems, and/or computer security requirements. Designs, '\
              'develops, engineers, and implements security solutions. Gathers and organizes technical '\
              'information about an organization’s mission, goals, and needs; existing security products; and '\
              'ongoing programs. Develops, analyzes, and implements security architecture(s) as appropriate. '\
              'Performs risk analysis and security audit services, develops analytical reports as required. May '\
              'be required to perform in one or more of the following areas: risk assessment methods and '\
              'procedures; security of system software generation; security of computer hardware; operating '\
              'system utility/support software; disaster recovery, incident response, application assessment, '\
              'vulnerability threat management, cloud security, and contingency planning; telecommunications '\
              'security; development of security policies and procedures. May be responsible for leading a team '\
              'in performing these services.<br>Requires: BA/BS and 10 years of experience, Ph.D. and 6 years of '\
              'experience, MA/MS and 8 years of experience, AA/AS and 12 years of experience, HS/GED and 14 years '\
              'of experience, or Professional Certification (s) in the related IT field and 12 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Security Architect')
gsa.update(
    gsa_floor_price: 177.00,
    federal_max_price: 154.16,
    description:'Assists more experienced Architects for the analysis, development and design of the enterprise '\
                'information architecture by determining security requirements; planning, implementing, and testing '\
                'security systems; preparing security standards, policies, and procedures; Security Architecture '\
                'review across a enterprise network and map review to required standards. Understands different '\
                'threat actors and able to conduct a threat modeling review for said system or systems.<br>Requires: '\
                'HS diploma and 5 years experience, or BS/BA degree and 3 years experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Senior Security Architect')
gsa.update(
  gsa_floor_price: 167.76,
  federal_max_price: 167.76,
  description:'<b>GSA SIN 54151S:</b> Responsible for the analysis, development, and design of the enterprise '\
              'information architecture by determining security requirements; planning, implementing, and '\
              'testing security systems; preparing security standards, policies, and procedures; mentoring team '\
              'members.<br>Requires: BA/BS and 5 years of experience, Ph.D. and 1 year of experience, MA/MS '\
              'and 3 years of experience, AA/AS and 7 years of experience, HS/GED and 9 years of experience, or '\
              'Professional Certification (s) in the related IT field and 7 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Senior Security Engineer')
gsa.update(
  gsa_floor_price: 163.22,
  federal_max_price: 163.22,
  description:'<b>GSA SIN 54151S:</b> Engineering technical lead of security solutions through analysis, '\
              'requirement assessment, network designs, through solution implementation. Leads the engineer '\
              'team with complex integration and implementation of network security stack-based devices. '\
              'Performs risk analysis and security audit services, developing analytical reports as required. '\
              'Directs the team in performing in one or more of the following areas: analysis & design; '\
              'implementation; optimization; security of computer hardware; operating system utility/support '\
              'software; disaster recovery and contingency planning; telecommunications security; development '\
              'of security policies and procedures.<br>Requires: BA/BS and 3 years of experience, Ph.D. and 0 '\
              'years of experience, MA/MS and 1 year of experience, AA/AS and 5 years of experience, HS/GED and '\
              '7 years of experience, or Professional Certification (s) in the related IT field and 5 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Security Engineer')
gsa.update(
  gsa_floor_price: 149.62,
  federal_max_price: 149.62,
  description:'<b>GSA SIN 54151S:</b> Assists more experienced engineers in the implementation and '\
              'optimization of IT infrastructure security solutions. Assists in performing the engineers with '\
              'complex integration and implementation of network security stack-based devices. May assist in '\
              'performing in one or more of the following areas: analysis & design; implementation; '\
              'optimization; security of computer hardware; operating system utility/support software; disaster '\
              'recovery and contingency planning; telecommunications security; development of security policies '\
              'and procedures.<br>Requires: BA/BS and 0 to 2 years of experience, Ph.D. and 0 years of '\
              'experience, MA/MS and 0 years of experience, AA/AS and 2 to 4 years of experience, HS/GED and '\
              '4 to 6 years of experience, or Professional Certification (s) in the related IT field and 2 to '\
              '4 years of experience.'
)

gsa = GsaLaborCategory.find_or_create_by(name: 'Associate Security Engineer')
gsa.update(
  gsa_floor_price: 165.00,
  federal_max_price: 144.00,
  description:'Assists more experienced engineers in the implementation and optimization of IT infrastructure '\
              'security solutions. Assists in performing the engineers with complex integration and implementation '\
              'of network security stack based devices. May assist in performing in one or more of the following '\
              'areas: cloud security, infrastructure security (to include but not limited to Network and Host '\
              'based security), Log/Audit security, Dashboarding Creation, Firewall/IP/DS engineering, Identity '\
              'Security (PAM, Access, Governance), EDR Engineering, Technology Operations, ADC/WAF/Access Policy '\
              'Engineering, Behavior Analytics (ML & AI), Insider Threat technology, and eDiscovery; '\
              'telecommunications security; development of security policies and procedures.<br>Requires: HS diploma '\
              'and 1 year experience.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'Project Coordinator')
gsa.update(
  description:'The Project Coordinator is responsible for the coordination of multiple projects under general '\
              'guidance of a Senior Project Manager or Program Manager. Project Coordinators align engagement '\
              'activity from inception to completion, identify and document project requirements, support clients '\
              'throughout the engagement lifecycle, keep stakeholders apprised of project and budget status, and '\
              'manage issues to resolution. The Project Coordinator is also responsible for assembling the delivery '\
              'team, which includes identifying the necessary resources, assigning resources to tasks, developing and '\
              'driving a schedule to ensure timely completion of a project.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'Managing Cloud Security Engineer')
gsa.update(
  description:'Directs the engineering/consulting teams in the delivery of any XaaS information security solutions, '\
              'information security systems, and/or computer security requirements. Designs, develops, engineers, '\
              'and implements security solutions. Gathers and organizes technical information about an '\
              'organization’s mission, goals, and needs; existing security products; and ongoing programs. '\
              'Develops, analyzes, and implements security architecture(s) as appropriate. Performs risk analysis '\
              'and security audit services, develops analytical reports as required.<br>Requires: HS diploma and 10 '\
              'years experience, or BS/BA degree and 5 years experience, or MS degree and 2 years experience.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'Senior Cloud Security Engineer')
gsa.update(
  description:'Engineering/Consulting technical lead of any XaaS security solutions through analysis, requirement '\
              'assessment, network designs, through solution implementation. Leads the engineer team with complex '\
              'integration and implementation of network security stack based devices. Performs risk analysis and '\
              'security audit services, developing analytical reports as required.<br>Requires: HS diploma and 7 '\
              'years experience, or BS/BA and 3 years experience, or MS degree and 1 year experience.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'Cloud Security Engineer')
gsa.update(
  description:'Assists more experienced engineers/consultants in any XaaS service solutions, including the '\
              'implementation and optimization of IT infrastructure security solutions. Assists in performing the '\
              'engineers with complex integration and implementation of network security stack based devices.<br>'\
              'Requires: HS diploma and 5 years experience, or BS/BA degree and 2 years experience.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'Associate Cloud Security Engineer')
gsa.update(
  description:'Assists engineers/consulting in any XaaS service solutions, including the implementation and '\
              'optimization of IT infrastructure security solutions. Assists in performing the engineers with '\
              'complex integration and implementation of network security stack based devices.<br>Requires: HS '\
              'diploma and 1 year experience.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'Program Manager')
gsa.update(
  gsa_floor_price: nil,
  federal_max_price: nil,
  description:'Plans and directs multiple highly technical project or a technical Program to manage deliverables, '\
              'burn rate, cost, and other task related across the spectrum, Work with the government Contracting '\
              'Officer, the COTR, government management personnel, and client agency representatives. Under the '\
              'guidance of the client representative, is responsible for the overall management of Task Orders and '\
              'ensures that the technical solutions and schedules in the Task Order are implemented in a timely '\
              'manner.<br>Requires: HS diploma and 7 years experience, or BS/BA degree and 3 years experience.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'Engineer Specialist')
gsa.update(
  description:'Technician trained on one unique vendor security solution. Provides analysis, requirements assessment, '\
              'and solution implementation. Works with other engineers on complex integration and implementation of '\
              'that one vendor\'s network security solution. Works on previously scoped, well-defined projects. '\
              'Provides the team in expertise in the one vendors solutions performing in one or more of the following '\
              'areas: analysis & design; implementation; optimization; security of computer hardware; operating '\
              'system utility/support software; disaster recovery and contingency planning; telecommunications '\
              'security; development of security policies and procedures.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'GuidePoint SOAR Services-Standard')
gsa.update(
  gsa_floor_price: 1632.24,
  federal_max_price: 1632.24,
  description:'<b>GSA SIN 54151S:</b> GuidePoint Security will provide services for your SOAR platform.  This service '\
              'includes, but is not limited to, standard configuration of your SOAR platform, and basic playbook '\
              'development and integrating products into workflow actions. Such services are on-site. Price is daily '\
              'during normal hours of business.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'GuidePoint SOAR Services-Remote')
gsa.update(
  gsa_floor_price: 1450.88,
  federal_max_price: 1450.88,
  description:'<b>GSA SIN 54151S:</b> GuidePoint Security will provide services for your SOAR platform.  This service '\
              'includes, but is not limited to, standard configuration of your SOAR platform, and basic playbook '\
              'development and integrating products into workflow actions. Such services will be provided remotely. '\
              'Price is daily during normal hours of business.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'GuidePoint SOAR Services-Premium')
gsa.update(
  gsa_floor_price: 1813.60,
  federal_max_price: 1813.60,
  description:'<b>GSA SIN 54151S:</b> GuidePoint Security will provide premium services for your SOAR platform that '\
              'require extensive SOAR expertise.  This service offering includes, but is not limited to, tasks such '\
              'as assisting with platform selection based on your requirements, architecture & design, reviewing SOC '\
              'workflows and creating a SOAR implementation plan that includes a sustainable foundation for your SOAR '\
              'environment. Such services are on-site. Price is daily during normal hours of business.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'GuidePoint Splunk Services-Standard')
gsa.update(
  gsa_floor_price: 1632.24,
  federal_max_price: 1632.24,
  description:'<b>GSA SIN 54151S:</b> GuidePoint Security will provide services for Splunk core infrastructure, '\
              'architecture and design, installation, data collection, log governance, and onboarding and management, '\
              'and ensuring best practices across the entire Splunk lifecycle are addressed. Such services are '\
              'on-site. Price is daily during normal hours of business.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'GuidePoint Splunk Services-Remote')
gsa.update(
  gsa_floor_price: 1450.88,
  federal_max_price: 1450.88,
  description:'<b>GSA SIN 54151S:</b> GuidePoint Security will provide services for Splunk core infrastructure, '\
              'architecture and design, installation, data collection, log governance, and onboarding and management, '\
              'and ensuring best practices across the entire Splunk lifecycle are addressed. Such services will be '\
              'provided remotely. Price is daily during normal hours of business.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'GuidePoint Splunk Services-Premium')
gsa.update(
  gsa_floor_price: 1813.60,
  federal_max_price: 1813.60,
  description:'<b>GSA SIN 54151S:</b> Guidepoint Security will provide services for Splunk environments that involve '\
              'their premium applications. GuidePoint will assist with products such as Enterprise Security, ITSI, '\
              'and UBA.  These services include, but is not limited to, architecture and design, installation, '\
              'configuration, optimizing & tuning, and creating specific use case content for Splunk Premium '\
              'Applications. Such services are on-site. Price is daily during normal hours of business.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'GuidePoint F5 Networks Services-Standard')
gsa.update(
  gsa_floor_price: 1632.24,
  federal_max_price: 1632.24,
  description:'<b>GSA SIN 54151S:</b> GuidePoint Security will provide services for an F5 solution that includes '\
              'standard F5 features.  This service offering includes, but is not limited to, tasks such as '\
              'architecting and configuring F5 LTM, F5 DNS (Previously known as GTM), F5 APM '\
              '(Basic/Simple deployments), F5 AFM, BIG-IQ, F5 AWAF (Basic/Simple deployments) implementation and '\
              'standard O&M of your base F5 platform. Such services are on-site. Price is daily during normal hours '\
              'of business.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'GuidePoint F5 Networks Services-Remote')
gsa.update(
  gsa_floor_price: 1450.88,
  federal_max_price: 1450.88,
  description:'<b>GSA SIN 54151S:</b> GuidePoint Security will provide services for an F5 solution that includes '\
              'standard F5 features.  This service offering includes, but is not limited to, tasks such as '\
              'architecting and configuring F5 LTM, F5 DNS (Previously known as GTM), F5 APM (Basic/Simple '\
              'deployments), F5 AFM, BIG-IQ, F5 AWAF (Basic/Simple deployments) implementation and standard O&M of '\
              'your base F5 platform. Such services will be provided remotely. Price is daily during normal hours of '\
              'business.'
)

gsa = GsaLaborCategory.find_or_create_by!(name:'GuidePoint F5 Networks Services-Premium')
gsa.update(
  gsa_floor_price: 1813.60,
  federal_max_price: 1813.60,
  description:'<b>GSA SIN 54151S:</b> GuidePoint Security will provide premium professional services for an F5 '\
              'solution that includes premium F5 features.  This service offering includes, but is not limited to, '\
              'tasks such as advanced architecting and configuring of SSL Orchestration, F5 AWAF, F5 APM, F5 AFM, and '\
              'other F5 modules. Such services are on-site. Price is daily during normal hours of business.'
)

# Proposal Project Structures
Enumeration.find_or_create_by!(name: "Application Security", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Cloud Security", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Compliance", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Incident Response", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Security Assessments", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Federal Information Assurance", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "F5 Guardian", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Splunk Sub PS", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Corporate Technology Services", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Federal Technology Services", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Heartland Technology Services", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Mid-Atlantic Technology Solutions", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "North Central Technology Solutions", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Northeast Technology Solutions", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "Southeast Technology Solutions", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "vSOC Detect", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "vSOC Identify-TI", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "vSOC Identify-VM", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "vSOC Protect", enum_type: "project_structure")
Enumeration.find_or_create_by!(name: "N/A", enum_type: "project_structure")

Enumeration.find_or_create_by!(name:"Carolinas", enum_type: "region")
Enumeration.find_or_create_by!(name:"Delaware Valley", enum_type: "region")
Enumeration.find_or_create_by!(name:"Federal", enum_type: "region")
Enumeration.find_or_create_by!(name:"Four Corners", enum_type: "region")
Enumeration.find_or_create_by!(name:"Great Lakes", enum_type: "region")
Enumeration.find_or_create_by!(name:"Heartland", enum_type: "region")
Enumeration.find_or_create_by!(name:"Mid-Atlantic", enum_type: "region")
Enumeration.find_or_create_by!(name:"Northeast", enum_type: "region")
Enumeration.find_or_create_by!(name:"Northwest", enum_type: "region")
Enumeration.find_or_create_by!(name:"North Central", enum_type: "region")
Enumeration.find_or_create_by!(name:"Ohio Valley", enum_type: "region")
Enumeration.find_or_create_by!(name:"Southeast", enum_type: "region")
Enumeration.find_or_create_by!(name:"Southwest", enum_type: "region")
Enumeration.find_or_create_by!(name:"Texas", enum_type: "region")
Enumeration.find_or_create_by!(name:"MSSP", enum_type: "region")
Enumeration.find_or_create_by!(name:"All Other", enum_type: "region")
Enumeration.find_or_create_by!(name:"Corporate", enum_type: "region")

Enumeration.find_or_create_by(name: "FFP", enum_type:"contract_type")
Enumeration.find_or_create_by(name: "T&M", enum_type:"contract_type")

# No Longer Valid
# Enumeration.find_or_create_by(name: "Combined FFP/T&M", enum_type:"contract_type")
combined = Enumeration.find_by(name: "Combined FFP/T&M", enum_type:"contract_type")
if !combined.nil?
  combined.destroy
end

# No Longer Valid
# Enumeration.find_or_create_by(name: "Unknown", enum_type:"contract_type")
unknown = Enumeration.find_by(enum_type:'contract_type', name:'Unknown')
if !unknown.nil?
  unknown.destroy
end

Enumeration.find_or_create_by(name: "50% upon Signature, 50% upon Draft Deliverable", enum_type:"billing_rule")
Enumeration.find_or_create_by(name: "PCI - 25%/50%/25%", enum_type:"billing_rule")
Enumeration.find_or_create_by(name: "Upon Completion", enum_type:"billing_rule")
Enumeration.find_or_create_by(name: "Upon Delivery of All Draft Deliverables", enum_type:"billing_rule")
Enumeration.find_or_create_by(name: "Upon Delivery of Individual Draft Deliverables", enum_type:"billing_rule")
Enumeration.find_or_create_by(name: "Upon Signature", enum_type:"billing_rule")
Enumeration.find_or_create_by(name: "Monthly", enum_type:"billing_rule")
Enumeration.find_or_create_by(name: "Contract Term Period", enum_type:'billing_rule')
#Enumeration.find_or_create_by(name: "Other", enum_type:"billing_rule")
other = Enumeration.find_by(enum_type:'billing_rule', name:'Other')
if !other.nil?
  other.destroy
end

Enumeration.find_or_create_by(name: "GuidePoint Direct", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "1st Source", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "8(a) Set Aside", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "Agency BPA", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "FedBid-GSA", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "FedBid-Open Market", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "FedBiz", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "GSA", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "GSA - GuidePoint Security", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "ITES", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "NetCents", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "Open Market", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "SEWP", enum_type:'contract_vehicle')
Enumeration.find_or_create_by(name: "TD SYNNEX- MSA-NCPA Omnia Equalis Use", enum_type:'contract_vehicle')

Enumeration.find_or_create_by(name: "IPT",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "EPT",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "WSA",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "RSE",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "CSE",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "VA",    enum_type: "sku" )
Enumeration.find_or_create_by(name: "PSR",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "OSE",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "Other", enum_type: "sku" )
Enumeration.find_or_create_by(name: "IOT",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "OSINT", enum_type: "sku" )
Enumeration.find_or_create_by(name: "CPT",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "ADSR",  enum_type: "sku" )
Enumeration.find_or_create_by(name: "RTA",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "PTA",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "SCR",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "ASA",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "MASA",  enum_type: "sku" )
Enumeration.find_or_create_by(name: "SAV",   enum_type: "sku" )
Enumeration.find_or_create_by(name: "ASMR",  enum_type: "sku" )

Enumeration.find_or_create_by(name: 'High', enum_type: "priority" )
Enumeration.find_or_create_by(name: 'Medium', enum_type: "priority" )
Enumeration.find_or_create_by(name: 'Low', enum_type: "priority" )

Enumeration.find_or_create_by(name:"Yes", enum_type:"yes_no_response")
Enumeration.find_or_create_by(name:"No", enum_type:"yes_no_response")
Enumeration.find_or_create_by(name:"N/A", enum_type:"yes_no_response")
Enumeration.find_or_create_by(name:"Unknown", enum_type:"yes_no_response")

Enumeration.find_or_create_by(name: "Unknown", enum_type: 'award_status')
Enumeration.find_or_create_by(name: "Won", enum_type: 'award_status')
Enumeration.find_or_create_by(name: "Lost", enum_type: 'award_status')
Enumeration.find_or_create_by(name: "Cancelled", enum_type: 'award_status')
Enumeration.find_or_create_by(name: "Postponed", enum_type: 'award_status')

Enumeration.find_or_create_by(name: 'Low', enum_type:'risk_level')
Enumeration.find_or_create_by(name: 'Medium', enum_type:'risk_level')
Enumeration.find_or_create_by(name: 'High', enum_type:'risk_level')

Enumeration.find_or_create_by(name: 'Actuals', enum_type: 'expense_structure')
Enumeration.find_or_create_by(name: 'Per Diem', enum_type: 'expense_structure')
Enumeration.find_or_create_by(name: 'Unknown (RFP, etc.)', enum_type: 'expense_structure')
Enumeration.find_or_create_by(name: 'N/A', enum_type: 'expense_structure')

Enumeration.find_or_create_by(name:'EST', enum_type:'timezone')
Enumeration.find_or_create_by(name:'CST', enum_type:'timezone')
Enumeration.find_or_create_by(name:'PST', enum_type:'timezone')
Enumeration.find_or_create_by(name:'MST', enum_type:'timezone')
Enumeration.find_or_create_by(name:'AST', enum_type:'timezone')

Enumeration.find_or_create_by(name:'string', enum_type:'variable_type')
Enumeration.find_or_create_by(name:'float', enum_type:'variable_type')
Enumeration.find_or_create_by(name:'integer', enum_type:'variable_type')
Enumeration.find_or_create_by(name:'text', enum_type:'variable_type')
Enumeration.find_or_create_by(name:'currency', enum_type:'variable_type')

variable = Variable.find_or_create_by(name:'default_billable_rate', label:'Default Billable Rate')
variable.kind = 'currency'
variable.value = 250.0
variable.save

variable = Variable.find_or_create_by(name:'default_internal_rate', label:'Default Internal Rate')
variable.kind = 'currency'
variable.value = 180.0
variable.save

variable = Variable.find_or_create_by(name:'default_contract_vehicle', label:'Default Contract Vehicle')
variable.value = 'GuidePoint Direct'
variable.save

variable = Variable.find_or_create_by(name:'default_contract_type', label:'Default Contract Type')
variable.value = 'FFP'
variable.save

variable = Variable.find_or_create_by(name:'default_dfir_internal_rate', label: 'Default DFIR Internal Rate')
variable.kind = 'currency'
variable.value = 200.0
variable.save

variable = Variable.find_or_create_by(name: 'admin_message', label: 'Administrative Message', kind:'string')
variable.value = ''
variable.save

variable = Variable.find_or_create_by(name: 'admin_delay', label: 'Administrative Message Delay (ms)', kind:'integer')
variable.value = 10000
variable.save

variable = Variable.find_or_create_by(name: 'calculated_max_tries', label: 'Max times to wait for Quote to calculate', kind:'integer')
variable.value = 20
variable.save

variable = Variable.find_or_create_by(name: 'calculated_sleep_time', label: 'Time COGS waits between polling for a quote to be calculated (exp)', kind:'integer')
variable.value = 1
variable.save
# Removed...use rake wbs:reindex instead
#WorkBreakdownStructure.reindex
