class UpdatePracticesWbsGroups < ActiveRecord::Migration[5.1]
  def change
    rename_column :practices_wbs_groups, :project_structure_id, :practice_id
    rename_index :practices_wbs_groups, :project_structure_wbs_group_index, :practice_wbs_group_index
  end
end
