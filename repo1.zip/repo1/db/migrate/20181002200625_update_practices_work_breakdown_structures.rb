class UpdatePracticesWorkBreakdownStructures < ActiveRecord::Migration[5.1]
  def change
    rename_column :practices_work_breakdown_structures, :project_structure_id, :practice_id
    rename_index :practices_work_breakdown_structures, :project_structure_index, :practice_index
  end
end
