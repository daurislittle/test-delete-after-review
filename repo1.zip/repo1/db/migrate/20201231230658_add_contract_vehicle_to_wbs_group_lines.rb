class AddContractVehicleToWbsGroupLines < ActiveRecord::Migration[6.0]
  def change
    add_column :wbs_group_lines, :contract_vehicle, :string
  end
end
