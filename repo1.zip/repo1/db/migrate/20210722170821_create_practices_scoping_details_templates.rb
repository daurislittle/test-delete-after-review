class CreatePracticesScopingDetailsTemplates < ActiveRecord::Migration[6.0]
  def change
    create_join_table :practices, :scoping_detail_templates do |t|
      t.index :practice_id, name: 'practices_sdts_on_practice_index'
      t.index :scoping_detail_template_id, name: 'practices_sdts_on_sdt_index'
    end
  end
end
