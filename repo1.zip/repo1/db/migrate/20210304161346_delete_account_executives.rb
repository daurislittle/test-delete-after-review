class DeleteAccountExecutives < ActiveRecord::Migration[6.0]
  def change
    drop_table :account_executives
  end
end
