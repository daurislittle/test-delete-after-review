class RenameProjectStructure < ActiveRecord::Migration[5.1]
  def change
    rename_column :work_breakdown_structures, :project_structure, :primary_structure
  end
end
