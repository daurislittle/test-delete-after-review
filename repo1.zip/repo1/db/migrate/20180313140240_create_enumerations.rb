class CreateEnumerations < ActiveRecord::Migration[5.1]
  def change
    create_table :enumerations do |t|
      t.string "name"
      t.string "enum_type"
      t.integer "ordinal"
      t.text "description"
      t.index ["enum_type"], name: "index_enumerations_on_enum_type"

      t.timestamps
    end
  end
end
