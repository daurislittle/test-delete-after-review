class ScopingDetailsChangeSkuIdToString < ActiveRecord::Migration[6.0]
  def change
    change_column :scoping_details, :sku_id, :string
  end
end
