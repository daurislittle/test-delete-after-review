class AddOrdinalToScopingDetails < ActiveRecord::Migration[6.0]
  def change
    add_column :scoping_details, :ordinal, :integer, default: 0
  end
end
