class SdtItemChangeSkuIdToString < ActiveRecord::Migration[6.0]
  def change
    change_column :sdt_items, :sku_id, :string
  end
end
