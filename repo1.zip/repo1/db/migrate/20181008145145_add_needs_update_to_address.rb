class AddNeedsUpdateToAddress < ActiveRecord::Migration[5.1]
  def change
    add_column :addresses, :needs_update, :boolean, default:false
  end
end
