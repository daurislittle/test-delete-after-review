class CreateSalesOperationSpecialists < ActiveRecord::Migration[5.1]
  def change
    create_table :sales_operation_specialists do |t|
      t.string :name
      t.string :region
    end
  end
end
