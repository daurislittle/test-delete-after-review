class CreateAddresses < ActiveRecord::Migration[5.1]
  def change
    create_table :addresses do |t|
      t.references :addressable, polymorphic: true, index:true
      t.string :kind, default:'other'
      t.string :address1, default:''
      t.string :address2, default:''
      t.string :city, default:''
      t.string :state, default:''
      t.string :postalcode, default:''
      t.string :country, default:''
    end
  end
end
