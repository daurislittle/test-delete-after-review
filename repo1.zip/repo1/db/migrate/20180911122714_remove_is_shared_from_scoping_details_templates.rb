class RemoveIsSharedFromScopingDetailsTemplates < ActiveRecord::Migration[5.1]
  def change
    remove_column :scoping_detail_templates, :is_shared, :boolean
  end
end
