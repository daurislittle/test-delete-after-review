class CreateSdtItems < ActiveRecord::Migration[5.1]
  def change
    create_table :sdt_items do |t|
      t.integer :sku_id
      t.string :item
      t.text :value
      t.belongs_to :scoping_detail_template, foreign_key: true

      t.timestamps
    end
  end
end
