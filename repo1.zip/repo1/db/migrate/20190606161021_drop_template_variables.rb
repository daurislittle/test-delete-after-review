class DropTemplateVariables < ActiveRecord::Migration[5.1]
  def change
    drop_table :template_variables, if_exists:true
  end
end
