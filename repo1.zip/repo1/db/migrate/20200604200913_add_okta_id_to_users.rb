class AddOktaIdToUsers < ActiveRecord::Migration[6.0]
  def change
    add_column :users, :okta_id, :string
  end
end
