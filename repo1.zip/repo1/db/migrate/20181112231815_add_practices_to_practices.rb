class AddPracticesToPractices < ActiveRecord::Migration[5.1]
  def change
    add_column :practices, :practices, :string, array:true, default:[]

    Practice.all.each do |practice|
      if !practice.practice.blank?
        practice.practices << practice.practice
      end

      practice.save
    end

    remove_column :practices, :practice, :string
  end
end
