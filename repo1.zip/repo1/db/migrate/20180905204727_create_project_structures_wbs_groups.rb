class CreateProjectStructuresWbsGroups < ActiveRecord::Migration[5.1]
  def change
    create_table :project_structures_wbs_groups, index:false do |t|
      t.belongs_to :project_structure, index: {name:'project_structure_wbs_group_index'}
      t.belongs_to :wbs_group, index: {name:'wbs_group_index'}
    end
  end
end
