class CreateWorkBreakdownStructures < ActiveRecord::Migration[5.1]
  def change
    create_table :work_breakdown_structures do |t|
      t.string :title
      t.string :sfdc_opportunity_id
      t.string :sfdc_quote_id
      t.string :contract_type
      t.string :project_structure
      t.string :billing_rule
      t.boolean :expenses_billable, default: true
      t.boolean :vendor_delivered_services, default: false
      t.text :engagement_notes
      t.integer :scoped_by_id
      t.boolean :is_deleted, default:false
      t.string :gps_primary_contact_id
      t.string :gps_secondary_contact_id
      t.string :acct_primary_contact_id
      t.string :acct_secondary_contact_id

      t.belongs_to :user, foreign_key:true
      t.timestamps
    end
  end
end
