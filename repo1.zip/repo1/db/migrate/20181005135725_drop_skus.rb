class DropSkus < ActiveRecord::Migration[5.1]
  def change
    drop_table :skus
  end
end
