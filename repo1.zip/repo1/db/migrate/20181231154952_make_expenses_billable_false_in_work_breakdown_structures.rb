class MakeExpensesBillableFalseInWorkBreakdownStructures < ActiveRecord::Migration[5.1]
  def change
    change_column :work_breakdown_structures, :expenses_billable, :boolean, :default => false
  end
end
