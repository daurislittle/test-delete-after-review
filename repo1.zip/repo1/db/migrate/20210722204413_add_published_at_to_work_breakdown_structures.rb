class AddPublishedAtToWorkBreakdownStructures < ActiveRecord::Migration[6.0]
  def change
    add_column :work_breakdown_structures, :published_at, :datetime
  end
end
