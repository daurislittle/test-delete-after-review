class AddPublishedByIdToWorkBreakdownStructures < ActiveRecord::Migration[6.0]
  def change
    add_column :work_breakdown_structures, :published_by_id, :integer
    add_foreign_key :work_breakdown_structures, :users, column: :published_by_id
  end
end
