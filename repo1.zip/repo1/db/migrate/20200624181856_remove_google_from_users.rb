class RemoveGoogleFromUsers < ActiveRecord::Migration[6.0]
  def change
    remove_column :users, :oauth_uid, :string
    remove_column :users, :oauth_access_token, :string
    remove_column :users, :oauth_refresh_token, :string
    remove_column :users, :oauth_expires, :string
    remove_column :users, :image, :string
  end
end
