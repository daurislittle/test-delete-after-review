class AddPhaseToWbsGroupLines < ActiveRecord::Migration[5.1]
  def change
    add_column :wbs_group_lines, :phase, :integer, default:1
  end
end
