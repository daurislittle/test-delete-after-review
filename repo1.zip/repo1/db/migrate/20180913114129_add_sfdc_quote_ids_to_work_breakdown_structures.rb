class AddSfdcQuoteIdsToWorkBreakdownStructures < ActiveRecord::Migration[5.1]
  def change
    add_column :work_breakdown_structures, :sfdc_quote_ids, :text

    WorkBreakdownStructure.all.each do |wbs|
      if !wbs.sfdc_quote_id.nil?
        wbs.sfdc_quote_ids << wbs.sfdc_quote_id
        wbs.save
      end
    end
  end
end
