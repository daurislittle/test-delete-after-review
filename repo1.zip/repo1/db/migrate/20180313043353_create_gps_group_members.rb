class CreateGpsGroupMembers < ActiveRecord::Migration[5.1]
  def change
    create_table :gps_group_members do |t|
      t.belongs_to :gps_group
      t.belongs_to :corporate

      t.timestamps
    end
  end
end
