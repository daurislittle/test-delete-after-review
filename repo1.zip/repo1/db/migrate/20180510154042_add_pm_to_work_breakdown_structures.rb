class AddPmToWorkBreakdownStructures < ActiveRecord::Migration[5.1]
  def change
    add_column :work_breakdown_structures, :project_manager_id, :integer, index: true
  end
end
