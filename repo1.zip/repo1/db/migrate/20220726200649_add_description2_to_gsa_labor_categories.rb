class AddDescription2ToGsaLaborCategories < ActiveRecord::Migration[6.0]
  def change
    add_column :gsa_labor_categories, :description2, :string
  end
end
