class RenameProjectStructuresWorkBreakdownStructures < ActiveRecord::Migration[5.1]
  def change
    rename_table :project_structures_work_breakdown_structures, :practices_work_breakdown_structures
  end
end
