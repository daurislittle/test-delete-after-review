class CreateSkus < ActiveRecord::Migration[5.1]
  def change
    create_table :skus do |t|
      t.string "sku"
      t.string "practice"
      t.string "description"
      t.boolean "is_legacy", default: false
    end
  end
end
