class RenameProjectStructuresWbsGroups < ActiveRecord::Migration[5.1]
  def change
    rename_table :project_structures_wbs_groups, :practices_wbs_groups
  end
end
