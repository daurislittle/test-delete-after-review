class AddContractVehicleToWbsEntries < ActiveRecord::Migration[6.0]
  def change
    add_column :wbs_entries, :contract_vehicle, :string
  end
end
