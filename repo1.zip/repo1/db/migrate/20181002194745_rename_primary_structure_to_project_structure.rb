class RenamePrimaryStructureToProjectStructure < ActiveRecord::Migration[5.1]
  def change
    rename_column :work_breakdown_structures, :primary_structure, :project_structure
  end
end
