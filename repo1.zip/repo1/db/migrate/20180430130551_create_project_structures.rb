class CreateProjectStructures < ActiveRecord::Migration[5.1]
  def change
    create_table :project_structures do |t|
      t.string :name
      t.string :practice
      t.integer :leadership_team_id, index:true
      t.integer :scoping_team_id, index:true
      t.string :leadership_slack
      t.string :scoping_slack
      t.string :sku_prefixes, array:true, default:[]

      t.timestamps
    end
  end
end
