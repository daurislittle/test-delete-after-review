class CreateCorporates < ActiveRecord::Migration[5.1]
  def change
    create_table :corporates do |t|
      t.string "firstname"
      t.string "lastname"
      t.string "title"
      t.string "region"
      t.string "location"
      t.integer "grasshopper"
      t.string "mobile"
      t.string "email"
      t.string "status"
      t.string "flags"
      t.string "manager"
      t.boolean "is_legacy"

      t.timestamps
    end
  end
end
