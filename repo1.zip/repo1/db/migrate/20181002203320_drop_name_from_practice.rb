class DropNameFromPractice < ActiveRecord::Migration[5.1]
  def change
    remove_column :practices, :name
  end
end
