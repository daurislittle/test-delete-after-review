class DropSectionTemplates < ActiveRecord::Migration[5.1]
  def change
    drop_table :section_templates, if_exists:true
  end
end
