class RemoveOrdinalFromGsaLaborCategory < ActiveRecord::Migration[6.0]
  def change
    remove_column :gsa_labor_categories, :ordinal, :integer
  end
end
