class AddContractTermToWorkBreakdownStructures < ActiveRecord::Migration[5.1]
  def change
    add_column :work_breakdown_structures, :contract_term, :integer, default:0
  end
end
