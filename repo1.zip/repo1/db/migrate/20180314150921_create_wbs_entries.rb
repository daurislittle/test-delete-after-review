class CreateWbsEntries < ActiveRecord::Migration[5.1]
  def change
    create_table :wbs_entries do |t|
      t.belongs_to :work_breakdown_structure, index: true, foreign_key: true
      t.string :sku
      t.string :notes, default: ""
      t.string :task, default: ""
      t.belongs_to :gsa_labor_category, index: true, foreign_key: true
      t.float :billable_rate, default: 0.0
      t.integer :total_hours, default: 0
      t.float :internal_hourly_rate, default: 0.0
      t.date :start_date
      t.date :end_date
      t.integer :link_type, default: 0
      t.string :link_task
      t.float :link_percent, default: 0.25
      t.integer :ordinal, default: 0
      t.string :sfdc_lineitem_id

      t.timestamps
    end
  end
end
