class AddUpdatedByIdToWorkBreakdownStructures < ActiveRecord::Migration[6.0]
  def change
    add_column :work_breakdown_structures, :updated_by_id, :integer
    add_foreign_key :work_breakdown_structures, :users, column: :updated_by_id
  end
end
