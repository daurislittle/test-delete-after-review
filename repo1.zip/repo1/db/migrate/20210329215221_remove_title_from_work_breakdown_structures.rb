class RemoveTitleFromWorkBreakdownStructures < ActiveRecord::Migration[6.0]
  def change
    remove_column :work_breakdown_structures, :title
  end
end
