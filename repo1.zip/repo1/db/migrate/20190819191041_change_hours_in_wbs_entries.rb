class ChangeHoursInWbsEntries < ActiveRecord::Migration[5.2]
  def up
    change_column :wbs_entries, :total_hours, :float
  end

  def down
    change_column :wbs_entries, :total_hours, :integer
  end
end
