class RemoveSfdcQuoteIdsFromWorkBreakdownStructures < ActiveRecord::Migration[6.0]
  def change
    remove_column :work_breakdown_structures, :sfdc_quote_ids, :text
  end
end
