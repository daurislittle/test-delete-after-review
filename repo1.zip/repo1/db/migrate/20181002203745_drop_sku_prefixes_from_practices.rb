class DropSkuPrefixesFromPractices < ActiveRecord::Migration[5.1]
  def change
    remove_column :practices, :sku_prefixes
  end
end
