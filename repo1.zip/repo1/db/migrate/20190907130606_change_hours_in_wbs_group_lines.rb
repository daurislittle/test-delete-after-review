class ChangeHoursInWbsGroupLines < ActiveRecord::Migration[5.2]
  def up
    change_column :wbs_group_lines, :total_hours, :float
  end

  def down
    change_column :wbs_group_lines, :total_hours, :integer
  end
end
