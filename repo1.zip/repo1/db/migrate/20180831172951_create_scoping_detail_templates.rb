class CreateScopingDetailTemplates < ActiveRecord::Migration[5.1]
  def change
    create_table :scoping_detail_templates do |t|
      t.string :name
      t.text :description
      t.boolean :is_shared, default: true
      t.belongs_to :user, foreign_key: true

      t.timestamps
    end
  end
end
