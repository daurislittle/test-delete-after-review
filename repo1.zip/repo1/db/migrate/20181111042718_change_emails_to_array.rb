class ChangeEmailsToArray < ActiveRecord::Migration[5.1]
  def change
    add_column :practices, :scoping_team, :string, array:true, default:[]
    add_column :practices, :leadership_team, :string, array:true, default: []
    remove_column :practices, :scoping_team_id, :integer
    remove_column :practices, :leadership_team_id, :integer
  end
end
