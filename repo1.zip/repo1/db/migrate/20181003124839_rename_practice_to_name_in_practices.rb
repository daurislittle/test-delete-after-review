class RenamePracticeToNameInPractices < ActiveRecord::Migration[5.1]
  def change
    rename_column :practices, :practice, :name
  end
end
