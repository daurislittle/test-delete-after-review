class AddPracticeToPractices < ActiveRecord::Migration[5.1]
  def change
    rename_column :practices, :name, :project_structure
    add_column :practices, :practice, :string

    # Copy existing practice name to practice field, name will be used to
    # store the project structure name from the opportunity picklist
    Practice.all.each do |practice|
      practice.practice = practice.project_structure
      practice.save
    end
  end
end
