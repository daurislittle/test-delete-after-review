class AddTitleToRecentlyViewed < ActiveRecord::Migration[5.2]
  def change
    add_column :recently_vieweds, :title, :string
  end
end
