class CreateWbsGroupLines < ActiveRecord::Migration[5.1]
  def change
    create_table :wbs_group_lines do |t|
      t.belongs_to :wbs_group, index: true, foreign_key: true
      t.string :notes
      t.string :task
      t.belongs_to :gsa_labor_category, index: true, foreign_key: true
      t.float :billable_rate, default: 0.0
      t.integer :total_hours, default:0
      t.float :internal_hourly_rate, default: 0.0
      t.integer :link_type, default: 0
      t.string :link_task
      t.float :link_percent

      t.timestamps
    end
  end
end
