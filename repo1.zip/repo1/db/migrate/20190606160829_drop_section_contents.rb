class DropSectionContents < ActiveRecord::Migration[5.1]
  def change
    drop_table :section_contents, if_exists:true
  end
end
