class AddSkuToWbsGroupLine < ActiveRecord::Migration[5.1]
  def change
    add_column :wbs_group_lines, :sku, :string
  end
end
