class DropSalesOperationSpecialists < ActiveRecord::Migration[6.0]
  def change
    drop_table :sales_operation_specialists
  end
end
