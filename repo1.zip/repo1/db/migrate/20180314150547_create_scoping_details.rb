class CreateScopingDetails < ActiveRecord::Migration[5.1]
  def change
    create_table :scoping_details do |t|
      t.belongs_to :work_breakdown_structure, foreign_key: true
      t.integer :sku_id
      t.string :item
      t.text :value

      t.timestamps
    end
  end
end
