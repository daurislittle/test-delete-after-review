class CreateGsaLaborCategories < ActiveRecord::Migration[5.1]
  def change
    create_table :gsa_labor_categories do |t|
      t.string "name"
      t.integer "ordinal"
      t.text "description"
      t.float "gsa_floor_price"
      t.float "federal_max_price"
      t.float "default_price", default: 210.0
      t.float "default_internal", default: 135.0
    end
  end
end
