class DropContentVariable < ActiveRecord::Migration[5.1]
  def change
    drop_table :content_variables, if_exists:true
  end
end
