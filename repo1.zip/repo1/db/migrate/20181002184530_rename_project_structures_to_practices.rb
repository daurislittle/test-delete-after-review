class RenameProjectStructuresToPractices < ActiveRecord::Migration[5.1]
  def change
    rename_table :project_structures, :practices
  end
end
