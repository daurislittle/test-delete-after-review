class AddIsDeletedToWbsGroups < ActiveRecord::Migration[5.1]
  def change
    add_column :wbs_groups, :is_deleted, :boolean, default:false
  end
end
