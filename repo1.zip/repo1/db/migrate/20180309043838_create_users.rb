class CreateUsers < ActiveRecord::Migration[5.1]
  def change
    create_table :users do |t|
      t.text :oauth_uid
      t.text :oauth_refresh_token
      t.text :oauth_access_token
      t.text :oauth_expires
      t.text :first_name
      t.text :last_name
      t.text :email
      t.text :image

      t.timestamps
    end
  end
end
