class CreateGpsGroups < ActiveRecord::Migration[5.1]
  def change
    create_table :gps_groups do |t|
      t.string :name
      t.string :email

      t.timestamps
    end
  end
end
