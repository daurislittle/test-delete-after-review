class CreateAccountExecutives < ActiveRecord::Migration[5.1]
  def change
    create_table :account_executives do |t|
      t.string :name
      t.string :region
      t.belongs_to :sales_operation_specialist, foreign_key: true
    end
  end
end
