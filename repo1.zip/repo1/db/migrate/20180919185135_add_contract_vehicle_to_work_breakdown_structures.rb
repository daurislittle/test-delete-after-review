class AddContractVehicleToWorkBreakdownStructures < ActiveRecord::Migration[5.1]
  def change
    add_column :work_breakdown_structures, :contract_vehicle, :string
  end
end
