class CreateProjectStructuresWorkBreakdownStructures < ActiveRecord::Migration[5.1]
  def change
    create_table :project_structures_work_breakdown_structures, id:false do |t|
      t.belongs_to :project_structure, index: {name:'project_structure_index'}
      t.belongs_to :work_breakdown_structure, index: { name: 'wbs_index'}
    end
  end
end
