class CreateRecentlyVieweds < ActiveRecord::Migration[5.1]
  def change
    create_table :recently_vieweds do |t|
      t.string :viewed_type
      t.string :viewed_id
      t.string :viewed_url
      t.belongs_to :user, foreign_key: true

      t.timestamps
    end
  end
end
