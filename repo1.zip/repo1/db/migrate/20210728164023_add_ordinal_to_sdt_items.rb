class AddOrdinalToSdtItems < ActiveRecord::Migration[6.0]
  def change
    add_column :sdt_items, :ordinal, :integer, default: 0
  end
end
