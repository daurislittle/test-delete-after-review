class DropDocumentTemplates < ActiveRecord::Migration[5.1]
  def change
    drop_table :document_templates, if_exists:true
  end
end
