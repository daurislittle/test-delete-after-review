class DropContentTemplates < ActiveRecord::Migration[5.1]
  def change
    drop_table :content_templates, if_exists:true
  end
end
