# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `rails
# db:schema:load`. When creating a new database, `rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2022_07_26_200649) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "addresses", force: :cascade do |t|
    t.string "addressable_type"
    t.bigint "addressable_id"
    t.string "kind", default: "other"
    t.string "address1", default: ""
    t.string "address2", default: ""
    t.string "city", default: ""
    t.string "state", default: ""
    t.string "postalcode", default: ""
    t.string "country", default: ""
    t.boolean "needs_update", default: false
    t.index ["addressable_type", "addressable_id"], name: "index_addresses_on_addressable_type_and_addressable_id"
  end

  create_table "corporates", force: :cascade do |t|
    t.string "firstname"
    t.string "lastname"
    t.string "title"
    t.string "region"
    t.string "location"
    t.integer "grasshopper"
    t.string "mobile"
    t.string "email"
    t.string "status"
    t.string "flags"
    t.string "manager"
    t.boolean "is_legacy"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "okta_id"
  end

  create_table "enumerations", force: :cascade do |t|
    t.string "name"
    t.string "enum_type"
    t.integer "ordinal"
    t.text "description"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["enum_type"], name: "index_enumerations_on_enum_type"
  end

  create_table "gps_group_members", force: :cascade do |t|
    t.bigint "gps_group_id"
    t.bigint "corporate_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["corporate_id"], name: "index_gps_group_members_on_corporate_id"
    t.index ["gps_group_id"], name: "index_gps_group_members_on_gps_group_id"
  end

  create_table "gps_groups", force: :cascade do |t|
    t.string "name"
    t.string "email"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "gsa_labor_categories", force: :cascade do |t|
    t.string "name"
    t.text "description"
    t.float "gsa_floor_price"
    t.float "federal_max_price"
    t.float "default_price", default: 210.0
    t.float "default_internal", default: 135.0
    t.string "description2"
  end

  create_table "permissions", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "permissions_roles", id: false, force: :cascade do |t|
    t.bigint "permission_id"
    t.bigint "role_id"
    t.index ["permission_id"], name: "index_permissions_roles_on_permission_id"
    t.index ["role_id"], name: "index_permissions_roles_on_role_id"
  end

  create_table "practices", force: :cascade do |t|
    t.string "project_structure"
    t.string "leadership_slack"
    t.string "scoping_slack"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "scoping_team", default: [], array: true
    t.string "leadership_team", default: [], array: true
    t.string "practices", default: [], array: true
    t.boolean "in_active", default: true
  end

  create_table "practices_scoping_detail_templates", id: false, force: :cascade do |t|
    t.bigint "practice_id", null: false
    t.bigint "scoping_detail_template_id", null: false
    t.index ["practice_id"], name: "practices_sdts_on_practice_index"
    t.index ["scoping_detail_template_id"], name: "practices_sdts_on_sdt_index"
  end

  create_table "practices_wbs_groups", force: :cascade do |t|
    t.bigint "practice_id"
    t.bigint "wbs_group_id"
    t.index ["practice_id"], name: "practice_wbs_group_index"
    t.index ["wbs_group_id"], name: "wbs_group_index"
  end

  create_table "practices_work_breakdown_structures", id: false, force: :cascade do |t|
    t.bigint "practice_id"
    t.bigint "work_breakdown_structure_id"
    t.index ["practice_id"], name: "practice_index"
    t.index ["work_breakdown_structure_id"], name: "wbs_index"
  end

  create_table "recently_vieweds", force: :cascade do |t|
    t.string "viewed_type"
    t.string "viewed_id"
    t.string "viewed_url"
    t.bigint "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "title"
    t.index ["user_id"], name: "index_recently_vieweds_on_user_id"
  end

  create_table "roles", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "roles_users", id: false, force: :cascade do |t|
    t.bigint "role_id"
    t.bigint "user_id"
    t.index ["role_id"], name: "index_roles_users_on_role_id"
    t.index ["user_id"], name: "index_roles_users_on_user_id"
  end

  create_table "scoping_detail_templates", force: :cascade do |t|
    t.string "name"
    t.text "description"
    t.bigint "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_deleted", default: false
    t.index ["user_id"], name: "index_scoping_detail_templates_on_user_id"
  end

  create_table "scoping_details", force: :cascade do |t|
    t.bigint "work_breakdown_structure_id"
    t.string "sku_id"
    t.string "item"
    t.text "value"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "ordinal", default: 0
    t.index ["work_breakdown_structure_id"], name: "index_scoping_details_on_work_breakdown_structure_id"
  end

  create_table "sdt_items", force: :cascade do |t|
    t.string "sku_id"
    t.string "item"
    t.text "value"
    t.bigint "scoping_detail_template_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "ordinal", default: 0
    t.index ["scoping_detail_template_id"], name: "index_sdt_items_on_scoping_detail_template_id"
  end

  create_table "sessions", force: :cascade do |t|
    t.string "session_id", null: false
    t.text "data"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["session_id"], name: "index_sessions_on_session_id", unique: true
    t.index ["updated_at"], name: "index_sessions_on_updated_at"
  end

  create_table "users", force: :cascade do |t|
    t.text "first_name"
    t.text "last_name"
    t.text "email"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_disabled", default: false
    t.string "okta_id"
    t.datetime "last_login"
  end

  create_table "variables", force: :cascade do |t|
    t.string "name"
    t.string "label"
    t.jsonb "value", default: {}, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "kind", default: "string"
  end

  create_table "versions", force: :cascade do |t|
    t.string "item_type", null: false
    t.integer "item_id", null: false
    t.string "event", null: false
    t.string "whodunnit"
    t.text "object"
    t.datetime "created_at"
    t.text "object_changes"
    t.index ["item_type", "item_id"], name: "index_versions_on_item_type_and_item_id"
  end

  create_table "wbs_entries", force: :cascade do |t|
    t.bigint "work_breakdown_structure_id"
    t.string "sku"
    t.string "notes", default: ""
    t.string "task", default: ""
    t.bigint "gsa_labor_category_id"
    t.float "billable_rate", default: 0.0
    t.float "total_hours", default: 0.0
    t.float "internal_hourly_rate", default: 0.0
    t.date "start_date"
    t.date "end_date"
    t.integer "link_type", default: 0
    t.string "link_task"
    t.float "link_percent", default: 0.25
    t.integer "ordinal", default: 0
    t.string "sfdc_lineitem_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "phase", default: 1
    t.string "resource"
    t.string "contract_vehicle"
    t.index ["gsa_labor_category_id"], name: "index_wbs_entries_on_gsa_labor_category_id"
    t.index ["work_breakdown_structure_id"], name: "index_wbs_entries_on_work_breakdown_structure_id"
  end

  create_table "wbs_group_lines", force: :cascade do |t|
    t.bigint "wbs_group_id"
    t.string "notes"
    t.string "task"
    t.bigint "gsa_labor_category_id"
    t.float "billable_rate", default: 0.0
    t.float "total_hours", default: 0.0
    t.float "internal_hourly_rate", default: 0.0
    t.integer "link_type", default: 0
    t.string "link_task"
    t.float "link_percent"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "ordinal", default: 0
    t.string "sku"
    t.integer "phase", default: 1
    t.string "contract_vehicle"
    t.index ["gsa_labor_category_id"], name: "index_wbs_group_lines_on_gsa_labor_category_id"
    t.index ["wbs_group_id"], name: "index_wbs_group_lines_on_wbs_group_id"
  end

  create_table "wbs_groups", force: :cascade do |t|
    t.string "name"
    t.bigint "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "is_deleted", default: false
    t.index ["user_id"], name: "index_wbs_groups_on_user_id"
  end

  create_table "work_breakdown_structures", force: :cascade do |t|
    t.string "sfdc_opportunity_id"
    t.string "sfdc_quote_id"
    t.string "contract_type"
    t.string "project_structure"
    t.string "billing_rule"
    t.boolean "expenses_billable", default: false
    t.boolean "vendor_delivered_services", default: false
    t.text "engagement_notes"
    t.integer "scoped_by_id"
    t.boolean "is_deleted", default: false
    t.string "gps_primary_contact_id"
    t.string "gps_secondary_contact_id"
    t.string "acct_primary_contact_id"
    t.string "acct_secondary_contact_id"
    t.bigint "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "project_manager_id"
    t.string "contract_vehicle"
    t.integer "contract_term", default: 0
    t.jsonb "extra", default: {}, null: false
    t.integer "published_by_id"
    t.integer "updated_by_id"
    t.datetime "published_at"
    t.index ["user_id"], name: "index_work_breakdown_structures_on_user_id"
  end

  add_foreign_key "permissions_roles", "permissions"
  add_foreign_key "permissions_roles", "roles"
  add_foreign_key "recently_vieweds", "users"
  add_foreign_key "roles_users", "roles"
  add_foreign_key "roles_users", "users"
  add_foreign_key "scoping_detail_templates", "users"
  add_foreign_key "scoping_details", "work_breakdown_structures"
  add_foreign_key "sdt_items", "scoping_detail_templates"
  add_foreign_key "wbs_entries", "gsa_labor_categories"
  add_foreign_key "wbs_entries", "work_breakdown_structures"
  add_foreign_key "wbs_group_lines", "gsa_labor_categories"
  add_foreign_key "wbs_group_lines", "wbs_groups"
  add_foreign_key "wbs_groups", "users"
  add_foreign_key "work_breakdown_structures", "users"
  add_foreign_key "work_breakdown_structures", "users", column: "published_by_id"
  add_foreign_key "work_breakdown_structures", "users", column: "updated_by_id"
end
