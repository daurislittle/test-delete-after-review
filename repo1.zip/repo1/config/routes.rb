Rails.application.routes.draw do
  #namespace :administration do
  #  get 'logging/index'
  #end
  match "/401", :to => "errors#unauthorized", :via => :all
  match "/403", :to => "errors#forbidden", :via => :all
  #match "/404", :to => "errors#not_found", :via => :all
  match "/500", :to => "errors#internal_server_error", :via => :all

  mount ActionCable.server => '/cable'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  #
  get 'index' => 'application/index'
  get 'recently_viewed' => 'application#recently_viewed', as: :recently_viewed
  get 'wbs_status' => 'application#wbs_status', as: :wbs_status

  root 'application#index'
  get 'search' => 'application#search'
  get 'welcome' => 'application#welcome'

  get 'saml/login'
  post 'saml/consume'

  get 'trashcan/index', as: :trashcan
  post 'trashcan/empty' => 'trashcan#remove_all'

  resources :accounts, only:[:index, :show] do
    member do
      get 'address' => 'accounts#address'
    end
  end
  resources :opportunities, only:[:index, :show]
  resources :contacts, only:[:index, :show]
  resources :sales_force_users, only:[:index, :show]
  resources :gsa_labor_categories, only:[:show]

  get '/quotes/:quote_id' => 'work_breakdown_structures#for_quote'

  resources :work_breakdown_structures, :path => "wbs" do
    member do
      get 'print' => 'work_breakdown_structures#print'
      get 'refresh' => 'work_breakdown_structures#refresh'
      get 'valid_skus' => 'work_breakdown_structures#valid_skus'
      post 'calculate' => 'work_breakdown_structures#calculate'
      get 'quote' => 'work_breakdown_structures#quote'
      post 'copy' => 'work_breakdown_structures#copy'
      post 'submit' => 'work_breakdown_structures#submit'
      post 'received' => 'work_breakdown_structures#receive'
      post 'assigned' => 'work_breakdown_structures#assign'
      post 'in_progress' => 'work_breakdown_structures#in_progress'
      post 'completed' => 'work_breakdown_structures#complete'
      post 'block' => 'work_breakdown_structures#block'
      post 'restore' => 'work_breakdown_structures#restore'
      post 'publish' => 'work_breakdown_structures#publish'
      put 'line_item/:line_item_id/sku/:gsa_labor_category_id' => 'work_breakdown_structures#change_sku', format:'js'
      get 'validate' => 'work_breakdown_structures#validate', format: 'js'
      get 'mark_all' => 'work_breakdown_structures#mark_all', format: 'js'
    end

    collection do
      get 'add_line' => 'work_breakdown_structures#add_line'
      get 'add_group' => 'work_breakdown_structures#add_group'
      get 'add_detail' => 'work_breakdown_structures#add_detail'
      get 'add_scoping_details' => 'work_breakdown_structures#add_scoping_details'
      get 'gsa_compliance' => 'work_breakdown_structures#check_gsa_compliance'
      get 'opportunity' => 'work_breakdown_structures#select_opportunity', format: 'js'
      get 'practices' => 'work_breakdown_structures#practices_selected', format: 'js'
      get 'contract_type' => 'work_breakdown_structures#on_contract_type'
    end
  end

  resources :quotes, only:[:show]

  resources :wbs_groups do
    member do
      post 'restore' => 'wbs_groups#restore'
      post 'copy' => 'wbs_groups#copy'
      get 'mark_all' => 'wbs_groups#mark_all', format: 'js'
      get 'line_item/:line_item_id/sku/:gsa_labor_category_id' => 'wbs_groups#change_sku', format:'js'
    end

    collection do
      get 'add_line' => 'wbs_groups#manage_add_line', as: :add_line
      get 'practices' => 'wbs_groups#practices_selected'
      get 'line_item/:line_item_id/sku/:gsa_labor_category_id' => 'wbs_groups#change_sku', format:'js'
    end
  end

  resources :scoping_detail_templates do
    member do
      post 'restore' => 'scoping_detail_templates#restore'
      post 'copy' => 'scoping_detail_templates#copy'
      get 'mark_all' => 'scoping_detail_templates#mark_all', format: 'js'
    end

    collection do
      get 'add_detail' => 'scoping_detail_templates#add_detail', as: :add_detail
      get 'practices' => 'scoping_detail_templates#practices_selected', format: 'js'
    end
  end

  resources :practices, only:[:index, :show] do
    collection do
      get 'skus' => 'practices#skus', format: 'json'
    end

    member do
      get 'skus' => 'practices#skus', format:'json'
    end
  end

  resources :templates, only:[:index]

  get 'administration' => 'administration#index', as: :administration
  namespace :administration do
    resources :enumerations, only:[:index, :new, :create]
    resources :variables, only:[:index, :update]

    resources :users, only:[:index, :show, :update] do
      member do
        post 'disable' => 'users#disable_account'
        post 'enable' => 'users#enable_account'
      end
    end

    resources :roles do
      collection do
        post 'update_roles' => 'roles#update_roles'
      end
    end
    resources :permissions, only:[:index, :create, :destroy]

    get '/corporate_dbs' => 'corporate_databases#index'

    resources :corporates, only:[:index] do
      collection do
        post 'import' => 'corporates#import'
        post 'sync' => 'corporates#sync'
      end
    end

    resources :gps_groups, only:[:index] do
      collection do
        post 'import' => 'gps_groups#import'
        post 'purge' => 'gps_groups#purge'
      end
    end

    resources :gsa_labor_categories

    #get '/sos_ae' => 'sos_ae#index', as: :sos_ae
    #post '/sos_ae/import' => 'sos_ae#import', as: :sos_ae_import

    resources :practices, only:[:index, :edit, :update, :destroy] do
      member do
        get 'skus' => 'practices#skus'
      end

      collection do
        get 'emails' => 'practices#emails'
      end
    end

    get '/salesforce/admin'            => 'salesforce#admin', as: :salesforce_admin
    get '/salesforce/admin/parameters' => 'salesforce#parameters', as: :salesforce_admin_parameters
    get '/salesforce/admin/query'      => 'salesforce#query', as: :salesforce_admin_query
    get '/salesforce/query'            => 'salesforce#ajax_query'
    get '/salesforce/describe'         => 'salesforce#ajax_describe'
    get '/salesforce/picklist'         => 'salesforce#ajax_picklist'
    get '/salesforce/find'             => 'salesforce#ajax_find'
    get '/salesforce/connect'          => 'salesforce#ajax_connect'

    #get '/logging'                     => 'logging#index'
  end
end
