module COGS
  class Application < Rails::Application
    config.session_store :active_record_store, :key => '_Application_session'
  end
end
