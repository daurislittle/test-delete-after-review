# config/initializers/salesforce.rb
#
salesforce_config = Rails.application.config_for :salesforce

Rails.application.configure do
  config.salesforce = ActiveSupport::OrderedOptions.new

  config.salesforce.host           = Rails.application.credentials.salesforce[Rails.env.to_sym][:host]
  config.salesforce.username       = Rails.application.credentials.salesforce[Rails.env.to_sym][:username]
  config.salesforce.password       = Rails.application.credentials.salesforce[Rails.env.to_sym][:password]
  config.salesforce.security_token = Rails.application.credentials.salesforce[Rails.env.to_sym][:security_token]
  config.salesforce.client_id      = Rails.application.credentials.salesforce[Rails.env.to_sym][:client_id]
  config.salesforce.client_secret  = Rails.application.credentials.salesforce[Rails.env.to_sym][:client_secret]
  config.salesforce.api_version    = "49.0"

  config.salesforce.redis_host     = 'localhost'
  config.salesforce.redis_port     = 6379
  config.salesforce.redis_timeout  = 1000

  config.salesforce.log_file       = 'log/salesforce.log'
  config.salesforce.log_level      = SalesForce::Logger::DEBUG
end

topics = SalesForce::PushTopic.all.map { |t| t.channel }
topics = ["/topic/AllContacts", "/topic/AllAccounts", "/topic/AllOpportunities"]
Rails.logger.debug("Subscribing to #{topics}")

Thread.new {
  begin
    EM.run do
      SalesForce.client.restforce.subscription topics, replay:-1 do |message|
        Rails.logger.debug message.inspect

        case message['event']['type']
        when 'created'
          Rails.logger.debug("Salesforce Notification: Created #{message['sobject']['Id']}")
          SalesForce.load(message['sobject']['Id'], refresh:true)
        when 'updated'
          Rails.logger.debug("Salesforce Notification: Updated #{message['sobject']['Id']}")
          SalesForce.load(message['sobject']['Id'], refresh:true)
        when 'deleted'
          Rails.logger.debug("Salesforce Notification: Deleted #{message['sobject']['Id']}")
          object = SalesForce.load(message['sobject']['Id'])
          object.update(IsDeleted:true)
          object.cache
        when 'undeleted'
          Rails.logger.debug("Salesforce Notification: Restored #{message['sobject']['Id']}")
          object = SalesForce.load(message['sobject']['Id'])
          object.update(IsDeleted:false)
          object.cache
        end
      end
    end
  rescue StandardError => e
    Rails.logger.error("Failed to successfully subscribe to push topics: #{e.message}")
  end
}
