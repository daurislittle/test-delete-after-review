Rails.application.config.action_mailer.delivery_method = :smtp
Rails.application.config.action_mailer.raise_delivery_errors = true
Rails.application.config.action_mailer.perform_deliveries = true

Rails.application.config.action_mailer.default_url_options = {
    host: 'localhost'
}

Rails.application.config.action_mailer.smtp_settings = {
    #address: 'smtp.gmail.com',
    port: 587,
    address: 'smtp-relay.gmail.com',
    #port:25,
    #port: 465,
    domain: 'guidepointsecurity.com'
    #user_name: 'cogs@guidepointsecurity.com',
    #password:'PQU$msDBw7t6t@FJ',
    #authentication: 'plain',
    #enable_starttls_auto: true
}

Rails.application.config.action_mailer.raise_delivery_errors = true