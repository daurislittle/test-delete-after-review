SecureHeaders::Configuration.default do |config|
  config.cookies = {
    secure: true, # mark all cookies as "Secure"
    httponly: true # mark all cookies as "HttpOnly"

    #samesite: {
    #  strict: true # mark all cookies as SameSite=Strict
    #}
  }

  config.csp = SecureHeaders::OPT_OUT

  # TODO: Figure out other headers later
  #config.csp = {
  #  # directive values: these values will directly translate into source directives
  #  default_src: %w('self'),
  #  font_src: %w('self' data:),
  #  img_src: %w(mycdn.com data:),
  #  script_src: %w('self'),
  #  style_src: %w('unsafe-inline')
  #}
end
