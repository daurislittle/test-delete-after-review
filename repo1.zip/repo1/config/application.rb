require_relative 'boot'

require 'rails/all'

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module COGS
  class Application < Rails::Application

    # Initialize configuration defaults for originally generated Rails version.
    config.load_defaults 6.0

    # Settings in config/environments/* take precedence over those specified here.
    # Application configuration should go into files in config/initializers
    # -- all .rb files in that directory are automatically loaded.
    config.autoload_paths << Rails.root.join('lib', 'classes')
    config.autoload_paths << Rails.root.join('mixins')
    config.eager_load_paths << Rails.root.join('lib', 'classes')

    config.action_controller.include_all_helpers = false

    config.time_zone = 'Eastern Time (US & Canada)'
    config.exceptions_app = self.routes

    config.title = 'COGS'
    config.logo_file = 'logo.png'
  end
end
