require 'enumeration'

class String
  def == (object)
    if object.is_a?(Enumeration)
      object == self
    else
      super(object)
    end
  end
end