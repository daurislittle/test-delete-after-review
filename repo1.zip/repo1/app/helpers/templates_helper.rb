module TemplatesHelper
  def templates
    [
        {
            name: 'WBS',
            template: 'wbs',
            create_url: new_wbs_group_path,
            active: true
        },
        {
            name: 'Scoping Details',
            template: 'scoping_detail',
            create_url: new_scoping_detail_template_path,
        }
    ]
  end
end
