module OpportunitiesHelper
  def pager_path (page:1, per_page:15, view:'icon', search_for:'')
    opportunities_path(page: page, per_page: per_page, view: view, search_for: search_for)
  end
end
