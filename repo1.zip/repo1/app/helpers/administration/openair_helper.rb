module Administration::OpenairHelper
end
