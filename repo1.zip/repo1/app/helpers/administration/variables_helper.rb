module Administration::VariablesHelper
  def display_for variable
    if variable.kind == 'currency'
      number_to_currency(variable.value)
    else
      variable.value
    end
  end

  def error_message_for variable
    if variable.kind == 'integer'
      '(+/-)[0..9]+'
    elsif variable.kind == 'float'
      '(+/-)[0..9]+(.[0..9]+)'
    elsif variable.kind == 'currency'
      '[0..9]+.[0..9]{2}'
    end
  end

  def form_field_for form, variable
    if variable.kind == 'string' || variable.kind == 'float'
      form.text_field :value, class:'form-control form-control-sm'
    elsif variable.kind == 'integer'
      form.number_field :value, class:'form-control form-control-sm'
    elsif variable.kind == 'currency'
      '<div class="input-group">'\
      '<div class="input-group-prepend">'\
      '<span class="input-group-text" style="padding-top:0;padding-bottom:2px;padding-right:6px;padding-left:6px;">$</span>'\
      '</div>'\
      "#{form.text_field :value, value:'%.2f' % variable.value, class:'form-control form-control-sm'}"\
      '</div>'.html_safe
    elsif variable.kind == 'text'
      form.text_area :value, class:'form-control form-control-sm', rows:4
    end
  end
end
