module Administration::PracticesHelper
end
