module Administration::CorporatesHelper
end
