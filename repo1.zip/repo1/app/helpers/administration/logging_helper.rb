module Administration::LoggingHelper
  LOG_LINE_REGEX = /^(?<marker>[EWID]),\s+\[(?<date>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{6})\s+#(?<pid>\d+)\]\s+(?<type>\w+)\s+--\s+(?<message>.*)$/

  def log_match (line)
    begin
      LOG_LINE_REGEX.match(line)
    rescue StandardException => e
      Rails.logger.debug("log_match: #{e.message} for #{line.inspect}")
    end
  end

  def row_class (type)
    case type
    when 'ERROR'
      'table-danger'

    when 'WARN'
      'table-warning'

    when 'INFO'
      'table-info'
    end
  end
end
