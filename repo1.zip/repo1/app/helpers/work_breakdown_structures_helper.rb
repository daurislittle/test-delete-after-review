module WorkBreakdownStructuresHelper
  def user_can_edit? wbs
    has_permission('is_admin', halt:false) ||
    has_permission('wbs_edit', halt:false) ||
    has_permission('wbs_edit_own', halt:false, condition:current_user == wbs.user) ||
    wbs.can_edit?(current_user)
  end

  def pager_path (page:1, per_page:15, view:'icon', search_for:'')
    work_breakdown_structures_path(page: page, per_page: per_page, view: view, search_for: search_for)
  end

  def task_highlight_class(line)
    if line.task.downcase.gsub(/[[:space:]]/, '') == 'afterhours'.downcase
      'after-hours'
    elsif (!line.sku.nil? && line.sku.downcase.end_with?('tools')) || (!line.task.nil? && line.task.downcase == 'tools')
      'tools'
    end
  end

  def available_addresses account
    addresses = []

    if !account.nil?
      if account.billing_address?
        addresses << "Billing"
      end

      if account.headquarters_address?
        addresses << "Headquarters"
      end

      addresses << "Other"

      if account.shipping_address?
        addresses << "Shipping"
      end
    else
      addresses << "Other"
    end

    addresses
  end
end
