module QuotesHelper
end
