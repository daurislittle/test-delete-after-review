module TrashcanHelper
end
