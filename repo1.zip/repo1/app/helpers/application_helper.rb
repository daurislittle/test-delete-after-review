module ApplicationHelper
  include FontAwesome5::Rails::IconHelper

  def quote_status_class (status)
    if status == 'Reviewed / Approved'
      'text-success'
    elsif status == 'Rejected'
      'text-danger'
    else
      'text-warning'
    end
  end

  def error_class(resource, field_name)
    if !resource.errors[field_name].empty?
      return "has-error"
    end
  end
end
