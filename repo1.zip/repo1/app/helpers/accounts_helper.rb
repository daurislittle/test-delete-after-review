module AccountsHelper
  def pager_path (page:1, per_page:15, view:'icon', search_for:'')
    accounts_path(page: page, per_page: per_page, view: view, search_for: search_for)
  end
end
