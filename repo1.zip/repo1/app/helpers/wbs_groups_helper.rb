module WbsGroupsHelper
  def find_linked ( line )
    line.wbs_group.wbs_group_lines.where("link_type = ? AND link_task = ?", 1, "#{line.sku}:#{line.task}")
  end

  def find_linked_to_all (group)
    group.wbs_group_lines.where(link_type: 2).or(group.wbs_group_lines.where(link_type:3))
  end
end
