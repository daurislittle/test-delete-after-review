module IsWatchable
  extend ActiveSupport::Concern

  def watchlist (**extra)
    fail NotImplementedError
  end
end