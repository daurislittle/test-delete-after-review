//= link_tree ../images
//= link_directory ../javascripts .js
//= link_directory ../stylesheets .css
//= link_directory ../javascripts/administration .js
//= link_directory ../stylesheets/administration .css
