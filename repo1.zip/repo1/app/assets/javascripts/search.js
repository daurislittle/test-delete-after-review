function configure_search (callback) {
    $('#search-button').on('click', function () {
        $('#search-icon').html('<span class="fas fa-spinner fa-pulse"></span>');

        callback(1, $('#pager-limit').val());
        return false;
    });

    $('#reset-button').on('click', function () {
        $('#search').val('');

        $('#search-icon').html('<span class="fas fa-spinner fa-pulse"></span>');
        callback(1, $('#pager-limit').val());

        return false;
    });

    $('#search').on('keypress', function (e) {
        if (e.keyCode == 13) {
            $('#search-icon').html('<span class="fas fa-spinner fa-pulse"></span>');

            callback(1, $('#pager-limit').val());
            return false;
        }
    });
}
