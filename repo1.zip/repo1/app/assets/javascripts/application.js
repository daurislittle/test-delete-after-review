// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, or any plugin's
// vendor/assets/javascripts directory can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file. JavaScript code in this file should be added after the last require_* statement.
//
// Read Sprockets README (https://github.com/rails/sprockets#sprockets-directives) for details
// about supported directives.
// require cable
//= require rails-ujs
//= require turbolinks
//= require jquery3
// require jquery_ujs
//= require popper
//= require bootstrap-sprockets
//= require sortable
//= require toasts

//= require chartkick
//= require Chart.bundle

jQuery.fn.autohide = function (timeout) {
    var element = $(this);

    timeout = timeout || 5000;

    setTimeout(function () { element.fadeOut({ complete: element.remove() }); }, timeout);
    return this;
}

//API for time and date functions
var startTime

var timeAndDateHandling = {
    /** Computes the elapsed time since the moment the function is called in the format mm:ss or hh:mm:ss
     * @param {String} startTime - start time to compute the elapsed time since
     * @returns {String} elapsed time in mm:ss format or hh:mm:ss format if elapsed hours are 0.
     */
    getElapsedTime: function (startTime) {

        // Record end time
        let endTime = new Date();

        // Compute time difference in milliseconds
        let timeDiff = endTime.getTime() - startTime.getTime();

        // Convert time difference from milliseconds to seconds
        timeDiff = timeDiff / 1000;

        // Extract integer seconds that dont form a minute using %
        let seconds = Math.floor(timeDiff % 60); //ignoring uncomplete seconds (floor)

        // Pad seconds with a zero if neccessary
        let secondsAsString = seconds < 10 ? "0" + seconds : seconds + "";

        // Convert time difference from seconds to minutes using %
        timeDiff = Math.floor(timeDiff / 60);

        // Extract integer minutes that don't form an hour using %
        let minutes = timeDiff % 60; //no need to floor possible incomplete minutes, becase they've been handled as seconds

        // Pad minutes with a zero if neccessary
        let minutesAsString = minutes < 10 ? "0" + minutes : minutes + "";

        // Convert time difference from minutes to hours
        timeDiff = Math.floor(timeDiff / 60);

        // Extract integer hours that don't form a day using %
        let hours = timeDiff % 24; //no need to floor possible incomplete hours, becase they've been handled as seconds

        // Convert time difference from hours to days
        timeDiff = Math.floor(timeDiff / 24);

        // The rest of timeDiff is number of days
        let days = timeDiff;

        let totalHours = hours + (days * 24); // add days to hours
        let totalHoursAsString = totalHours < 10 ? "0" + totalHours : totalHours + "";

        if (totalHoursAsString === "00") {
            return minutesAsString + ":" + secondsAsString;
        } else {
            return totalHoursAsString + ":" + minutesAsString + ":" + secondsAsString;
        }
    }
}

$(document).on('turbolinks:load', function() {
    configure_clickable_rows($('table'));

    $('#recently-viewed-previous, #recently-viewed-next').on('click', function () {
        $('#recently-viewed-working').removeClass('d-none');

        $.ajax({
            url: $(this).attr('href'),
            method: 'GET',
            dataType: 'script',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                $('#recently-viewed-working').addClass('d-none');
            },
            error: function () {
                $('#recently-viewed-working').addClass('d-none');
            }
        });

        return false;
    });

    $('#wbs-status-previous, #wbs-status-next').on('click', function () {
        $('#wbs-status-working').removeClass('d-none');

        $.ajax({
            url: $(this).attr('href'),
            method: 'GET',
            dataType: 'script',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                $('#wbs-status-working').addClass('d-none');
            },
            error: function () {
                $('#wbs-status-working').addClass('d-none');
            }
        });

        return false;
    });

    $("#menu-toggle").click(function(e) {
        e.preventDefault();

        $("#wrapper").toggleClass("active");

        // Fix other components after the transitions end.
        $("#wrapper").one("webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend", function(e) {
            $(window).trigger('resize');
        });
    });

    $('.sidebar-nav > li > a').each(function () {
        if ($(this).attr('href') == window.location.pathname) {
            $(this).addClass('active');
        }
    });


    $('.customCollapse').on('shown.bs.collapse', function () {
        $(this).parent().find(".fa-caret-down").removeClass("fa-caret-down").addClass("fa-caret-up");
    });

    $('.customCollapse').on('hidden.bs.collapse', function () {
        $(this).parent().find(".fa-caret-up").removeClass("fa-caret-up").addClass("fa-caret-down");
    });

    $("a.hamburger").click(function(e) {
        e.preventDefault();
        e.stopPropagation();

        $("#status-wrapper").toggleClass("active");
    });

    $('#right-side-status a').on('click', function(e) {
        e.preventDefault();

        $(this).tab('show');
    });

    $('#help-link').on('click', function () {
        $('#help-tab').tab('show');
        $("#status-wrapper").addClass("active");

        return false;
    });

    $('img.clickable').on('click', function () {
        $('#help-image-viewer').find('.modal-body').html($(this).clone().removeClass('clickable'));
        $('#help-image-viewer').modal('show');
    });

    $('[data-toggle="tooltip"]').tooltip();
    $('[data-tooltip]').tooltip();

    $(window).resize(function () {
        let topnav = $('#main-navbar');
        let subnav = $('#sub-navbar');

        let top_height = topnav.outerHeight();
        let sub_height = subnav.outerHeight();

        let bottom_height = 0;
        $('.bottom-nav').each( function () {
            bottom_height += $(this).outerHeight();
        });

        // This is done this way so that the 'important' can be overriden
        if (subnav.length > 0) {
            subnav[0].style.setProperty('top', top_height + "px", 'important');
        }

        // Position top of the right side status pullout
        $('#status-wrapper').css({
            'top': (top_height + sub_height) + 'px',
            'bottom': bottom_height + 'px'
        });

        // Position top of the main page area
        $('#page-content-wrapper').css({
            'margin-top': (top_height + sub_height),
            'margin-bottom': bottom_height
        });

        $('.toasts-area').css({
            top: (top_height + sub_height),
            bottom: bottom_height
        });

        $('.alert').each(function () {
            if (($(this).hasClass('alert-success') || $(this).hasClass('alert-info')) && !$(this).hasClass('static')) {
                $(this).autohide();
            }
        });
    });

    $(document).on('click', function () {
        $('#status-wrapper').removeClass('active');
    });

    $('#status-wrapper').on('click', function (e) {
        e.stopPropagation();
    });

    $(window).trigger('resize');
});

function configure_rotatables () {
    $('.rotatable').parents('a').on('click', function () {
        $(this).find('.rotatable').toggleClass('down');
    });
}

function configure_clickable_rows (table) {
    table.find('tr.clickable-row').each(function () {
        if ($(this).attr('title') !== undefined) {
            $(this).tooltip();
        }
    });

    table.find('tr.clickable-row').click(function () {
        if ($(this).data('url')) {
            if ($(this).data('target') !== 'blank')
                window.location = $(this).data('url');
            else
                window.open($(this).data('url'));
        }

        return false;
    });
}

function show_backdrop (message, show_busy) {
    let backdrop       = $('.application-backdrop');
    let message_region = backdrop.find('.spinner');
    let message_item   = backdrop.find(".backdrop-message");
    let busy_item      = backdrop.find(".fa-spinner");

    if (message === undefined) {
        message = 'Please Wait';
    }

    if (show_busy === false) {
        backdrop.css({ backgroundColor: 'rgba(255, 255, 255, 0.50)'});
        busy_item.hide();
    } else {
        busy_item.show();
    }

    message_item.text(message);
    if (message === undefined || message.length === 0) {
        message_item.hide();
    } else {
        message_item.show();
    }

    if (show_busy === false && (message === undefined || message.length === 0)) {
        message_region.hide();
    } else {
        startTime = new Date();

        $('.backdrop-timer').text('00:00');
        let timer = setInterval(function () {
            $('.backdrop-timer').text(timeAndDateHandling.getElapsedTime(startTime));
        }, 1000);

        message_region.data('timer-id', timer);
        message_region.show();

    }

    $('.application-backdrop').show();
}


function hide_backdrop () {
    let backdrop       = $('.application-backdrop');
    let message_region = backdrop.find('.spinner');

    clearInterval(message_region.data('timer-id'));
    $('.application-backdrop').hide();
}

function count_object_fields (obj) {
    if (obj.__count__ !== undefined) { // Old FF
        return obj.__count__;
    }

    if (Object.keys) { // ES5
        return Object.keys(obj).length;
    }

    // Everything else:
    var c = 0, p;
    for (p in obj) {
        if (obj.hasOwnProperty(p)) {
            c += 1;
        }
    }

    return c;

}
