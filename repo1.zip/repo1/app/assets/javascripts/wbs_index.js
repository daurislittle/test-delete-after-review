function configure_browser () {
    configure_search(update_view);
    configure_pager(update_view);

    $('div.fixed-banner').find('button').on('click', function () {
        $(this).parents(".fixed-banner").remove();
        return false;
    });

    var table = $('#wbs-table');
    if (table.length !== 0) {
        configure_table_sortable(table, update_view);
    }

    // When the view changes in the WBS browser
    $('ul.view-selector').on('click', 'li', function () {
        $('ul.view-selector > li.active').removeClass('active');
        $(this).addClass('active');

        //pager_loading();
        update_view($('#pager-page').val(), $('#pager-limit').val());
        return false;
    });

    // When 'Refresh' is clicked in the main menu
    $('#refresh-link').on('click', function () {
        //pager_loading();
        update_view($('#pager-page').val(), $('#pager-limit').val());

        return false;
    });

    $('input[name="search"]').on('input', function () {
        reload_wbs();
    });

    $('[name^="filter"]').on('change', function () {
        reload_wbs();
    });

    // When a card is clicked in the WBS browser, show its details
    $('.wbs-card').click(function () {
        window.location = 'wbs/' + $(this).data('id');
    });
};

function reload_wbs () {
    $.ajax({
        url: "/wbs",
        method: "GET",
        dataType: "script",
        data: {
            search: $('input[name="search"]').val(),
            page: 1,
            filters: {
                client: $('select[name="filters[client]"]').val(),
                project_structure: $('select[name="filters[project_structure]"]').val(),
                account_executive: $('select[name="filters[account_executive]"]').val(),
                scoped_by: $('select[name="filters[scoped_by]"]').val()
            }
        }
    });
}

function update_view (page, per_page) {
    show_backdrop('Requesting Work Breakdown Structures...');

    var table = $('#wbs-table');
    if (table.length != 0) {
        var sort_by = table.data('sort-by');
        var sort_direction = table.data('sort-direction');

        $.ajax({
            url: '/wbs',
            method: 'GET',
            dataType: 'script',
            data: {
                page: page,
                per_page: per_page,
                view: $('ul.view-selector > li.active').data('view'),
                search_for: $('#search').val(),
                sort_by: sort_by,
                sort_direction: sort_direction
            },
            success: function () {
                hide_backdrop();
            },
            error: function () {
                hide_backdrop();
            }
        });
    } else {
        $.ajax({
            url: '/wbs',
            method: 'GET',
            dataType: 'script',
            data: {
                page: page,
                per_page: per_page,
                view: $('ul.view-selector > li.active').data('view'),
                search_for: $('#search').val()
            },
            success: function () {
                hide_backdrop();
            },
            error: function () {
                hide_backdrop();
            }
        });
    }
}

//$(document).on('turbolinks:load', function() {
configure_browser();

if ($('ul.view-selector > li.active').data('view') == 'table') {
    $('#page-content-wrapper').addClass('tabular');
} else {
    $('#page-content-wrapper').removeClass('tabular');
}
//});