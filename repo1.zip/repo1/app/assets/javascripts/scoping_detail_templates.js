// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
//= require select2-full
//= require jquery-ui/widgets/sortable

$(document).on('turbolinks:load', function() {
    var practices_selection = $('select[name="scoping_detail_template[practice_ids][]"]');

    // Configure the project structure select element to use the select2 widget
    practices_selection.select2({
        minimumResultsForSearch: 10,
        theme: 'bootstrap4'

        // Prevent showing of the dropdown if we are deselecting...
    }).on('select2:opening', function (e) {
        if (practices_selection.data('unselecting')) {
            practices_selection.removeData('unselecting');
            e.preventDefault();
            return false;
        }

        // Need to adjust the z-index of the dropdown to appear behind the modal if present
    }).on('select2:open', function (e) {
        $('body').find('.select2-dropdown').css('z-index', 1039);
    }).on('select2:select', function (e) {
        var data = e.params.data;

        $('#practices-spinner').show();
        $.ajax({
            url:'/scoping_detail_templates/practices',
            method:'get',
            dataType:'script',
            data: {
                practices: practices_selection.val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success:function () {
                $('#practices-spinner').hide();
            },
            error: function () {
                $('#practices-spinner').hide();
            }
        });
    }).on('select2:unselecting', function (e) {
        // Determine if there are any entries that use this project structure and prevent the unselect if there are...
        var selected_id = e.params.args.data.id;
        var selected_text = e.params.args.data.text;

        practices_selection.data('unselecting', true);
        $('#practices-spinner').show();

        $.ajax({
            url: '/practices/' + selected_id + '/skus',
            method:'GET',
            dataType:'json',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function (response, status, jqXHR) {
                var removeable = true;

                $.each(response.skus, function (i, sku) {
                    $('select[name$="[sku_id]"]').each(function () {
                        if ($(this).val() === sku['Id']) {
                            removeable = false;
                        }
                    });
                });

                if (removeable) {
                    removeProjectStructure(selected_id, selected_text);
                    practices_selection.select2('close');
                } else {
                    $('#remove-project-structure-modal').data('practice', response).modal('show');
                }

                $('#practices-spinner').hide();
            },
            error:function () {
                $('#practices-spinner').hide();
            }
        });

        return false;
    });

    $('select[name$="[sku_id]"]').select2({
        theme: 'bootstrap4',
        minimumResultsForSearch: 10,
        templateResult: formatSKUItem,
        width: '100%'
    });

    $('a.add-scope-detail').on('click', function () {
        let table = $('table.scoping-template-table');
        let last_sku = '';
        let last_sku_element = table.find('tr:last').find('select[name$="[sku_id]"]');

        if (last_sku_element.length > 0) {
            last_sku = last_sku_element.val();
        }

        $.ajax({
            url: $(this).attr('href'),
            method:'GET',
            dataType:'script',
            data: {
                practices: $('select[name="scoping_detail_template[practice_ids][]"]').val(),
                sku: last_sku
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                update_order(table);
            },
            error: function () {
                update_order(table);
            }
        });
        return false;
    });

    $('#template-submit').on('click', function () {
        $('#scoping-template-form').submit();
        return false;
    });

    let table = $('table.scoping-template-table');

    table.find('input[type="checkbox"][name $= "[_destroy]"]').on('click', function () {
        let table = $(this).parents('table');
        let table_body = table.find('tbody');

        if ($(this).is(':checked')) {
            $(this).parents('tr').addClass('selected');

            if (table_body.find('tr.selected').length == table_body.find('tr').length) {
                $('#mark-all').find('i').removeClass('far').addClass('fas');
            } else {
                $('#mark-all').find('i').removeClass('fas').addClass('far');
            }

        } else {
            $(this).parents('tr').removeClass('selected');
            $('#mark-all').find('i').removeClass('fas').addClass('far');
        }

        update_order(table);
    });

    table.find('tbody').sortable({
        cursor: "move",
        revert: true,
        handle: '.sort-handle',
        placeholder: 'sort-placeholder',
        containment: table,
        scrollSpeed: 10,
        scrollSensitivity: 30,
        helper: function (e, ui) {
            let sku = ui.find('select[name$="[sku_id]"] option:selected').text();
            let item = ui.find('input[name$="[item]"]').val();
            let value = ui.find('textarea[name$="[value]"]').val();

            return '<div class="sort-helper">' +
                '<div class="header">' + sku + '</div>' +
                '<div class="body">' +
                '<div class="float-right">' + value + '</div>' +
                '<div class=>' + item + '</div>' +
                '</div>' +
                '</div>';
        },
        update: function (event, ui) {
            update_order($(this).parent());
        }
    });

    // Show modal dialog asking if removal of project structure should be forced
    $('#remove-project-structure-modal').on('show.bs.modal', function () {
        $('span.ps-title').text($(this).data('practice').name);
    });

    // When requested remove line items associated with the project structure being removed
    $('#force-remove').on('click', function () {
        var modal = $('#remove-project-structure-modal');
        var practice = modal.data('practice');
        // Check each line item for a match with the project structure's prefixes
        $('select.sku').each(function () {
            var current_select = $(this);
            var current_value  = current_select.val();
            var current_row    = current_select.parents('tr');
            var row_index = current_row.data('data-index');
            $.each(practice.skus, function (index, sku) {
                if (current_value === sku['Id']) {
                    console.log('matched',row_index);
                    var destroy_check = $('input[name="scoping_detail_template[sdt_items_attributes][' + row_index + '][_destroy]"]');
                    destroy_check.val(1);
                    destroy_check.appendTo($('form'));

                    current_row.remove();
                }
            });
            row_index = row_index + 1;
        });

        removeProjectStructure(practice.id, practice.name);
        modal.modal('hide');
    });
});

function removeProjectStructure(id, name) {
    var select = $('select[name="scoping_detail_template[practice_ids][]"]');
    var selected = select.val();

    var indexOf = $.inArray(id + "", selected);
    if (indexOf >= 0) {
        selected.splice($.inArray(id + "", selected), 1);
        select.val(selected).change();

        $.ajax({
            url:'/scoping_detail_templates/practices',
            method:'get',
            dataType:'script',
            data: {
                practices: select.val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            }
        });
    }
}

// Function used by the select2 widget to add the SKU descriptions to the select options
function formatSKUItem (sku) {
    if (!sku.id) {
        return sku.text;
    }

    var $item = $(
        '<div>' +
        sku.text + '<br/>' +
        '<span style="font-size:12px;font-style:italic">' + $(sku.element).data('description') + '</span>' +
        '</div>'
    );

    return $item;
}

function update_order (table) {
    let index = 0;

    table.find('tbody tr').each(function () {
        if (!$(this).find('input[type="checkbox"][name$="[_destroy]"]').is(':checked')) {
            $(this).find('input[type="hidden"][name$="[ordinal]"]').val(index);
            $(this).find('td:first').text(index + 1);

            index += 1;

        } else {
            $(this).find('td:first').text('');
        }
    });
}