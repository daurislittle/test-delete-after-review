function configure_view () {
    $('div.fixed-banner').find('button').on('click', function () {
        $(this).parents(".fixed-banner").remove();
        return false;
    });

    $('a[data-toggle="tooltip"]').tooltip({container: 'body'});

    // Handle show/hide of notes line
    $('#wbs-lineitems').find('td a.collapsible').each(function () {
        let target = $($(this).attr('href'));

        target.on('show.bs.collapse', function () {
            $(this).prev().find('td[rowspan]').attr('rowspan', 2);
        }).on('hidden.bs.collapse', function () {
            $(this).prev().find('td[rowspan]').attr('rowspan', 1);
        });

        $(this).on('click', function () {
            $(this).tooltip('hide');
            $(this).blur();
            target.collapse('toggle');
        })
    });

    // When 'Publish' is clicked in the main menu
    $('#wbs-publish').on('click', function () {
        publish_wbs($(this));
        return false;
    });

    $('a[data-toggle="tab"]').on('shown.bs.tab', function (event) {
        if (event.target.href.endsWith('#quotes')) {
            $('#quote-refresh-btn').removeClass('d-none');
            $('#quote-validate-btn').removeClass('d-none');
        } else {
            $('#quote-refresh-btn').addClass('d-none');
            $('#quote-validate-btn').addClass('d-none');
        }

        if (event.target.href.endsWith('#details')) {
            $('#wbs-calculator').parent().removeClass('d-none');
        } else {
            if ($('#calculator').is(':visible')) {
                $('#wbs-calculator').trigger('click');
            }

            $('#wbs-calculator').parent().addClass('d-none').removeClass('calc-link-active');
        }
    });

    if ($('#toasts-pane').find('.unpublishable').length > 0) {
        $('#publishability-warnings-link').on('click', function () {
            $('#publishability-warnings-tab').tab('show');
            $("#status-wrapper").addClass("active");

            return false;
        });

        //$('#toasts-tab').tab('show');
        //$("#status-wrapper").addClass("active");
    }
};

function configure_quote_refresh () {
    $('#quote-validate-btn').on('click', function () {
        show_backdrop("Validating Quote...");

        $.ajax({
            url: $(this).attr('href'),
            method: $(this).data('method'),
            dataType: 'script',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                hide_backdrop();
            },
            error: function () {
                hide_backdrop();
            }
        });

        return false;
    });

    $('#quote-refresh-btn').on('click', function () {
        show_backdrop("Requesting Quote from Salesforce...");
        $(this).tooltip('hide');

        $.ajax({
            url: $(this).attr('href'),
            method: $(this).data('method'),
            dataType: 'script',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                hide_backdrop();
            },
            error: function () {
                hide_backdrop();
            }
        });

        return false;
    });
}

function reload_wbs () {
    $.ajax({
        url: "/wbs",
        method: "GET",
        dataType: "script",
        data: {
            search: $('input[name="search"]').val(),
            page: 1,
            filters: {
                client: $('select[name="filters[client]"]').val(),
                project_structure: $('select[name="filters[project_structure]"]').val(),
                account_executive: $('select[name="filters[account_executive]"]').val(),
                scoped_by: $('select[name="filters[scoped_by]"]').val()
            }
        },
        beforeSend: function(xhr) {
            xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
        }
    });
}

function publish_wbs (button) {
    if (!button.hasClass('disabled')) {
        show_backdrop('Publishing WBS to Salesforce...Please Wait...');
        const timer = setTimeout(function () {
            window.location.reload();
        }, 300 * 1000);
        $.ajax({
            url: button.attr('href'),
            method: button.data('method'),
            dataType: 'script',
            complete: function () {
                clearTimeout(timer);
                hide_backdrop();
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            }
        });
    }
}

$(document).on('turbolinks:load', function() {
    configure_view();
    configure_quote_refresh();

    if ($('ul.view-selector > li.active').data('view') == 'table') {
        $('#page-content-wrapper').addClass('tabular');
    } else {
        $('#page-content-wrapper').removeClass('tabular');
    }
});