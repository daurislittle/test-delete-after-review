// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.

$(document).on('turbolinks:load', function() {
    $('a[data-tab]').on('click', function () {
        show_tab($(this).data('tab'));
        return false;
    });

    $('table.template-table').find('tbody > tr').on('click', function () {
        window.location = $(this).data('url');
    });

    $('#page-content-wrapper').addClass('tabular');
});

function show_tab (index) {
    $('a[href="' + index + '"]').tab('show');
}