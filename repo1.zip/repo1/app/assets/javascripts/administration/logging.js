const date_regex = /^(\d{4})[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/;

Date.daysBetween = function( date1, date2 ) {
    //Get 1 day in milliseconds
    var one_day=1000*60*60*24;

    // Convert both dates to milliseconds
    var date1_ms = date1.getTime();
    var date2_ms = date2.getTime();

    // Calculate the difference in milliseconds
    var difference_ms = date2_ms - date1_ms;

    // Convert back to days and return
    return Math.round(difference_ms/one_day);
}

$(document).on('turbolinks:load', function () {
    $('#filter-server').on('click', function () {
        log_filter('server');
        return false;
    });

    $('#filter-salesforce').on('click', function () {
        log_filter('salesforce');
        return false;
    });

    $('#server-page-backward').on('click', function () {
        $(this).tooltip('hide');

        log_page_backward('server', $('#server_from_date'), $('#server_to_date'));
        return false;
    });

    $('#server-page-forward').on('click', function () {
        $(this).tooltip('hide');

        log_page_forward('server', $('#server_from_date'), $('#server_to_date'));
        return false;
    });

    $('#salesforce-page-backward').on('click', function () {
        $(this).tooltip('hide');

        log_page_backward('salesforce', $('#salesforce_from_date'), $('#salesforce_to_date'));
        return false;
    });

    $('#salesforce-page-forward').on('click', function () {
        $(this).tooltip('hide');

        log_page_forward('salesforce', $('#salesforce_from_date'), $('#salesforce_to_date'));
        return false;
    });
});

function log_page_backward (prefix, from_element, to_element) {
    // Split and create a Date object for the from date.
    let parsed_from = from_element.val().split('-')
    let from_date = new Date(parseInt(parsed_from[0]), parseInt(parsed_from[1])-1, parseInt(parsed_from[2]));

    // Split and create a Date object from the to date.
    let parsed_to = to_element.val().split('-');
    let to_date = new Date(parseInt(parsed_to[0]), parseInt(parsed_to[1])-1, parseInt(parsed_to[2]));

    // Move the from date by number of dates between the two dates
    days = Date.daysBetween(from_date, to_date);
    from_date = new Date(from_date.getFullYear(), from_date.getMonth(), (from_date.getDate() - days));

    // Append 0 to month if required.  Note: months are stored 0 indexed (hence the +1)
    month = from_date.getMonth() + 1;
    month = (month < 10) ? '0' + month : month;

    // Append 0 to the day if required.
    day = from_date.getDate();
    day = (day < 10) ? '0' + day : day;

    // Set the to value to the current from value
    to_element.val(from_element.val());

    // Set the from value to be the current value - Xdays
    from_element.val(from_date.getFullYear() + '-' + month + '-' + day);

    // Update the log display
    log_filter(prefix);
}

function log_page_forward (prefix, from_element, to_element) {
    // Split and create a Date object for the from date.
    let parsed_from = from_element.val().split('-');
    let from_date = new Date(parseInt(parsed_from[0]), parseInt(parsed_from[1])-1, parseInt(parsed_from[2]));

    // Split and create a Date object from the to date.
    let parsed_to = to_element.val().split('-');
    let to_date = new Date(parseInt(parsed_to[0]), parseInt(parsed_to[1])-1, parseInt(parsed_to[2]));

    // Move the to date by number of dates between the two dates
    days = Date.daysBetween(from_date, to_date);
    to_date = new Date(to_date.getFullYear(), to_date.getMonth(), (to_date.getDate() + days));

    // Append 0 to month if required.  Note: months are stored 0 indexed (hence the +1)
    month = to_date.getMonth() + 1;
    month = (month < 10) ? '0' + month : month;

    // Append 0 to the day if required.
    day = to_date.getDate();
    day = (day < 10) ? '0' + day : day;

    // Move from value to be current to value
    from_element.val(to_element.val());

    // Set the to value to the old value + Xdays.
    to_element.val(to_date.getFullYear() + '-' + month + '-' + day);

    // Update the log display
    log_filter(prefix);
}

function log_filter (prefix) {
    let form = $('#' + prefix + '-form');
    let spinner = $('#' + prefix + '-spinner');

    spinner.removeClass('d-none');

    $.ajax({
        url:form.attr('action'),
        method: form.attr("data-method"),
        dataType: 'script',
        data: form.serialize(),
        beforeSend: function(xhr) {
            xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
        },
        success: function () {
            spinner.addClass('d-none');
        },
        error: function () {
            spinner.addClass('d-none');
        }
    });
}