// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
//= require select2

$(document).on('turbolinks:load', function () {
    $('a.hide-button').on('click', function () {
        $(this).parent('.alert').hide();
    });

    $('a[data-toggle="collapse"]').each(function () {
        var link = $(this);

        $(link.attr('href')).on('show.bs.collapse', function () {
            link.text('- ' + link.data('count') + ' less');
        }).on('hide.bs.collapse' ,function ()  {
            link.text('+ ' + link.data('count') + ' more');
        });
    });

    $('.practice-edit-link').on('click', function () {
        $(this).hide();
        $(this).parent().find('.row-spinner').show();
    });

    /*
    $('select[name="practice[leadership_team_id]"]').select2({
        theme: 'bootstrap4'
    });
    */

    $('select[name="scoping_team"]').select2({
        theme: 'bootstrap4'
    });

    $('button[type="submit"]').on('click', function () {
        $.ajax({
            url: $('#practice-form').attr('action'),
            method: 'POST',
            dataType: 'script',
            data: $('#practice-form').serialize(),
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            }
        });

        //$('#practice-form').submit();
        return false;
    });
});