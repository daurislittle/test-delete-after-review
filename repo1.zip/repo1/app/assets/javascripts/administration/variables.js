// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
$(document).on('turbolinks:load', function() {
    $('#variable-table td.editable').find('a.cancel').on('click', function () {
        var editable = $(this).parents('td.editable');
        var editor   = editable.find('.editor');

        editor.find('[name="variable[value]"]').val(editable.data('value'));
        editable.find('.value').show();
        editor.hide();

        return false;
    });

    $('#variable-table td.editable').find('a.save').on('click', function () {
        var editable = $(this).parents('td.editable');
        var form = editable.find('form');
        var editor_element = editable.find('.editor');
        var value_element = editable.find('.value');
        var value = editor_element.find('[name="variable[value]"]').val();

        editor_element.find('.error-message').hide();
        editor_element.removeClass('border border-danger')

        var new_value = null;
        if (value_element.data('type') == 'currency') {
            if (value.match(/^\d+\.\d{2}$/gm)) {
                new_value = '$' + value;
            } else {
                editor_element.find('.error-message').show();
                editor_element.addClass('border border-danger');
            }

        } else if (value_element.data('type') == 'integer') {
            if (value.match(/^[-+]?\d+$/gm)) {
                new_value = value;
            } else {
                editor_element.find('.error-message').show();
                editor_element.addClass('border border-danger');
            }

        } else if (value_element.data('type') == 'float') {
            if (value.match(/^[+-]?\d+(\.\d+)?$/gm)) {
                new_value = value;
            } else {
                editor_element.find('.error-message').show();
                editor_element.addClass('border border-danger');
            }
        } else {
            new_value = value;
        }

        if (new_value !== null) {
            value_element.text(new_value);
            value_element.show();
            editable.find('.editor').hide();

            $.ajax({
                url: form.attr('action'),
                method: form.attr('method'),
                dataType: 'script',
                data: form.serialize(),
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
                }
            });
        }

        return false;
    });

    $('#variable-table td.editable').on('click', function () {
        $(this).find('.value').hide();
        $(this).find('.editor').show();
        $(this).data('value', $(this).find('[name="variable[value]"]').val());

        return false;
    });
});