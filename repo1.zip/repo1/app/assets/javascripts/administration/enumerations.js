// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.

$(document).on( 'turbolinks:load', function () {
    $(document).on('page:load', configure_enumerations_page );

    configure_enumerations_page();
});

function configure_enumerations_page () {
    $('#enum_type').on('change', function () {
        $('#enumeration-filter-form').submit();
        return false;
    });

    $('#enum-submit').on('click', function () {
        $('#enumeration-form').submit();
        return false;
    });
}