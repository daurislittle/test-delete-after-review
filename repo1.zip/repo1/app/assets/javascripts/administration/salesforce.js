// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
$(document).on('turbolinks:load', function () {
    $('#sfdc-connect').on('click', function () {
        var button = $(this);

        button.html('<span class="fas fa-spinner fa-spin"></span>');
        $('#sfdc-status').removeClass('text-success').addClass('text-warning').text('Connecting...');
        $('p.help-text.text-danger').text('').hide();

        $.ajax({
            url:'/administration/salesforce/connect',
            method:'get',
            dataType:'script',
            data:{
                env:$('select[name="salesforce[env]"]').val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                button.text('Connect');
            }
        });
        return false;
    });

    $('#select-all').on('click', function () {
        if ( $(this).is(':checked') ) {
            $('input.import-checkbox').prop('checked', true);
        } else {
            $('input.import-checkbox').prop('checked', false);
        }
    });

    $('#clear-console').on('click', function () {
        $('#salesforce-console').html('');
        return false;
    });

    $('#submit-query').on('click', function () {
        var spinner = $(this).parents('.card').find('.fa-spinner');

        spinner.show();
        $.ajax({
            url: "/administration/salesforce/query",
            method: "GET",
            dataType: "JSON",
            data: {
                query: $('#salesforce-query').val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function ( responseData, responseText, jqXHR ) {
                $('#salesforce-console').prepend('<div class="query">' + $('#salesforce-query').val() + '</div><pre class="text-primary entry">' + syntaxHighlight(JSON.stringify(responseData, null, 2)) + '</pre>')
                spinner.hide();
            },
            error: function ( error ) {
                $('#salesforce-console').prepend('<div class="text-danger entry">' + error.responseText.replace(/\n/g, "<br />") + '</div>')
                spinner.hide();
            }
        })
    });

    $('#submit-describe').on('click', function () {
        var spinner = $(this).parents('.card').find('.fa-spinner');
        spinner.show();

        $.ajax({
            url: "/administration/salesforce/describe",
            method: "GET",
            dataType: "JSON",
            data: {
                query: $('#salesforce-describe').val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function ( responseData, responseText, jqXHR ) {
                $('#salesforce-console').prepend('<div class="query">' + $('#salesforce-describe').val() + '</div><pre class="text-primary entry">' + syntaxHighlight(JSON.stringify(responseData, null, 2)) + '</pre>')
                spinner.hide();
            },
            error: function ( error ) {
                $('#salesforce-console').prepend('<div class="text-danger entry">' + error.responseText.replace(/\n/g, "<br />") + '</div>')
                spinner.hide();
            }
        })
    });

    $('#submit-picklist').on('click', function () {
        var spinner = $(this).parents('.card').find('.fa-spinner');
        spinner.show();

        $.ajax({
            url: "/administration/salesforce/picklist",
            method: "GET",
            dataType: "JSON",
            data: {
                object: $('#salesforce-pl-object').val(),
                field: $('#salesforce-pl-field').val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function ( responseData, responseText, jqXHR ) {
                $('#salesforce-console').prepend('<div class="query">' + $('#salesforce-describe').val() + '</div><pre class="text-primary entry">' + syntaxHighlight(JSON.stringify(responseData, null, 2)) + '</pre>')
                spinner.hide();
            },
            error: function ( error ) {
                $('#salesforce-console').prepend('<div class="text-danger entry">' + error.responseText.replace(/\n/g, "<br />") + '</div>')
                spinner.hide();
            }
        })
    });

    $('#submit-find').on('click', function () {
        var spinner = $(this).parents('.card').find('.fa-spinner');
        spinner.show();

        $.ajax({
            url: "/administration/salesforce/find",
            method: "GET",
            dataType: "JSON",
            data: {
                what: $('#salesforce-find-what').val(),
                value: $('#salesforce-find-value').val(),
                field: $('#salesforce-find-field').val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function ( responseData, responseText, jqXHR ) {
                $('#salesforce-console').prepend('<div class="query">' + '</div><pre class="text-primary entry">' + syntaxHighlight(JSON.stringify(responseData, null, 2)) + '</pre>')
                spinner.hide();
            },
            error: function ( error ) {
                $('#salesforce-console').prepend('<div class="text-danger entry">' + error.responseText.replace(/\n/g, "<br />") + '</div>')
                spinner.hide();
            }
        });
    });

    function syntaxHighlight(json) {
        json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
            var cls = 'number';
            if (/^"/.test(match)) {
                if (/:$/.test(match)) {
                    cls = 'key';
                } else {
                    cls = 'string';
                }
            } else if (/true|false/.test(match)) {
                cls = 'boolean';
            } else if (/null/.test(match)) {
                cls = 'null';
            }
            return '<span class="' + cls + '">' + match + '</span>';
        });
    }
});