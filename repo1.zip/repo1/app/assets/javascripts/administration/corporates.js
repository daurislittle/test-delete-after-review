// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
$(document).on('turbolinks:load', function () {
    $('#import').on('click', function () {
        $('#corporates-import-modal').on('show.bs.modal', function () {
            var file_dialog = $(this);
            file_dialog.find('button[type="submit"]').one('click', function () {
                Rails.fire(file_dialog.find('form')[0], 'submit');
                file_dialog.find('.file-form').addClass('d-none');
                file_dialog.find('.import-results').removeClass('d-none');

                file_dialog.find('.modal-title').html('<i class="fa fa-spinner fa-pulse"></i> Importing...');
                file_dialog.find('button.close').hide();
                file_dialog.find('.modal-footer').hide();
                file_dialog.find('.modal-body').hide();
                return false;
            });

        }).on('hidden.bs.modal', function () {
            window.location = '/administration/corporates'
        }).modal('show');
    });

    $('#okta-sync').on('click', function () {
        let url = $(this).attr('href');

        $('#import-modal').on('show.bs.modal', function () {
            let modal = $(this);

            modal.find('h5.modal-title').html(
                '<i class="far fa-spinner fa-spin"></i>&nbsp;Syncing Corporate Database with Okta...'
            );

            modal.find('div.import-results').text('');
            modal.find('div.modal-body').hide();
            modal.find('button.close').hide();
            modal.find('div.modal-footer').hide();

        }).on('shown.bs.modal', function () {
            let modal = $(this);

            $.ajax({
                url: url,
                method: 'post',
                dataType: 'script',
                data: {
                    authenticity_token: $('meta[name=csrf-token]').attr('content')
                },
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
                },
                success: function () {
                    modal.find('div.modal-body').show();
                    modal.find('button.close').show();
                    modal.find('.modal-footer').show();
                },
                error: function () {
                    modal.find('div.modal-body').show();
                    modal.find('button.close').show();
                    modal.find('.modal-footer').show();
                }
            });
        }).modal('show');

        return false;
    });
});