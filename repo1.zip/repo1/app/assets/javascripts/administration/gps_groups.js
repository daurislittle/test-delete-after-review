// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.

$(document).on('turbolinks:load', function () {
    $('#import').on('click', function () {
        $('#groups-import-modal').on('show.bs.modal', function () {
            var file_dialog = $(this);
            file_dialog.find('button[type="submit"]').one('click', function () {
                Rails.fire(file_dialog.find('form')[0], 'submit');
                file_dialog.find('.file-form').addClass('d-none');
                file_dialog.find('.import-results').removeClass('d-none');

                file_dialog.find('.modal-title').html('<i class="fa fa-spinner fa-pulse"></i> Importing...');
                file_dialog.find('button.close').hide();
                file_dialog.find('.modal-footer').hide();
                file_dialog.find('.modal-body').hide();
                return false;
            });

        }).on('hidden.bs.modal', function () {
            window.location = '/administration/gps_groups'
        }).modal('show');
    });

    $('#purge-groups').on('click', function () {
        $.ajax({
            url: '/administration/gps_groups/purge',
            method: 'POST',
            dataType: 'script',
            data: {
                authenticity_token: $("meta[name='csrf-token']").attr("content")
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                window.location = '/administration/gps_groups';
            }
        });

        return false;
    });
});