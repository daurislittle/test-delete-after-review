var LINKED_TO_NONE = "0";
var LINKED_TO_ONE  = "1";
var LINKED_TO_SKU  = "2";
var LINKED_TO_ALL  = "3"

var VALIDITY_OK                  = 0;
var VALIDITY_INVALID_CIRCULAR    = 1;
var VALIDITY_INVALID_LINKEDTOALL = 2;

var MANAGEMENT_LCAT = [
    'Project Manager',
    'Senior Project Manager',
    'Program Manager',
    'Project Coordinator'
]

function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
}

function row_sku (row) {
    return row.find('select[name$="[sku]"]').val();
}

function row_task (row) {
    return row.find('input[name $= "[task]"]').val();
}

function row_labor_category (row) {
    var selected = row.find('select[name $= "[gsa_labor_category_id]"]').find('option:selected');
    if (selected.length !== 0) {
        return {
            id:selected.val(),
            label:selected.text()
        };
    }

    return {};
}

function row_qualified_name(row) {
    return row_sku(row) + ':' + row_task(row);
}

function row_total_hours(row) {
    return parseFloat(row.find('input[name$="[total_hours]"]').val());
}

function row_link_type (row) {
    return row.find('input[name $= "[link_type]"]').val();
}

function row_link_task (row) {
    return row.find('input[name $= "[link_task]"]').val();
}

function row_compliancy (row) {
    let opp_vehicle = $('select[name="work_breakdown_structure[contract_vehicle]"]').val();
    let row_vehicle = row.find('select[name$="[contract_vehicle]"]').val();

    // If the row does not have a specific contract vehicle then use the opportunity level contract vehicle
    contract_vehicle = !row_vehicle ? opp_vehicle : row_vehicle;

    $.ajax({
        url: '/wbs/gsa_compliance',
        method: 'GET',
        dataType: 'json',
        data: {
            vehicle: contract_vehicle,
            gsa_labor_category: row.find('select[name$="[gsa_labor_category_id]"] option:selected').val(),
            billable_rate: row.find('input[name$="[billable_rate]"]').val(),
            region: $('form').find('input[name$="[region]"]').val()
        },
        beforeSend: function(xhr) {
            xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
        },
        success: function ( responseData, responseStatus, jqXHR ) {
            if ( responseData.is_compliant ) {
                row.find('td.gsa-compliance').removeClass('text-danger').addClass('text-success').text('COMPLIANT');
            } else {
                row.find('td.gsa-compliance').removeClass('text-success').addClass('text-danger').html(
                    '<span title="' + responseData.message + '" data-toggle="tooltip" style="cursor:help">VIOLATION</span>'
                ).find('span').tooltip();
            }
        }
    });
}

function find_row (table, sku, task) {
    var qualified_name = sku + ':' + task;

    var row = null;
    table.find('tbody').each(function () {
        if (qualified_name === row_qualified_name($(this))) {
            row = $(this);
            return false;
        }
    });

    return row;
}

function is_engagement (row) {
    let sku = row.find('select[name$="[sku]"]').val();
    let task = row.find('input[name$="[task]"]').val().toLowerCase();
    let lcat = row.find('select[name$="[gsa_labor_category_id]"]').find(':selected').text();

    if (sku.endsWith('TOOLS') || task.includes('gears') ||
        task.includes('after hours') || MANAGEMENT_LCAT.includes(lcat) ) {
        return false;
    }

    return true;
}

// If sku is provided, this function will return all engagement rows (e.g. non-PM, non-Tool, and Non-After Hours
// that share the provided sku.  If sku is not provided, then it returns all engagement rows not considering sku.
function engagement_rows (table, sku) {
    rows = [];

    if (sku !== undefined && sku.length > 0) {
        table.find('tbody[data-index]').each(function () {
            var row = $(this);

            if (row_sku(row) === sku) {
                if (is_engagement(row)) {
                    rows.push(row);
                }
            }
        });
    } else {
        table.find('tbody[data-index]').each(function () {
            if (is_engagement($(this))) {
                rows.push($(this));
            }
        });
    }

    return rows;
}

function pm_rows (table, sku) {
    rows = [];

    table.find('tbody[data-index]').each(function () {
        var row = $(this);
        var labor_category = row_labor_category(row);

        if (sku === undefined || sku.length <= 0 || row_sku(row) === sku) {
            if (labor_category.label === 'Project Manager' || labor_category.label === 'Project Coordinator' ||
                labor_category.label === 'Program Manager' || labor_category.label === 'Senior Project Manager') {
                rows.push(row);
            }
        }
    });

    return rows;
}

function validate_link ( table, id, link_type, link_sku, link_task ) {
    var row = table.find('tbody[data-index="' + id + '"]');
    var validity = VALIDITY_OK;

    if ( link_type === LINKED_TO_ONE ) {
        var next_row = null;
        table.find('tbody').each( function () {
            var row_sku = $(this).find('select.sku').val();
            var row_task = $(this).find('input.task').val();

            if (row_sku == link_sku && row_task == link_task) {
                next_row = $(this);
                return false;
            }
        });

        if ( is_circular(table, row, next_row) ) {
            validity = VALIDITY_INVALID_CIRCULAR;

        } else {
            // Make sure this doesn't link to an "all" link
            if (row_link_type(next_row) === LINKED_TO_SKU || row_link_type(next_row) === LINKED_TO_ALL) {
                validity = VALIDITY_INVALID_LINKEDTOALL;
            }
        }
    }

    return validity;
}

function is_circular (table, start, row) {
    if ( row === null )
        return false;

    var next_row = follow_link(table, row);

    while ( next_row !== null ) {
        if ( next_row.data('index') === start.data('index') ) {
            return true;
        }

        next_row = follow_link(table, next_row);
    }

    return false;
}

// Follows the link (if any) on the provided row and returns the next row (if any)
function follow_link (table, row) {
    var link_type = row_link_type(row);

    if ( link_type === LINKED_TO_ONE ) {
        var link_name = row_link_task(row); // Qualified name (SKU:Task) this row is linked to

        var return_row = null;
        table.find('tbody').each( function () {
            if (link_name === row_qualified_name($(this))) {
                return_row = $(this);
                return false;
            }
        });

        return return_row;
    }

    return null;
}

function remove_link (table, id) {
    var line = table.find('tbody[data-index="' + id + '"]');
    if ( line.length > 0 ) {
        line.find('input[type="hidden"][name$="[link_type]"]').val(LINKED_TO_NONE);
        line.find('input[type="hidden"][name$="[link_task]"]').val("");
        line.find('input[type="hidden"][name$="[link_percent]"]').val("");
        line.find('span.link-badge').html('<i class="fas fa-unlink"></i>');
        line.find('input.linked').removeClass('linked');
    }
}

// Compute costs and revenue for the given row based on the current hours and rates
function compute_line ( row ) {
    var total_hours_input   = row.find('.total-hours');
    var billable_rate_input = row.find('.billable-rate');
    var internal_rate_input = row.find('.internal-rate');
    var total_hours   = 0;
    var billable_rate = 0.0;
    var internal_rate = 0.0;

    // Convert form element value strings to numbers
    if ( total_hours_input.length != 0 ) {
        total_hours = parseFloat( total_hours_input.val() );
    }

    if ( billable_rate_input.length != 0 ) {
        billable_rate = parseFloat( billable_rate_input.val() );
    }

    if ( internal_rate_input.length != 0 ) {
        internal_rate = parseFloat( internal_rate_input.val() );
    }

    var revenue = total_hours * billable_rate;

    row.find('.total-revenue').text('$' + revenue.toFixed(2));
    row.find('.internal-cost').text('$' + (total_hours * internal_rate).toFixed(2));

    var gross_profit = total_hours * ( billable_rate - internal_rate);

    row.find('.gross-profit-dollars').text('$' + gross_profit.toFixed(2));

    if ( revenue > 0 ) {
        row.find('.gross-profit-percent').text((gross_profit / revenue * 100).toFixed(2) + '%');
    }

    row_compliancy(row, $('select[name="work_breakdown_structure[contract_vehicle]"]').val());
}

function update_row (row, link_type, percentage, link_task) {
    var table = row.parents('table').eq(0);
    var total_hours = 0;

    if ( link_type !== LINKED_TO_NONE ) {
        row.find('span.link-badge').html('<i class="fas fa-link"></i>');
        row.find('input.total-hours').addClass('linked');

    } else {
        row.find('span.link-badge').html('<i class="fas fa-unlink"></i>');
        row.find('input.linked').removeClass('linked');
    }

    row.find('input[name$="[link_type]"]').val(link_type);
    row.find('input[name$="[link_task]"]').val(link_task[0] + ':' + link_task[1]);
    row.find('input[name$="[link_percent]"]').val(percentage);

    if ( link_type === LINKED_TO_ONE ) {
        var linked_row = find_row(table, link_task[0], link_task[1]);

        if ( linked_row !== undefined ) {
            total_hours = parseFloat(linked_row.find('input.total-hours').val());
        }

    } else if ( link_type == LINKED_TO_SKU ) {
        var row_id = row.data('index');
        var this_sku = row_sku(row);

        total_hours = 0;
        $.each(engagement_rows(table, this_sku), function (index, engagement_row) {
            if (engagement_row.data('index') != row_id) {
                total_hours += parseFloat($(this).find('input.total-hours').val());
            }
        });

    } else if (link_type == LINKED_TO_ALL) {
        var row_id = row.data('index');

        total_hours = 0;
        $.each(engagement_rows(table), function (index, engagement_row) {
            if (engagement_row.data('index') != row_id) {
                total_hours += parseFloat($(this).find('input.total-hours').val());
            }
        });
    }

    total_hours = Math.round(percentage * total_hours * 100) / 100;
    total_hours = Math.ceil(total_hours * 4) / 4;
    row.find('input[name$="[total_hours]"]').val(total_hours);

    compute_line(row);
}

// Update the total hours for all rows based on the row passed in
function update_total_hours (table, row) {
    var sku = row_sku(row);
    var task = row_task(row);
    var total_hours = 0;

    if (!row.find('.selected').is(':checked')) {
        total_hours = row_total_hours(row);
    }

    var qualified_task_name = sku + ':' + task;
    var rows_linkedto_sku = [];
    var rows_linkedto_all = [];

    table.find('tbody[data-index!="' + row.data('index') + '"]').each( function () {
        var current_row = $(this);

        var mark_for_deletion = current_row.find('.selected');
        if (mark_for_deletion && !mark_for_deletion.is(':checked')) {
            var link_type = row_link_type(current_row);
            var link_task = row_link_task(current_row);
            var sku_for_row = row_sku(current_row);

            // If the current entry is linked to the task passed in...
            if (link_type === LINKED_TO_ONE && link_task === qualified_task_name) {
                var link_percent = parseFloat(current_row.find('input[type="hidden"][name $= "[link_percent]"]').val());

                update_row(current_row, link_type, link_percent, link_task.split(':'));

                // Cascade to update any rows linked to the current row...
                update_total_hours(table, current_row);

            // If this entry is linked to all tasks (of the sku) save it and process it last
            } else if (link_type === LINKED_TO_SKU) {
                if (sku_for_row === sku) {
                    rows_linkedto_sku.push(current_row);
                }

            } else if (link_type === LINKED_TO_ALL) {
                rows_linkedto_all.push(current_row);
            }
        }
    });

    $.each(rows_linkedto_sku, function (i, row) {
        var link_type = row.find('input[type="hidden"][name $= "[link_type]"]').val();
        var link_task = row.find('input[type="hidden"][name $= "[link_task]"]').val();
        var link_percent = parseFloat(row.find('input[type="hidden"][name $= "[link_percent]"]').val());

        update_row(row, link_type, link_percent, link_task.split(':'));
    });

    // Process an "All Rows" Link last
    $.each(rows_linkedto_all, function (i, row) {
        var link_type = row.find('input[type="hidden"][name $= "[link_type]"]').val();
        var link_task = row.find('input[type="hidden"][name $= "[link_task]"]').val();
        var link_percent = parseFloat(row.find('input[type="hidden"][name $= "[link_percent]"]').val());

        update_row(row, link_type, link_percent, link_task.split(':'));
    });
}

function create_popover_links () {
    return $(this).next('.popover-content').html();
}

function configure_popover (table, link) {
    var link_popover_options = {
        //selector: "a.link-popover",
        container: "body",
        placement: "right",
        title: "This Item Links To...",
        html: true,
        trigger: "manual",
        sanitize: false,
        template:'<div class="popover" role="tooltip" style="min-width:600px;z-index:10100;">' +
                 '<div class="arrow"></div><div class="popover-title bg-primary text-white">' +
                 'Links allow the <em>total hours</em> to be automatically calculated as a percentage of\n' +
                 'other line items within the WBS.</div><div class="popover-body"></div></div>',
        content: create_popover_links
    }

    link.popover(link_popover_options);

    link.on('click', function (e) {
        if (!link.hasClass('disabled')) {
            $(this).popover('toggle');
        }

        return false;

    }).on('show.bs.popover', function () {
        show_backdrop('', false);

    }).on('shown.bs.popover', function() {
        var popover = $('div.popover');
        var popover_id = popover.find('div.popover-div').data('id');
        var task_select = popover.find('select[name="link_task"]').empty();

        var row = table.find('tbody[data-index="' + popover_id + '"]');

        table.find('tbody').each( function () {
            if ( $(this).data('index') !== popover_id ) {
                var task = $(this).find('input.task').val();
                var task_sku = $(this).find('select.sku').val();

                if (task_select.data('selected') !== task )
                    $('<option value="' + task_sku + ':' + task + '">' + task_sku + ':' + task + '</option>').appendTo(task_select);
                else
                    $('<option value="' + task_sku + ':' + task + '" selected>' + task_sku + ':' + task + '</option>').appendTo(task_select);
            }
        });

        // Configure values in the form to what is currently set in the WBS form...
        var link_type    = row.find('input[name$="[link_type]"]').val();
        var link_task    = row.find('input[name$="[link_task]"]').val();
        var link_percent = row.find('input[name$="[link_percent]"]').val();

        // Check the correct radio button
        popover.find('input[name="link_type"]').each( function () {
            if ( $(this).val() === link_type )
                $(this).attr('checked', '');
            else
                $(this).removeAttr('checked');
        });

        // Enable set the correct fields based on the link type
        if ( link_type === LINKED_TO_NONE) {
            popover.find('select[name="link_task"]').attr('disabled', '');
            popover.find('input[name="link_percent"]').attr('disabled', '');
            popover.find('div.percentage-group').hide();

        } else if ( link_type === LINKED_TO_ONE ) {
            popover.find('select[name="link_task"]').removeAttr('disabled').data('selected', link_task).attr('data-selected', link_task);
            popover.find('input[name="link_percent"]').removeAttr('disabled');
            popover.find('select[name="link_task"] option[value="' + link_task + '"]').attr('selected', '');
            popover.find('div.percentage-group').show();

            if ( link_percent.length > 0 ) {
                popover.find('input[name="link_percent"]').val(parseFloat(link_percent, 0) * 100);
            }

        } else {
            popover.find('select[name="link_task"]').attr('disabled', '');
            popover.find('input[name="link_percent"]').removeAttr('disabled');
            popover.find('div.percentage-group').show();

            if ( link_percent.length > 0 ) {
                popover.find('input[name="link_percent"]').val(parseFloat(link_percent, 0) * 100);
            }
        }

        popover.find('input[name="link_type"]').on('change', function () {
            var popover_element = $(this).parents('.popover');

            var selected = popover_element.find('input[name="link_type"]:checked').val();
            if ( selected === LINKED_TO_NONE ) {
                popover_element.find('select[name="link_task"]').attr('disabled', '');
                popover_element.find('input[name="link_percent"]').attr('disabled', '');
                popover_element.find('div.percentage-group').hide();

            } else if (selected === LINKED_TO_ONE) {
                popover_element.find('select[name="link_task"]').removeAttr('disabled');
                popover_element.find('input[name="link_percent"]').removeAttr('disabled');
                popover_element.find('div.percentage-group').show();

            } else if ( selected === LINKED_TO_SKU ) {
                popover_element.find('select[name="link_task"]').attr('disabled', '');
                popover_element.find('input[name="link_percent"]').removeAttr('disabled');
                popover_element.find('div.percentage-group').show();

            } else if (selected === LINKED_TO_ALL) {
                popover_element.find('select[name="link_task"]').attr('disabled', '');
                popover_element.find('input[name="link_percent"]').removeAttr('disabled');
                popover_element.find('div.percentage-group').show();
            }
        });

        // Apply the changes when the update button is pressed...
        popover.find('button.link-update-btn').on('click', function () {
            var popover_element = $(this).parents('.popover');

            var row = table.find('tbody[data-index="' + $(this).data('id') + '"]');
            var link_type = popover_element.find('input[name="link_type"]:checked').val();
            var percentage = popover_element.find('input[name="link_percent"]').val().trim();
            var link_task = popover_element.find('select[name="link_task"]').val().split(':');

            // Clear errors
            popover_element.find('p.validity-check').removeClass('text-danger');
            popover_element.find('.has-error').removeClass('has-error');

            if ( link_type !== LINKED_TO_NONE && ((percentage.length === 0) || !isNumeric(percentage)) ) {
                popover_element.find('input[name="link_percent"]').parents('.form-group').addClass('has-error');

            } else {
                var validity_code = validate_link(table, $(this).data('id'), link_type, link_task[0], link_task[1] );
                if ( validity_code === VALIDITY_INVALID_CIRCULAR ) {
                    popover_element.find('p.circular').addClass('text-danger');
                    return false;
                } else if (validity_code === VALIDITY_INVALID_LINKEDTOALL ) {
                    popover_element.find('p.linked-to-all').addClass('text-danger');
                    return false;
                }

                update_row(row, link_type, parseFloat(percentage)/100.0, link_task);
                update_total_hours(table, row);

                $('a.link-popover[aria-describedby="' + popover_element.attr('id') + '"]').popover('hide');
            }

            return false;
        });

        popover.find('button.link-cancel-btn').on('click', function () {
            var popover_element = $(this).parents('.popover').attr('id');

            $('a.link-popover[aria-describedby="' + popover_element + '"]').popover('hide');
        });
    }).on('hidden.bs.popover', function () {
        hide_backdrop();
    });
}

function delete_row (table, removed_row) {
    var removed_row_task = row_task(removed_row);
    var removed_row_sku  = row_sku(removed_row);
    var qualified_task = removed_row_sku + ':' + removed_row_task;

    // Find any rows linked to the row being removed
    table.find('tbody > tr').each(function () {
        var current_row = $(this);
        if (row_link_type(current_row) == LINKED_TO_ONE) {
            var row_task = row_link_task(current_row);

            if (row_task == qualified_task) {
                remove_link(table, current_row.data('index'));
            }
        }
    });

    removed_row.remove();
}

function update_order (table) {
    let index = 0;

    table.find('tbody').each(function () {
        console.log("Checkng %o: %o", $(this).data('index'), $(this).find('input[type="hidden"][name$="[_destroy]"]').val());

        if ($(this).find('input[type="hidden"][name$="[_destroy]"]').val() !== '1') {
            console.log("Updating %o to %o", $(this).data('index'), index);
            $(this).find('input[type="hidden"][name$="[ordinal]"]').val(index);
            $(this).find('tr:first td:first').text(index + 1);

            index += 1;
        } else {
            $(this).find('tr:first td:first').text('');
        }
    });
}

function update_order_sdt (table) {
    let index = 0;

    table.find('tr').each(function () {
        console.log("Checkng %o: %o", $(this).data('index'), $(this).find('input[type="hidden"][name$="[_destroy]"]').val());

        if ($(this).find('input[type="hidden"][name$="[_destroy]"]').val() !== '1') {
            console.log("Updating %o to %o", $(this).data('index'), index);
            $(this).find('input[type="hidden"][name$="[ordinal]"]').val(index);
            $(this).find('td:first').text(index + 1);

            index += 1;
        } else {
            $(this).find('td:first').text('');
        }
    });
}