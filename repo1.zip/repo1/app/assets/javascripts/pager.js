
var pager_paged_callback = null;

function configure_pager (callback) {
    pager_paged_callback = callback;

    $('li.page-item > a').on('click', function () {
        /*
        show_backdrop();

        $.ajax({
            url: $(this).attr('href'),
            method: 'get',
            dataType: 'script',
            success:function () {
                hide_backdrop();
            },
            error:function () {
                hide_backdrop();
            }
        });

        return false;
        */

        if (pager_paged_callback !== undefined) {
            pager_paged_callback($(this).data('page'), $('#pager-limit').val())
        }

        return false;
    });

    $('#pager-page').blur(function () {
        if (parseInt($(this).val()) > parseInt($(this).data('max-value'))) {
            $(this).val($(this).data('max-value'));
        }

        if (pager_paged_callback !== undefined) {
            pager_paged_callback($('#pager-page').val(), $('#pager-limit').val());
        }
    });

    $('.pager-limit-item').click(function () {
        $('#pager-limit').val($(this).data('value'));
        $('.pager-button').text($(this).data('value'));

        if (pager_paged_callback !== undefined) {
            pager_paged_callback($('#pager-page').val(), $('#pager-limit').val())
        }
    });
}
