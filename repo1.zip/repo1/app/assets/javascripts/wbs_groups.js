// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
//= require jquery-ui/widgets/sortable
//= require select2-full
//= require lineitem_support

const LINKED_TO_NONE_TYPE    = 0;
const LINKED_TO_TASK_TYPE    = 1;
const LINKED_TO_ALL_SKU_TYPE = 2;
const LINKED_TO_ALL_TYPE     = 3;

$(document).on('turbolinks:load', function() {
    $('a.link-popover').each(function () {
        configure_popover($('#group-line-table'), $(this));
    });

    let table = $('#group-line-table');

    // Make the rows in the WBS editor sortable
    table.sortable({
        handle: '.sort-handle',
        placeholder: 'sort-placeholder',
        cursor: "move",
        revert: true,
        helper: function (e, ui) {
            let lcat_select = ui.find('select[name$="[gsa_labor_category_id]"]')
            let sku = ui.find('select[name$="[sku]"]').val();
            let task = ui.find('input[name$="[task]"]').val();
            let lcat = lcat_select.find('option[value="' + lcat_select.val() + '"]').text();

            return '<div class="sort-helper">' +
                '<div class="header">' + sku + '</div>' +
                '<div class="body">' +
                '<div class="float-right">' + lcat + '</div>' +
                '<div class=>' + task + '</div>' +
                '</div>' +
                '</div>';
        },
        update: function (event, ui) {
            var table = $(this);

            $(this).find('tbody').each(function (i) {
                var index = $(this).data('index');

                $(this).find('input[type="hidden"][name="wbs_group[wbs_group_lines_attributes][' + index + '][ordinal]"]').val(i);
                $(this).find('tr:first').find('td:first').text(i+1);
            });
        }
    });

    table.on('focus', 'input[name$="[total_hours]"]', function () {
        $(this).data('current-value', $(this).val());
    }).on('blur', 'input[name$="[total_hours]"]', function () {
        var row = $(this).parents('tr').first();
        var index = row.data('index');

        // If the value has changed, break the link
        if ( $(this).val() != $(this).data('current-value')) {
            remove_link($('#group-line-table'), index);
        }

        update_total_hours(table, row);
    });

    table.on('change', 'select[name$="[gsa_labor_category_id]"]', function () {
        var row = $(this).parents('tr').first();
        let alerttd = $(this).parents('tbody').children('tr').last().children('td').last();
        let selectedText = $(this).children("option:selected").text()
        if (selectedText === "GuidePoint SOAR Services-Standard" ||
            selectedText === "GuidePoint SOAR Services-Remote" ||
            selectedText === "GuidePoint SOAR Services-Premium" ||
            selectedText === "GuidePoint Splunk Services-Standard" ||
            selectedText === "GuidePoint Splunk Services-Remote" ||
            selectedText === "GuidePoint Splunk Services-Premium" ||
            selectedText === "GuidePoint F5 Networks Services-Standard" ||
            selectedText === "GuidePoint F5 Networks Services-Remote" ||
            selectedText === "GuidePoint F5 Networks Services-Premium") {
            alerttd.html("This Labor Category has a daily rate.<br>Please ensure you enter number of days in the 'Total Hours' field for this row.<br>Billable Hourly Rate and Internal Hourly Rate columns will list the daily rates for this Labor Category.");
            alerttd.css("border", "2px solid red");
            alerttd.css("font-weight", "bold");
        } else {
            alerttd.html("");
            alerttd.css( "border", "" );
        }
        $.ajax({
            url: '/gsa_labor_categories/' + $(this).val(),
            method: "GET",
            dataType: "json",
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function (response, status, jqXHR) {
                row.find('input.billable-rate').val(response.revenue);
                row.find('input.internal-rate').val(response.cost);
            }
        });

        update_total_hours($('#group-line-table'), row);
    });

    table.on('blur', 'input[name$="[task]"]', function () {
        var row = $(this).parents('tr');

        update_total_hours($('#group-line-table'), row);
    });

    // Highlight/Unhighlight linked rows on mouse moves
    configure_highlighter( $('#group-line-table > tbody') );

    // Show modal dialog asking if removal of project structure should be forced
    $('#remove-project-structure-modal').on('show.bs.modal', function () {
        $('span.ps-title').text($(this).data('practice').name);
    });

    // When requested remove line items associated with the project structure being removed
    $('#force-remove').on('click', function () {
        var modal = $('#remove-project-structure-modal');
        var practice = modal.data('practice');
        // Check each line item for a match with the project structure's prefixes
        $('select.sku').each(function () {
            var current_select = $(this);
            var current_value  = current_select.val();
            var current_row    = current_select.parents('tbody');
            var row_index          = current_row.data('index');

            $.each(practice.skus, function (index, sku) {
                if (current_value === sku['Name']) {
                    $('input[name="wbs_group[wbs_group_lines_attributes][' + row_index + '][_destroy]"]').val(1);
                    current_row.remove();
                }
            });
        });

        removeProjectStructure(practice.id, practice.name);
        modal.modal('hide');
    });

    var practices_selection = $('select[name="wbs_group[practice_ids][]"]');

    // Configure the project structure select element to use the select2 widget
    practices_selection.select2({
        theme: 'bootstrap4',
        closeOnSelect: true

    // Prevent showing of the dropdown if we are deselecting...usually be clicking on the X in the tag.
    }).on('select2:opening', function (e) {
      if (practices_selection.data('unselecting')) {
          practices_selection.removeData('unselecting');
          e.preventDefault();
          return false;
      }

    // Need to adjust the z-index of the dropdown to appear behind the modal if present
    }).on('select2:open', function (e) {
        $('body').find('.select2-dropdown').css('z-index', 1039);

    // Perform necessary updates when a project structure is added
    }).on('select2:select', function (e) {
        var data = e.params.data;

        $('#practice-spinner').show();

        $.ajax({
            url:'/wbs_groups/practices',
            method:'get',
            dataType:'script',
            data: {
                practices: practices_selection.val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success:function () {
                $('a.mgmt-new-entry').removeClass('disabled');
                $('#practice-spinner').hide();
            },
            error: function () {
                $('#practice-spinner').hide();
            }
        });

    // Determine if there are any entries that use this project structure and prevent the unselect if there are...
    }).on('select2:unselecting', function (e) {
        var selected_id = e.params.args.data.id;
        var selected_text = e.params.args.data.text;

        practices_selection.data('unselecting', true);
        $('#practice-spinner').show();

        $.ajax({
            url: '/practices/' + selected_id + '/skus',
            method:'GET',
            dataType:'json',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function (response, status, jqXHR) {
                var removeable = true;

                $.each(response.skus, function (i, sku) {
                    $('select.sku').each(function () {
                        if ($(this).val() === sku['Name']) {
                            removeable = false;
                        }
                    });
                });

                if (removeable) {
                    removeProjectStructure(selected_id, selected_text);
                    practices_selection.select2('close');
                } else {
                    $('#remove-project-structure-modal').data('practice', response).modal('show');
                }

                $('#practice-spinner').hide();
            },
            error: function () {
                $('#practice-spinner').hide();
            }
        });

        e.preventDefault();
        return false;

    });

    $('select.sku').select2({
        theme: 'bootstrap4',
        minimumResultsForSearch: 10,
        templateResult: formatSKUItem
    }).on('select2:select', function (e) {
        var data = e.params.data;
        var form = $('#group-management-form');
        var row = $(this).parents('tbody');
        var gsa_id = row.find('select[name$="[gsa_labor_category_id]"]');

        $.ajax({
            url: form.attr('action') + '/line_item/' + row.data('index') + '/sku/' + gsa_id.val(),
            method: 'GET',
            dataType: 'script',
            data: {
                sku: data.id
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            }
        });

        update_total_hours($('#group-line-table'), row);
    });

    // Request for new line item...
    $('a.mgmt-new-entry').on('click', function () {
        if (!$(this).hasClass('disabled')) {
            var last_row = $('#group-line-table').find('tbody:last');
            var last_sku = '';
            if (last_row) {
                last_sku = last_row.find('select[name$="[sku]"]').val();
            }

            $.ajax({
                url: $(this).attr('href'),
                method: 'GET',
                dataType: 'script',
                data: {
                    practices: $('select[name="wbs_group[practice_ids][]"]').val(),
                    sku: last_sku
                },
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
                },
                success: function () {
                    console.log('trying to add click function',$('#group-line-table').find('tbody:last').find('input.selected'));
                    $('#group-line-table').find('tbody:last').find('input.selected').on('click', function() {
                        var table = $(this).parents('table');
                        var row = $(this).parents('tbody');

                        if ( $(this).is(':checked') ) {
                            console.log('here');
                            row.addClass('selected');
                            row.find('input[name$="[_destroy]"]').val(1);

                            if (table.find('tbody.selected').length == table.find('tbody').length) {
                                $('#mark-all').find('i').removeClass('far').addClass('fas');
                                $('#mark-all').attr('data-original-title', 'Unmark All').tooltip('hide');
                            } else {
                                $('#mark-all').find('i').removeClass('fas').addClass('far');
                                $('#mark-all').attr('data-original-title', 'Mark All').tooltip('hide');
                            }

                        } else {
                            console.log('here2');
                            row.removeClass('selected');
                            row.find('input[name$="[_destroy]"]').val(0);

                            $('#mark-all').find('i').removeClass('fas').addClass('far');
                            $('#mark-all').attr('data-original-title', 'Mark All').tooltip('hide');
                            console.log('setting mark all');
                        }

                        update_total_hours($('#group-line-table'), row);
                    });
                }
            });
        }

        return false;
    });

    $('input.selected').on('click', function () {
        var table = $(this).parents('table');
        var row = $(this).parents('tbody');

        if ( $(this).is(':checked') ) {
            console.log('here');
            row.addClass('selected');
            row.find('input[name$="[_destroy]"]').val(1);

            if (table.find('tbody.selected').length == table.find('tbody').length) {
                $('#mark-all').find('i').removeClass('far').addClass('fas');
                $('#mark-all').attr('data-original-title', 'Unmark All').tooltip('hide');
            } else {
                $('#mark-all').find('i').removeClass('fas').addClass('far');
                $('#mark-all').attr('data-original-title', 'Mark All').tooltip('hide');
            }

        } else {
            console.log('here2');
            row.removeClass('selected');
            row.find('input[name$="[_destroy]"]').val(0);

            $('#mark-all').find('i').removeClass('fas').addClass('far');
            $('#mark-all').attr('data-original-title', 'Mark All').tooltip('hide');
            console.log('setting mark all');
        }

        update_total_hours($('#group-line-table'), row);
    });

    // Submit the WBS form
    $('#wbs-group-submit').on('click', function () {
        $('#group-management-form').submit();
        return false;
    });

    if ($('.alert').length > 0) {
        setTimeout(function () { $('.alert').hide() }, 3000);
    }

    adjust_display();
});

// Function used by the select2 widget to add the SKU descriptions to the select options
function formatSKUItem (sku) {
    if (!sku.id) {
        return sku.text;
    }

    var $item = $(
        '<div>' +
        sku.text + '<br/>' +
        '<span style="font-size:12px;font-style:italic">' + $(sku.element).data('description') + '</span>' +
        '</div>'
    );

    return $item;
}

// Perform the necessary updates when a project structure is removed.
function removeProjectStructure(id, name) {
    var select = $('select[name="wbs_group[practice_ids][]"]');
    var selected = select.val();

    var indexOf = $.inArray(id + "", selected);
    if (indexOf >= 0) {
        selected.splice($.inArray(id + "", selected), 1);
        select.val(selected).change();

        $.ajax({
            url:'/wbs_groups/practices',
            method:'get',
            dataType:'script',
            data: {
                practices: select.val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            }
        });
    }

    if (select.val().length === 0) {
        $('a.mgmt-new-entry').addClass('disabled');
    }
}

function adjust_display () {
    let line_top = 25;

    let toplevels = $('.wbs-line-detail[data-linked-to=""]');

    toplevels.each( function () {
        line_top = adjust_line_display($(this), line_top, 0);
    });

    $('#template-col').css({
        height: line_top
    });
}

function adjust_line_display (line, top, depth) {
    let link_type = line.data('link-type');

    line.css({
        top: top,
        left: depth * 200 + 25
    });

    if (link_type === LINKED_TO_TASK_TYPE) {
        let connector = $('<div class="connector d-flex" data-link-from="' + line.data('id') + '" data-link-to="' + line.data('linked-to') + '"></div>');
        let linked_to = $('.wbs-line-detail[data-id="' + line.data('linked-to') + '"]');
        let position = linked_to.position();

        let connector_top = position.top + linked_to.outerHeight();

        connector.css({
            top: connector_top,
            left: position.left + 25,
            height: top - connector_top + line.outerHeight() / 2.0,
            width: line.position().left - (position.left + 25)
        });

        connector.appendTo($('#template-col'));
        connector.append('<i class="fas fa-arrow-up" style="margin-left:-8px"></i>');
        connector.append('<div class="align-self-end pr-1" style="margin-left:auto;"><i class="fas fa-arrow-left" style="margin-right:5px"></i>' + line.data('percent') * 100 + '%</div>');

    } else if (link_type === LINKED_TO_ALL_TYPE || link_type === LINKED_TO_ALL_SKU_TYPE) {

    }

    top = top + line.outerHeight() + 25;

    find_linked(line).each(function () {
        top = adjust_line_display($(this), top, depth + 1);
    });

    return top
}

function find_linked (line) {
    return $('.wbs-line-detail[data-linked-to="' + line.data('id') + '"]');
}

function configure_highlighter (item) {
    item.on('mouseenter', function () {
        var row = $(this);
        var link_type = row_link_type(row);

        if (link_type === LINKED_TO_ONE) {
            var link_task = row_link_task(row).split(':');
            var linked_to = find_row($('#group-line-table'), link_task[0], link_task[1]);

            linked_to.addClass('highlight');

        } else if (link_type === LINKED_TO_SKU) {
            var index = row.data('index');
            var sku = row_sku(row);

            $.each(engagement_rows($('#group-line-table'), sku), function (i, row) {
                if ($(this).data('index') !== index) {
                    $(this).addClass('highlight');
                }
            });

        } else if (link_type === LINKED_TO_ALL) {
            var index = row.data('index');

            $.each(engagement_rows($('#group-line-table')), function (i, row) {
                if ($(row).data('index') !== index) {
                    $(row).addClass('highlight');
                }
            });
        }

    }).on('mouseleave', function () {
        var row = $(this);
        var link_type = row_link_type(row);

        if (link_type === LINKED_TO_ONE) {
            var link_task = row_link_task(row).split(':');
            var linked_to = find_row($('#group-line-table'), link_task[0], link_task[1]);

            linked_to.removeClass('highlight');

        } else if (link_type === LINKED_TO_SKU) {
            var index = row.data('index');
            var sku = row_sku(row);

            $.each(engagement_rows($('#group-line-table'), sku), function (i, row) {
                if ($(this).data('index') !== index) {
                    $(this).removeClass('highlight');
                }
            });

        } else if (link_type === LINKED_TO_ALL) {
            var index = row.data('index');

            $.each(engagement_rows($('#group-line-table')), function (i, row) {
                if ($(row).data('index') !== index) {
                    $(row).removeClass('highlight');
                }
            });
        }

    });
}