//= require search

$(document).on('turbolinks:load', function() {
    configure_search(global_search)
});

function global_search () {
    var search_term = $('#search').val();

    if (search_term.length > 0) {
        show_backdrop('Searching for matching records...');
        window.location = "/search?search_for=" + search_term
        /*
        $.ajax({
            url: '/search',
            method: 'GET',
            dataType: 'script',
            data: {
                search_for: search_term
            },
            success: function () {
                hide_backdrop();
            },
            error: function () {
                hide_backdrop();
            }
        });
        */
    } else {
        $('#search-icon').html('<span class="fas fa-search"></span>');
    }

}