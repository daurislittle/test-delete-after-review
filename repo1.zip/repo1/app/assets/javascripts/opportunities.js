// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
//= require search
//= require pager

$(document).on('turbolinks:load', function() {
    $('.opportunity-card').click(function () {
        window.location = 'opportunities/' + $(this).data('id');
    });

    configure_search(update_view);
    configure_pager(update_view);
    configure_table_sortable($('#opp-table'), update_view);

    $('ul.view-selector').on('click', 'li', function () {
        $('ul.view-selector > li.active').removeClass('active');
        $(this).addClass('active');

        //pager_loading();
        update_view($('#pager-page').val(), $('#pager-limit').val());

        return false;
    });

    $('#refresh-link').on('click', function () {
        //pager_loading();
        update_view($('#pager-page').val(), $('#pager-limit').val(), true);

        return false;
    });

    $('#opportunity-refresh-link').on('click', function () {
        show_backdrop('Requesting Opportunity from Salesforce...');

        $.ajax({
            url: $(this).attr('href'),
            method: $(this).data('method'),
            dataType: 'script',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                hide_backdrop();
            },
            error: function () {
                hide_backdrop();
            }
        })

        return false;
    });

    $('a.create-from-quote').on('click', function () {
        show_backdrop('Creating WBS from Salesforce quote...', true)

        $.ajax({
            url: $(this).attr('href'),
            method: 'post',
            data: {
                authenticity_token: $('meta[name="csrf-token"]').attr( 'content' )
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            }
        });

        return false;
    });

    if ($('ul.view-selector > li.active').data('view') == 'table') {
        $('#page-content-wrapper').addClass('tabular');
    } else {
        $('#page-content-wrapper').removeClass('tabular');
    }
});

function update_view (page, per_page, refresh) {
    refresh = refresh || false;

    var table = $('#opp-table');
    var sort_by = table.data('sort-by');
    var sort_direction = table.data('sort-direction');

    show_backdrop('Requesting Opportunities from Salesforce...');

    $.ajax({
        url: '/opportunities',
        method: 'GET',
        dataType: 'script',
        data: {
            page: page,
            per_page: per_page,
            view: $('ul.view-selector > li.active').data('view'),
            search_for: $('#search').val(),
            sort_by: sort_by,
            sort_direction: sort_direction,
            refresh: refresh
        },
        beforeSend: function(xhr) {
            xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
        },
        success: function () {
            hide_backdrop();
        },
        error: function () {
            hide_backdrop();
        }
    });
}