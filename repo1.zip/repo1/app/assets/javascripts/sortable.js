function configure_table_sortable (table, callback) {
    var sort_by = table.data('sort-by');
    var sort_direction = table.data('sort-direction');

    table.find('thead > tr > th[data-sort-key]').each( function () {
        var sort_key = $(this).data('sort-key');

        if (sort_key !== sort_by) {
            $(this).append('<i class="fas fa-sort" style="float:right;"></i>').on('click', function () {
                on_sortable_click(table, $(this), callback);
            }).css('cursor', 'pointer');
        } else {
            if (sort_direction === 'asc') {
                $(this).append('<i class="fas fa-sort-down" style="float:right;"></i>').on('click', function () {
                    on_sortable_click(table, $(this), callback);
                }).css('cursor', 'pointer');
            } else {
                $(this).append('<i class="fas fa-sort-up" style="float:right;"></i>').on('click', function () {
                    on_sortable_click(table, $(this), callback)
                }).css('cursor', 'pointer');
            }
        }
    });
}

function on_sortable_click (table, sortable, callback) {
    var direction = table.data('sort-direction');
    var current_key = table.data('sort-by');
    var current_sortable = table.find('thead tr th[data-sort-key="' + current_key + '"]');

    if (sortable.data('sort-key') !== current_key) {
        if (current_sortable.length != 0) {
            current_sortable.find('svg').removeClass('fa-sort-up').removeClass('fa-sort-down').addClass('fa-sort');
        }

        table.data('sort-by', sortable.data('sort-key'));
        table.data('sort-direction', 'asc').attr('data-sort-direction', 'asc');
        sortable.find('svg').removeClass('fa-sort').addClass('fa-sort-down');

        if (callback) callback(1, $('#pager-limit').val());

    } else if (direction == 'asc') {
        table.data('sort-direction', 'desc').attr('data-sort-direction', 'desc');
        sortable.find('svg').removeClass('fa-sort-down').addClass('fa-sort-up');

        if (callback) callback(1, $('#pager-limit').val());

    } else {
        table.data('sort-direction', 'asc').attr('data-sort-direction', 'asc');
        sortable.find('svg').removeClass('fa-sort-up').addClass('fa-sort-down');

        if (callback) callback(1, $('#pager-limit').val());
    }
}