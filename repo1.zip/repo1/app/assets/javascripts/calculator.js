$(document).on('turbolinks:load', function() {
    var table = $('#wbs-lineitems');

    $('#calc-clear').on('click', function () {
        table.find('tbody.selected').removeClass('selected');
        table.find('tbody.over').removeClass('over');

        $('#total-hours').text('0');
        $('#total-revenue').text('$0.00');
        $('#total-internal').text('$0.00');
        $('#total-profit').text('$0.00');
        $('#total-profit-pct').text('0%');

        return false;
    });

    let calculator = $('#calculator');

    $('#close-calculator').on('click', function () {
        $('#wbs-calculator').trigger('click');
    });

    $('#wbs-calculator').on('click', function () {
        let parent = $(this).parent();

        if (parent.hasClass('calc-link-active')) {
            let table = $('#wbs-lineitems');

            parent.removeClass('calc-link-active');
            table.find('tbody.selected').removeClass('selected');
            table.find('tbody.over').removeClass('over');

            calculator.fadeOut();

        } else {
            parent.addClass('calc-link-active');
            $('#close-calculator').hide();
            $('#calculation-pending').show();

            // Clear the fields
            $('#total-hours').text('0');
            $('#total-revenue').text('$0.00');
            $('#total-internal').text('$0.00');
            $('#total-profit').text('$0.00');
            $('#total-profit-pct').text('0%');

            $('#total-engagement').text(0);
            $('#total-management').text(0);
            $('#percentage').text('0%');

            $.ajax({
                url:'/wbs/' + $('#wbs-content').data('id') + '/calculate',
                method: 'POST',
                dataType: 'json',
                data: {
                    authenticity_token: $("meta[name='csrf-token']").attr("content"),
                    pm: true
                },
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
                },
                success: function (response) {
                    $('#total-engagement').text(response.engagement);
                    $('#total-management').text(response.pm);

                    if (response.engagement > 0) {
                        $('#percentage').text((response.pm / response.engagement * 100).toFixed(1) + '%')
                    } else {
                        $('#percentage').text('100%');
                    }

                    $('#close-calculator').show();
                    $('#calculation-pending').hide();
                }
            });

            calculator.show();
        }
    })

    configure_calculator(table);
});

function configure_calculator (table) {
    table.find('tbody:not(:last)').on('mouseover', function () {
        if ($('#calculator').is(':visible')) {
            $(this).addClass('over');
        }
    }).on('mouseout', function () {
        if ($('#calculator').is(':visible')) {
            $(this).removeClass('over');
        }
    }).on('click', function (e) {
        if ($('#calculator').is(':visible')) {
            if (e.shiftKey) {
                $(this).toggleClass('selected');

            } else {
                table.find('tbody.selected').removeClass('selected');

                $(this).addClass('selected');
            }

            document.getSelection().removeAllRanges();

            $('#close-calculator').hide();
            $('#calculation-pending').show();

            var selected = []
            table.find('tbody.selected').each(function () {
                selected.push($(this).data('id'));
            });

            $.ajax({
                url: '/wbs/' + $('#wbs-content').data('id') + '/calculate',
                method: 'POST',
                dataType: 'json',
                data: {
                    authenticity_token: $("meta[name='csrf-token']").attr("content"),
                    sum: selected
                },
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
                },
                success: function (response) {
                    $('#total-hours').text(response.total_hours.toFixed(2));
                    $('#total-revenue').text('$' + response.total_revenue.toFixed(2));
                    $('#total-internal').text('$' + response.total_internal.toFixed(2));
                    $('#total-profit').text('$' + response.total_profit.toFixed(2));
                    $('#total-profit-pct').text(response.total_profit_pct.toFixed(2) + '%');

                    $('#close-calculator').show();
                    $('#calculation-pending').hide();
                }
            });
        }

        return false;
    });
}
