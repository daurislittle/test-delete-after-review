function configure_editor () {
    var form = $('#wbs-form');

    configure_sfdc_card();
    configure_engagement_card();
    configure_wbs();
    configure_contacts_tab();
    configure_scoping_details_tab();

    $('#selectedMenuButton').tooltip();

    form.find(':input').not('[name="sku_selector"]').not('[name="template_selector"]').on( 'change', function () {
        form.data('changed', true);
    });

    $('[data-toggle="popover"]').popover();

    // Prevent RETURN submitting the form
    $(window).keydown(function(event){
        if ((event.keyCode == 13) && (event.target.type === 'button' || event.target.type === 'submit' || event.target.type === '' || event.target.type === undefined)) {
            event.preventDefault();
            return false;
        }
    });

    // Disable mousewheel on a input number field when in focus (to prevent Chromium browsers from changing
    // the value when scrolling)
    form.on('focus', 'input[type=number]', function (e) {
        $(this).on('mousewheel.disableScroll', function (e) {
            e.preventDefault();
        })
    });

    // Re-enable mouse scroll
    form.on('blur', 'input[type=number]', function (e) {
        $(this).off('mousewheel.disableScroll');
    });

    // Submit the WBS form
    $('#wbs-submit').on('click', function () {
        // Adjust the ordinals
        update_order($('#wbs-line-tbl'));

        form.submit();
        return false;
    });

    $('#wbs-cancel').on('click', function () {
        var url = $(this).attr('href');

        if (form.data('changed')) {
            $('#confirm-cancel').on('shown.bs.modal', function () {
                var yes_button = $(this).find('#yes');

                yes_button.data('url', url);
                yes_button.one('click', function () {
                    window.location = $(this).data('url');
                });
            }).modal('show');

        } else {
            window.location = url; // Force beforeunload to trigger...
        }

        return false;
    });

    $('a.link-popover').each(function () {
        configure_popover($('#wbs-line-tbl'), $(this));
    });

    if ($('#toasts-pane').find('.unpublishable').length > 0) {
        $('#publishability-warnings-link').on('click', function () {
            $('#publishability-warnings-tab').tab('show');
            $("#status-wrapper").addClass("active");

            return false;
        });

        //$('#toasts-tab').tab('show');
        //$("#status-wrapper").addClass("active");
    }

    $('#wbs-line-tbl').find('input.selected[type="checkbox"]').on('click', function () {
        if ($(this).is(':checked')) {
            $(this).parents('tbody').addClass('selected');

        } else {
            $(this).parents('tbody').removeClass('selected');
        }

        if ($('#wbs-line-tbl').find('input.selected[type="checkbox"]:checked').length > 0) {
            $('#selectedMenuButton').removeClass('disabled');
        } else {
            $('#selectedMenuButton').addClass('disabled');
        }
    });

    $('#mark-all').on('click', function () {
        table = $('#wbs-line-tbl');

        var link = $('#mark-all');
        var icon = link.find('i');

        if (icon.hasClass('far')) {
            icon.removeClass('far').addClass('fas');
            link.attr('data-original-title', 'Unmark All').tooltip('hide');

            table.find('tbody').each(function () {
                checkbox = $(this).find('input.selected[type="checkbox"]');
                if (checkbox.length == 1 && !checkbox.is(':checked')) {
                    checkbox.trigger('click');
                }
            });

        } else {
            icon.removeClass('fas').addClass('far');
            link.attr('data-original-title', 'Mark All').tooltip('hide');

            table.find('tbody').each(function () {
                checkbox = $(this).find('input.selected[type="checkbox"]');
                if (checkbox.length == 1 && checkbox.is(':checked')) {
                    checkbox.trigger('click');
                }
            });
        }
    });

    $('#delete-selected').on('click', function () {
        $('#selectedMenuButton').dropdown('hide');
        $('#delete-line_items-modal').modal('show');
    });

    $('#force-delete').on('click', function () {
        $('#wbs-line-tbl tbody').find('input.selected[type="checkbox"]:checked').each(function () {
            let body = $(this).parents('tbody');
            let destroy = body.find('input[type="hidden"][name$="[_destroy]"]');

            if (destroy.val() === '0') {
                destroy.val(1);
                body.addClass('deleted');
            } else {
                destroy.val(0);
                body.removeClass('deleted');
            }
        });

        $('#wbs-line-tbl tbody').find('input.selected[type="checkbox"]:checked').trigger('click');
        $('#mark-all').find('i').removeClass('fas').addClass('far');
        $('#mark-all').attr('data-original-title', 'Mark All').tooltip('hide');
        var modal = $('#delete-line_items-modal');
        modal.modal('hide');
        return false;
    });
}

function configure_sfdc_card () {
    // Configure the opportunity select element to use the select2 widget
    $('select.opp-select').select2({
        theme: 'bootstrap4',
        minimumResultsForSearch: 10,
        placeholder: 'Select Opportunity...',
        ajax: {
            url:'/opportunities',
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    search_for: params.term,
                    page: params.page
                }
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            processResults: function (data, params) {
                params.page = params.page || 1;

                return {
                    results: data.results,
                    pagination: {
                        more: data.pagination.more
                    }
                }
            }
        }
    }).on('select2:select', function (e) {
        var data = e.params.data;

        $('#opp-spinner').show();
        $.ajax({
            url:'/wbs/opportunity',
            method:'get',
            dataType:'script',
            data: {
                id: $('input[type="hidden"][name$="[id]"]').val(),
                opportunity_id: data.id
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            }
        });
    });

    // Show modal dialog asking if removal of project structure should be forced
    $('#remove-project-structure-modal').on('show.bs.modal', function () {
        $('span.ps-title').text($(this).data('practice').name);
    });

    // When requested remove line items associated with the project structure being removed
    $('#force-remove').on('click', function () {
        var modal = $('#remove-project-structure-modal');
        var practice = modal.data('practice');

        // Check each WBS line item for a match with the project structure's prefixes
        $('select.sku').each(function () {
            var current_select = $(this);
            var current_value  = current_select.val();
            var current_row    = current_select.parents('tbody');
            var row_index = current_row.data('index');

            practice.skus.forEach(function(sku) {
                if (current_value === sku['Name']) {
                    var destroy_check = $('input[name="work_breakdown_structure[wbs_entries_attributes][' + row_index + '][_destroy]"]');
                    destroy_check.val(1);
                    destroy_check.appendTo($('form'));
                    current_row.remove();
                }
            });
        });

        // Check each Scoping Detail line item for a match with the project structure's prefixes
        $('select.sd_sku').each(function () {
            var current_select = $(this);
            var current_value  = current_select.val();
            var current_row    = current_select.parents('tr');
            var row_index      = current_row.data('index');

            practice.skus.forEach(function(sku) {
                if (current_value === sku['Id']) {
                    var destroy_check = $('input[name="work_breakdown_structure[scoping_details_attributes][' + row_index + '][_destroy]"]');
                    destroy_check.val(1);
                    destroy_check.appendTo($('form'));
                    current_row.remove();

                    destroy_check = $('input[id="work_breakdown_structure_scoping_details_attributes_' + row_index + '__destroy"]');
                    destroy_check.remove();
                }
            });
        });

        removeProjectStructure(practice.id, practice.name);
        modal.modal('hide');
    });

    var practices_selection = $('select[name="work_breakdown_structure[practice_ids][]"]');

    // Configure the project structure select element to use the select2 widget
    practices_selection.select2({
        minimumResultsForSearch: 10,
        theme: 'bootstrap4'

        // Prevent showing of the dropdown if we are deselecting...
    }).on('select2:opening', function (e) {
        if (practices_selection.data('unselecting')) {
            practices_selection.removeData('unselecting');
            e.preventDefault();
            return false;
        }

        // Need to adjust the z-index of the dropdown to appear behind the modal if present
    }).on('select2:open', function (e) {
        $('body').find('.select2-dropdown').css('z-index', 1039);

    }).on('select2:select', function (e) {
        var data = e.params.data;

        $('#practices-spinner').show();
        $.ajax({
            url:'/wbs/practices',
            method:'get',
            dataType:'script',
            data: {
                practices: practices_selection.val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success:function () {
                $('#practices-spinner').hide();
            },
            error: function () {
                $('#practices-spinner').hide();
            }
        });

    }).on('select2:unselecting', function (e) {
        // Determine if there are any entries that use this project structure and prevent the unselect if there are...
        var selected_id = e.params.args.data.id;
        var selected_text = e.params.args.data.text;

        practices_selection.data('unselecting', true);
        $('#practices-spinner').show();

        $.ajax({
            url: '/practices/' + selected_id + '/skus',
            method:'GET',
            dataType:'json',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function (response, status, jqXHR) {
                var removeable = true;

                response.skus.forEach(function(sku) {
                    $('select.sku').each(function () {
                        if ($(this).val() === sku['Name']) {
                            removeable = false;
                        }
                    });
                });
                response.skus.forEach(function(sku) {
                    $('select.sd_sku').each(function () {
                        if ($(this).val() === sku['Id']) {
                            removeable = false;
                        }
                    });
                });

                if (removeable) {
                    removeProjectStructure(selected_id, selected_text);
                    practices_selection.select2('close');

                } else {
                    $('#remove-project-structure-modal').data('practice', response).modal('show');
                }

                $('#practices-spinner').hide();
            },
            error:function () {
                $('#practices-spinner').hide();
            }
        });

        return false;

    });

    $('select[name="work_breakdown_structure[contract_vehicle]"]').on('change', function () {
        let selector = $(this);
        let parent = selector.parents('.form-group');

        if (!selector.val()) {
            selector.parents('.form-group').addClass('has-error');
            parent.find('p.help-block').text('Please select a contract vehicle.  Select "GuidePoint Direct"" for all direct sales to customers.')

        } else {
            selector.parents('.form-group').removeClass('has-error');
            parent.find('p.help-block').text('Select "GuidePoint Direct"" for all direct sales to customers.')
        }

        // For each row...recompute compliancy
        $('table.lineitem-edit > tbody').each( function () {
            row_compliancy($(this));
        });
    });

    $('select[name="work_breakdown_structure[billing_rule]"]').on('change', function () {
        var selector = $(this);

        if (!selector.val()) {
            selector.parents('.form-group').addClass('has-error');

        } else {
            selector.parents('.form-group').removeClass('has-error');
        }
    });

    $('select[name="work_breakdown_structure[contract_type]"]').on('change', function () {
        var selector = $(this);

        if (!selector.val()) {
            selector.parents('.form-group').addClass('has-error');
            return false;
        }

        selector.parents('.form-group').removeClass('has-error');

        // Retrieve the valid billing rules for the selected contract type.
        $.ajax({
            url:'/wbs/' + 'contract_type',
            method:'GET',
            dataType:'script',
            data: {
                billing_rule:$('select[name="work_breakdown_structure[billing_rule]"]').val(),
                contract_type:$(this).val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            error: function (jqXHR, textStatus, errorThrown) {
                selector.parents('.form-group').addClass('has-error');
            }
        });
    });

    $('select[name="work_breakdown_structure[billing_rule]"]').on('change', function () {
        if ($(this).val() === 'Contract Term Period') {
            $('#contract-term-group').show();
        } else {
            $('#contract-term-group').hide();
        }
    });

    $('select[name="work_breakdown_structure[project_structure]"]').on('change', function () {
        var selector = $(this);

        if (!selector.val()) {
            selector.parents('.form-group').addClass('has-error');

        } else {
            selector.parents('.form-group').removeClass('has-error');
        }
    });
}

function configure_engagement_card () {
    // Configure the requested project manager select element to use the select2 widget
    $('select[name="work_breakdown_structure[project_manager_id]"]').select2({
        minimumResultsForSearch: 10,
        theme:'bootstrap4'
    });

    // Configure the Scoped By select element to use the select2 widget
    $('#work_breakdown_structure_scoped_by_id').select2({
        minimumResultsForSearch: 10,
        theme: 'bootstrap4'
    });
}

function configure_wbs () {
    const MAX_CHAR_LENGTH = 255;

    var table = $('#wbs-line-tbl');
    var body = table.find('tbody');

    $('textarea.notes-field').on('input', function () {
        let char_count = $(this).val().length
        $(this).next().text('Characters: ' + char_count + '/' + MAX_CHAR_LENGTH);

        if (char_count > MAX_CHAR_LENGTH) {
            $(this).parents('tr').addClass('error');
        } else {
            $(this).parents('tr').removeClass('error');
        }
    });

    table.sortable({
        cursor: "move",
        revert: true,
        handle: '.sort-handle',
        placeholder: 'sort-placeholder',
        containment:table.parent(),
        scrollSpeed:10,
        scrollSensitivity: 30,
        helper: function (e, ui) {
            let lcat_select = ui.find('select[name$="[gsa_labor_category_id]"]')
            let sku = ui.find('select[name$="[sku]"]').val();
            let task = ui.find('input[name$="[task]"]').val();
            let lcat = lcat_select.find('option[value="' + lcat_select.val() + '"]').text();

            return '<div class="sort-helper">' +
                '<div class="header">' + sku + '</div>' +
                '<div class="body">' +
                '<div class="float-right">' + lcat + '</div>' +
                '<div class=>' + task + '</div>' +
                '</div>' +
                '</div>';
        },
        update: function (event, ui) {
            update_order($(this));
        }
    });

    body.each(function () {
        configure_lineitem_callbacks($(this));
    });

    // Configure the WBS template select element to use the select2 widget
    $('#template-selector').select2({
        theme:'bootstrap4',
        minimumResultsForSearch: 10,
        width:'100%'
    });

    // Configure the main SKU selector select element to use the select2 widget
    $('select[name="sku_selector"]').select2({
        theme:'bootstrap4',
        minimumResultsForSearch: 10,
        width:'100%',
        templateResult: formatSKUItem
    });

    // When the add line item button is clicked...
    $('#add-wbs-line').on('click', function () {
        if ($('select[name="sku_selector"] option').length == 0) {
            alert("You must add at least one project structure first.");
            return false;
        }

        $('#adding-message').show();

        $.ajax({
            url: '/wbs/add_line',
            method: "GET",
            dataType:"script",
            data: {
                sku: $('select[name="sku_selector"]').val(),
                practices:$('select[name="work_breakdown_structure[practice_ids][]"]').val(),
                region: $('input[name$="[region]"]').val(),
                contract_vehicle:$('select[name$="[contract_vehicle]"]').val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                $('#adding-message').hide();
            },
            error: function () {
                $('#adding-message').hide();
            }
        });

        return false;
    });

    // When the add line item button is clicked...
    $('#add-sd-line').on('click', function () {
        if (!($('select[name="sku_sd_selector"]').val())) {
            return false;
        }

        $('#adding-sd-message').show();

        $.ajax({
            url: '/wbs/add_detail',
            method: "GET",
            dataType:"script",
            data: {
                sku: $('select[name="sku_sd_selector"]').val(),
                practices: $('select[name="work_breakdown_structure[practice_ids][]"]').val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                $('#adding-sd-message').hide();
            },
            error: function () {
                $('#adding-sd-message').hide();
            }
        });

        return false;
    });

    // When the add template button is clicked...
    $('#add-wbs-template').on('click', function () {
        if ($('select[name="template_selector"] option').length == 0) {
            alert("You must add at least one project structure that has a template defined for it.");
            return false;
        }

        $('#adding-message').show();

        $.ajax({
            url: '/wbs/add_group',
            method: "GET",
            dataType:"script",
            data: {
                group: $('select[name="template_selector"]').val(),
                practices:$('select[name="work_breakdown_structure[practice_ids][]"]').val(),
                region: $('input[name$="[region]"]').val(),
                contract_vehicle:$('select[name$="[contract_vehicle]"]').val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                $('#adding-message').hide();
            },
            error: function () {
                $('#adding-message').hide();
            }
        });

        return false;
    });

    $('#new-group-link').on('click', function () {
        if ($('#wbs-line-tbl tbody[data-index]').length == 0) {
            alert("Your WBS must include at least one line item.");
            return false;
        }

        $.ajax({
            url: $(this).attr('href'),
            method: 'GET',
            dataType: 'script',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            }
        });

        return false;
    });

    $('#group-dropdown > li > a').on('click', function () {
        $('button.group-select-btn').find('span.btn-select-text').text($(this).text());
        $('button.group-select-btn').data('value', $(this).data('value'));
    });
}

function configure_contacts_tab () {
    $('select[name$="[billing_address_attributes][kind]"]').on('change',function () {
        var which = $(this).val();

        if (which === 'other') {
            $('input[name$="[billing_address_attributes][address1]"]').prop('disabled', false).val('');
            $('input[name$="[billing_address_attributes][address2]"]').prop('disabled', false).val('');
            $('input[name$="[billing_address_attributes][city]"]').prop('disabled', false).val('');
            $('input[name$="[billing_address_attributes][state]"]').prop('disabled', false).val('');
            $('input[name$="[billing_address_attributes][postalcode]"]').prop('disabled', false).val('');
            $('input[name$="[billing_address_attributes][country]"]').prop('disabled', false).val('');

        } else {
            $('#billing-address-active').show();

            $.ajax({
                url: '/accounts/' + $('input[name="account_id"][type="hidden"]').val() + '/address',
                method: 'get',
                dataType: 'json',
                data: {
                    which: which
                },
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
                },
                success: function (response) {
                    $(':hidden[name$="[billing_address_attributes][address1]"]').val(response.address1);
                    $(':hidden[name$="[billing_address_attributes][address2]"]').val(response.address2);
                    $(':hidden[name$="[billing_address_attributes][city]"]').val(response.city);
                    $(':hidden[name$="[billing_address_attributes][state]"]').val(response.state);
                    $(':hidden[name$="[billing_address_attributes][postalcode]"]').val(response.zipcode);
                    $(':hidden[name$="[billing_address_attributes][country]"]').val(response.country);

                    $('input[name$="[billing_address_attributes][address1]"]:not(:hidden)').prop('disabled', true).val(response.address1);
                    $('input[name$="[billing_address_attributes][address2]"]:not(:hidden)').prop('disabled', true).val(response.address2);
                    $('input[name$="[billing_address_attributes][city]"]:not(:hidden)').prop('disabled', true).val(response.city);
                    $('input[name$="[billing_address_attributes][state]"]:not(:hidden)').prop('disabled', true).val(response.state);
                    $('input[name$="[billing_address_attributes][postalcode]"]:not(:hidden)').prop('disabled', true).val(response.zipcode);
                    $('input[name$="[billing_address_attributes][country]"]:not(:hidden)').prop('disabled', true).val(response.country);

                    $('#billing-address-active').hide();
                },
                error: function () {
                    $('#billing-address-active').hide();
                }
            });
        }
    });

    // Configure the GPS primary contact select element to use the select2 widget
    var gps_primary = $('[name="work_breakdown_structure[gps_primary_contact_id]"]').select2({
        minimumResultsForSearch: 10,
        theme:'bootstrap4'
    }).on('select2:select', function(e) {
        if ($(this).val() !== undefined && $(this).val() !== null && $(this).val().length > 0) {
            $.ajax({
                url: '/contacts/' + $(this).val(),
                method: "GET",
                dataType: "json",
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
                },
                success: function (response, responseText, jqXHR) {
                    if (response.contact.Title && response.contact.Title.length > 0)
                        $('#gps-primary-title').text(response.contact.Title);
                    else
                        $('#gps-primary-title').text("NA")

                    if (response.contact.Phone && response.contact.Phone.length > 0)
                        $('#gps-primary-phone').text(response.contact.Phone);
                    else
                        $('#gps-primary-phone').text("NA")

                    if (response.contact.Email && response.contact.Email.length > 0)
                        $('#gps-primary-email').text(response.contact.Email);
                    else
                        $('#gps-primary-email').text("NA")
                }
            });
        } else {
            $('#gps-primary-title').text("NA");
            $('#gps-primary-phone').text("NA");
            $('#gps-primary-email').text("NA");
        }
    });

    // Configure the GPS secondary contact select element to use the select2 widget
    $('[name="work_breakdown_structure[gps_secondary_contact_id]"]').select2({
        minimumResultsForSearch: 10,
        theme:'bootstrap4'
    }).on('select2:select', function(e) {
        if ($(this).val().length > 0) {
            $.ajax({
                url: '/contacts/' + $(this).val(),
                method: "GET",
                dataType: "json",
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
                },
                success: function (response, responseText, jqXHR) {
                    if (response.contact.Title && response.contact.Title.length > 0)
                        $('#gps-secondary-title').text(response.contact.Title);
                    else
                        $('#gps-secondary-title').text("NA")

                    if (response.contact.Phone && response.contact.Phone.length > 0)
                        $('#gps-secondary-phone').text(response.contact.Phone);
                    else
                        $('#gps-secondary-phone').text("NA")

                    if (response.contact.Email && response.contact.Email.length > 0)
                        $('#gps-secondary-email').text(response.contact.Email);
                    else
                        $('#gps-secondary-email').text("NA")
                }
            });
        } else {
            $('#gps-secondary-title').text("NA");
            $('#gps-secondary-phone').text("NA");
            $('#gps-secondary-email').text("NA");
        }
    });

    // Configure the Client primary contact select element
    $('[name="work_breakdown_structure[acct_primary_contact_id]"]').on('change', function () {
        if ($(this).val().length == 0) {
            $('#client-primary-title').text("NA");
            $('#client-primary-phone').text("NA");
            $('#client-primary-email').text("NA");

            $('input[name="work_breakdown_structure[extra][primary_contact][name]"]').hide();
            $('#client-primary-title').show();
            $('input[name="work_breakdown_structure[extra][primary_contact][title]"]').hide();
            $('#client-primary-phone').show();
            $('input[name="work_breakdown_structure[extra][primary_contact][phone]"]').hide();
            $('#client-primary-email').show();
            $('input[name="work_breakdown_structure[extra][primary_contact][email]"]').hide();

        } else if ($(this).val() == 'not-listed') {
            $('input[name="work_breakdown_structure[extra][primary_contact][name]"]').show();
            $('#client-primary-title').hide();
            $('input[name="work_breakdown_structure[extra][primary_contact][title]"]').show();
            $('#client-primary-phone').hide();
            $('input[name="work_breakdown_structure[extra][primary_contact][phone]"]').show();
            $('#client-primary-email').hide();
            $('input[name="work_breakdown_structure[extra][primary_contact][email]"]').show();

        } else {
            $('#client-contact-spinner').show();

            $('input[name="work_breakdown_structure[extra][primary_contact][name]"]').hide();
            $('#client-primary-title').show();
            $('input[name="work_breakdown_structure[extra][primary_contact][title]"]').hide();
            $('#client-primary-phone').show();
            $('input[name="work_breakdown_structure[extra][primary_contact][phone]"]').hide();
            $('#client-primary-email').show();
            $('input[name="work_breakdown_structure[extra][primary_contact][email]"]').hide();

            $.ajax({
                url: '/contacts/' + $(this).val(),
                method: "GET",
                dataType: "json",
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
                },
                success: function (response, responseText, jqXHR) {
                    if (response.contact.Title && response.contact.Title.length > 0)
                        $('#client-primary-title').text(response.contact.Title);
                    else
                        $('#client-primary-title').text("NA")

                    if (response.contact.Phone && response.contact.Phone.length > 0)
                        $('#client-primary-phone').text(response.contact.Phone);
                    else
                        $('#client-primary-phone').text("NA")

                    if (response.contact.Email && response.contact.Email.length > 0)
                        $('#client-primary-email').text(response.contact.Email);
                    else
                        $('#client-primary-email').text("NA")

                    $('#client-contact-spinner').hide();
                }
            });
        }
    });

    // Configure the client secondary contact select element
    $('[name="work_breakdown_structure[acct_secondary_contact_id]"]').on('change', function () {
        if ($(this).val().length == 0) {
            $('#client-secondary-title').text("NA");
            $('#client-secondary-phone').text("NA");
            $('#client-secondary-email').text("NA");

            $('input[name="work_breakdown_structure[extra][secondary_contact][name]"]').hide();
            $('#client-secondary-title').show();
            $('input[name="work_breakdown_structure[extra][secondary_contact][title]"]').hide();
            $('#client-secondary-phone').show();
            $('input[name="work_breakdown_structure[extra][secondary_contact][phone]"]').hide();
            $('#client-secondary-email').show();
            $('input[name="work_breakdown_structure[extra][secondary_contact][email]"]').hide();

        } else if ($(this).val() == 'not-listed') {
            $('input[name="work_breakdown_structure[extra][secondary_contact][name]"]').show();
            $('#client-secondary-title').hide();
            $('input[name="work_breakdown_structure[extra][secondary_contact][title]"]').show();
            $('#client-secondary-phone').hide();
            $('input[name="work_breakdown_structure[extra][secondary_contact][phone]"]').show();
            $('#client-secondary-email').hide();
            $('input[name="work_breakdown_structure[extra][secondary_contact][email]"]').show();

        } else {
            $('#client-contact-spinner').show();

            $('input[name="work_breakdown_structure[extra][secondary_contact][name]"]').hide();
            $('#client-secondary-title').show();
            $('input[name="work_breakdown_structure[extra][secondary_contact][title]"]').hide();
            $('#client-secondary-phone').show();
            $('input[name="work_breakdown_structure[extra][secondary_contact][phone]"]').hide();
            $('#client-secondary-email').show();
            $('input[name="work_breakdown_structure[extra][secondary_contact][email]"]').hide();

            $.ajax({
                url: '/contacts/' + $(this).val(),
                method: "GET",
                dataType: "json",
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
                },
                success: function (response, responseText, jqXHR) {
                    if (response.contact.Title && response.contact.Title.length > 0)
                        $('#client-secondary-title').text(response.contact.Title);
                    else
                        $('#client-secondary-title').text("NA")

                    if (response.contact.Phone && response.contact.Phone.length > 0)
                        $('#client-secondary-phone').text(response.contact.Phone);
                    else
                        $('#client-secondary-phone').text("NA")

                    if (response.contact.Email && response.contact.Email.length > 0)
                        $('#client-secondary-email').text(response.contact.Email);
                    else
                        $('#client-secondary-email').text("NA")

                    $('#client-contact-spinner').hide();
                }
            });
        }
    });
}

function configure_scoping_details_tab () {
    // Configure the Scoping Detail template select element to use the select2 widget
    $('#sd-template-selector').select2({
        theme:'bootstrap4',
        minimumResultsForSearch: 10,
        width:'100%'
    });

    $('select[name^="work_breakdown_structure[scoping_details_attributes]"][name$="[sku_id]"]').select2({
        theme: 'bootstrap4',
        minimumResultsForSearch: 10,
        width:'100%',
        templateResult: formatSKUItem
    });

    // Mark existing scoping detail row for deletion
    $(document).on('click', '.delete-detail', function () {
        var table = $('#scoping-detail-table tbody');
        var row = $(this).parents('tr').first();

        if ($(this).is(":checked")) {
            row.addClass('deleted');

            if (table.find('tr.deleted').length == table.find('tr').length) {
                $(this).attr('data-original-title', 'Unmark All');
                $('#toggle-all-sdt i').removeClass('far').addClass('fas');
            }

        } else {
            row.removeClass('deleted');

            $(this).attr('data-original-title', 'Mark All');
            $('#toggle-all-sdt i').removeClass('fas').addClass('far');
        }

        update_scoping_order(table.parent());
    });

    $('#toggle-all-sdt').on('click', function () {
        let table = $('#scoping-detail-table tbody');
        let icon = $(this).find('i');

        if (icon.hasClass('far')) {
            table.find('tr').each(function () {
                $(this).find('input[name$="[_destroy]"][type="checkbox"]').prop('checked', true);
                $(this).addClass('deleted');
            });

            $(this).attr('data-original-title', 'Unmark All');
            icon.removeClass('far').addClass('fas');
        } else {
            table.find('tr').each(function () {
                $(this).find('input[name$="[_destroy]"][type="checkbox"]').prop('checked', false);
                $(this).removeClass('deleted');
            });

            $(this).attr('data-original-title', 'Mark All');
            icon.removeClass('fas').addClass('far');
        }

        $(this).tooltip('hide');

        return false;
    });

    $('a.new-scope-detail').on('click', function () {
        let table = $('#scoping-detail-table');
        let last_sku = '';
        let last_sku_element = table.find('tr:last').find('select[name$="[sku_id]"]');

        if (last_sku_element.length > 0) {
            last_sku = last_sku_element.val();
        }

        $('#sdt-spinner').removeClass('d-none');

        $.ajax({
            url: $(this).attr('href'),
            method:'GET',
            dataType:'script',
            data: {
                practices: $('select[name="work_breakdown_structure[practice_ids][]"]').val(),
                sku: last_sku
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                update_scoping_order(table);
                $('#sdt-spinner').addClass('d-none');
            },
            error: function () {
                update_scoping_order(table);
                $('#sdt-spinner').addClass('d-none');
            }
        });

        return false;
    });

    // When the Scoping Detail template insert button is clicked
    $('#insert-template').on('click', function () {
        $('#sdt-spinner').removeClass('d-none');

        $.ajax({
            url: $(this).attr('href'),
            method:'GET',
            dataType: 'script',
            data: {
                sd_template: $('#sd-template-selector').val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function () {
                update_scoping_order($('#scoping-detail-table'));
                $('#sdt-spinner').addClass('d-none');
            },
            error: function () {
                update_scoping_order($('#scoping-detail-table'));
                $('#sdt-spinner').addClass('d-none');
            }
        });

        return false;
    });

    let table = $('#scoping-detail-table');

    table.find('tbody').sortable({
        cursor: "move",
        revert: true,
        handle: '.sort-handle',
        placeholder: 'sort-placeholder',
        containment: table,
        scrollSpeed: 10,
        scrollSensitivity: 30,
        helper: function (e, ui) {
            let sku = ui.find('select[name$="[sku_id]"] option:selected').text();
            let item = ui.find('input[name$="[item]"]').val();
            let value = ui.find('textarea[name$="[value]"]').val();

            return '<div class="sort-helper">' +
                '<div class="header">' + sku + '</div>' +
                '<div class="body">' +
                '<div class="float-right">' + value + '</div>' +
                '<div class=>' + item + '</div>' +
                '</div>' +
                '</div>';
        },
        update: function (event, ui) {
            update_scoping_order($(this).parent());
        }
    })
}

function update_scoping_order (table) {
    let index = 0;

    table.find('tbody tr').each(function () {
        if (!$(this).find('input[type="checkbox"][name$="[_destroy]"]').is(':checked')) {
            $(this).find('input[type="hidden"][name$="[ordinal]"]').val(index);
            $(this).find('td:first').text(index + 1);

            index += 1;

        } else {
            $(this).find('td:first').text('');
        }
    });
}

function configure_sortable (enabled) {
    // Make the rows in the WBS editor sortable
    if (enabled) {
        $('#wbs-line-tbl').sortable('enable');
    } else {
        $('#wbs-line-tbl').sortable('disable');
    }
}

function configure_lineitem_callbacks (line) {
    /*
    line.on('click', function () {
        if ( $('div.instructions').length !== 0 ) {
            if ($(this).hasClass('selected')) {
                $(this).removeClass('selected');
            } else {
                $(this).addClass('selected');
            }
        }
    }).on('mouseover', function () {
        if ( $('div.instructions').length !== 0 ) {
            $(this).addClass('over');
        }
    }).on('mouseout', function () {
        if ( $('div.instructions').length !== 0 ) {
            $(this).removeClass('over');
        }
    });
    */

    // Immediately remove new row (trashcan icon link is clicked) delete-it
    line.find('a.delete-wbs-entry').on('click', function () {
        let table = line.parents('table');

        $(this).parents('tbody')[0].remove();
        update_order(table);
    });

    // Configure the SKU select element in the line items to use the select2 widget
    line.find('select[name$="[sku]"]').select2({
        theme: 'bootstrap4',
        minimumResultsForSearch: 10,
        templateResult: formatSKUItem

        // Update row if SKU changes if it is linked to all
    }).on('select2:select', function (e) {
        var form = $('#wbs-form');
        var row = $(this).parents('tbody');
        var gsa_id = row.find('select[name$="[gsa_labor_category_id]"]');
        $.ajax({
            url: form.attr('action') + '/line_item/' + row.data('index') + '/sku/' + gsa_id.val(),
            method: 'put',
            dataType: 'script',
            data: {
                sku: e.params.data.id
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            }
        });

        if (row_link_type(row) === LINKED_TO_SKU) {
            update_row(
                row,
                row.find('input[name$="[link_type]"]').val(),
                parseFloat(row.find('input[name$="[link_percent]"]').val()),
                row.find('input[name$="[link_task]"]').val()
            );
        }
    });

    line.find('input[name$="[task]"]').on('blur', function () {
        var row = $(this).parents('tr');

        update_total_hours($('#wbs-line-tbl'), row);
    });

    line.find('select[name$="[contract_vehicle]"]').on('change', function () {
        row_compliancy($(this).parents('tbody'));
    });

    line.find('select[name$="[gsa_labor_category_id]"]').on('change', function () {
        let row = $(this).parents('tr').first();
        let alerttd = $(this).parents('tbody').children('tr').last().children('td').last();
        let selectedText = $(this).children("option:selected").text()
        if (selectedText === "GuidePoint SOAR Services-Standard" ||
            selectedText === "GuidePoint SOAR Services-Remote" ||
            selectedText === "GuidePoint SOAR Services-Premium" ||
            selectedText === "GuidePoint Splunk Services-Standard" ||
            selectedText === "GuidePoint Splunk Services-Remote" ||
            selectedText === "GuidePoint Splunk Services-Premium" ||
            selectedText === "GuidePoint F5 Networks Services-Standard" ||
            selectedText === "GuidePoint F5 Networks Services-Remote" ||
            selectedText === "GuidePoint F5 Networks Services-Premium") {
            alerttd.html("This Labor Category has a daily rate.<br>Please ensure you enter number of days in the 'Total Hours' field for this row.<br>Billable Hourly Rate and Internal Hourly Rate columns will list the daily rates for this Labor Category.");
            alerttd.css("border", "2px solid red");
            alerttd.css("font-weight", "bold");
        } else {
            alerttd.html("");
            alerttd.css( "border", "" );
        }
        let contract_vehicle = row.find('select[name$="[contract_vehicle]"]').val();
        if (contract_vehicle.length === 0) {
            contract_vehicle = $('select[name$="[contract_vehicle]"]').val()
        }

        $.ajax({
            url: '/gsa_labor_categories/' + $(this).val(),
            method: "GET",
            dataType: "json",
            data: {
                region:$('input[name$="[region]"]').val(),
                contract_vehicle:contract_vehicle
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            },
            success: function (response, status, jqXHR) {
                var billable_rate = row.find('input[name$="[billable_rate]"]');
                var internal_rate = row.find('input[name$="[internal_hourly_rate]"]');

                if (!billable_rate.data('user-modified')) {
                    billable_rate.val(response.revenue);
                }

                if (parseFloat(internal_rate.val()) === response.cost) {
                    internal_rate.data('user-modified', false);
                }

                if (!internal_rate.data('user-modified')) {
                    internal_rate.val(response.cost);
                }

                compute_line(row);
            }
        });
    });

    // When the total hours gets the focus, save its current value for later...
    line.find('input[name$="[total_hours]"]').on('focus', function () {
        $(this).data('value', $(this).val());
    }).on('blur', function () {
        var format = /^\d+(?:\.\d{0,2})?$/;
        var current_value = $(this).val();
        var previous_value = $(this).data('value');
        var row = $(this).parents('tbody').first();

        if (!current_value.match(format)) {
            $(this).addClass('error');
        } else {
            $(this).removeClass('error');
        }

        // If the value has changed, remove any link, update linked items,
        // and calculate static text fields
        if ( previous_value !== current_value ) {
            remove_link($('#wbs-line-tbl'), row.data('index') );

            update_total_hours($('#wbs-line-tbl'), row);
            compute_line(row);
        }
    });

    // When the billable rate element loses focus...
    line.find('input[name$="[billable_rate]"]').on('focus', function () {
        $(this).data('current-value', $(this).val());

    }).on('blur', function () {
        var format = /^\d+(?:\.\d{0,2})?$/;
        var previous_value = $(this).data('current-value');
        var current_value = $(this).val();

        if (!current_value.match(format)) {
            $(this).addClass('error');
        } else {
            $(this).removeClass('error');
        }

        if (current_value !== previous_value) {
            $(this).data('user-modified', true);
        }

        compute_line($(this).parents('tr').first());
    });

    // When the internal rate element loses focus...
    line.find('input[name$="[internal_hourly_rate]"]').on('focus', function () {
        $(this).data('current-value', $(this).val());

    }).on('blur', function () {
        var format = /^\d+(?:\.\d{0,2})?$/;
        var previous_value = $(this).data('current-value');
        var current_value = $(this).val();

        if (!current_value.match(format)) {
            $(this).addClass('error');
        } else {
            $(this).removeClass('error');
        }

        if (current_value !== previous_value) {
            $(this).data('user-modified', true);
        }

        compute_line($(this).parents('tr').first());
    });
}

// Function used by the select2 widget to add the SKU descriptions to the select options
function formatSKUItem (sku) {
    if (!sku.id) {
        return sku.text;
    }

    var $item = $(
        '<div>' +
        sku.text + '<br/>' +
        '<span style="font-size:12px;font-style:italic">' + $(sku.element).data('description') + '</span>' +
        '</div>'
    );

    return $item;
}

function removeProjectStructure(id, name) {
    var select = $('select[name="work_breakdown_structure[practice_ids][]"]');
    var selected = select.val();

    var indexOf = $.inArray(id + "", selected);
    if (indexOf >= 0) {
        selected.splice($.inArray(id + "", selected), 1);
        select.val(selected).change();

        var primary_select = $('select[name="work_breakdown_structure[project_structure]"]');
        primary_select.find('option[value="' + name + '"]').remove();

        $.ajax({
            url:'/wbs/practices',
            method:'get',
            dataType:'script',
            data: {
                practices: select.val()
            },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
            }
        });
    }
}

configure_editor();
