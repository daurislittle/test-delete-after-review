App.quote = App.cable.subscriptions.create("QuoteChannel", {
  connected: function() {
    // Called when the subscription is ready for use on the server
    console.log("Connected to Quote WebSocket...");
  },

  disconnected: function() {
    // Called when the subscription has been terminated by the server
  },

  received: function(data) {
    // Called when there's incoming data on the websocket for this channel
      console.log( "Recieved %o", data);

      var modal_body = $('#quote-status-modal').find('.modal-body');

      message = '';
      if (data['success'] == -2) {
         message = '<div class="text-danger">' + data['message'] + '</div>';

      } else if (data['success'] == -1) {
          message = '<div class="text-warning">' + data['message'] + '</div>';

      } else if (data['success'] == 0) {
          message = '<div class="text-info">' + data['message'] + '</div>';

      } else if (data['success'] == 1) {
          message = '<div class="text-primary">' + data['message'] + '</div>';

      } else if (data['success'] == 2) {
          message = '<div class="text-success">' + data['message'] + '</div>';
      }

      message = message.replace('\t', '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;')

      var new_element = $(message).appendTo(modal_body);

      modal_body.animate({
          scrollTop: new_element.offset().top
      });
  }
});
