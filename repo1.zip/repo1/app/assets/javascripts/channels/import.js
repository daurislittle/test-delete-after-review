App.client_import = App.cable.subscriptions.create("ImportChannel", {
    // Called when the subscription is ready for use on the server
    connected: function() {
        console.log("Connected to Import WebSocket...");
    },

    // Called when the subscription has been terminated by the server
    disconnected: function() {

    },

    // Called when there's incoming data on the websocket for this channel
    received: function(data) {
        var import_results = $('div.import-results');

        if (data['success'] == -1) {
            $.each(data['errors'], function (index, value) {
                import_results.prepend('<div>' + value + '</div>');
            });

            import_results.prepend('<div class="text-danger">' + data['message'] + '</div>');

        } else if (data['success'] == 0) {
            $('div.current-import').text(data['message']);

        } else if (data['success'] == 1) {
            $('div.import-results').prepend('<div class="text-success">' + data['message'] + '</div>');
        }


        if (import_results.children().length > 50) {
            import_results.children().last().remove();
        }
    },

    subscribe: function() {
        return this.perform('subscribe');
    }
});
