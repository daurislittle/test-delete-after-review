
function configure_toasts () {
    $('.toast').each(function () {
        $(this).toast({
            autohide: $(this).data('type') !== 'error' && $(this).data('type') !== 'warning',
            delay: 5000
        }).on('hidden.bs.toast', function () {
            $(this).remove();

            if ($('.toasts-area').find('.toast').length == 0) {
                $('.toasts-area').addClass('d-none');
            }
        }).toast('show');
    });

    if ($('.toasts-area').find('.toast').length > 0) {
        $('.toasts-area').removeClass('d-none');
    }
}