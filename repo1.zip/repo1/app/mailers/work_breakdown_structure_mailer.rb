class WorkBreakdownStructureMailer < ApplicationMailer
  default from: "no-reply@guidepointsecurity.com"

  def sandbox
    Rails.env == 'production' ? '' : Rails.env.upcase + ' Sandbox: '
  end

  def submit_creation
    @request = params[:request]
    @url = params[:url]

    mail(to:params[:to], subject: "#{sandbox}WBS Created: #{@request.title}")
  end

  def submit_update
    @request = params[:request]
    @url = params[:url]

    mail(to:params[:to], subject: "#{sandbox}WBS Updated: #{@request.title}")
  end

  def submit_published
    @request = params[:request]
    @url = params[:url]
    @quote = params[:quote]

    mail(to:params[:to], subject: "#{sandbox}WBS Published: [Opportunity #{@request.opportunity.GP_Opportunity_Number__c}] #{@request.title}")
  end

  def submit_publish_failure
    @request = params[:request]
    @url = params[:url]
    @message = params[:message]

    mail(to:params[:to], subject: "#{sandbox}WBS Publish Failed: [Opportunity #{@request.opportunity.GP_Opportunity_Number__c}] #{@request.title}")
  end

  def submit_action_required
    @request = params[:request]
    @url = params[:url]
    @quote = params[:quote]

    mail(to:params[:to], subject:"#{sandbox}[ACTION REQUIRED]: [Opportunity #{@request.opportunity.GP_Opportunity_Number__c}] #{@request.title}")
  end
end
