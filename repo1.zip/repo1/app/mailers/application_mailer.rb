class ApplicationMailer < ActionMailer::Base
  default from: 'cogs@guidepointsecurity.com'
  layout 'mailer'
end
