class ExceptionMailer < ApplicationMailer
  default from: "no-reply@guidepointsecurity.com"

  def submit_exception
    @exception = params[:exception]
    @user = params[:user]

    subject = "#{Rails.env.upcase} Exception Occurred"
    unless !params.key?(:title) || params[:title].blank?
      subject << ": #{params[:title]}"
    end

    mail(to:distribution_list, subject: subject)
  end

  private
  def distribution_list
    ['cogs-alert@guidepointsecurity.com']
  end
end
