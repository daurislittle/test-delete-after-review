class TemplatesController < ApplicationController
  def index
    @page_title = "Templates"
  end
end
