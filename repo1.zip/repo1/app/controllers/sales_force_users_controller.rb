class SalesForceUsersController < ApplicationController
  DEFAULT_PAGE_SIZE = 25

  def index
    @total = SalesForce::User.count

    if params[:limit] == 'All'
      params[:limit] = @total
    end

    @limit = params[:limit] ? params[:limit].to_i : DEFAULT_PAGE_SIZE

    @num_pages = @total / @limit
    if @total % @limit != 0
      @num_pages += 1
    end

    @page = params[:page] ? params[:page].to_i : 1
    if @page < 1
      @page = 1
    elsif @page > @num_pages
      @page = @num_pages
    end

    @start = (@page-1) * @limit

    @records = SalesForce::User.offset(@start).limit(@limit)

    respond_to do |format|
      format.json { render json:@records }
    end
  end

  def show
    @user = SalesForce::User.fetch(params[:id])

    raise ObjectNotFound.new("The requested Salesforce User does not exist.") unless @user.valid?

    respond_to do |format|
      format.json { render json:@user }
    end
  end
end
