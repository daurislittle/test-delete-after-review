class PracticesController < ApplicationController
  def index
    respond_to do |format|
      format.json {render json:Practice.all.order(:name)}
    end
  end

  def show
    practice = Practice.find_by(id:params[:id])

    if !practice.nil?
      respond_to do |format|
        format.json { render json:practice }
      end
    end
  end

  def skus
    practice = Practice.find_by(id:params[:id])

    respond_to do |format|
      format.json do
        render json:{
          id:   practice.id,
          name: practice.project_structure,
          skus: practice.skus
        }
      end
    end
  end
end
