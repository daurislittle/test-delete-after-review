class ErrorsController < ApplicationController
  def not_found
    render template:'errors/not_found', status:400, layout: 'error'
  end

  def internal_server_error
    render template:'errors/internal_server_error', status:500, layout: 'error'
  end

  def forbidden
    render template:'errors/forbidden', status:403, layout: 'error'
  end

  def unauthorized
    render template:'errors/unauthorized', status:401, layout: 'error'
  end
end
