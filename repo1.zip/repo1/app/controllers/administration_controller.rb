class AdministrationController < ApplicationController
  def index
    has_permission('is_admin', halt: true)

    @sections = [
        {
            title: "Content",
            icon:"far fa-newspaper",
            links: [
                {
                    title: "Enumerations",
                    description: "Manage the various enumeration types.",
                    permission: "is_admin",
                    href: administration_enumerations_path
                },
                {
                    title: "Variables",
                    description: "Manage the various variables accessed by COGS.",
                    permission: "is_admin",
                    href: administration_variables_path
                }
            ]
        },
        {
            title: "Security",
            icon:'fas fa-lock',
            links: [
                {
                    title: "Users",
                    description: "Manage the users of the site.",
                    permission: "is_admin",
                    href: administration_users_path
                },
                {
                    title: "Roles",
                    description: "Manage the roles that users can have.",
                    permission: "is_admin",
                    href: administration_roles_path
                },
                {
                    title: "Permissions",
                    description: "Manage the permissions that individual roles have.",
                    permission: "is_admin",
                    href: administration_permissions_path
                }
            ]
        },
        {
            title: "Addons",
            icon:'fas fa-puzzle-piece',
            links: [
                {
                    title: "Corporate",
                    description: "Manage the corporate databases",
                    href: administration_corporate_dbs_path,
                    permission: "is_admin"
                },
                {
                    title: "Salesforce",
                    description: "Manage configurable items for Salesforce integration",
                    href: administration_salesforce_admin_path,
                    permission: "is_admin"
                }#,
                #{
                #    title: "Logging",
                #    description: "Manage and view log files",
                #    href: administration_logging_index_path,
                #}
            ]
        }
    ]
  end
end
