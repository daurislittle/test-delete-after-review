class AccountsController < ApplicationController
  DEFAULT_PAGE_SIZE = 25

  def index
    @page_title = "Accounts"

    if params[:search_for] and !params[:search_for].blank?
      if params[:search_for].length > 1
        @total = SalesForce::Account.search(params[:search_for]).count
      else
        @total = SalesForce::Account.count

        flash[:toast] = {
          type: :error,
          message: "Please enter a search term that is larger than a single character."
        }.to_json

        redirect_to accounts_path
      end
    else
      @total = SalesForce::Account.count
    end

    params[:per_page] = @total if params[:per_page] == 'All'
    @per_page = params[:per_page] ? params[:per_page].to_i : DEFAULT_PAGE_SIZE

    @num_pages = @total / @per_page
    @num_pages += 1 if (@total % @per_page) != 0 or @num_pages == 0

    @page = params[:page] ? params[:page].to_i : 1
    if @page < 1
      @page = 1
    elsif @page > @num_pages
      @page = @num_pages
    end

    @start = (@page-1) * @per_page

    @sort_by        = params.key?(:sort_by) ? params[:sort_by].to_sym : :Name
    @sort_direction = params.key?(:sort_direction) ? params[:sort_direction].to_sym : :asc

    if params[:search_for] && !params[:search_for].blank?
      @records = if params.key?(:refresh) && params[:refresh] == 'true'
                   SalesForce::Account.search(params[:search_for]).offset(@start).limit(@per_page).refresh
                 else
                   SalesForce::Account.search(params[:search_for]).offset(@start).limit(@per_page)
                 end

      @search_for = params[:search_for]
    else
      @records = if params.key?(:refresh) && params[:refresh] == 'true'
                   SalesForce::Account.order(@sort_by => @sort_direction).offset(@start).limit(@per_page).refresh

                 else
                   SalesForce::Account.order(@sort_by => @sort_direction).offset(@start).limit(@per_page)
                 end.map { |record| record }

      @search_for = ''
    end

    @view = if params[:view]
              params[:view]
            else
              @view = 'table'
            end

    @show_bottom_subnav = true

    respond_to do |format|
      format.html {}
      format.js {}
    end
  end

  def show
    @account = if params.key?(:refresh)
                 SalesForce::Account.find_by(Id:params[:id]).refresh
               else
                 SalesForce::Account.find_by(Id:params[:id])
               end

    raise ObjectNotFound.new("The requested Salesforce Account does not exist.") unless @account.valid?

    @page_title = "Account: #{@account.Name if !@account.nil?}"
    @opportunities = @account.opportunities(only_services: true)
    @contacts = @account.contacts

    respond_to do |format|
      format.html do
        viewed = RecentlyViewed.find_by(user:current_user, viewed_type:@account.class.name, viewed_id:@account.Id)
        if !viewed.nil?
          viewed.touch
        else
          viewed = RecentlyViewed.new(
            user:current_user,
            title: @account.Name,
            viewed_type:@account.class.name,
            viewed_id:@account.Id,
            viewed_url:request.original_fullpath
          )
          viewed.save
        end
      end

      format.js {}
    end

  end

  def address
    account = SalesForce::Account.fetch(params[:id])

    raise ObjectNotFound.new("The requested Salesforce Account does not exist.") unless account.valid?
    raise ArgumentError.new("No address type was specified in request for account address.") unless params.key?(:which)

    if params[:which] == 'billing'
      if account.billing_address?
        render json:get_address_hash(account.billing)
      else
        raise ArgumentError.new("Account does not have a billing address.")
      end

    elsif params[:which] == 'headquarters'
      if account.headquarters_address?
        render json:get_address_hash(account.headquarters)
      else
        raise ArgumentError.new("Account does not have a headquarters address.")
      end

    elsif params[:which] == 'shipping'
      if account.shipping_address?
        render json:get_address_hash(account.shipping)
      else
        raise ArgumentError.new("Account does not have a shippings address.")
      end

    else
      raise ArgumentError.new("Invalid address type requested.")
    end
  end

  def get_address_hash(address)
    full_address = [address.address1]
    if (!address.address1.nil? && address.address1.include?("\n"))
      full_address = address.address1.split("\n",2)
      full_address[0] = full_address[0].strip
      full_address[1] = full_address[1].strip
    end
    {"address1":full_address[0],"address2":(full_address.length > 1 ? full_address[1] : ''),"city":address.city,
            "state":address.state, "zipcode":address.zipcode,"country":address.country}
  end
end
