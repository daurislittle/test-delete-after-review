module Administration
  class LoggingController < ApplicationController
    include LoggingHelper

    BACKWARD_STEP = 1000

    def index
      today = Time.current

      @refresh_server = params.key?(:server) || !params.key?(:salesforce)
      @refresh_salesforce = params.key?(:salesforce) || !params.key?(:server)

      # Configure server logging
      if @refresh_server
        @server_kinds = if params.key?(:server) && params[:server].key?(:kind)
                          params[:server][:kind]
                        else
                          %w[ERROR WARN INFO]
                        end

        server_from_date = if params.key?(:server) && params[:server].key?(:from) && params[:server][:from].key?(:date)
                             Date.parse(params[:server][:from][:date])
                           else
                             today - 1.day
                           end

        server_from_time = if params.key?(:server) && params[:server].key?(:from) && params[:server][:from].key?(:time)
                             Time.parse(params[:server][:from][:time])
                           else
                             today - 1.day
                           end

        @server_start = DateTime.new(
          server_from_date.year,
          server_from_date.month,
          server_from_date.day,
          server_from_time.hour,
          server_from_time.min,
          0
        )

        server_end_date = if params.key?(:server) && params[:server].key?(:to) && params[:server][:to].key?(:date)
                            Date.parse(params[:server][:to][:date])
                          else
                            today
                          end

        server_end_time = if params.key?(:server) && params[:server].key?(:to) && params[:server][:to].key?(:time)
                            Time.parse(params[:server][:to][:time])
                          else
                            today
                          end

        @server_end = DateTime.new(
          server_end_date.year,
          server_end_date.month,
          server_end_date.day,
          server_end_time.hour,
          server_end_time.min,
          59
        )

        @server_pid = params[:server][:pid] if params.key?(:server) && params[:server].key?(:pid)
        @server_text = params[:server][:text] if params.key?(:server) && params[:server].key?(:text)

        @server = File::Tail::Logfile.open("log/#{Rails.env}.log")
        Rails.logger.debug("FIRST TELL: #{@server.tell}")
        @server.return_if_eof = true
        find_start(@server, @server_start)

        @server.tail(1) do |line|
          Rails.logger.debug("This Line> #{line}")
        end

        @server_lines = get_lines(@server, @server_pid, @server_text, @server_kinds, @server_start, @server_end)
      end

      # Configure SalesForce logging
      if @refresh_salesforce
        @salesforce_kinds = if params.key?(:salesforce) && params[:salesforce].key?(:kind)
                              params[:salesforce][:kind]
                            else
                              %w[ERROR WARN INFO]
                            end

        sf_from_date = if params.key?(:salesforce) && params[:salesforce].key?(:from) && params[:salesforce][:from].key?(:date)
                         Date.parse(params[:salesforce][:from][:date])
                       else
                         today - 1.day
                       end

        sf_from_time = if params.key?(:salesforce) && params[:salesforce].key?(:from) && params[:salesforce][:from].key?(:time)
                         Time.parse(params[:salesforce][:from][:time])
                       else
                         today - 1.day
                       end

        @salesforce_start = DateTime.new(
          sf_from_date.year,
          sf_from_date.month,
          sf_from_date.day,
          sf_from_time.hour,
          sf_from_time.min,
          0
        )

        sf_end_date = if params.key?(:salesforce) && params[:salesforce].key?(:to) && params[:salesforce][:to].key?(:date)
                        Date.parse(params[:salesforce][:to][:date])
                      else
                        today
                      end

        sf_end_time = if params.key?(:salesforce) && params[:salesforce].key?(:to) && params[:salesforce][:to].key?(:time)
                        Time.parse(params[:salesforce][:to][:time])
                      else
                        today
                      end

        @salesforce_end = DateTime.new(
          sf_end_date.year,
          sf_end_date.month,
          sf_end_date.day,
          sf_end_time.hour,
          sf_end_time.min,
          59
        )

        @salesforce_pid = if params.key?(:salesforce) && params[:salesforce].key?(:pid)
                            params[:salesforce][:pid]
                          else
                            nil
                          end

        @salesforce_text = if params.key?(:salesforce) && params[:salesforce].key?(:text)
                             params[:salesforce][:text]
                           else
                             nil
                           end

        @salesforce = File::Tail::Logfile.open(Rails.configuration.salesforce.log_file) unless Rails.configuration.salesforce.log_file.blank?
        @salesforce.return_if_eof = true
        find_start(@salesforce, @salesforce_start)
        @salesforce_lines = get_lines(@salesforce, @salesforce_pid, @salesforce_text, @salesforce_kinds, @salesforce_start, @salesforce_end)
      end

      respond_to do |format|
        format.html {}
        format.js {}
      end
    end

    private

    # Works backward from the end of the file, looking for the first line that is less than the provided date.
    def find_start (file, date)
      tries = 1
      found = false

      file.backward(BACKWARD_STEP)
      last_found = nil
      while !found
        if file.tell == 0
          break
        end

        file.tail(BACKWARD_STEP) do |line|
          group = log_match(line)

          if group
            last_found = group[:date]

            if DateTime.parse(group[:date]) < date
              found = true
            end

            break
          end
        end

        unless found
          tries += 1
          file.backward(tries * BACKWARD_STEP)
        end
      end

      Rails.logger.debug("FOUND? #{found}: #{(tries + 1) * BACKWARD_STEP}")
      file.backward((tries + 1) * BACKWARD_STEP) if found

      file
    end

    # Retrieves all lines matching the criteria specified in [pid, text, kinds, start date, end date].
    def get_lines (file, pid, text, kinds, start_date, end_date)
      lines = []
      eof = false

      #while !eof do
        file.each do |line|
          match_group = log_match(line)
          if match_group
            if DateTime.parse(match_group[:date]) >= start_date

              # If we move passed the end date then set the EOF flag to break out of the outer loop
              if !end_date.nil? && DateTime.parse(match_group[:date]) > end_date
                eof = true
                break
              end

              if match_group[:type].in?(kinds) &&
                (pid.blank? || match_group[:pid] == pid) &&
                (text.blank? || match_group[:message].include?(text))
                lines << line
              end
            end
          end
        end
      #end

      lines
    end
  end
end
