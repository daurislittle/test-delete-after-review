module Administration
  class CorporateDatabasesController < ApplicationController
    def index
      has_permission('is_admin', halt:true)

      @sections = [
          {
              title: "Directory",
              description: "Manage the corporate directory database.",
              href: administration_corporates_path,
              permission: "is_admin"
          },
          {
              title: "Email Distribution Lists",
              description: "Manage the corporate email distribution database.",
              href: administration_gps_groups_path,
              permission: "is_admin"
          },
          {
              title: "GSA Labor Categories",
              description: "Administer the GSA labor categories.",
              href: administration_gsa_labor_categories_path,
              permission: "is_admin"
          },
          {
              title: "Practices",
              description: "View/Manage the practice definitions along with their defined SKUs as pulled from Salesforce.",
              href: administration_practices_path,
              permission: "is_admin"
          }
      ]
    end
  end
end

