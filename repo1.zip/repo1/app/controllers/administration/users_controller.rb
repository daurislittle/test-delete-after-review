class Administration::UsersController < ApplicationController
  def index
    has_permission('is_admin', halt:true)

    @users = User.all.order(:last_name, :first_name)
  end

  def show
    has_permission('is_admin', halt:true)

    @show_user = User.find_by(id: params[:id])

    if @show_user.nil?
      raise ActiveRecord::RecordNotFound.new("The requested User does not exist.")
    end
  end

  def update
    has_permission('is_admin', halt:true)

    @user = User.find_by(id: params[:id])

    if @user.nil?
      raise ActiveRecord::RecordNotFound.new("The requested User does not exist.")
    end

    if @user.update(user_params)
      flash[:toast] = {
        type: :success,
        message: "Successfully updated user \"#{@user.name}\"."
      }.to_json
    else
      flash[:toast] = {
        type: :error,
        message: "Failed to update user \"#{@user.name}\"."
      }.to_json
    end

    redirect_to administration_user_path(@user)
  end

  def disable_account
    has_permission('is_admin', halt:true)

    @user = User.find_by(id:params[:id])

    if @user.nil?
      raise ActiveRecord::RecordNotFound.new("The requested User does not exist.")
    end

    if @user.update(is_disabled:true)
      flash[:toast] = {
        type: :success,
        message: "#{@user.name} has been disabled."
      }.to_json
    else
      flash[:toast] = {
        type: :error,
        message: "There was an issue disabling #{@user.name}"
      }.to_json
    end

    redirect_to administration_user_path(@user)
  end

  def enable_account
    has_permission('is_admin', halt:true)

    @user = User.find_by(id:params[:id])

    if @user.nil?
      raise ActiveRecord::RecordNotFound.new("The requested User does not exist.")
    end

    if @user.update(is_disabled:false)
      flash[:toast] = {
        type: :success,
        message: "#{@user.name} has been reinstated."
      }.to_json
    else
      flash[:toast] = {
        type: :success,
        message: "This was an issue reinstating #{@user.name}"
      }.to_json
    end

    redirect_to administration_user_path(@user)
  end

=begin Some initial playing with pulling from Okta
  def sync
    has_permission('is_admin', halt:true)

    url = "#{root_url}saml/consume"
    url = "http://localhost:3000/saml/consume"

    @okta_client ||= Oktakit.new(token:'00MRkT6rlV-BOicW1NUojyGrBHJfhXrKl8rq5wglBO', organization:'dev-966178')

    applications, status = @okta_client.list_applications
    if status != 200
      raise StandardError.new("Failed to list okta applications")
    end

    application = applications.find { |app| app[:settings][:signOn][:ssoAcsUrl] == url}
    if application.nil?
      raise StandardError.new("Failed to find application for #{url}")
    end

    users, status = @okta_client.list_users_assigned_to_application(application[:id])
    if status == 200 && !users.empty?
      users.each do |user|
        okta_user, status = @okta_client.get_user(user[:id])
        if status != 200
          raise StandardError.new("Failed to retrieve user: #{user[:credentials][:userName]}")
        end

        cogs_user = User.where(email:okta_user[:profile][:email]).first_or_initialize
        cogs_user.first_name = okta_user[:profile][]

        Rails.logger.debug("#{okta_user[:profile][:lastName]}, #{okta_user[:profile][:firstName]}: #{okta_user[:profile][:email]}")
      end
    elsif status != 200
      raise StandardError.new("Failed to get users for #{application[:name]}")
    end
  end
=end

  private
  def user_params
    params.require(:user).permit(:is_disabled, :role_ids => [])
  end
end
