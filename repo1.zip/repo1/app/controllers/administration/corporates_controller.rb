require 'csv'
require 'creek'

module Administration
  class CorporatesController < ApplicationController
    def index
      has_permission('is_admin', halt:true)

      @show_bottom_subnav = true
      @directory = Corporate.all.order(:lastname, :firstname).paginate(page:params[:page], per_page:20)
    end

    def sync
      has_permission('is_admin', halt:true)

      respond_to do |format|
        format.js { @results = Corporate.sync }
      end
    end

    def import
      has_permission('is_admin', halt:true)

      @error = false
      @total    = 0
      @errors   = []
      @created  = []
      @updated  = []
      @skipped = []
      @error_messages = []

      imported = []

      if params.key? :file
        file = params[:file]

        if file.content_type != 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
          @error = "Invalid file selected.  Only XLSX formatted files are supported."
        else
          existing = Corporate.all.map { |person| {lastname: person.lastname, firstname: person.firstname}}

          begin
            book = Creek::Book.new file.path
            sheet = book.sheets[0]

            # Validate the data
            sheet.rows.each_with_index do |row, r|
              values = row.map {|key, value| value}

              # Use first row to validate what is expected
              if r.zero?
                # Note: Cannot validate first column because it currently contains a URL to Okta????

                if values[1] != 'First Name'
                  @error_messages << 'Header Validation: Second column does not appear to contain the First Name.'
                end

                if values[2] != 'Title'
                  @error_messages << 'Header Validation: Third column does not appear to contain the Title'
                end

                if values[8] != 'Email Address'
                  @error_messages << 'Header Validation: Nineth column does not appear to contain the Email Address'
                end

              elsif !values[0].blank? || !values[1].blank? || !values[8].blank?
                if values[0].blank?
                  @error_messages << "Data Validation: Row #{r} does not contain a Last Name"
                end

                if values[1].blank?
                  @error_messages << "Data Validation: Row #{r} does not contain a First Name"
                end

                if values[8].blank?
                  @error_messages << "Data Validation: Row #{r} does not contain an Email Address"
                end
              end
            end

            if @error_messages.empty?
              sheet.rows.each_with_index do |row, r|
                # Skip the first row (header)
                next if r == 0

                values = row.map {|key, value| value}

                if !values[0].blank? && !values[1].blank? && !values[8].blank?
                  person = Corporate.where(lastname: values[0], firstname:values[1]).first_or_initialize

                  person.title = values[2]
                  person.region = values[3].strip unless values[3].nil?
                  person.location = values[4]
                  person.grasshopper = values[5].to_i if values[5] =~ /\A\d+\z/ # Just digits
                  person.mobile = values[6].delete("\u0000").delete("\x00")
                  person.email = values[8].delete("\u0000").delete("\x00")
                  person.status = values[9].strip unless values[9].nil?
                  person.flags = values[10]
                  person.manager = values[11]
                  person.is_legacy = false

                  imported << {
                    firstname: person.firstname,
                    lastname: person.lastname
                  }

                  if person.id.nil?
                    @created << person
                  else
                    @updated << person
                  end

                  if !person.save
                    Rails.logger.error "#{person.name}: #{person.errors.full_messages}"
                    @errors << person
                  end

                elsif values[0].blank? || values[1].blank? || values[8].blank?
                  @skipped << {
                      first_name: values[1],
                      last_name: values[0],
                      email: values[8]
                  }
                end
              end

              removed = existing - imported
              removed.each do |removed_person|
                person = Corporate.find_by(lastname:removed_person[:lastname], firstname:removed_person[:firstname])
                person.is_legacy = true

                if !person.save
                  Rails.logger.error "#{person.name}: #{person.errors.full_messages}"
                  @errors << person
                end
              end
            end

          rescue StandardError => e
            @error = e.message

            Rails.logger.error("#{@error}")
            Rails.logger.error(e.backtrace.join("\n"))
          end
        end

      else
        @error = "No file selected."
      end

      respond_to do |format|
        format.js {}
      end
    end
  end
end

