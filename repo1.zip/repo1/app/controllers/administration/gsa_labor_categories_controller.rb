module Administration
  class GsaLaborCategoriesController < ApplicationController
    def index
      has_permission('is_admin', halt:true)

      @categories = GsaLaborCategory.all.order('lower(name) ASC')
    end

    def show
      has_permission('is_admin', halt:true)

      @category = GsaLaborCategory.find_by(id: params[:id])

      if @category.nil?
        raise ActiveRecord::RecordNotFound.new("The requested GSA Labor Category does not exist.")
      end
    end

    def new
      has_permission('is_admin', halt:true)

      @category = GsaLaborCategory.new
    end

    def create
      has_permission('is_admin', halt:true)

      @category = GsaLaborCategory.new(category_params)
      if @category.save
        flash[:toast] = {
          type: :success,
          message: "Successfully created the GSA Labor Category named \"#{@category.name}\"."
        }.to_json

        redirect_to [:administration, @category]
      else
        render 'new'
      end
    end

    def edit
      has_permission('is_admin', halt:true)

      @category = GsaLaborCategory.find_by(id:params[:id])

      if @category.nil?
        raise ActiveRecord::RecordNotFound.new("The requested GSA Labor Category does not exist.")
      end
    end

    def update
      has_permission('is_admin', halt:true)

      @category = GsaLaborCategory.find_by(id:params[:id])

      if @category.nil?
        raise ActiveRecord::RecordNotFound.new("The requested GSA Labor Category does not exist.")
      end

      if @category.update_attributes(category_params)
        flash[:toast] = {
          type: :success,
          message: "Successfully updated the GSA Labor Category named \"#{@category.name}\"."
        }.to_json
        redirect_to [:administration, @category]
      else
        render 'edit'
      end
    end

    def destroy
      has_permission('is_admin', halt:true)

      @category = GsaLaborCategory.find_by(id:params[:id])

      if @category.nil?
        raise ActiveRecord::RecordNotFound.new("The requested GSA Labor Category does not exist.")
      end

      if @category.destroy
        flash[:toast] = {
          type: :success,
          message: "Successfully removed the GSA Labor Category named \"#{@category.name}\"."
        }.to_json
      else
        flash[:toast] = {
          type: :error,
          message: "Removal of the GSA Labor Category named \"#{@category.name}\" failed."
        }.to_json
      end

      redirect_to administration_gsa_labor_categories_path
    end

    private
    def category_params
      params.require(:gsa_labor_category).permit(
          :name,
          :description,
          :description2,
          :gsa_floor_price,
          :federal_max_price,
          :ordinal
      )
    end
  end
end

