class Administration::VariablesController < ApplicationController
  def index
    has_permission( 'is_admin', halt: true)

    @variables = Variable.all.order(:label)
  end

  def update
    has_permission('is_admin', halt:true)

    params.require(:id)
    params.require(:variable)

    @variable = Variable.find_by(id:params[:id])
    if @variable.nil?
      raise ActiveRecord::RecordNotFound.new("The requested variable does not exist.")
    end

    if params.key?(:variable) && params[:variable].key?(:value)
      params[:variable][:value] = typecast(params[:variable][:value].gsub(/[\r\n]+/m, " "), @variable.kind)
      if params[:variable][:value].nil?
        flash.now[:toast] = {
          type: :error,
          message: "Invalid value for #{@variable.name}, was expecting #{@variable.kind}"
        }.to_json

        return
      end
=begin
      if @variable.kind == 'currency' || @variable.kind == 'float'
        params[:variable][:value] = Float(params[:variable][:value])

       elsif @variable.kind == 'integer'
         params[:variable][:value] = Integer(params[:variable][:value])
       end
=end
    end

    if @variable.update(variable_params)
      flash.now[:toast] = {
        type: :success,
        message: "Successfully saved variable '#{@variable.name}'"
      }.to_json
    else
      flash.now[:toast] = {
        type: :error,
        message: "There was a problem saving variable: #{@variable.errors.full_messages}"
      }.to_json
    end
  end

  private

  def variable_params
    params.require(:variable).permit(
      :name,
      :kind,
      :value,
      :label
    )
  end

  def value_of_type? (value, type)
    case type
    when 'float'
      value.is_a?(Float) || !!Float(value)

    when 'currency'
      value.is_a?(Float) || !!Float(value)

    when 'integer'
      value.is_a?(Integer) || !!Integer(value)

    else
      true
    end

  rescue ArgumentError
    false
  end

  def typecast (value, type)
    return unless value_of_type?(value, type)

    case type
    when 'float'
      Float(value)

    when 'currency'
      Float(value)

    when 'integer'
      Integer(value)

    else
      value
    end
  end
end
