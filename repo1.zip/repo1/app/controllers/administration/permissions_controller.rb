class Administration::PermissionsController < ApplicationController
  def index
    has_permission('is_admin', halt:true)

    @permissions = Permission.all
    @roles = Role.all
    @permission = Permission.new

    session[:return_to] = administration_permissions_path
  end
end
