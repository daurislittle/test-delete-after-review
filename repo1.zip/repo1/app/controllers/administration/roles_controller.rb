class Administration::RolesController < ApplicationController
  def index
    has_permission('is_admin', halt:true)

    @roles = Role.all.order(:name)
    @role = Role.new
  end

  def show
    has_permission('is_admin', halt:true)

    @role = Role.find_by(id: params[:id])

    if @role.nil?
      raise ActiveRecord::RecordNotFound.new("The requested Role does not exist.")
    end

    session[:return_to] = administration_role_path(@role)
  end

  def edit
    has_permission('is_admin', halt:true)

    @role = Role.find_by(id: params[:id])

    if @role.nil?
      raise ActiveRecord::RecordNotFound.new("The requested Role does not exist.")
    end
  end

  def create
    has_permission('is_admin', halt:true)

    @role = Role.create(role_params)

    if @role.save
      flash[:toast] = {
        type: :success,
        message: "Role #{@role.name} has been successfully created."
      }.to_json
      redirect_to administration_roles_path
    else
      @roles = Role.all

      render 'index'
    end
  end

  def update
    has_permission('is_admin', halt:true)

    @role = Role.find_by(id: params[:id])

    if @role.nil?
      raise ActiveRecord::RecordNotFound.new("The requested Role does not exist.")
    end

    if @role.update_attributes(role_params)
      flash[:toast] = {
        type: :success,
        message: "Role has been succesfully updated."
      }.to_json
      redirect_to administration_roles_path
    else
      render 'edit'
    end
  end

  def update_roles
    has_permission('is_admin', halt:true)

    unless params.key?(:roles)
      flash[:toast] = {
        type: :warn,
        message: 'No roles were provided to update.'
      }.to_json

      return
    end

    params[:roles].each do |role_name, permissions|
      role = Role.find_by(name: role_name)

      permissions.each do |perm|
        perm_name = perm[0]
        is_set = perm[1]
        puts "#{role.name}: #{perm_name} = #{is_set}"

        if ( is_set == "false" )
          if ( role.permissions.exists?(name: perm_name) )
            role.permissions.delete(Permission.find_by(name:perm_name))
          end
        else
          unless role.permissions.exists?(name: perm_name)
            role.permissions << Permission.find_by(name: perm_name)
          end
        end
      end
    end

    flash[:toast] = {
      type: :success,
      message: "Roles/Permissions have been updated."
    }.to_json
    redirect_to session.delete(:return_to)
  end

  private
  def role_params
    params.require(:role).permit(:name)
  end
end
