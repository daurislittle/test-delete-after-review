class Administration::EnumerationsController < ApplicationController
  PER_PAGE = 25

  def index
    has_permission('is_admin', halt:true)

    @enumeration_types = Enumeration.select(:enum_type).distinct.order(:enum_type)
    if params.key?(:enum_type)
      if !params[:enum_type].blank? && Enumeration.is_valid_type?(params[:enum_type])
        @enumerations = Enumeration.where(enum_type: params[:enum_type]).order(:ordinal).paginate(page:params[:page], per_page:PER_PAGE)
        @enum_type = params[:enum_type].squish
      else
        @enumerations = Enumeration.by_type.paginate(page:params[:page], per_page:PER_PAGE)
        @enum_type = ''
      end

    elsif !session[:enumeration_filter].blank? && Enumeration.is_valid_type?(session[:enumeration_filter])
      @enumerations = Enumeration.where(enum_type: session[:enumeration_filter]).order(:ordinal).paginate(page:params[:page], per_page:PER_PAGE)
      @enum_type = session[:enumeration_filter]

    else
      @enumerations = Enumeration.by_type.paginate(page:params[:page], per_page: PER_PAGE)
      @enum_type = ''
    end

    session[:enumeration_filter] = @enum_type.squish

    if @enumerations.count > PER_PAGE
      @show_bottom_subnav = true
    end

    respond_to do |format|
      format.html {}
      format.js {}
    end
  end

  def new
    has_permission('is_admin', halt:true)

    @enumeration = Enumeration.new
    @show_bottom_subnav = true
  end

  def create
    has_permission('is_admin', halt:true)

    @enumeration = Enumeration.new(enum_params)
    if @enumeration.save
      flash[:toast] = {
        type: :success,
        message: "Successfully created enumeration '#{@enumeration.name}'."
      }.to_json

      redirect_to administration_enumerations_path
    else
      @show_bottom_subnav = true
      render 'new'
    end
  end

  private
  def enum_params
    params.require(:enumeration).permit(:name, :enum_type, :description)
  end
end
