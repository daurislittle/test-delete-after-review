class Administration::PracticesController < ApplicationController
  def index
    has_permission('is_admin', halt:true)

    @skus_by_practice = SalesForce::Sku.by_practice

    # Force the pull of all of the project structures from Salesforce
    @project_structures = SalesForce.force_query do
      SalesForce.client.picklist('Opportunity', 'Project_Structure__c')
    end.map { |structure| structure.value }

    # Will new ones be created?
    @contains_new = Practice.where(project_structure: @project_structures).count < @project_structures.count

    # Grab all the practices for the project structures, and create the ones that don't exist
    @practices = @project_structures.map {
      |structure| Practice.find_or_create_by(project_structure: structure)
    }

    # Do inactive practices exist?
    @contains_inactive = Practice.where(in_active: true).count.nonzero?
  end

  def edit
    has_permission('is_admin', halt:true)

    @practice = Practice.find_by(id:params[:id])
    @practices = SalesForce::Sku.practices

    respond_to do |format|
      format.js {}
    end
  end

  def update
    has_permission('is_admin', halt:true)

    @practice = Practice.find_by(id:params[:id])
    if @practice.update(ps_params)
      flash.now[:toast] = {
        type: :success,
        message: "Successfully updated #{@practice.project_structure}"
      }.to_json
    else
      flash.now[:toast] = {
        type: :error,
        message: "A problem occurred updating #{@practice.project_structure}"
      }.to_json
    end

    respond_to do |format|
      format.js {}
    end
  end

  def destroy
    has_permission('is_admin', halt:true)

    params.require(:id)

    @practice = Practice.find_by(id:params[:id])
    @destroyed = false

    unless @practice.nil?
      if @practice.work_breakdown_structures.empty?
        @practice.delete

        if @practice.destroyed?
          @destroyed = true

          flash.now[:toast] = {
            type: :success,
            message: "#{@practice.project_structure} has been removed."
          }.to_json
        else
          flash.now[:toast] = {
            type: :error,
            message: "Something went wrong when removing #{@practice.project_structure}."
          }.to_json
        end

      else
        flash.now[:toast] = {
          type: :error,
          message: "#{@practice.project_structure} cannot be removed because it is tied to one or more WBSs."
        }.to_json
      end
    end

    respond_to do |format|
      format.js {}
    end
  end

  def skus
    @practice = Practice.find_by(id:params[:id])

    if params.key? :practices
      @practice.practices = params[:practices]
    end

    respond_to do |format|
      format.js {}
    end
  end

  def emails
    emails = []

    if params.key?(:search_for) and !params[:search_for].blank?
      count = Corporate.where('email LIKE ?', "%#{params[:search_for]}%").count +
              GpsGroup.where('email LIKE ?', "%#{params[:search_for]}%").count
    else
      count = Corporate.all.count + GpsGroup.all.count
    end

    page = params.key?(:page) ? params[:page] : 1
    per_page = 25

    num_pages = count / per_page
    if (count % per_page) != 0 or num_pages == 0
      num_pages += 1
    end

    page = params.key?(:page) ? params[:page].to_i : 1
    if page < 1
      page = 1
    elsif page > num_pages
      page = num_pages
    end

    start = (page-1) * per_page

    if params.key? :search_for
      emails = Corporate.where('email LIKE ?', "%#{params[:search_for]}%").order(:email).limit(per_page).offset(start) +
               GpsGroup.where('email LIKE ?', "%#{params[:search_for]}%").order(:email).limit(per_page).offset(start)
    else
      emails = Corporate.all.order(:email).limit(per_page).offset(start) +
               GpsGroup.all.order(:email).limit(per_page).offset(start)
    end

    respond_to do |format|
      format.json { render json:{
          results: emails.map{|item| {id:item.email, text:item.email}}.sort{|x,y| x[:id] <=> y[:id]},
          pagination: {
              more: (page * per_page) < count
          }
      }}
    end
  end

  private
  def ps_params
    params.require(:practice).permit(
        :project_structure,
        :leadership_slack,
        :scoping_slack,
        :in_active,
        :practices => [],
        :leadership_team => [],
        :scoping_team => [],
    )
  end
end
