module Administration
  class GpsGroupsController < ApplicationController
    def index
      has_permission('is_admin', halt:true)

      per_page = params.key?(:per_page) ? params[:per_page] : 10

      @show_bottom_subnav = true
      @groups = GpsGroup.all.order(:name).paginate(page:params[:page], per_page: per_page)
    end

    # todo Change this to report in toasts and not the dialog?
    def import
      has_permission('is_admin', halt:true)

      require 'set'

      @error = nil
      @total    = 0
      @created  = []
      @updated  = {}
      @removed  = []
      @errors   = {}
      @validation_messages = []

      imported = []

      if params.key? :file
        @file = params[:file]

        if @file.content_type != 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
          @error = "Invalid file selected.  Only XLSX formatted files are supported."
        else
          begin
            book = Creek::Book.new @file.path
            sheet = book.sheets[0]

            num_header_columns = 0

            # Validate the data
            sheet.rows.each_with_index do |row, index|
              # Collect the column values
              values = row.map {|key, value| value}

              # Use first to to validate what is expected
              if index.zero?
                num_header_columns = values.count
                if num_header_columns < 3
                  @validation_messages << "<b>Header Validation:</b> Expected at least 3 columns, but found only #{num_header_columns}."

                # Only validate the header contents if we know we have at least 3 values
                else
                  if values[0].downcase != 'group name'
                    @validation_messages << '<b>Header Validation:</b> First column does not appear to contain the name of the distribution group.'
                  end

                  if values[1].downcase != 'group email'
                    @validation_messages << '<b>Header Validation:</b> Second column does not appear to contain the email address for the distribution group.'
                  end

                  if values[2].downcase != 'members'
                    @validation_messages << '<b>Header Validation:</b> Third column does not appear to contain the members of the distribution group.'
                  end
                end

                # If there are errors in the header, then maybe this isn't the correct file
                break unless @validation_messages.empty?
              end

              if index.nonzero?
                # Skip blank rows.
                next if values.count.zero?

                if values.count != num_header_columns
                  @validation_messages << "<b>Data Validation, Row #{index}</b>: Number of columns [#{values.count}] do not match the number of header columns [#{num_header_columns}] in the header."
                end

                if values.count < 3
                  @validation_messages << "<b>Data Validation, Row #{index}</b>: Expected at least three columns but found #{values.length}"

                else
                  if !values[0].blank?
                    if values[1].blank?
                      @validation_messages << "<b>Data Validation, Row #{index}</b>: Malformed (#{values}).  Expected group email address in column 2."
                    end
                  elsif values[2].blank?
                    @validation_messages << "<b>Data Validation, Row #{index}</b>: Malformed (#{values}).  Expected member email address in column 3."
                  end
                end
              end
            end

            @error = "<b>Validation Failed:</b> Did you select the correct file?" unless @validation_messages.empty?
            if @error.blank?
              current_lists = GpsGroup.all
              new_lists     = Set.new

              current_list = nil
              has_changed = false

              current_members = nil
              new_members = Set.new

              sheet.rows.each_with_index do |row, index|
                # Skip the first row (header)
                next if index == 0

                # Collect the column values
                values = row.map {|key, value| value}

                # Skip blank rows
                next if values.count.zero?

                # This is the first line of a new distribution list
                if !values[0].blank?

                  # We can't check for changes to the members until we find the end of the definition
                  # as indicated by the start of the next list
                  if current_list != nil
                    num_removed = (current_members - new_members.to_a).length
                    num_added = (new_members.to_a - current_members).length
                    if (num_removed != 0) || (num_added != 0)
                      has_changed = true

                      if !@updated.key?(current_list)
                        @updated[current_list] = ["Distribution list members updated [#{num_added} Added, #{num_removed} Removed]."]
                      else
                        @updated[current_list] << "Distribution list members updated [#{num_added} Added, #{num_removed} Removed]."
                      end
                    end

                    # Remove any members no longer in this list
                    (current_members - new_members.to_a).each do |member|
                      member.delete

                      unless member.destroyed?
                        if @errors.key?(current_list)
                          @errors[current_list] << "Failed to remove #{member.corporate.email} from #{current_list.name}"
                        else
                          @errors[current_list] = ["Failed to remove #{member.corporate.email} from #{current_list.name}"]
                        end
                      end
                    end
                  end

                  # Process the start of a new distribution list
                  current_list = GpsGroup.find_by(name: values[0])
                  is_new = current_list.nil?
                  has_changed = false

                  # If we didn't find it, then create it
                  if is_new
                    current_list = GpsGroup.new(name: values[0])
                  end

                  new_lists << current_list

                  new_members = Set.new
                  current_members = current_list.gps_group_members

                  # If it isn't a new list and the email changed, then update it and mark it as changed.
                  if current_list.email != values[1] && !is_new
                    current_list.email = values[1]
                    has_changed = true

                    @updated[current_list] = ['Distribution email address updated.']
                  end

                  if is_new || has_changed
                    if current_list.save
                      @created << current_list if is_new
                    else
                      if @errors.key?(current_list)
                        @errors[current_list] = @errors[current_list] + current_list.errors.full_messages
                      else
                        @errors[current_list] = current_list.errors.full_messages
                      end
                    end
                  end

                # Process member list entry
                elsif !values[2].blank?
                  corporate = Corporate.for_email(values[2])

                  if corporate.nil?
                    if @errors.key?(current_list)
                      @errors[current_list] << "Could not locate a corporate directory entry for #{values[2]}"
                    else
                      @errors[current_list] = ["Could not locate a corporate directory entry for #{values[2]}"]
                    end

                  else
                    member = current_members.find_by(corporate:corporate)
                    if member.nil?
                      member = current_list.gps_group_members.build(corporate:corporate)
                      if !member.save()
                        if @errors.key?(current_list)
                          @errors[current_list] = @errors[current_list] + member.errors.full_messages
                        else
                          @errors[current_list] = member.errors.full_messages
                        end
                      end
                    end

                    new_members << member
                  end
                end
              end

              (current_lists - new_lists.to_a).each do |list|
                list.delete

                if list.destroyed?
                  @removed << list
                end
              end
            end

          rescue StandardError => e
            @error = e.message

            Rails.logger.error("#{@error}")
            Rails.logger.error(e.backtrace.join("\n"))
          end
        end

      else
        @error = "No file selected."
      end
    end

    def purge
      has_permission('is_admin', halt:true)

      GpsGroup.all.each do |group|
        group.destroy()
      end

      respond_to do |format|
        format.js {}
      end
    end
  end
end

