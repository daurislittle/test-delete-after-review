require "erb"
include ERB::Util

module Administration
  class SalesforceController < ApplicationController
    def admin
      has_permission('is_admin', halt:true)

      @sections = [
          {
              title: "Parameters",
              description: "Configure parameters used to connect to Salesforce",
              href: administration_salesforce_admin_parameters_path,
              permission: "is_admin"
          },
          {
              title: "Query and Test",
              description: "Perform queries and tests with Salesforce",
              href: administration_salesforce_admin_query_path,
              permission: "is_admin"
          }
      ]
    end

    def parameters
      has_permission('is_admin', halt:true)
    end

    def query
      has_permission('is_admin', halt:true)

      @config = YAML.load_file('config/salesforce.yml')
      @status = SalesForce.salesforce?
    end

    def ajax_connect
      has_permission('is_admin', halt:true)

      @config = YAML.load(ERB.new(File.read("#{Rails.root}/config/salesforce.yml")).result).slice(params[:env])
      if @config.key? params[:env]
        begin
          SalesForce.client.connect(
              host:           @config[params[:env]]['host'],
              username:       @config[params[:env]]['username'],
              password:       @config[params[:env]]['password'],
              security_token: @config[params[:env]]['security_token'],
              client_id:      @config[params[:env]]['client_id'],
              client_secret:  @config[params[:env]]['client_secret']
          )
        rescue SalesForce::ConnectError => e
          @error = e.message
        end
      end
    end

    def ajax_query
      has_permission('is_admin', halt:true)

      render json: SalesForce.client.query( params[:query] )
    end

    def ajax_describe
      has_permission('is_admin', halt:true)

      render json: SalesForce.client.describe( params[:query] )
    end

    def ajax_picklist
      has_permission('is_admin', halt:true)

      render json: SalesForce.client.picklist( params[:object], params[:field] )
    end

    def ajax_find
      has_permission('is_admin', halt:true)

      render json: json_escape(SalesForce.client.find(params[:what], params[:value], params[:field]).to_json)
    end
  end
end
