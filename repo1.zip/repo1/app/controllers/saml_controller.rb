class SamlController < ApplicationController
  skip_before_action :verify_authenticity_token

  def login
    request = OneLogin::RubySaml::Authrequest.new
    redirect_to(request.create(saml_settings))
  end

  def consume
    if Rails.env != 'test'
      response = OneLogin::RubySaml::Response.new(params[:SAMLResponse])
      response.settings = saml_settings

      # SAML response failed to validate
      raise StandardError, "Invalid SAML Response: #{response.errors}" unless response.is_valid?

      # Check to see if a user with the given Okta UID exists
      user = User.find_by(okta_id: response.attributes['Okta.ID'])
      if user.nil?
        # User did not exist with the Okta UID, look for one with the given login Email
        # If the user does not exist, then create it.
        user = User.find_or_create_by(email: response.attributes['Email'])
      end

      user.okta_id = response.attributes['Okta.ID']
      user.email = response.attributes['Email']
      user.first_name = response.attributes['FirstName']
      user.last_name = response.attributes['LastName']
      user.last_login = Time.now

      # Save the user entry, raise exception if it fails
      raise StandardError, 'Failed to save the user entry' unless user.save

      # If the user has been disabled then throw the Forbidden exception
      raise Forbidden, 'Your account has been disabled.' if user.is_disabled?

      # Successful authentication
      cookies.signed['current_user'] = user.id
      session[:user_id] = user.id
      flash[:success] = "Welcome #{user.name}...You have been successfully signed in."

      if Variable.get('admin_message').blank?
        redirect_to root_path
      else
        redirect_to welcome_path
      end

    # Fake the login for test environment
    else
      user = User.find_or_create_by(email: params['email'])
      user.last_name = params[:last_name]
      user.first_name = params[:first_name]
      user.last_login = Time.now
      user.save

      # Successful authentication
      cookies.signed['current_user'] = user.id
      session[:user_id] = user.id
      flash[:success] = "Welcome #{user.name}...You have been successfully signed in."

      redirect_to root_path
    end
  end

  private

  def saml_settings
    idp_metadata_parser = OneLogin::RubySaml::IdpMetadataParser.new
    settings = idp_metadata_parser.parse(idp_metadata)
    settings.assertion_consumer_service_url = "#{root_url}saml/consume"
    settings.name_identifier_format = 'urn:oasis:names:tc:SAML:2.0:nameid-format:emailAddress'
    settings.assertion_consumer_service_binding = 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST'

    settings
  end

  def idp_metadata
    Rails.application.credentials.okta[Rails.env.to_sym]
  end
end
