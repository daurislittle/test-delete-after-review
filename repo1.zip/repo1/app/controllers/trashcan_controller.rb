class TrashcanController < ApplicationController
  def index
    @wbs = WorkBreakdownStructure.where(is_deleted: true)
    @wbs_templates = WbsGroup.where(is_deleted:true)
    @sd_templates = ScopingDetailTemplate.where(is_deleted:true)
    end

  def remove_all
    has_permission('is_admin', halt:true)

    WorkBreakdownStructure.where(is_deleted: true).each do |content|
      content.destroy
    end

    WbsGroup.where(is_deleted:true).each do |content|
      content.destroy
    end

    ScopingDetailTemplate.where(is_deleted:true).each do |content|
      content.destroy
    end

    @wbs = WorkBreakdownStructure.where(is_deleted: true)
    @wbs_templates = WbsGroup.where(is_deleted: true)
    @sd_templates = ScopingDetailTemplate.where(is_deleted: true)
  end
end
