require 'will_paginate/array'

class WorkBreakdownStructuresController < ApplicationController
  ADDITIONAL_FLOAT_REGEX = /^\d+\./.freeze
  DEFAULT_PAGE_SIZE = 25.freeze
  PDF_ZOOM_LEVEL = 0.65.freeze

  # Maximum number of times to poll for information while publishing quote
  MAX_TRIES = Variable.get('calculated_max_tries', default_value: 20).to_i.freeze

  # Number of seconds to sleep while waiting for bulk lineitem job to complete,
  # can be fractional
  JOB_SLEEP_TIME = 1.0.freeze

  # Initial number of seconds to sleep while checking the uncalculated quote flag,
  # can be fractional
  CALC_SLEEP_TIME = Variable.get('calculated_sleep_time', default_value: 1).to_i.freeze

  HELPDESK_PORTAL_LINK = 'https://guidepointsecurity.atlassian.net/servicedesk/customer/portal/10'.freeze

  skip_before_action :verify_authenticity_token, only: [:create, :update]

  def index
    @page_title = "Work Breakdown Structures"

    @per_page       = params[:per_page] ? params[:per_page].to_i : DEFAULT_PAGE_SIZE
    @sort_by        = params.key?(:sort_by) ? params[:sort_by].to_sym : :updated_at
    @sort_direction = params.key?(:sort_direction) ? params[:sort_direction].to_sym : :desc
    search_for = "*"

    if params.key?(:search_for) && !params[:search_for].blank?
      search_for = params[:search_for]
    end

    if !WorkBreakdownStructure.all.empty?
      if has_permission('wbs_view', halt: false)
        @records = WorkBreakdownStructure.search search_for,
                                                 where: { is_deleted:false },
                                                 order: { @sort_by => @sort_direction },
                                                 page: params[:page],
                                                 per_page: @per_page

      elsif has_permission('wbs_view_own', halt: true)
        @records = WorkBreakdownStructure.search search_for,
                                                 where: {
                                                     is_deleted: false,
                                                     user_id: current_user.id
                                                 },
                                                 order: { @sort_by => @sort_direction },
                                                 page: params[:page],
                                                 per_page: @per_page
      end

      @total = @records.total_entries
    else
      @total = 0
      @records = WorkBreakdownStructure.all
    end

    @num_pages = @total / @per_page
    @num_pages += 1 if (@total % @per_page) != 0 || @num_pages.zero?

    @page = params[:page] ? params[:page].to_i : 1
    if @page < 1
      @page = 1
    elsif @page > @num_pages
      @page = @num_pages
    end

    @start = (@page - 1) * @per_page
    @search_for = params[:search_for]
    @view = params[:view] || 'table'

    respond_to do |format|
      format.html {
        @show_bottom_subnav = true
      }
      format.js {}
    end
  end

  def show
    Rails.logger.info('Trying to load WBS: '+params[:id])
    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?

    has_permission('wbs_view', halt: false) ||
    has_permission('wbs_view_own', condition: current_user == @wbs.user, halt: true)

    @page_title = "WBS #{@wbs.title}"

    respond_to do |format|
      format.html {
        @show_bottom_subnav = true

        unless @wbs.is_deleted?
          flash[:publishability] = []

          # Only check issues if the WBS hasn't been deleted.
          unless @wbs.pm_compliant?
            flash[:publishability] << {
              type: :warning,
              message: "Project Management hours are < #{WorkBreakdownStructure::PM_COMPLIANCE * 100}% of the engagement hours."
            }
          end

          warnings = @wbs.validate_publishability
          email = current_user.email
          if Rails.env == 'production'
            estimateowner_id = SalesForce::User.find_by(Email: email)&.id
          else
            estimateowner_id = SalesForce::User.find_by(Email: email + '.invalid')&.id
            if estimateowner_id.present?
              email = email + '.invalid'
            else
              estimateowner_id = SalesForce::User.find_by(Email: email)&.id
            end
          end
          warnings << 'No user record was found for the current user with email: ' + email unless estimateowner_id
          @publishable = warnings.empty?

          unless @publishable
            warning_string = warnings.map { |w| "<li class='font-italic'>#{w}</li>" }.join
            flash[:publishability] << if warnings.count > 1
                               {
                                 type: :warning,
                                 message: "You will not be able to publish this WBS until the following "\
                                          "#{warnings.count} items are corrected: "\
                                          "<ol style='padding-left:30px;'>#{warning_string}</ol>"
                               }
                             else
                               {
                                 type: :warning,
                                 message: "You will not be able to publish this WBS until the following "\
                                          "item is corrected: <ul style='padding-left:30px;'>#{warning_string}</ul>"
                               }
                             end
          end

          if !flash[:publishability].empty?
            flash.now[:publishability] = flash[:publishability].to_json
          else
            flash.delete(:publishability)
          end
          Rails.logger.info('Finished validations WBS: ' + params[:id])
          # Only update the recently viewed if not deleted
          viewed = RecentlyViewed.find_by(user: current_user, viewed_type: @wbs.class.name, viewed_id: @wbs.id)
          if !viewed.nil?
            viewed.update(title: @wbs.title, viewed_url: work_breakdown_structure_path(@wbs))
            viewed.touch

          else
            viewed = RecentlyViewed.new(
              user: current_user,
              title: @wbs.title,
              viewed_type: @wbs.class.name,
              viewed_id: @wbs.id,
              viewed_url: work_breakdown_structure_path(@wbs)
            )
            viewed.save
          end
        end
      }
      Rails.logger.info('Rendering show WBS: ' + params[:id])
      format.json {
        render json: {
          wbs: @wbs,
          primary_contact: SalesForce::Contact.fetch(@wbs.acct_primary_contact_id),
          secondary_contact: SalesForce::Contact.fetch(@wbs.acct_secondary_contact_id)
        }
      }
    end
  end

  def new
    has_permission('wbs_create', halt: true)

    if params.key? :opportunity
      opportunity = SalesForce::Opportunity.fetch params[:opportunity]
      @wbs = WorkBreakdownStructure.create_for(current_user, opportunity: opportunity)
    else
      @wbs = WorkBreakdownStructure.create_for(current_user)
    end

    @structures    = @wbs.practices.pluck(:project_structure)
    @opportunity   = @wbs.opportunity
    @wbs_groups    = @wbs.valid_templates.sort_by(&:name)
    @sdt_templates = @wbs.valid_sdt_templates.sort_by(&:name)
    @skus          = @wbs.valid_skus.sort_by(&:name)
    @skus_list     = WbsEntry.collectSkus(@skus)
    @skus_sd       = @skus + GenericSku.all
    @skus_sd_items = @skus_sd.map {|sku| [sku.name, sku.id, {'data-description' => (/\A\d+\z/.match(sku.id) ? 'Legacy Value - Please Change' : sku.description)}]}
    @contract_vehicles ||= ContractVehicle.contract_vehicles
    @gps_contacts ||= Corporate.gps_contacts.map { |person| ["#{person.LastName}, #{person.FirstName}", person.Id]}
    @line_items    = []
    @billing_rules = WorkBreakdownStructure.billing_rules(@wbs.contract_type)

    @wbs.billing_rule = @billing_rules.first.name if @wbs.billing_rule.blank? && @billing_rules.length == 1

    @page_title = 'New WBS'
    @show_bottom_subnav = true
  end

  def create
    has_permission('wbs_create', halt: true)

    param_adjustments

    @wbs = WorkBreakdownStructure.new(wbs_params)
    @wbs.user = current_user
    @wbs.updated_by = current_user
    @wbs.updated_at = DateTime.current
    @gps_contacts ||= Corporate.gps_contacts.map { |person| ["#{person.LastName}, #{person.FirstName}", person.Id]}
    if @wbs.save
      if @wbs.billing_address.kind == 'other'
        @wbs.billing_address.needs_update = true
        @wbs.billing_address.save
      end

      unless Rails.env.in?(['local_dev', 'test'])
        begin
          WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.watchlist
          ).submit_creation.deliver!

        rescue StandardError => e
          Rails.logger.error("Failed to send out the creation email: #{e.message}")
          Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")

          flash[:toast] = {
            type: :warning,
            message: "Successfully created wbs (#{@wbs.title}), but sending creating email failed: #{e.message}"
          }.to_json

          redirect_to @wbs

          return
        end
      end

      flash[:toast] = {
        type: :success,
        message: "Successfully created wbs: #{@wbs.title}"
      }.to_json

      redirect_to @wbs

    else
      @show_bottom_subnav = true
      @opportunity        = @wbs.opportunity
      @wbs_groups         = @wbs.valid_templates.sort_by(&:name)
      @sdt_templates      = @wbs.valid_sdt_templates.sort_by(&:name)
      @skus               = @wbs.valid_skus.sort_by(&:name)
      @skus_list          = WbsEntry.collectSkus(@skus)
      @skus_sd            = @skus + GenericSku.all
      @skus_sd_items = @skus_sd.map {|sku| [sku.name, sku.id, {'data-description' => (/\A\d+\z/.match(sku.id) ? 'Legacy Value - Please Change' : sku.description)}]}
      @contract_vehicles ||= ContractVehicle.contract_vehicles

      @structures         = @wbs.practices.pluck(:project_structure)

      @wbs.build_billing_address if @wbs.billing_address.nil?

      @billing_rules      = WorkBreakdownStructure.billing_rules(@wbs.contract_type)
      @page_title = 'New WBS'

      render 'new'
    end
  end

  def edit
    Rails.logger.info('Loading WBS for edit: ' + params[:id])
    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?
    Rails.logger.info('Loaded WBS for edit: ' + params[:id])
    # Check practice scoping teams for permission to edit.
    if !has_permission('is_admin', halt: false) &&
       !has_permission('wbs_edit', halt: false) &&
       !has_permission('wbs_edit_own', condition: current_user == @wbs.user, halt: false) &&
       !@wbs.can_edit?(current_user)
      raise NotAuthorized.new('You are not authorized to edit this WBS.')
    end

    Rails.logger.info('Authorized user for edit')

    @wbs.build_billing_address if @wbs.billing_address.nil?

    unless @wbs.extra.key? 'primary_contact'
      @wbs.extra['primary_contact'] = {
        name: '',
        title: '',
        phone: '',
        email: ''
      }
    end

    unless @wbs.extra.key? 'secondary_contact'
      @wbs.extra['secondary_contact'] = {
        name: '',
        title: '',
        phone: '',
        email: ''
      }
    end

    Rails.logger.info('Initialized billing address and contacts')
    @skus               = @wbs.valid_skus.sort_by(&:name)
    @skus_list          = WbsEntry.collectSkus(@skus)
    @skus_sd            = @skus + GenericSku.all
    @skus_sd_items = @skus_sd.map {|sku| [sku.name, sku.id, {'data-description' => (/\A\d+\z/.match(sku.id) ? 'Legacy Value - Please Change' : sku.description)}]}
    @contract_vehicles ||= ContractVehicle.contract_vehicles
    @gps_contacts ||= Corporate.gps_contacts.map { |person| ["#{person.LastName}, #{person.FirstName}", person.Id]}
    warnings = @wbs.validate_publishability_with_skus(@skus, @skus_sd)
    unless warnings.empty?
      checklist = warnings.map.with_index { |warning, i|
        "<div class='form-group form-check' style='margin-bottom:5px'>"\
            "<input id='fix-#{i}' type='checkbox' class='form-check-input'>"\
            "<label class='form-check-label font-italic' for='fix-#{i}'>#{warning}</label>"\
            "</div>"
      }.join

      flash.now[:publishability] = {
        type: :warning,
        message: "You will not be able to publish this WBS until the following #{warnings.count} "\
                 "#{'item'.pluralize(warnings.count)} are corrected: #{checklist}"
      }.to_json
    end
    Rails.logger.info('Checked publishability')

    @wbs_groups         = @wbs.valid_templates.sort_by(&:name)
    @sdt_templates      = @wbs.valid_sdt_templates.sort_by(&:name)
    @structures         = @wbs.practices.pluck(:project_structure)
    @billing_rules      = WorkBreakdownStructure.billing_rules(@wbs.contract_type)

    @wbs.billing_rule = @billing_rules.first.name if @wbs.billing_rule.blank? && @billing_rules.length == 1
    Rails.logger.info('Initialized groups, templates, structures, billing rules')
    @page_title = "Edit WBS: #{@wbs.title}"
    @show_bottom_subnav = true
    Rails.logger.info('EDIT END')
  end

  def update
    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?

    # Check practice scoping teams for permission to edit.
    if !has_permission('is_admin', halt: false) &&
       !has_permission('wbs_edit', halt: false) &&
       !has_permission('wbs_edit_own', condition: current_user == @wbs.user, halt: false) &&
       !@wbs.can_edit?(current_user)
      raise NotAuthorized.new('You are not authorized to edit this WBS.')
    end

    # If this WBS has been published create a 'version' of it
    unless @wbs.sfdc_quote_id.blank?
      @wbs.with_lock do
        @copy = @wbs.amoeba_dup
        @copy.sfdc_quote_id = @wbs.sfdc_quote_id
        @copy.created_at = @wbs.created_at
        @copy.updated_at = @wbs.updated_at
        @copy.user = @wbs.user
        @copy.updated_by = @wbs.updated_by

        WorkBreakdownStructure.record_timestamps = false
        result = @copy.save
        WorkBreakdownStructure.record_timestamps = true

        unless result
          flash[:toast] = {
            type: :error,
            message: 'There was a problem creating a new version of this WBS.'
          }.to_json

          redirect_to work_breakdown_structure_path(@wbs)
        end
      end
    end

    @wbs.sfdc_quote_id = nil

    # Save GPS contacts
    gps_primary_contact = @wbs.gps_primary_contact_id
    gps_secondary_contact = @wbs.gps_secondary_contact_id

    param_adjustments

    old_pids = []
    @wbs.practices.each do |p|
      old_pids << p.id
    end

    @wbs.assign_attributes(wbs_params)
    changes = @wbs.changed?

    if (!changes)
      @wbs.wbs_entries.each do |e|
        changes = e.changed?
        break if changes
      end
    end

    if (!changes)
      @wbs.scoping_details.each do |e|
        changes = e.changed?
        break if changes
      end
    end

    if !changes
      new_pids = []
      @wbs.practices.each do |p|
        new_pids << p.id
      end

      changes = Set.new(old_pids) != Set.new(new_pids)
      if (!changes && !wbs_params[:wbs_entries_attributes].nil?)
        wbs_params[:wbs_entries_attributes].keys.each do |key|
          if (wbs_params[:wbs_entries_attributes][key.to_sym][:_destroy] == "1" && !wbs_params[:wbs_entries_attributes][key.to_sym][:id].nil?)
            changes = true
            break
          end
        end
      end
      if (!changes && !wbs_params[:scoping_details_attributes].nil?)
        wbs_params[:scoping_details_attributes].keys.each do |key|
          if (wbs_params[:scoping_details_attributes][key.to_sym][:_destroy] == "1" && !wbs_params[:scoping_details_attributes][key.to_sym][:id].nil?)
            changes = true
            break
          end
        end
      end
    end

    @wbs.gps_primary_contact_id = gps_primary_contact if @wbs.gps_primary_contact_id.blank?
    @wbs.gps_secondary_contact_id = gps_secondary_contact if @wbs.gps_secondary_contact_id.blank?
    @wbs.billing_address.needs_update = true if @wbs.billing_address.changed? && @wbs.billing_address.kind == 'other'

    # Rails.logger.debug("Changes: #{difference}")
    ar_array = Array[@wbs, @wbs.billing_address] + @wbs.wbs_entries.load_target + @wbs.scoping_details.load_target
    if changes || ar_array.any? { |ar| ar.changed? }
      @wbs.updated_by = current_user
      @wbs.updated_at = DateTime.current
    end

    if @wbs.save
      flash[:toast] = {
        type: :success,
        message: 'Your WBS has been successfully updated.'
      }.to_json

      redirect_to work_breakdown_structure_path(@wbs)

    else
      @page_title         = "Edit WBS: #{@wbs.title}"
      @show_bottom_subnav = true
      @wbs_groups         = @wbs.valid_templates.sort_by(&:name)
      @sdt_templates      = @wbs.valid_sdt_templates.sort_by(&:name)
      @opportunity        = @wbs.opportunity
      @skus               = @wbs.valid_skus.sort_by(&:name)
      @skus_sd            = @skus + GenericSku.all
      @skus_sd_items = @skus_sd.map {|sku| [sku.name, sku.id, {'data-description' => (/\A\d+\z/.match(sku.id) ? 'Legacy Value - Please Change' : sku.description)}]}
      @contract_vehicles ||= ContractVehicle.contract_vehicles
      @gps_contacts ||= Corporate.gps_contacts.map { |person| ["#{person.LastName}, #{person.FirstName}", person.Id]}
      @structures         = @wbs.practices.pluck(:project_structure)
      @billing_rules      = WorkBreakdownStructure.billing_rules(@wbs.contract_type)

      render 'edit'
    end
  end

  def destroy
    @content = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @content.nil?

    has_permission('wbs_delete', halt: false) ||
    has_permission('wbs_delete_own', condition: current_user == @content.user, halt: true)

    RecentlyViewed.where(viewed_id: @content.id, viewed_type: @content.class.name).each(&:destroy)

    if params.key? :permanent
      @content.destroy

      flash[:toast] = {
        type: :success,
        message: "Content [#{@content.title}] has been permanently destroyed."
      }.to_json
      redirect_to trashcan_path

    else
      @content.is_deleted = true
      if @content.save
        # TODO: Soft delete quotes...

        flash[:toast] = {
          type: :success,
          message: "Content [#{@content.title}] was moved to the trashcan."
        }.to_json

        if @content.has_opportunity?
          redirect_to opportunity_path(@content.opportunity.GP_Opportunity_Number__c.nil? ? @content.opportunity.Id : @content.opportunity.GP_Opportunity_Number__c)
        else
          redirect_to work_breakdown_structures_path
        end

      else
        flash[:toast] = {
          type: :error,
          message: "There was an issue moving content [#{@content.title}] to the trashcan."
        }.to_json
      end
    end
  end

  def mark_all
    params.require(:id)

    @wbs = WorkBreakdownStructure.find_by(id: params[:id])
    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?

    has_permission('wbs_delete', halt: false) ||
    has_permission('wbs_delete_own', condition: current_user == @wbs.user, halt: true)

    respond_to do |format|
      format.js {}
    end
  end

  def select_opportunity
    if params.key?(:id) && !params[:id].blank?
      @wbs = WorkBreakdownStructure.find_by(id: params[:id])
      @wbs.opportunity = SalesForce::Opportunity.fetch(params[:opportunity_id])

    else
      @wbs = WorkBreakdownStructure.create_for(current_user, opportunity: SalesForce::Opportunity.fetch(params[:opportunity_id]))
    end

    @structures  = @wbs.practices.pluck(:project_structure)
    @opportunity = @wbs.opportunity
    @billing_rules = WorkBreakdownStructure.billing_rules(@wbs.contract_type)
    @skus = @wbs.valid_skus.sort_by(&:name)
    @skus_list = WbsEntry.collectSkus(@skus)
    @skus_sd = @skus + GenericSku.all
    @skus_sd_items = @skus_sd.map {|sku| [sku.name, sku.id, {'data-description' => (/\A\d+\z/.match(sku.id) ? 'Legacy Value - Please Change' : sku.description)}]}
    @contract_vehicles ||= ContractVehicle.contract_vehicles
    @gps_contacts ||= Corporate.gps_contacts.map { |person| ["#{person.LastName}, #{person.FirstName}", person.Id]}
    @templates = @wbs.valid_templates
    @sdt_templates = @wbs.valid_sdt_templates
    @wbs.billing_rule = @billing_rules.first.name if @wbs.billing_rule.blank? && @billing_rules.length == 1
  end

=begin No longer Supported, but keeping for now...
  def from_quote
    if !params.key?(:quote_id) || params[:quote_id].blank?
      # error: Missing key
    end

    quote = SalesForce.load(params[:quote_id])
    unless quote.valid?
      flash[:toast] = {
        type: :error,
        message: 'Invalid quote requested...'
      }.to_json
    end

    wbs = WorkBreakdownStructure.for_quote(params[:quote_id])
    unless wbs.nil?
      # error: WBS already exists...
      flash[:toast] = {
        type: :error,
        message: 'A WBS already exists for this quote.'
      }.to_json

      redirect_to opportunity_path(quote.OpportunityId)
      return
    end

    @wbs = WorkBreakdownStructure::from_quote(quote)
    @wbs.user = current_user
    @wbs.scoped_by = current_user.corporate if @wbs.scoped_by.nil?

    if @wbs.save
      redirect_to work_breakdown_structure_path(@wbs)
    else
      message = 'There was a problem creating the WBS from the given quote.'

      @wbs.errors.each do |attr, error|
        message << "#{attr}: #{error}  "
      end

      flash[:toast] = {
        type: :error,
        message: message
      }.to_json

      redirect_to opportunity_path(quote.OpportunityId)
    end
  end
=end

  def restore
    @content = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @content.nil?

    has_permission('wbs_delete', halt: false) ||
    has_permission('wbs_delete_own', condition: @content.user == current_user, halt: true)

    @content.is_deleted = false
    if @content.save
      flash[:toast] = {
        type: :success,
        message: "WBS [#{@content.title}] has been restored."
      }.to_json

      redirect_to @content

    else
      flash[:toast] = {
        type: :error,
        message: "There was an error restoring WBS [#{@content.title}]."
      }.to_json
      redirect_to trashcan_path
    end
  end

  def copy
    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?

    has_permission('wbs_view', halt: false) ||
    has_permission('wbs_view_own', condition: current_user == @wbs.user, halt: true)

    has_permission('wbs_create', halt: true)

    @copy = @wbs.amoeba_dup
    @copy.user = current_user
    @copy.updated_by = current_user
    @copy.updated_at = DateTime.current
    if @copy.save
      flash[:toast] = {
        type: :success,
        message: "Successfully created copy of '#{@wbs.title}'"
      }.to_json
      redirect_to work_breakdown_structure_path(@copy)

    else
      @show_bottom_subnav = true
      @opportunity        = @copy.opportunity
      @structures         = @copy.practices.pluck(:name)
      @wbs_groups         = @copy.valid_templates.sort_by(&:name)
      @skus               = @copy.valid_skus.sort_by(&:name)
      @skus_list          = WbsEntry.collectSkus(@skus)
      @skus_sd            = @skus + GenericSku.all
      @skus_sd_items = @skus_sd.map {|sku| [sku.name, sku.id, {'data-description' => (/\A\d+\z/.match(sku.id) ? 'Legacy Value - Please Change' : sku.description)}]}
      @contract_vehicles ||= ContractVehicle.contract_vehicles
      @gps_contacts ||= Corporate.gps_contacts.map { |person| ["#{person.LastName}, #{person.FirstName}", person.Id]}
      @line_items         = @copy.wbs_entries.sort { |a, b| a.ordinal <= b.ordinal }

      render 'new'
    end
  end

  def print
    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?

    has_permission('wbs_view', halt: false) ||
    has_permission('wbs_view_own', condition: current_user == @wbs.user, halt: true)

    render pdf: @wbs.title, orientation: 'Landscape', zoom: PDF_ZOOM_LEVEL
  end

  def submit
    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?

    has_permission('wbs_edit', halt: false) ||
    has_permission('wbs_edit_own', condition: current_user == @wbs.user, halt: true)

    begin
      WorkBreakdownStructureMailer.with(
        request: @wbs,
        url: work_breakdown_structure_url(@wbs),
        to: @wbs.watchlist
      ).submit_creation.deliver!
    rescue StandardError => e
      Rails.logger.error("Failed to send out the creation email: #{e.message}")
      Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
    end

    respond_to do |format|
      format.js {}
    end
  end


  def publish
    params.require(:id)
    Rails.logger.info('Starting publish WBS: ' + params[:id])

    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    if @wbs.nil?
      flash.now[:toast] = {
        type: :warning,
        message: "The requested WBS does not exist."
      }.to_json

      return
    end

    if !has_permission('wbs_edit', halt: false) &&
        !has_permission('wbs_edit_own', condition: current_user == @wbs.user, halt: false)
      flash.now[:toast] = {
        type: :warning,
        message: "You do not have permission to publish this WBS."
      }.to_json

      return
    end

    # Is this WBS publishable?  If not, then configure the toast to alert the user to the issues.
    problems = @wbs.validate_publishability
    unless problems.empty?
      checklist = problems.map { |w| "<li class='font-italic'>#{w}</li>" }.join

      flash.now[:toast] = {
        type: :warning,
        message: "You will not be able to publish this WBS until the following "\
                     "#{problems.count} #{'item'.pluralize(problems.count)} are corrected: "\
                     "<ul>#{checklist}</ul>"
      }.to_json

      return
    end

    Rails.logger.info("Beginning publish of WBS #{@wbs.id}.")

    # unsync code was removed on 01/30/2025 for "ITAPP-11859 - At Risk Opp Needs Approval" Jira Ticket
    # unsync code was re-instated on 02/21/2025 as it did not fix the issue (testing in QA) -- this code was *never* removed in PROD

    # Un-sync any quotes that already exist that are synced
    quotes = SalesForce::SBQQ__Quote.where(SBQQ__Opportunity2__c: @wbs.sfdc_opportunity_id).refresh
    quotes.each do |quote|
      if quote.syncing?
        quote.cogs_primary_flag = false
        quote.save
      end
    end

    # Gather additional information
    expiration_date = Date.today + 30

    @wbs.opportunity.update(
      expenses_billable: @wbs.expenses_billable? ? 'Yes' : 'No',
      vendor_delivered_services: @wbs.vendor_delivered_services? ? 'Yes' : 'No',
      contract_type: @wbs.contract_type,
      project_structure: @wbs.project_structure,
      contract_vehicle: @wbs.contract_vehicle
    )

    unless @wbs.opportunity.save
      # Failed the save the opportunity, so notify the user
      message = "Failed to update the associated opportunity #{@wbs.opportunity.Id}: #{@wbs.opportunity.last_error}. "\
                "No quote was created in Salesforce."

      # Send emails...do not send in local dev and test environments
      unless Rails.env.in?(['local_dev', 'test'])
        begin
          WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.failure_email_list,
            message: message
          ).submit_publish_failure.deliver_later

        rescue StandardError => e
          Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
          Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
        end
      end

      flash.now[:toast] = {
        type: :error,
        message: message
      }.to_json

      # Log the problem and halt
      Rails.logger.error(message)
      return
    end

    Rails.logger.info('Building quote WBS: ' + params[:id])

    # Build the quote object
    quote = SalesForce::SBQQ__Quote.create(
      name: @wbs.title,
      record_type_id: SalesForce::SBQQ__Quote.record_type_services_id,
      expiration_date: expiration_date.strftime('%Y-%m-%d'),
      acct_primary_contact_id: @wbs.acct_primary_contact_id != 'not-listed' ? @wbs.acct_primary_contact_id : '',
      acct_secondary_contact_id: @wbs.acct_secondary_contact_id != 'not-listed' ? @wbs.acct_secondary_contact_id : '',
      opportunity_id: @wbs.opportunity.id,
      pricebook_id: @wbs.opportunity.pricebook_id,
      cogs_status: @wbs.actions_required.blank? ? 'Reviewed / Approved' : 'Under Review',
      psl_owner_id: @wbs.psl_owner.id,
      psl_team: @wbs.practice.scoping_team[0],
      billing_name: @wbs.bill_to_account.name,
      billing_street: "#{@wbs.billing_address.address1} #{@wbs.billing_address.address2}".strip,
      billing_city: @wbs.billing_address.city,
      billing_state: @wbs.billing_address.state,
      billing_postal_code: @wbs.billing_address.postalcode,
      billing_country: @wbs.billing_address.country,
      cogs_action_required: @wbs.actions_required,
      wbs_link: work_breakdown_structure_url(@wbs),
      cogs_primary_flag: false,
      line_items_grouped: true
    )

    owner = SalesForce::User.find_by(Email: current_user.email + '.invalid') if Rails.env != 'production'
    owner = SalesForce::User.find_by(Email: current_user.email) unless owner
    unless owner.nil?
      quote.OwnerId = owner.Id
    end

    # Attempt to create the quote in Salesforce
    unless quote.save
      # Quote save failed so notify the user

      # Send emails...do not send in local dev and test environments
      unless Rails.env.in?(['local_dev', 'test'])
        begin
          WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.failure_email_list,
            message: "There was an issue creating the Salesforce quote: #{quote.last_error}"
          ).submit_publish_failure.deliver_later

        rescue StandardError => e
          Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
          Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
        end
      end

      flash.now[:toast] = {
        type: :error,
        message: "There was an issue creating the Salesforce quote: #{quote.last_error}"
      }.to_json

      # Log the problem and halt
      Rails.logger.error("Failed to create the Salesforce quote: #{quote.last_error}")
      return
    end

    # Update the WBS in the database
    @wbs.sfdc_quote_id = quote.id
    @wbs.billing_address.needs_update = false

    # If the save of the WBS fails, then fail the process
    unless @wbs.save
      # Delete the quote on Salesforce
      # Rails.logger.error("Failed to delete quote #{quote.id}") if !quote.delete

      # Create alert to the user
      message = "There was an issue updating the WBS with the quote created in Salesforce: "\
                "<ul>#{@wbs.errors.full_messages.map{|item| "<li>#{item}</li>"}.join}</ul>"

      # Send emails...do not send in local dev and test environments
      unless Rails.env.in?(['local_dev', 'test'])
        begin
          WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.failure_email_list,
            message: message
          ).submit_publish_failure.deliver_later

        rescue StandardError => e
          Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
          Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
        end
      end

      flash.now[:toast] = {
        type: :error,
        message: message
      }.to_json

      # Log the problem and halt
      Rails.logger.error(
        "There was an issue updating the WBS with the published quote: #{@wbs.errors.full_messages.join(",\n")}"
      )
      return
    end

    quoteLineGroup = SalesForce::SBQQ__QuoteLineGroup.create(
      name: "Services",
      quote_id: quote.id,
      category: "Line Details",
      number: 1,
      booking_date: @wbs.opportunity.closedate.blank? ? nil : @wbs.opportunity.closedate.to_s.dup
    )
    # Attempt to create the quoteLineGroup in Salesforce
    unless quoteLineGroup.save
      # QuoteLineGroup save failed so notify the user

      # Send emails...do not send in local dev and test environments
      unless Rails.env.in?(['local_dev', 'test'])
        begin
          WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.failure_email_list,
            message: "There was an issue creating the Salesforce quote line group: #{quoteLineGroup.last_error}"
          ).submit_publish_failure.deliver_later

        rescue StandardError => e
          Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
          Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
        end
      end

      flash.now[:toast] = {
        type: :error,
        message: "There was an issue creating the Salesforce quote line group: #{quoteLineGroup.last_error}"
      }.to_json

      # Log the problem and halt
      Rails.logger.error("Failed to create the Salesforce quote line group: #{quoteLineGroup.last_error}")
      return
    end

    Rails.logger.info('Starting to build quote lines WBS: ' + params[:id])

    # Collect the line items as SF quote lines
    entries = []
    @wbs.wbs_entries.order(:ordinal).each_with_index do |entry, index|
      quote_line = SalesForce::SBQQ__QuoteLine.create(
        quote_id: quote.Id,
        product_id: entry.pricebook_entry.product_id,
        pricebook_entry_id: entry.pricebook_entry.id,
        quantity: entry.total_hours,
        total_cost: (entry.internal_hourly_rate * entry.total_hours),
        client_unit_price: entry.billable_rate,
        msrp: entry.billable_rate,
        line_item_description: entry.task,
        labor_category: entry.gsa_labor_category.name,
        # comments: entry.notes.gsub('<', '&lt;').gsub('>', '&gt;').gsub("\r\n", '<br>'),
        line_number: index + 1,
        unit_cost: entry.billable_rate,
        group_id: quoteLineGroup.id
      )

      # If there was a line item contract vehicle given, then add it in
      unless entry.contract_vehicle.blank?
        quote_line.contract_vehicle = entry.contract_vehicle
      end

      entries << quote_line.to_h
    end

    # Use the Salesforce Bulk API to create the line items
    errors = []
    unless entries.count.zero?
      begin
        start_time = Time.now
        result = SalesForce.client.bulk.create('SBQQ__QuoteLine__c', entries, true)

        # Monitor the job
        number_batches = result['numberBatchesTotal'][0]
        job = SalesForce.client.bulk.job_from_id(result['id'][0])

        tries = 1
        status = job.check_job_status
        while status['numberBatchesCompleted'][0] != number_batches && tries < MAX_TRIES
          Rails.logger.warn("Job has not completed yet after #{ActiveSupport::Duration.build(Time.now - start_time).inspect}...")

          sleep JOB_SLEEP_TIME
          tries += 1
          status = job.check_job_status
        end

        if tries == MAX_TRIES
          Rails.logger.warn("It appears that the SF bulk did not complete after #{MAX_TRIES} checks.")
        else
          Rails.logger.info("Salesforce bulk job completed within #{ActiveSupport::Duration.build(Time.now - start_time).inspect}")
        end

        # Check for errors
        if result.key?('batches')
          result['batches'].each do |batch|
            unless batch['numberRecordsFailed'][0].to_i.zero?
              #num_errors += batch['numberRecordsFailed'][0].to_i

              # Find the failures
              batch['response'].each do |batch_response|
                if batch_response.key?('errors')
                  batch_response['errors'].each do |error|
                    errors << error['message'][0]
                  end
                end
              end
            end
          end
        end

      rescue SalesforceBulkApi::Job::SalesforceException => e
        # Delete the quote in SF
        # Rails.logger.error("There was a problem deleting the quote: #{quote.id}") unless quote.delete

        message = "There was a problem creating the quote line items in Salesforce: #{e.message}. "\
                  "Please contact the help desk <a href='#{HELPDESK_PORTAL_LINK}' target='_blank'>Help Desk</a>."

        # Send emails...do not send in local dev and test environments
        unless Rails.env.in?(['local_dev', 'test'])
          begin
            WorkBreakdownStructureMailer.with(
              request: @wbs,
              url: work_breakdown_structure_url(@wbs),
              to: @wbs.failure_email_list,
              message: message
            ).submit_publish_failure.deliver_later
          rescue StandardError => e
            Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
            Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
          end
        end

        # Notify the user
        flash.now[:toast] = {
          type: :error,
          message: message
        }.to_json

        # Log the problem and halt
        SalesForce.logger.error("There was a problem publishing the WBS line items: #{e.message}.")
        return
      end
    end

    Rails.logger.info("Quote line bulk API submission finished.")

    # If there were errors publishing the line items...
    unless errors.empty?
      # Delete the quote in SF
      # Rails.logger.error("There was a problem deleting the quote: #{quote.id}") unless quote.delete

      # Notify the user
      list_string = errors.map { |warning| "<li>#{warning}</li>" }.join

      # Send emails...do not send in local dev and test environments
      unless Rails.env.in?(['local_dev', 'test'])
        begin
          WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.failure_email_list,
            message: "There were errors creating the quote line items in Salesforce: <ul>#{list_string}</ul>"
          ).submit_publish_failure.deliver_later

        rescue StandardError => e
          Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
          Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
        end
      end

      flash.now[:toast] = {
        type: :error,
        message: "There were errors creating the quote line items in Salesforce: <ul>#{list_string}</ul>"
      }.to_json

      # Log the problem(s) and halt
      Rails.logger.error("There was a problem publishing the WBS (#{@wbs.id}): #{errors.join(",\n")}")
      return
    end

    start_time = Time.now

    sleep 8
    # Poll for the Quote uncalculated field...
    tries = 0
    while quote.uncalculated && tries < MAX_TRIES
      sleep CALC_SLEEP_TIME + Math.exp(tries * 0.25)

      Rails.logger.info("Checking uncalculated flag on quote [" + quote.id.to_s + "] for the " + (tries + 1).to_s + " time.")

      tries += 1
      quote.refresh
    end

    if quote.uncalculated
      Rails.logger.warn("Quote is still uncalculated after #{MAX_TRIES} tries.")

      # Send emails...do not send in local dev and test environments
      unless Rails.env.in?(['local_dev', 'test'])
        begin
          WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.failure_email_list,
            message: "The Salesforce quote was created but did not calculate within the COGS max time."
          ).submit_publish_failure.deliver_later

        rescue StandardError => e
          Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
          Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
        end
      end

      flash.now[:toast] << {
        type: :warning,
        message: "Salesforce calculation timed out. Please contact the IT Help Desk."
      }
      return
    else
      Rails.logger.info("Quote calculated in approximately #{ActiveSupport::Duration.build(Time.now - start_time).inspect}")
    end

    # Validate WBS with quote
    issues = @wbs.validate_with_quote(quote)
    unless issues.empty?
      # Delete the SF quote
      #Rails.logger.error("There was a problem deleting the quote: #{quote.id}") unless quote.delete

      # Notify the user
      issue_string = issues.map{ |issue| "<li>#{issue}</li>" }.join

      # Send emails...do not send in local dev and test environments
      unless Rails.env.in?(['local_dev', 'test'])
        begin
          WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.failure_email_list,
            message: "The Salesforce quote was created but failed validation and was not synced. <ul>#{issue_string}</ul>"
          ).submit_publish_failure.deliver_later
        rescue StandardError => e
          Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
          Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
        end
      end

      flash.now[:toast] = {
        type: :error,
        message: "The Salesforce quote was published but failed validation and was not synced. <ul>#{issue_string}</ul>"
      }.to_json

      # Log the problem and halt
      Rails.logger.error(
        "The Salesforce quote #{quote.id} was published but failed validation and was not synced for WBS (#{@wbs.id}). #{issues.join(', ')}"
      )
      return
    end

    # Update the sync flag
    if @wbs.actions_required.blank?
      quote.cogs_primary_flag = true

      unless quote.save

        # Send emails...do not send in local dev and test environments
        unless Rails.env.in?(['local_dev', 'test'])
          begin
            WorkBreakdownStructureMailer.with(
              request: @wbs,
              url: work_breakdown_structure_url(@wbs),
              to: @wbs.failure_email_list,
              message: "There was an error syncing the Salesforce quote: #{quote.last_error}."
            ).submit_publish_failure.deliver!

          rescue StandardError => e
            Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
            Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
          end
        end

        flash.now[:toast] = {
          type: :error,
          message: "There was an error syncing the Salesforce quote: #{quote.last_error}."
        }.to_json

        Rails.logger.error("Failed to set the sync flag for WBS:Quote (#{@wbs.id}:#{quote.id}): #{quote.last_error}")
        return
      end
    end

    estimateowner_id = SalesForce::User.find_by(Email: current_user.email + '.invalid')&.id if Rails.env != 'production'
    estimateowner_id = SalesForce::User.find_by(Email: current_user.email)&.id unless estimateowner_id
    @wbs.opportunity.update(
      estimateowner: estimateowner_id
    )

    unless estimateowner.present? && @wbs.opportunity.save
      # Send emails...do not send in local dev and test environments
      unless Rails.env.in?(['local_dev', 'test'])
        begin
          WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.failure_email_list,
            message: "There was an error setting the Estimate Owner on the Opportunity."
          ).submit_publish_failure.deliver!

        rescue StandardError => e
          Rails.logger.error("Failed to send email that there was an error setting the estimate owner on the Opportunity: #{e.message}")
          Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
        end
      end

      flash.now[:toast] = {
        type: :error,
        message: "There was an error setting the Estimate Owner on the Opportunity."
      }.to_json

      Rails.logger.error("Failed to set the estimate owner on the Opportunity")
      return
    end

      # Update the title of the recently viewed if it exists.
    viewed = RecentlyViewed.find_by(user: current_user, viewed_type: @wbs.class.name, viewed_id: @wbs.id)
    unless viewed.nil?
      viewed.update(title: @wbs.title)
    end

    # Initialize the flash toast as an array...
    flash[:toast] = []

    # Create the PDF and link it to the quote
    begin
      pdf = to_pdf(@wbs)

      v = SalesForce::ContentVersion.from_file(@wbs.title, pdf)
      if v.valid?
        v.refresh # Refresh to get the content document
        link = v.document.link_to(quote) if v.document.valid?

        # If linking the version to the document failed...
        unless link.valid?

          # Send emails...do not send in local dev and test environments
          unless Rails.env.in?(['local_dev', 'test'])
            begin
              WorkBreakdownStructureMailer.with(
                request: @wbs,
                url: work_breakdown_structure_url(@wbs),
                to: @wbs.failure_email_list,
                message: 'There was a problem publishing the quote: Failed to link the PDF content to the quote in Salesforce.'
              ).submit_publish_failure.deliver_later

            rescue StandardError => e
              Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
              Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
            end
          end

          # Notify the user
          flash[:toast] << {
            type: :error,
            message: 'There was a problem publishing the quote: Failed to link the PDF content to the quote in Salesforce.'
          }

          # Log the problem
          Rails.logger.error("Failed to link the PDF to the quote WBS:Quote (#{@wbs.id}:#{quote.id}).")
        end

        # Creating the document failed
      else

        # Send emails...do not send in local dev and test environments
        unless Rails.env.in?(['local_dev', 'test'])
          begin
            WorkBreakdownStructureMailer.with(
              request: @wbs,
              url: work_breakdown_structure_url(@wbs),
              to: @wbs.failure_email_list,
              message: 'There was a problem publishing the quote: Failed to create the PDF document in Salesforce.'
            ).submit_publish_failure.deliver_later

          rescue StandardError => e
            Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
            Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
          end
        end

        # Notify the user
        flash[:toast] << {
          type: :error,
          message: 'There was a problem publishing the quote: Failed to create the PDF document in Salesforce.'
        }

        # Log the problem
        Rails.logger.error("Failed to create the PDF document in Saleforce for WBS:Quote (#{@wbs.id}:#{quote.id}).")
      end

    rescue StandardError => e

      # Send emails...do not send in local dev and test environments
      unless Rails.env.in?(['local_dev', 'test'])
        begin
          WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.failure_email_list,
            message: "Failed to create and attach the PDF to the quote: #{e.message}"
          ).submit_publish_failure.deliver!

        rescue StandardError => e
          Rails.logger.error("Failed to send out the publish failure email: #{e.message}")
          Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
        end
      end

      # Notify the user
      flash[:toast] << {
        type: :error,
        message: "Failed to create and attach the PDF to the quote: #{e.message}"
      }

      # Log the problem
      Rails.logger.error("Failed to create and attach the PDF WBS:Quote (#{@wbs.id}:#{quote.id}): #{e.message}")
    end

    # Send emails...do not send in local dev and test environments
    #unless Rails.env.in?(['local_dev', 'test'])
      # Only include the SOS and AE in production
      extra = if Rails.env == 'production'
                { sos: true, ae: true }
              else
                {}
              end

      begin
        WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.watchlist(**extra)
        ).submit_published.deliver!

      rescue StandardError => e
        Rails.logger.error("Failed to send out the published email: #{e.message}")
        Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")

        flash[:toast] << {
          type: :warning,
          message: "Failed to send notification: #{e.message}"
        }
      end

      # If actions were required, send out additional email...
      unless @wbs.actions_required.blank?
        begin
          WorkBreakdownStructureMailer.with(
            request: @wbs,
            url: work_breakdown_structure_url(@wbs),
            to: @wbs.watchlist(**extra)
          ).submit_action_required.deliver!

        rescue StandardError => e
          Rails.logger.error("Failed to send out the actions required email: #{e.message}")
          Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")

          flash[:toast] << {
            type: :warning,
            message: "Failed to send action required notification: #{e.message}"
          }
        end
      end
      #end

    quote.refresh
    if (!quote.is_syncing)
      Rails.logger.info("Quote is expected to be true but appears false for quote with ID: #{quote.Id} on WBS #{@wbs.id}")
    end

    @wbs.published_at = DateTime.current
    @wbs.published_by = current_user
    @wbs.updated_by = current_user
    @wbs.save

    # Publish succeed?
    if flash[:toast].empty?
      flash[:toast] = {
        type: :success,
        message: 'The Salesforce quote for this WBS has been successfully published.'
      }
    end

    flash.now[:toast] = flash[:toast].to_json

  rescue StandardError => e
    Rails.logger.error("Something went really wrong: #{e.message}")
    Rails.logger.error("Something went really wrong: #{e.backtrace.join("\n")}")

    flash.now[:toast] = {
      type: :error,
      message: 'Unexpected error. Please contact a COGS Administrator.'
    }.to_json

    unless Rails.env.in?(['local_dev', 'test'])
      begin
        WorkBreakdownStructureMailer.with(
          request: @wbs,
          url: work_breakdown_structure_url(@wbs),
          to: @wbs.failure_email_list,
          message: "Something really bad happened trying to publish a quote: #{e.message} \n#{e.backtrace.join("\n")}"
        ).submit_publish_failure.deliver!

      rescue StandardError => e
        Rails.logger.error("Failed to send out the something bad happened email: #{e.message}")
        Rails.logger.error("Stacktrace: #{e.backtrace.join("\n")}")
      end
    end
  end

  def validate
    params.require(:id)

    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?

    has_permission('wbs_view', halt: false) ||
    has_permission('wbs_view_own', condition: current_user == @wbs.user, halt: true)

    unless @wbs.quote?
      flash[:toast] = {
        type: :success,
        message: 'The WBS has not been published.'
      }.to_json

      return
    end

    issues = @wbs.validate_with_quote(@wbs.quote)
    if issues.empty?
      flash.now[:toast] = {
        type: :success,
        message: 'The WBS matches the published quote.'
      }.to_json
    else
      issue_string = issues.map {|issue| "<li>#{issue}</li>" }.join
      issue_string = issue_string.gsub(/[\r\n]+/m, " ")
      flash.now[:toast] = {
        type: :error,
        message: "The WBS does not match the published quote.  The following issues have been found:"\
                 "<ul>#{issue_string}</ul>"
      }.to_json
    end

    respond_to do |format|
      format.js {}
    end
  end

  def refresh
    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?

    has_permission('wbs_view', halt: false) ||
    has_permission('wbs_view_own', condition: current_user == @wbs.user, halt: true)

    respond_to do |format|
      format.js {}
    end
  end

  def quote
    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?

    has_permission('wbs_view', halt: false) ||
    has_permission('wbs_view_own', condition: current_user == @wbs.user, halt: true)

    if @wbs.sfdc_quote_id.blank?
      flash.now[:toast] = {
        type: :success,
        message: "WBS has not been published.  There is nothing to refresh."
      }.to_json

    else
      @quote = @wbs.quote(refresh: true)
      if @quote.nil?
        flash.now[:toast] = {
          type: :error,
          message: "Salesforce did not locate a quote with id #{@wbs.sfdc_quote_id}."
        }.to_json
      end
    end

    respond_to do |format|
      format.js {}
    end
  end

  def for_quote
    raise ActiveRecord::RoutingError.new('The requested page does not exist.') unless params.key?(:quote_id)

    @wbs = WorkBreakdownStructure.find_by(sfdc_quote_id: params[:quote_id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?

    redirect_to @wbs
  end

  def valid_skus
    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    return if @wbs.nil?

    has_permission('wbs_view', halt: false) ||
    has_permission('wbs_view_own', condition: current_user == @wbs.user, halt: true)

    respond_to do |format|
      format.json { render json: @wbs.valid_skus }
    end
  end

  def calculate
    results = {}

    @wbs = WorkBreakdownStructure.find_by(id: params[:id])
    unless @wbs.nil?
      has_permission('wbs_view', halt: false) ||
      has_permission('wbs_view_own', condition: current_user == @wbs.user, halt: true)

      results = {
        total_hours:      0,
        total_revenue:    0.0,
        total_internal:   0.0,
        total_profit:     0.0,
        total_profit_pct: 0.0
      }

      results = @wbs.pm_and_engagement_hours if params.include?(:pm)
      results.merge!(@wbs.total_lines(params[:sum])) if params.include?(:sum)
    end

    respond_to do |format|
      format.json { render json: results }
    end
  end

  def add_line
    has_permission('wbs_create', halt: true)

    @wbs = WorkBreakdownStructure.new

    practices     = Practice.where(id: params[:practices])
    @skus = practices.map(&:skus).flatten.sort_by(&:name) unless practices.empty?
    @skus_list          = WbsEntry.collectSkus(@skus)
    @skus_sd      = (@skus.nil? ? [] : @skus) + GenericSku.all
    @skus_sd_items = @skus_sd.map {|sku| [sku.name, sku.id, {'data-description' => (/\A\d+\z/.match(sku.id) ? 'Legacy Value - Please Change' : sku.description)}]}
    @contract_vehicles ||= ContractVehicle.contract_vehicles
    @gps_contacts ||= Corporate.gps_contacts.map { |person| ["#{person.LastName}, #{person.FirstName}", person.Id]}
    gsa           = GsaLaborCategory.find_by_name('Security Consultant')
    @region       = params[:region]
    internal_rate = Variable.get('default_internal_rate')

    dfir = Practice.for_structure('Incident Response')
    internal_rate = Variable.get('default_dfir_internal_rate') if !dfir.nil? && dfir.sku?(params[:sku])

    if params[:sku] == 'IA-SA-RSE'
      billable_rate = 275.00
    else
      billable_rate = gsa.default_billrate(region: params[:region], contract_vehicle: params[:contract_vehicle])
    end

    @new_line = @wbs.wbs_entries.build(
      sku: params[:sku],
      gsa_labor_category: gsa,
      billable_rate: billable_rate,
      internal_hourly_rate: internal_rate
    )

    respond_to do |format|
      format.js {}
    end
  end

  def change_sku
    @wbs = WorkBreakdownStructure.find_by(id: params[:id])

    raise ActiveRecord::RecordNotFound.new('The requested WBS does not exist.') if @wbs.nil?

    has_permission('wbs_view', halt: false) ||
    has_permission('wbs_view_own', condition: current_user == @wbs.user, halt: true)

    @line_item_id = params[:line_item_id]
    @internal_rate = Variable.get('default_internal_rate')

    dfir = Practice.for_structure('Incident Response')
    @internal_rate = Variable.get('default_dfir_internal_rate') if !dfir.nil? && dfir.sku?(params[:sku])

    lc = GsaLaborCategory.find_by(id: params[:gsa_labor_category_id]);
    if (!lc.nil? &&
      (lc.name == "GuidePoint SOAR Services-Standard" ||
        lc.name == "GuidePoint SOAR Services-Remote" ||
        lc.name == "GuidePoint SOAR Services-Premium" ||
        lc.name == "GuidePoint Splunk Services-Standard" ||
        lc.name == "GuidePoint Splunk Services-Remote" ||
        lc.name == "GuidePoint Splunk Services-Premium" ||
        lc.name == "GuidePoint F5 Networks Services-Standard" ||
        lc.name == "GuidePoint F5 Networks Services-Remote" ||
        lc.name == "GuidePoint F5 Networks Services-Premium"))
      @internal_rate = @internal_rate * 8
    end

    respond_to do |format|
      format.js {}
    end
  end

  def add_group
    has_permission('wbs_create', halt: true)

    @wbs = WorkBreakdownStructure.new

    practices = Practice.where(id: params[:practices])
    @skus = practices.map(&:skus).flatten.sort_by(&:name) unless practices.empty?
    @skus_list = WbsEntry.collectSkus(@skus)
    @skus_sd = (@skus.nil? ? [] : @skus) + GenericSku.all
    @skus_sd_items = @skus_sd.map {|sku| [sku.name, sku.id, {'data-description' => (/\A\d+\z/.match(sku.id) ? 'Legacy Value - Please Change' : sku.description)}]}
    @contract_vehicles ||= ContractVehicle.contract_vehicles
    @gps_contacts ||= Corporate.gps_contacts.map { |person| ["#{person.LastName}, #{person.FirstName}", person.Id]}
    WbsGroup.find_by(id: params[:group]).wbs_group_lines.order(:ordinal).each do |line|
      @new_line = @wbs.wbs_entries.build(
        sku: line.sku,
        link_type: line.link_type,
        link_task: line.link_task,
        link_percent: line.link_percent,
        notes: line.notes,
        task: line.task,
        phase: line.phase,
        gsa_labor_category_id: line.gsa_labor_category_id,
        billable_rate: line.billable_rate,
        total_hours: line.total_hours,
        internal_hourly_rate: line.internal_hourly_rate,
        contract_vehicle: line.contract_vehicle,
        ordinal: line.ordinal
      )
    end

    respond_to do |format|
      format.js {}
    end
  end

  def practices_selected
    has_permission('wbs_view', halt: false) ||
    has_permission('wbs_view_own', halt: true)

    @practices = Practice.where(id: params[:practices])
    @skus = @practices.map(&:skus).flatten.sort_by(&:name)
    @skus_list = WbsEntry.collectSkus(@skus)
    @skus_sd = (@skus.nil? ? [] : @skus) + GenericSku.all
    @skus_sd_items = @skus_sd.map {|sku| [sku.name, sku.id, {'data-description' => (/\A\d+\z/.match(sku.id) ? 'Legacy Value - Please Change' : sku.description)}]}
    @contract_vehicles ||= ContractVehicle.contract_vehicles
    @templates = WbsGroup.ValidTemplatesFor(@practices)
    @sdt_templates = ScopingDetailTemplate.ValidTemplatesFor(@practices);

    respond_to do |format|
      format.js {}
    end
  end

  def on_contract_type
    has_permission('wbs_edit', halt: false) ||
    has_permission('wbs_edit_own', halt: true)

    raise ArgumentError.new('No contract type has been specified.') unless params.key?(:contract_type)

    @billing_rules = WorkBreakdownStructure.billing_rules(params[:contract_type])
    @billing_rule  = params[:billing_rule]

    respond_to do |format|
      format.js {}
    end
  end

  def add_detail
    has_permission('wbs_create', halt: true)
    return if params[:sku].blank?

    @wbs = WorkBreakdownStructure.new
    sku = SalesForce::Product2.fetch(params[:sku]) if params[:sku].length == 18 && params[:sku].starts_with?("01t")
    sku = SalesForce::Product2.find_by(Name: params[:sku]) if sku.blank?
    sku = Enumeration.find(params[:sku]) if sku.blank?
    return if sku.blank?

    @wbs.scoping_details.build(sku_id: sku.id)
    @skus_sd = Practice.where(id: params[:practices]).map(&:skus).flatten.sort_by(&:name) + GenericSku.all
    @skus_sd_items = @skus_sd.map {|sku| [sku.name, sku.id, {'data-description' => (/\A\d+\z/.match(sku.id) ? 'Legacy Value - Please Change' : sku.description)}]}
    @contract_vehicles ||= ContractVehicle.contract_vehicles

    respond_to do |format|
      format.js {}
    end
  end

  def add_scoping_details
    has_permission('wbs_create', halt: true)

    @wbs = WorkBreakdownStructure.new

    template = ScopingDetailTemplate.find_by(id: params[:sd_template])
    template.sdt_items.order(:ordinal).each do |detail|
      @wbs.scoping_details.build(
        sku_id: detail.sku_id,
        item: detail.item,
        value: detail.value
      )
    end

    @skus_sd = template.valid_skus.sort_by(&:name) + GenericSku.all
    @skus_sd_items = @skus_sd.map {|sku| [sku.name, sku.id, {'data-description' => (/\A\d+\z/.match(sku.id) ? 'Legacy Value - Please Change' : sku.description)}]}
    respond_to do |format|
      format.js {}
    end
  end

  def check_gsa_compliance
    labor_category = GsaLaborCategory.find_by(id: params['gsa_labor_category'])

    raise ActiveRecord::RecordNotFound.new('The requested GSA Labor Category does not exist.') if labor_category.nil?

    if !/^\d+(\.\d{0,2})?$/.match(params['billable_rate'])
      render json: {
        is_compliant: false,
        message: 'Invalid billable rate.  Must be numeric and of the form x.xx'
      }
    else
      render json: labor_category.compliant?(params['billable_rate'].to_f, contract_vehicle: params['vehicle'], region: params['region'])
    end
  end

  private

  def param_adjustments
    if params.key?(:work_breakdown_structure) && params[:work_breakdown_structure].key?(:wbs_entries_attributes)
      params[:work_breakdown_structure][:wbs_entries_attributes].each do |index, line|
        Rails.logger.debug("#{index}: #{params[:work_breakdown_structure][:wbs_entries_attributes][index][:task]} #{params[:work_breakdown_structure][:wbs_entries_attributes][index][:ordinal]}")

        if line.key?(:billable_rate) && line[:billable_rate] =~ ADDITIONAL_FLOAT_REGEX
          params[:work_breakdown_structure][:wbs_entries_attributes][index][:billable_rate] = "#{line[:billable_rate]}0"
        end

        if line.key?(:total_hours) && line[:total_hours] =~ ADDITIONAL_FLOAT_REGEX
          params[:work_breakdown_structure][:wbs_entries_attributes][index][:total_hours] = "#{line[:total_hours]}0"
        end

        if line.key?(:internal_hourly_rate) && line[:internal_hourly_rate] =~ ADDITIONAL_FLOAT_REGEX
          params[:work_breakdown_structure][:wbs_entries_attributes][index][:internal_hourly_rate] = "#{line[:internal_hourly_rate]}0"
        end
      end
    end
  end

  def to_pdf (wbs)
    if wbs.opportunity?
      sanitized_filename = "WBS#{wbs.id}-#{wbs.opportunity.GP_Opportunity_Number__c}-#{DateTime.now.strftime('%Y%m%d-%H%M')}"
    else
      sanitized_filename = "WBS#{wbs.id}-#{DateTime.now.strftime('%Y%m%d-%H%M')}"
    end

    # Sanitize the title and leave room for the file extension
    sanitized_filename = Zaru.sanitize!(sanitized_filename, padding: 5)
    sanitized_filename = sanitized_filename.gsub(/\s+/, '_')

    # or from your controller, using views & templates and all wicked_pdf options as normal
    pdf = render_to_string pdf: sanitized_filename,
                           template: 'work_breakdown_structures/print',
                           encoding: 'UTF-8',
                           zoom: PDF_ZOOM_LEVEL,
                           orientation: 'Landscape'

    # Save to a file
    save_path = Rails.root.join('public/pdfs', "#{sanitized_filename}.pdf")
    File.open(save_path, 'wb') do |file|
      file << pdf
    end

    save_path
  end

  def sort (records, sort_by, sort_direction)
    if ['updated_at', 'title'].include?(sort_by)
      records.order(sort_by => sort_direction)
    elsif sort_by == 'account_name'
      if sort_direction == 'asc'
        records.sort_by { |record| !record.opportunity.nil? ? record.opportunity.account.Name : '' }
      else
        records.sort_by { |record| !record.opportunity.nil? ? record.opportunity.account.Name : '' }.reverse
      end

    elsif sort_by == 'opportunity_num'
      if sort_direction == 'asc'
        records.sort_by { |record| !record.opportunity.nil? ? record.opportunity.GP_Opportunity_Number__c : ''}
      else
        records.sort_by { |record| !record.opportunity.nil? ? record.opportunity.GP_Opportunity_Number__c : ''}.reverse
      end
    end
  end

  def wbs_params
    params.require(:work_breakdown_structure).permit(
      :id,
      :title,
      :sfdc_opportunity_id,
      :sfdc_quote_id,
      :contract_vehicle,
      :contract_type,
      :project_structure,
      :billing_rule,
      :contract_term,
      :expenses_billable,
      :vendor_delivered_services,
      :engagement_notes,
      :scoped_by_id,
      :is_deleted,
      :user_id,
      :project_manager_id,
      :gps_primary_contact_id,
      :gps_secondary_contact_id,
      :acct_primary_contact_id,
      :acct_secondary_contact_id,
      :practice_ids => [],

      extra: [
        primary_contact:[
          :name,
          :title,
          :phone,
          :email
        ],

        secondary_contact:[
          :name,
          :title,
          :phone,
          :email
        ]
      ],

      wbs_entries_attributes:[
        :id,
        :sku,
        :notes,
        :phase,
        :task,
        :gsa_labor_category_id,
        :billable_rate,
        :total_hours,
        :internal_hourly_rate,
        :start_date,
        :end_date,
        :resource,
        :link_type,
        :link_task,
        :link_percent,
        :contract_vehicle,
        :ordinal,
        :_destroy
      ],

      scoping_details_attributes:[
        :id,
        :ordinal,
        :sku_id,
        :item,
        :value,
        :_destroy
      ],

      billing_address_attributes:[
        :id,
        :kind,
        :address1,
        :address2,
        :city,
        :state,
        :postalcode,
        :country
      ]
    )
  end
end
