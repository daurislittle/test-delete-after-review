class WbsGroupsController < ApplicationController
  def index
    has_permission('wbs_view', halt:true)

    @page_title = "WBS Templates"
    @wbs_groups = WbsGroup.where(is_deleted:false).order(:name)
  end

  def show
    has_permission('wbs_view', halt:true)

    @wbs_group = WbsGroup.find_by(id:params[:id])

    if @wbs_group.nil?
      raise ActiveRecord::RecordNotFound.new("The requested WBS Template does not exist.")
    end

    @page_title = "WBS Template: #{@wbs_group.name}"
    @unlinked = @wbs_group.wbs_group_lines.where(link_type: 0)
  end

  def new
    has_permission('wbs_template_create', halt:true)

    @wbs_group = WbsGroup.new

    @skus = @wbs_group.valid_skus.sort_by(&:name)
    @line_items = @wbs_group.get_line_items

    respond_to do |format|
      format.html{
        @show_bottom_subnav = true
      }
      format.js {}
    end
  end

  def create
    has_permission('wbs_template_create', halt:true)

    @wbs_group = WbsGroup.new(wbs_group_params)
    @wbs_group.user = current_user

    respond_to do |format|
      format.html {
        if @wbs_group.save
          flash[:toast] = {
            type: :success,
            message: "WBS Template \"#{@wbs_group.name}\" has been created."
          }.to_json

          redirect_to @wbs_group
        else
          @show_bottom_subnav = true
          @skus = @wbs_group.valid_skus.sort_by(&:name)
          @line_items = @wbs_group.get_line_items

          render 'new'
        end
      }

      format.js {
        if @wbs_group.save
          flash.now[:toast] = {
            type: :success,
            message: "WBS Template \"#{@wbs_group.name}\" has been created."
          }.to_json
        else
          flash.now[:toast] = {
            type: :error,
            message: "There was a problem creating the new WBS template '#{@wbs_group.name}'."
          }.to_json
        end
      }
    end
  end

  def edit
    @wbs_group = WbsGroup.find_by(id:params[:id])

    if @wbs_group.nil?
      raise ActiveRecord::RecordNotFound.new("The requested WBS Template does not exist.")
    end

    has_permission('wbs_template_edit', halt:false) ||
    has_permission('wbs_template_edit_own', condition:(@wbs_group.user == current_user), halt:true)

    @show_bottom_subnav = true
    @skus = @wbs_group.valid_skus.sort_by(&:name)
    @line_items = @wbs_group.get_line_items
  end

  def update
    @wbs_group = WbsGroup.find_by(id:params[:id])

    if @wbs_group.nil?
      raise ActiveRecord::RecordNotFound.new("The requested WBS Template does not exist.")
    end

    has_permission('wbs_template_edit', halt:false) ||
    has_permission('wbs_template_edit_own', condition:(@wbs_group.user == current_user), halt:true)

    if @wbs_group.update_attributes(wbs_group_params)
      flash[:toast] = {
        type: :success,
        message: "WBS Line Item \"#{@wbs_group.name}\" has been updated."
      }.to_json

      redirect_to @wbs_group
    else
      @show_bottom_subnav = true
      @skus = @wbs_group.valid_skus.sort_by(&:name)
      @line_items = @wbs_group.get_line_items

      render 'edit'
    end
  end

  def copy
    @wbs_group = WbsGroup.find_by(id:params[:id])

    if @wbs_group.nil?
      raise ActiveRecord::RecordNotFound.new("The requested WBS Template does not exist.")
    end

    has_permission('wbs_template_create', halt:true)

    @copy = @wbs_group.amoeba_dup
    @copy.user = current_user
    if @copy.save
      flash[:toast] = {
        type: :success,
        message: "Successfully created copy of '#{@wbs_group.name}'"
      }.to_json

      redirect_to wbs_group_path(@copy)
    else
      @show_bottom_subnav = true
      @skus               = @copy.valid_skus.sort_by(&:name)
      @line_items         = @copy.get_line_items

      render 'new'
    end
  end

  def destroy
    @content = WbsGroup.find_by(id:params[:id])

    if @content.nil?
      raise ActiveRecord::RecordNotFound.new("The requested WBS Template does not exist.")
    end

    has_permission('wbs_template_delete', halt:false) ||
    has_permission('wbs_template_delete_own', condition:current_user == @content.user, halt:true)

    #RecentlyViewed.where(viewed_id: @content.id, viewed_type: @content.class.name).each do |view|
    #  view.destroy
    #end

    if params.key? :permanent
      @content.destroy

      flash[:toast] = {
        type: :success,
        message: "Content [#{@content.name}] has been permanently destroyed."
      }.to_json

      redirect_to trashcan_path

    else
      @content.is_deleted = true
      if @content.save
        flash[:toast] = {
          type: :success,
          message: "Content [#{@content.name}] was moved to the trashcan."
        }.to_json

        redirect_to templates_path

      else
        flash[:toast] = {
          type: :error,
          message: "There was an issue moving content [#{@content.name}] to the trashcan."
        }.to_json
      end
    end
  end

  def restore
    @content = WbsGroup.find_by(id:params[:id])

    if @content.nil?
      raise ActiveRecord::RecordNotFound.new("The requested WBS Template does not exist.")
    end

    has_permission('wbs_template_delete', halt:false) ||
    has_permission('wbs_template_delete_own', condition:@content.user == current_user, halt:true)

    @content.is_deleted = false
    if @content.save
      flash[:toast] = {
        type: :success,
        message: "WBS Template [#{@content.name}] has been restored."
      }.to_json

      redirect_to @content

    else
      flash[:toast] = {
        type: :error,
        message: "There was an error restoring WBS Template [#{@content.name}]."
      }.to_json

      redirect_to trashcan_path
    end
  end

  # Called when the selected project structures change
  def practices_selected
    has_permission('wbs_view', halt:true)

    @practices = Practice.where(id:params[:practices])
    @skus = @practices.map { |practice| practice.skus }.flatten.sort_by(&:name)

    respond_to do |format|
      format.js {}
    end
  end

  def manage_add_line
    has_permission('wbs_template_create', halt:true)

    @practices = Practice.where(id:params[:practices])
    @skus = @practices.map { |practice| practice.skus }.flatten.sort_by(&:name)

    internal_rate = Variable.get('default_internal_rate')

    sku = params[:sku] || @skus.first.name

    dfir = Practice.for_structure('Incident Response')
    if !dfir.nil? && dfir.sku?(sku)
      internal_rate = Variable.get('default_dfir_internal_rate')
    end

    @wbs_group = WbsGroup.new
    gsa = GsaLaborCategory.find_by_name('Security Consultant')
    if sku == 'IA-SA-RSE'
      billable_rate = 275.00
    else
      billable_rate = gsa.default_billrate
    end
    @new_line = @wbs_group.wbs_group_lines.build(
      sku:sku,
      gsa_labor_category: gsa,
      billable_rate: billable_rate,
      internal_hourly_rate: internal_rate
    )

    respond_to do |format|
      format.js {}
    end
  end

  def change_sku
    has_permission('wbs_template_create', halt:true)

    @line_item_id = params[:line_item_id]
    @internal_rate = Variable.get('default_internal_rate')

    dfir = Practice.for_structure('Incident Response')
    if !dfir.nil? && dfir.sku?(params[:sku])
      @internal_rate = Variable.get('default_dfir_internal_rate')
    end

    lc = GsaLaborCategory.find_by(id: params[:gsa_labor_category_id]);
    if (!lc.nil? &&
      (lc.name == "GuidePoint SOAR Services-Standard" ||
        lc.name == "GuidePoint SOAR Services-Remote" ||
        lc.name == "GuidePoint SOAR Services-Premium" ||
        lc.name == "GuidePoint Splunk Services-Standard" ||
        lc.name == "GuidePoint Splunk Services-Remote" ||
        lc.name == "GuidePoint Splunk Services-Premium" ||
        lc.name == "GuidePoint F5 Networks Services-Standard" ||
        lc.name == "GuidePoint F5 Networks Services-Remote" ||
        lc.name == "GuidePoint F5 Networks Services-Premium"))
      @internal_rate = @internal_rate * 8
    end

    respond_to do |format|
      format.js {}
    end
  end
  
  def mark_all
    params.require(:id)

    @template = WbsGroup.find_by(id:params[:id])
    raise ActiveRecord::RecordNotFound.new("The requested WBS Template does not exist.") if @template.nil?

    has_permission('wbs_template_edit', halt:false) ||
    has_permission('wbs_template_edit_own', condition:(@template.user == current_user), halt:true)

    respond_to do |format|
      format.js {}
    end
  end

  private
  def wbs_group_params
    params.require(:wbs_group).permit(
      :id,
      :name,
      :practice_ids => [],
      wbs_group_lines_attributes:[
        :id,
        :sku,
        :notes,
        :task,
        :phase,
        :contract_vehicle,
        :gsa_labor_category_id,
        :billable_rate,
        :total_hours,
        :internal_hourly_rate,
        :link_type,
        :link_task,
        :link_percent,
        :ordinal,
        :_destroy
    ]);
  end
end
