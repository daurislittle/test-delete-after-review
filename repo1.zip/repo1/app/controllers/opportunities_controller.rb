class OpportunitiesController < ApplicationController
  DEFAULT_PAGE_SIZE = 25

  def index
    @page_title = 'Opportunities'

    if params[:search_for] and !params[:search_for].blank?
      if params[:search_for].length > 1
        @total = SalesForce::Opportunity.search(params[:search_for]).count
      else
        @total = SalesForce::Opportunity.only_services.count

        flash[:toast] = {
          type: :error,
          message: "Please enter a search term that is larger than a single character."
        }.to_json

        redirect_to opportunities_path
      end
    else
      @total = SalesForce::Opportunity.only_services.count
    end

    params[:per_page] = @total if params[:per_page] == 'All'

    @per_page = params[:per_page] ? params[:per_page].to_i : DEFAULT_PAGE_SIZE

    @num_pages = @total / @per_page
    @num_pages += 1 if (@total % @per_page) != 0 || @num_pages.zero?

    @page = params.key?(:page) ? params[:page].to_i : 1
    if @page < 1
      @page = 1
    elsif @page > @num_pages
      @page = @num_pages
    end

    @start = (@page - 1) * @per_page
    @view  = params.key?(:view) ? params[:view] : 'table'

    @sort_by        = params.key?(:sort_by) ? params[:sort_by].to_sym : :LastModifiedDate
    @sort_direction = params.key?(:sort_direction) ? params[:sort_direction].to_sym : :desc

    if params.key?(:search_for) && !params[:search_for].blank?
      @records = if params.key?(:refresh) && params[:refresh] == 'true'
                   SalesForce::Opportunity.search(params[:search_for]).offset(@start).limit(@per_page).refresh
                 else
                   SalesForce::Opportunity.search(params[:search_for]).offset(@start).limit(@per_page)
                 end

      @search_for = params[:search_for]
    else
      @records = if params.key?(:refresh) && params[:refresh] == 'true'
                   SalesForce::Opportunity.only_services.order(@sort_by => @sort_direction).offset(@start).limit(@per_page).refresh #(start:@start, limit:@per_page, only_services: only_services)

                 else
                   SalesForce::Opportunity.only_services.order(@sort_by => @sort_direction).offset(@start).limit(@per_page) #(start:@start, limit:@per_page, only_services: only_services)
                 end

      @search_for = ''
    end

    @show_bottom_subnav = true

    respond_to do |format|
      format.html {}
      format.js {}
      format.json {
        results = @records.map { |record| {id: record.id, text: "#{record.GP_Opportunity_Number__c} #{record.Name}"} }

        render json: {
          results: results,
          pagination: {
              more: (@page * @per_page) < @total
          }
        }
      }
    end
  end

  def show
    params.require(:id)

    opp_id = params[:id].to_s
    @opportunity = if opp_id.start_with?('006') && (opp_id.length >= 15)
                     SalesForce::Opportunity.find_by(Id:opp_id)
                   else
                     SalesForce::Opportunity.find_by(GP_Opportunity_Number__c:opp_id)
                   end
    if params.key?(:refresh)
      @opportunity = @opportunity.refresh
    end

    raise ObjectNotFound.new('The requested Salesforce Opportunity does not exist.') unless @opportunity.valid?

    @page_title = "Opportunity: #{@opportunity&.Name}"

    @wbs = WorkBreakdownStructure.where(
      sfdc_opportunity_id: @opportunity.Id
    ).where(is_deleted:false).order(updated_at: :desc)

    respond_to do |format|
      format.html do
        viewed = RecentlyViewed.find_by(user: current_user, viewed_type: @opportunity.class.name, viewed_id: @opportunity.Id)
        if !viewed.nil?
          viewed.touch
        else
          viewed = RecentlyViewed.new(
              user: current_user,
              title: @opportunity.Name,
              viewed_type: @opportunity.class.name,
              viewed_id: @opportunity.Id,
              viewed_url: request.original_fullpath
          )
          viewed.save
        end
      end

      format.js {}

      format.json do
        contacts = if @opportunity.Region__c != 'Federal' || !@opportunity.prime.valid?
                     @opportunity.account.contacts
                   else
                     @opportunity.prime.contacts
                   end

        render json: {
            opportunity: @opportunity,
            account: @opportunity.account,
            account_executive: @opportunity.account_executive.contact,
            sos: @opportunity.sos,
            contacts: contacts,
            practice: Practice.where('project_structure LIKE ?', "%#{@opportunity.Project_Structure__c}%")
        }
      end
    end
  end
end
