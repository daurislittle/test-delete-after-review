class ContactsController < ApplicationController
  DEFAULT_PAGE_SIZE = 25

  def index
    @page_title = "Contacts"

    if params[:search_for] and !params[:search_for].blank?
      if params[:search_for].length > 1
        @total = SalesForce::Contact.search(params[:search_for]).count
      else
        @total = SalesForce::Contact.count

        flash[:toast] = {
          type: :error,
          message: "Please enter a search term that is larger than a single character."
        }.to_json

        redirect_to opportunities_path
      end
    else
      @total = SalesForce::Contact.count
    end

    if params[:per_page] == 'All'
      params[:per_page] = @total
    end

    @per_page = params[:per_page] ? params[:per_page].to_i : DEFAULT_PAGE_SIZE

    @num_pages = @total / @per_page
    @num_pages += 1 if (@total % @per_page) != 0 || @num_pages.zero?

    @page = params.key?(:page) ? params[:page].to_i : 1
    if @page < 1
      @page = 1
    elsif @page > @num_pages
      @page = @num_pages
    end

    @start = (@page - 1) * @per_page
    @view  = params.key?(:view) ? params[:view] : 'table'

    @sort_by        = params.key?(:sort_by) ? params[:sort_by].to_sym : :LastName
    @sort_direction = params.key?(:sort_direction) ? params[:sort_direction].to_sym : :asc

    if params[:search_for] && !params[:search_for].blank?
      @records = if params.key?(:refresh) && params[:refresh] == 'true'
                   SalesForce::Contact.search(params[:search_for]).offset(@start).limit(@per_page).refresh
                 else
                   SalesForce::Contact.search(params[:search_for]).offset(@start).limit(@per_page)
                 end

      @search_for = params[:search_for]
    else
      @records = if params.key?(:refresh) && params[:refresh] == 'true'
                   SalesForce::Contact.order(@sort_by => @sort_direction).offset(@start).limit(@per_page).refresh

                 else
                   SalesForce::Contact.order(@sort_by => @sort_direction).offset(@start).limit(@per_page)
                 end.map { |record| record }

      @search_for = ''
    end

    @show_bottom_subnav = true

    respond_to do |format|
      format.html {}
      format.js {}
      format.json { render json:@records }
    end
  end

  def show
    @contact = if params.key?(:refresh)
                 SalesForce::Contact.find_by(Id:params[:id]).refresh
               else
                 SalesForce::Contact.find_by(Id:params[:id])
               end

    raise ObjectNotFound.new("The requested Salesforce Contact does not exist.") unless @contact.valid?

    @page_title = "Contact: #{@contact.Name if !@contact.nil?}"

    respond_to do |format|
      format.html do
        viewed = RecentlyViewed.find_by(user:current_user, viewed_type:@contact.class.name, viewed_id:@contact.Id)
        if !viewed.nil?
          viewed.touch
        else
          viewed = RecentlyViewed.new(
              user:current_user,
              title: @contact.Name,
              viewed_type:@contact.class.name,
              viewed_id:@contact.Id,
              viewed_url:request.original_fullpath
          )
          viewed.save
        end
      end

      format.js {}

      format.json { render json:{
          contact: @contact,
          account: @account
      }}
    end
  end
end
