require 'sales_force'


class ApplicationController < ActionController::Base
  WIDGET_PER_PAGE = 15

  protect_from_forgery with: :exception

  before_action :authorized?, except: [:login, :consume]
  before_action :set_paper_trail_whodunnit

  helper_method :current_user
  helper_method :has_permission

  add_flash_types :toast, :error, :warning, :success, :info, :publishability

  helper 'templates'

  rescue_from StandardError do |exception|
    @exception = exception

    # Shouldn't happen, but just in case...
    if !current_user.nil?
      Rails.logger.tagged("User: #{current_user.name}") do
        Rails.logger.error(exception.inspect)
        Rails.logger.error(exception.backtrace)
      end
    else
      Rails.logger.error(exception.inspect)
      Rails.logger.error(exception.backtrace)
    end

    respond_to do |format|
      format.html {
        post_toast_exception(@exception)

        #render template:'errors/internal_server_error', layout:'error', status:500
      }

      format.js {
        post_toast_exception(@exception)
      }

      format.all { render nothing: true, status: 500 }
    end
  end

  rescue_from NotAuthorized do |exception|
    @exception = exception

    Rails.logger.tagged("User: #{current_user.name}") do
      Rails.logger.error(exception.inspect)
      Rails.logger.error(exception.backtrace)
    end

    respond_to do |format|
      format.html {
        post_toast_exception(@exception, title: 'Not Authorized')
        #render template:'errors/unauthorized', layout:'error', status:401
      }

      format.js {
        post_toast_exception(@exception)
      }

      format.all { render nothing: true, status: 401 }
    end
  end

  rescue_from Forbidden do |exception|
    @exception = exception

    Rails.logger.tagged("User: #{current_user.name}") do
      Rails.logger.error(exception.inspect)
      Rails.logger.error(exception.backtrace)
    end

    respond_to do |format|
      format.html {
        render template: 'errors/forbidden', layout:'error', status:403
      }

      format.js {
        post_toast_exception(@exception)
      }

      format.all { render nothing: true, status: 403 }
    end
  end

  rescue_from NoMethodError do |exception|
    @exception = exception

    @error_title = "Invalid Action"
    @exception_error = exception.to_s

    Rails.logger.tagged("User: #{current_user.name}") do
      Rails.logger.error(exception.inspect)
      Rails.logger.error(exception.backtrace)
    end

    respond_to do |format|
      format.html {
        post_toast_exception(@exception, title: 'Invalid Action')
        #render template:'errors/not_found', layout:'error', status:404
      }

      format.js {
        post_toast_exception(@exception)
      }

      format.all { render nothing: true, status: 404 }
    end
  end

  rescue_from ActiveRecord::RecordNotFound do |exception|
    @exception = exception

    @error_title = "Object Not Found"
    @exception_error = exception.to_s

    Rails.logger.tagged("User: #{current_user.name}") do
      Rails.logger.error(exception.inspect)
      Rails.logger.error(exception.backtrace)
    end

    respond_to do |format|
      format.html {
        post_toast_exception(@exception, title: 'Object Not Found')
        #render template:'errors/not_found', layout:'error', status:404
      }

      format.js {
        post_toast_exception(@exception)
      }

      format.all { render nothing: true, status: 404 }
    end
  end

  rescue_from ObjectNotFound do |exception|
    @exception = exception

    @error_title = "Object Not Found"
    @exception_error = exception.to_s

    Rails.logger.tagged("User: #{current_user.name}") do
      Rails.logger.error(exception.inspect)
      Rails.logger.error(exception.backtrace)
    end

    respond_to do |format|
      format.html {
        post_toast_exception(@exception, title: 'Object Not Found')
        #render template:'errors/not_found', layout:'error', status:404
      }

      format.js {
        post_toast_exception(@exception)
      }

      format.all { render nothing: true, status: 404 }
    end
  end

  rescue_from ActionController::RoutingError do |exception|
    Rails.logger.tagged("User: #{current_user.name}") do
      Rails.logger.error(exception.inspect)
      Rails.logger.error(exception.backtrace)
    end

    respond_to do |format|
      format.html {
        post_toast_exception(@exception, title: 'Route Not Found')
      }

      format.js {
        post_toast_exception(@exception)
      }

      format.all { render nothing: true, status: 404 }
    end
  end

  rescue_from ActionController::InvalidAuthenticityToken do |exception|
    @exception = exception

    Rails.logger.tagged("User: #{current_user.name}") do
      Rails.logger.error(exception.inspect)
      Rails.logger.error(exception.backtrace)
      Rails.logger.error(request.env)
    end

    respond_to do |format|
      format.html {
        post_toast_exception(@exception, title: 'Invalid Authenticity Token')
      }

      format.js {
        post_toast_exception(@exception)
      }

      format.all { render nothing: true, status: 403 }
    end
  end

  RECENTLY_VIEWED_WHITELIST = [
      SalesForce::Account.name,
      SalesForce::Contact.name,
      SalesForce::Opportunity.name,
      WorkBreakdownStructure.name
  ]

  def authorized?
    redirect_to '/saml/login' unless current_user
    raise Forbidden.new("Your account has been disabled.") if !current_user.nil? && current_user.is_disabled?
  end

  def welcome
    respond_to do |format|
      format.html {
        render template:'application/welcome', layout:'welcome', status:200
      }
      format.all { render nothing: true, status: 200 }
    end
  end

  def index
    @viewed = RecentlyViewed.where(
                user:current_user
              ).where(
                viewed_type:RECENTLY_VIEWED_WHITELIST
              ).order(updated_at: :desc).limit(WIDGET_PER_PAGE)
    @recent_viewed_page = 1

    count = RecentlyViewed.where(
      user:current_user
    ).where(
      viewed_type:RECENTLY_VIEWED_WHITELIST
    ).count

    @recent_max_page = count / WIDGET_PER_PAGE
    if ((@recent_max_page * WIDGET_PER_PAGE) < count)
      @recent_max_page += 1
    end

    count = WorkBreakdownStructure.where(
              scoped_by:current_user.corporate
            ).where(
              is_deleted:false
            ).count

    @status_max_page = count / WIDGET_PER_PAGE
    if ((@status_max_page * WIDGET_PER_PAGE) < count)
      @status_max_page += 1
    end

    @status_viewed_page = 1

    @quotes = WorkBreakdownStructure.where(
                  scoped_by:current_user.corporate
                ).where(
                  is_deleted:false
                ).order(updated_at: :desc).limit(WIDGET_PER_PAGE)
  end

  def recently_viewed
    count = RecentlyViewed.where(
      user:current_user
    ).where(
      viewed_type:RECENTLY_VIEWED_WHITELIST
    ).count

    @recent_max_page = count / WIDGET_PER_PAGE
    if ((@recent_max_page * WIDGET_PER_PAGE) < count)
      @recent_max_page += 1
    end

    @recent_viewed_page = params.key?(:recent_page) ? params[:recent_page].to_i : 1
    @recent_viewed_page = @recent_max_page if @recent_viewed_page > @recent_max_page
    @recent_viewed_page = 1 if @recent_viewed_page.negative? || @recent_viewed_page.zero?

    @viewed = RecentlyViewed.where(
                user:current_user
              ).where(
                viewed_type:RECENTLY_VIEWED_WHITELIST
              ).order(updated_at: :desc).offset((@recent_viewed_page - 1) * WIDGET_PER_PAGE).limit(WIDGET_PER_PAGE)

    respond_to do |format|
      format.js {}
    end
  end

  def wbs_status
    count = WorkBreakdownStructure.where(
              scoped_by:current_user.corporate
            ).where(
              is_deleted:false
            ).count

    @status_max_page = count / WIDGET_PER_PAGE
    if ((@status_max_page * WIDGET_PER_PAGE) < count)
      @status_max_page += 1
    end

    @quotes = if params.key?(:recent_page)
                WorkBreakdownStructure.where(
                  scoped_by:current_user.corporate
                ).where(
                  is_deleted:false
                ).order(updated_at: :desc).offset((params[:recent_page].to_i - 1) * WIDGET_PER_PAGE).limit(WIDGET_PER_PAGE)
              else
                WorkBreakdownStructure.where(
                  scoped_by:current_user.corporate
                ).where(
                  is_deleted:false
                ).order(updated_at: :desc).limit(WIDGET_PER_PAGE)
              end

    @status_viewed_page = params.key?(:recent_page) ? params[:recent_page].to_i : 1
    @status_viewed_page = 1 if @status_viewed_page.negative? || @status_viewed_page.zero?
    @status_viewed_page = @status_max_page if @status_viewed_page > @status_max_page

    respond_to do |format|
      format.js {}
    end
  end

  def search
    @accounts = []
    @contacts = []
    @opportunities = []
    @wbs = []

    if params.key?(:search_for) && params[:search_for].length > 0
      @account_total = SalesForce::Account.search(params[:search_for]).count
      @accounts = SalesForce::Account.search(params[:search_for]).limit(5)

      @opportunity_total = SalesForce::Opportunity.search(params[:search_for]).count
      @opportunities = SalesForce::Opportunity.search(params[:search_for]).limit(5)

      @contact_total = SalesForce::Contact.search(params[:search_for]).count
      @contacts = SalesForce::Contact.search(params[:search_for]).limit(5)

      if has_permission('wbs_view', halt:false)
        @wbs_total = WorkBreakdownStructure.search(params[:search_for], where:{is_deleted:false}).count
        @wbs = WorkBreakdownStructure.search params[:search_for], where:{is_deleted:false}, order:{updated_at: :desc}, limit:5

      elsif has_permission('wbs_view_own', halt:true)
        @wbs_total = WorkBreakdownStructure.search(params[:search_for], where:{is_deleted:false, user_id:current_user.id}).count
        @wbs = WorkBreakdownStructure.search params[:search_for], where:{is_deleted:false, user_id:current_user.id}, order:{updated_at: :desc}, limit:5
      end
    end

    @page_title = "Search Results"
    @search_term = params[:search_for]

    render 'search', format:'html'

=begin
    respond_to do |format|
      format.js {
        @results = {
            accounts: account_records.map {|record| record[1]},
            contacts: contact_records.map {|record| record[1]},
            opportunities: opportunity_records.map {|record| record[1]},
            wbs: wbs_records
        }
      }
    end
=end
  end

  def current_user
    @user ||= User.find(session[:user_id]) if session[:user_id]
  end

  def has_permission(permission_name, opts={})
    defaults = {
        halt: true,
        condition: true
    }.merge(opts)

    if current_user.is_disabled?
      raise Forbidden.new
    end

    #has_permission = false
    user = current_user

    has_permission = current_user.has_permission? 'is_admin'

    if !has_permission
      has_permission = current_user.has_permission?(permission_name) and defaults[:condition]

      if defaults[:halt] and !has_permission
        raise NotAuthorized.new
      end
    end

    has_permission
  end

  private
  def post_toast_exception (exception, title: nil)
    message = '<p>Something went wrong.  COGS administration has been alerted.</p>'


    if !@exception.message.blank?
      ## ITH-22215 / tailor message here if it is a salesforce connectivity issue -- tell them to try again.
      in_salesforce = (@exception.backtrace.nil? || @exception.backtrace.length <= 0) ? false : @exception.backtrace.first.include?("sales_force/client.rb")
      if in_salesforce && (@exception.message.include?("end of file") || @exception.message.include?("ReadTimeout"))
        message = "<p>There was a network hiccup or temporary connection issue with Salesforce, please try again.</p>"
      elsif in_salesforce && @exception.message.include?('INVALID_SEARCH: search term must be longer than one character')
        message = "<p>Please enter a search term that is larger than a single character."
      else
        message += "<p><b>Problem:</b> #{exception.message}</p>"
      end
    end

    toast = {
      type: :error,
      message: message
    }

    unless title.blank?
      toast[:title] = title
    end

    flash[:toast] = toast.to_json

    # Send emails...do not send in local dev and test environments
    unless Rails.env.in?(['local_dev', 'test'])
      unless @exception.message && (@exception.message.include?("InvalidAuthenticityToken") || @exception.message.include?("You do not have the necessary permissions to perform this action or access this page"))
        begin
          ExceptionMailer.with(
            exception: exception,
            title: title,
            user: current_user
          ).submit_exception.deliver!

        rescue StandardError => e
          Rails.logger.error("Failed to send out the exception email: #{e.message}")
        end
      end
    end

    respond_to do |format|
      format.html {
        redirect_back(fallback_location: root_path)
      }

      format.js {
        head 302
      }
    end
  end
end
