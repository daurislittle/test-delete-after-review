class GsaLaborCategoriesController < ApplicationController
  def show
    @category = GsaLaborCategory.find_by(id:params[:id])

    if @category.nil?
      raise ActiveRecord::RecordNotFound.new("The requested GSA Labor Category does not exist.")
    end

    daily = @category.name == "GuidePoint SOAR Services-Standard" ||
            @category.name == "GuidePoint SOAR Services-Remote" ||
            @category.name == "GuidePoint SOAR Services-Premium" ||
            @category.name == "GuidePoint Splunk Services-Standard" ||
            @category.name == "GuidePoint Splunk Services-Remote" ||
            @category.name == "GuidePoint Splunk Services-Premium" ||
            @category.name == "GuidePoint F5 Networks Services-Standard" ||
            @category.name == "GuidePoint F5 Networks Services-Remote" ||
            @category.name == "GuidePoint F5 Networks Services-Premium"

    respond_to do |format|
      format.json {
        render json:{
          revenue: @category.default_billrate(region: params[:region], contract_vehicle:params[:contract_vehicle]),
          cost: (Variable.get('default_internal_rate') * (daily ? 8 : 1))
        }
      }
    end
  end
end
