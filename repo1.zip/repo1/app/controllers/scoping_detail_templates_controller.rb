class ScopingDetailTemplatesController < ApplicationController
  def index
    @page_title = "Scoping Detail Templates"
    @templates = ScopingDetailTemplate.all.order(:name)
  end

  def show
    @template = ScopingDetailTemplate.find_by(id:params[:id])
    if @template.nil?
      raise ActiveRecord::RecordNotFound.new("The requested Scoping Detail Template does not exist.")
    end

    @page_title = "SD Template: #{@template.name}"
  end

  def new
    @template = ScopingDetailTemplate.new
    @skus = @template.valid_skus.sort_by(&:name) + GenericSku.all
    @show_bottom_subnav = true
  end

  def create
    @template = ScopingDetailTemplate.new(template_params)
    @template.user = current_user

    if @template.save
      flash[:toast] = {
        type: :success,
        message: "Successfully created scoping detail template called \"#{@template.name}\""
      }.to_json

      redirect_to @template

    else
      @skus = @template.valid_skus.sort_by(&:name) + GenericSku.all
      @show_bottom_subnav = true

      render :new
    end
  end

  def edit
    @template = ScopingDetailTemplate.find_by(id:params[:id])
    if @template.nil?
      raise ActiveRecord::RecordNotFound.new("The requested Scoping Detail Template does not exist.")
    end

    @show_bottom_subnav = true
    @skus = @template.valid_skus.sort_by(&:name) + GenericSku.all
  end

  def update
    @template = ScopingDetailTemplate.find_by(id:params[:id])
    if @template.nil?
      raise ActiveRecord::RecordNotFound.new("The requested Scoping Detail Template does not exist.")
    end

    if @template.update(template_params)
      flash[:toast] = {
        type: :success,
        message: "Successfully updated Scoping Detail Template '#{@template.name}'"
      }.to_json

      redirect_to @template

    else
      @show_bottom_subnav = true
      @skus = @template.valid_skus.sort_by(&:name) + GenericSku.all
      render :edit
    end
  end

  def copy
    @template = ScopingDetailTemplate.find_by(id:params[:id])
    if @template.nil?
      raise ActiveRecord::RecordNotFound.new("The requested Scoping Detail Template does not exist.")
    end

    has_permission('wbs_template_create', halt:true)

    @copy = @template.amoeba_dup
    @copy.user = current_user
    if @copy.save
      flash[:toast] = {
        type: :success,
        message: "Successfully created copy of '#{@template.name}'"
      }.to_json

      redirect_to scoping_detail_template_path(@copy)
    else
      @show_bottom_subnav = true

      render :new
    end
  end

  def destroy
    @content = ScopingDetailTemplate.find_by(id:params[:id])
    if @content.nil?
      raise ActiveRecord::RecordNotFound.new("The requested Scoping Detail Template does not exist.")
    end

    if params.key? :permanent
      @content.destroy

      flash[:toast] = {
        type: :success,
        message: "Content [#{@content.name}] has been permanently destroyed."
      }.to_json

      redirect_to trashcan_path

    else
      @content.is_deleted = true
      if @content.save
        flash[:toast] = {
          type: :success,
          message: "Content [#{@content.name}] was moved to the trashcan."
        }.to_json

        redirect_to templates_path

      else
        flash[:toast] = {
          type: :error,
          message: "There was an issue moving content [#{@content.name}] to the trashcan."
        }.to_json
      end
    end

    #@template.destroy

    #flash[:success] = "Scoping Detail Template '#{@template.name}' has been removed."
    #redirect_to scoping_detail_templates_path
  end

  def restore
    @content = ScopingDetailTemplate.find_by(id:params[:id])

    if @content.nil?
      raise ActiveRecord::RecordNotFound.new("The requested Scoping Detail Template does not exist.")
    end

    #has_permission('wbs_template_delete', halt:false) ||
    #    has_permission('wbs_template_delete_own', condition:@content.user == current_user, halt:true)

    @content.is_deleted = false
    if @content.save
      flash[:toast] = {
        type: :success,
        message: "Scoping Detail Template [#{@content.name}] has been restored."
      }.to_json

      redirect_to @content

    else
      flash[:toast] = {
        type: :error,
        message: "There was an error restoring Scoping Detail Template [#{@content.name}]."
      }.to_json

      redirect_to trashcan_path
    end
  end

  def practices_selected
    practices = Practice.where(id: params[:practices])
    @skus = [] + practices.map(&:skus).flatten.sort_by(&:name) unless practices.empty?
    @skus += GenericSku.all

    respond_to do |format|
      format.js {}
    end
  end

  def add_detail
    @template = ScopingDetailTemplate.new
    @detail = @template.sdt_items.build(sku_id:params[:sku])

    practices = Practice.where(id: params[:practices])
    @skus = [] + practices.map(&:skus).flatten.sort_by(&:name) unless practices.empty?
    @skus += GenericSku.all

    respond_to do |format|
      format.js {}
    end
  end

  def mark_all
    params.require(:id)

    @template = ScopingDetailTemplate.find_by(id: params[:id])
    raise ActiveRecord::RecordNotFound.new("The requested Scoping Detail Template does not exist.") if @template.nil?

    respond_to do |format|
      format.js {}
    end
  end


  private
  def template_params
    params.require(:scoping_detail_template).permit(
      :name,
      :description,
      :practice_ids => [],
      sdt_items_attributes:[
          :id,
          :ordinal,
          :sku_id,
          :item,
          :value,
          :_destroy
      ]
    )
  end
end
