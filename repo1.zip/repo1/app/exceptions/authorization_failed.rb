class AuthorizationFailed < StandardError
  def initialize(message = "Authorization Failed")
    super
  end
end