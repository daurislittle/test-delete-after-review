class NotAuthorized < StandardError
  def initialize (msg="You do not have the necessary permissions to perform this action "\
                      "or access this page.  If you feel you have arrived at this page in "\
                      "error, please contact the COGS administrator.")
    super
  end
end