class Forbidden < StandardError
  def initialize (msg="Your account has been disabled.  If you feel you have arrived at this "\
                      "page in error, please contact the COGS administrator.")
    super
  end
end