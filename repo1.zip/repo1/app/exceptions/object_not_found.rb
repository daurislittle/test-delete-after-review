class ObjectNotFound < StandardError
  def initialize(msg="The requested object was not found.")
    super
  end
end