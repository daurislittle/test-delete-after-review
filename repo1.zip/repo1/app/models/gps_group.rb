class GpsGroup < ApplicationRecord
  has_many :gps_group_members, dependent: :destroy
  has_many :corporates, through: :gps_group_members

  alias_attribute :members, :gps_group_members

  def self.psg
    GpsGroup.find_by(name: 'Proposal Support Group')
  end

  def self.pmo
    GpsGroup.find_by(name: 'Project Management Office')
  end

  def self.scoping
    GpsGroup.where("name LIKE '%Scoping%'")
  end

  def self.leadership
    GpsGroup.where("name LIKE '%Leadership%' OR name LIKE '%LT'")
  end

  # Returns true if the person is a member of the PSG team
  def self.member_psg?(person)
    !GpsGroup.psg.nil? && GpsGroup.psg.member?(person)
  end

  # Returns true if the person is a member of a scoping team
  def self.member_scoping?(person)
    GpsGroup.scoping.each do |group|
      return true if group.member?(person)
    end

    false
  end

  # Returns true if the person is a member of the PMO team
  def self.member_pmo?(person)
    !GpsGroup.pmo.nil? && GpsGroup.pmo.member?(person)
  end

  def member? (person)
    if person.instance_of? Corporate
      !gps_group_members.find_by(corporate: person).nil?
    elsif person.instance_of? User
      !gps_group_members.find_by(corporate: person.corporate).nil?
    elsif person.instance_of? String
      !gps_group_members.find_by(corporate: Corporate.find_by(email: person)).nil?
    else
      false
    end
  end
end
