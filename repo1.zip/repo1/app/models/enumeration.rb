class Enumeration < ApplicationRecord
  before_save { |enumeration| enumeration.enum_type = enumeration.enum_type.downcase }

  validates_presence_of :name
  validates_uniqueness_of :name, scope: :enum_type

  validates :enum_type, presence: true
  validates :ordinal, numericality: { greater_than_or_equal_to: 0, only_integer: true }
  validates_format_of :enum_type, with: /\A[a-z_]+\Z/

  scope :by_type, -> { order(:enum_type, :ordinal) }
  scope :by_name, -> { order(:name) }
  scope :by_ordinal, -> { order(:ordinal) }

  before_validation do |enum|
    max_ordinal = Enumeration.where(enum_type:enum.enum_type).maximum(:ordinal)

    if max_ordinal.nil?
      max_ordinal = 0
    end

    enum.ordinal ||= (max_ordinal + 1)
  end

  def self.is_valid_type? type
    Enumeration.where("enum_type = ?", type).count > 0
  end

  def self.for_name ( kind, name )
    Enumeration.find_by(enum_type: kind, name: name)
  end

  def self.for_type ( type )
    Enumeration.where(enum_type: type).order(:ordinal)
  end

  def is_type? (type)
    self.enum_type == type
  end

  def == object
    if object.is_a? Enumeration
      object.enum_type == self.enum_type && object.name == self.name
    elsif object.is_a? String
      object.downcase == self.name.downcase
    else
      false
    end
  end

  def != object
    if object.is_a? Enumeration
      object.enum_type != self.enum_type || object.name != self.name
    elsif object.is_a? String
      object.downcase != self.name.downcase
    else
      true
    end
  end
end
