class SdtItem < ApplicationRecord
  belongs_to :scoping_detail_template

  validates :item, presence: true
  validates :sku_id, presence: true

  amoeba do
    enable
  end

  def sku
    if sku_id.start_with?(SalesForce::Product2.class_prefix)
      SalesForce::Product2.find_by(Id: sku_id)
    else
      Enumeration.find_by(id: sku_id)
    end
  end
end
