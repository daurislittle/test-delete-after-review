class GsaLaborCategory < ApplicationRecord
  FEDERAL_REGION         = Enumeration.find_by(enum_type: 'region', name: 'Federal')
  GSA_GUIDEPOINTSECURITY = Enumeration.find_by(enum_type: 'contract_vehicle', name: 'GSA - GuidePoint Security')

  MANAGEMENT = [
    GsaLaborCategory.find_by(name: 'Project Manager'),
    GsaLaborCategory.find_by(name: 'Senior Project Manager'),
    GsaLaborCategory.find_by(name: 'Program Manager'),
    GsaLaborCategory.find_by(name: 'Project Coordinator')
  ].compact

  NON_GSA = [
    GsaLaborCategory.find_by(name: 'Project Coordinator'),
    GsaLaborCategory.find_by(name: 'Engineer Specialist'),
    GsaLaborCategory.find_by(name: 'Managing Cloud Security Engineer'),
    GsaLaborCategory.find_by(name: 'Associate Cloud Security Engineer'),
    GsaLaborCategory.find_by(name: 'Senior Cloud Security Engineer'),
    GsaLaborCategory.find_by(name: 'Cloud Security Engineer'),
    GsaLaborCategory.find_by(name: 'Program Manager')
  ]

  validates :name, presence: true
  validates :gsa_floor_price, numericality: { greater_than: 0 }, if: proc { |c| !c.gsa_floor_price.nil? }
  validates :federal_max_price, numericality: { greater_than: 0 }, if: proc { |c| !c.federal_max_price.nil? }

  def self.isDailyRate?(id)
    lc = GsaLaborCategory.find_by(id: id)
    if lc.nil?
      false
    else
      lc.name == "GuidePoint SOAR Services-Standard" ||
      lc.name == "GuidePoint SOAR Services-Remote" ||
      lc.name == "GuidePoint SOAR Services-Premium" ||
      lc.name == "GuidePoint Splunk Services-Standard" ||
      lc.name == "GuidePoint Splunk Services-Remote" ||
      lc.name == "GuidePoint Splunk Services-Premium" ||
      lc.name == "GuidePoint F5 Networks Services-Standard" ||
      lc.name == "GuidePoint F5 Networks Services-Remote" ||
      lc.name == "GuidePoint F5 Networks Services-Premium"
    end
  end

  def management?
    GsaLaborCategory::MANAGEMENT.include?(self)
  end

  def default_billrate (region: nil, contract_vehicle: nil)
    if  name == "GuidePoint SOAR Services-Standard" ||
        name == "GuidePoint SOAR Services-Remote" ||
        name == "GuidePoint SOAR Services-Premium" ||
        name == "GuidePoint Splunk Services-Standard" ||
        name == "GuidePoint Splunk Services-Remote" ||
        name == "GuidePoint Splunk Services-Premium" ||
        name == "GuidePoint F5 Networks Services-Standard" ||
        name == "GuidePoint F5 Networks Services-Remote" ||
        name == "GuidePoint F5 Networks Services-Premium"
      gsa_floor_price
    elsif contract_vehicle == GSA_GUIDEPOINTSECURITY && !federal_max_price.nil?
      federal_max_price
    else
      Variable.get('default_billable_rate')
    end
  end

  def compliant? (billrate, contract_vehicle: nil, region: nil)
    compliant = true
    message = ''

    if contract_vehicle == GsaLaborCategory::GSA_GUIDEPOINTSECURITY && NON_GSA.include?(self)
      compliant = false
      message = 'You cannot use a non-GSA labor category for GSA service.'

    elsif region == GsaLaborCategory::FEDERAL_REGION
      if contract_vehicle == GsaLaborCategory::GSA_GUIDEPOINTSECURITY && !federal_max_price.nil?
        compliant = billrate > 0.0 && billrate <= federal_max_price
        unless compliant
          message = "Billable Hourly Rate must be less than or equal to the GSA Ceiling Price (#{federal_max_price})."
        end

      elsif GsaLaborCategory::NON_GSA.include?(self)
        compliant = billrate > 0.0
        message = 'Billable Hourly Rate must be greater than $0.00.' unless compliant
      end

    # NOT Federal Region
    elsif (contract_vehicle == GsaLaborCategory::GSA_GUIDEPOINTSECURITY) && !federal_max_price.nil?
      compliant = billrate > 0.0 && billrate <= federal_max_price
      unless compliant
        message = "Billable Hourly Rate must be less than or equal to the GSA Ceiling Price (#{federal_max_price})."
      end

    elsif (contract_vehicle != GsaLaborCategory::GSA_GUIDEPOINTSECURITY) && !gsa_floor_price.nil?
      compliant = billrate >= gsa_floor_price
      unless compliant
        message = "Billable Hourly Rate must be greater than or equal to the Commercial Floor Price (#{gsa_floor_price})."
      end

    # If not a NON-GSA category, then billrate must be greater than 0.0
    elsif !GsaLaborCategory::NON_GSA.include?(self)
      compliant = billrate > 0.0
      message = 'Billable Hourly Rate must be greater than $0.00.' unless compliant

    elsif billrate < 0.0
      compliant = false
      message = 'Billable Hourly Rate cannot be less than $0.00'
    end

    {
      is_compliant: compliant,
      message:      message
    }
  end
end
