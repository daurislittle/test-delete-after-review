class WorkBreakdownStructure < ApplicationRecord
  ICON = 'layer-group'.freeze
  ICON_PLUS = 'layer-plus'.freeze
  ICON_COLOR = 'text-warning'.freeze

  PM_COMPLIANCE = 0.095

  CONTRACT_TYPE_TM = 'T&M'.freeze
  CONTRACT_TYPE_FFP = 'FFP'.freeze

  include IsWatchable

  belongs_to :user
  belongs_to :published_by, class_name: 'User', optional: true
  belongs_to :updated_by, class_name: 'User'
  belongs_to :scoped_by, class_name: 'Corporate'
  belongs_to :project_manager, class_name: 'Corporate', optional: true

  has_many :wbs_entries, dependent: :destroy, inverse_of: :work_breakdown_structure
  has_many :scoping_details, dependent: :destroy
  has_many :recently_vieweds, -> { where viewed_type: 'WorkBreakdownStructure' }, foreign_key: 'viewed_id', dependent: :destroy
  has_and_belongs_to_many :practices, inverse_of: :work_breakdown_structure
  has_one :billing_address, inverse_of: :addressable, as: :addressable, class_name: 'Address', dependent: :destroy

  accepts_nested_attributes_for :wbs_entries, allow_destroy: true
  accepts_nested_attributes_for :scoping_details, allow_destroy: true
  accepts_nested_attributes_for :billing_address, allow_destroy: true

  #validates :title, presence: true
  validates :contract_term, numericality: { only_integer: true, greater_than: 0 },
                            presence: true, unless: proc { |a| a.billing_rule != 'Contract Term Period' }
  validate :has_practices
  validate :has_project_structure

  searchkick word_middle: [:title, :scoped_by, :owned_by, :account_name],
             word_start: [:scoped_by_first, :scoped_by_last, :owned_by_first, :owned_by_last]

  def search_data
    my_data = attributes.merge(
        scoped_by: scoped_by.name,
        owned_by: user.name,
        scoped_by_first: scoped_by.firstname,
        scoped_by_last: scoped_by.lastname,
        owned_by_first: user.first_name,
        owned_by_last: user.last_name
    )

    if !opportunity.nil?
      my_data.merge!(
          opportunity_name: opportunity.Name,
          opportunity_num: opportunity.GP_Opportunity_Number__c,
          account_name: opportunity.account.Name
      )
    else
      my_data.merge!(
          opportunity_name: '',
          opportunity_num: '',
          account_name: ''
      )
    end

    my_data
  end

  #has_paper_trail

  amoeba do
    enable
    nullify :sfdc_quote_id
  end

  def self.create_for (user, opportunity: nil)
    corporate = Corporate.for_email(user.email)
    corporate = Corporate.createFromOkta(user) unless corporate

    wbs = WorkBreakdownStructure.new
    wbs.user = user
    wbs.scoped_by = corporate
    wbs.build_billing_address(kind: 'other')
    wbs.extra['primary_contact'] = {
      name: '',
      title: '',
      phone: '',
      email: ''
    }

    wbs.extra['secondary_contact'] = {
      name: '',
      title: '',
      phone: '',
      email: ''
    }

    contact = SalesForce::Contact.find_by_email(user.email)

    wbs.gps_secondary_contact_id = contact.id if contact.valid?
    wbs.opportunity = opportunity

    wbs
  end

  def self.for_opportunity (opportunity)
    WorkBreakdownStructure.where(sfdc_opportunity_id: opportunity.id)
  end

  def self.with_practice (practice)
    WorkBreakdownStructure.all.select { |wbs| wbs.practices.include? practice }
  end

  def self.billing_rules (contract_type)
    if !contract_type.blank? && contract_type.downcase == CONTRACT_TYPE_TM.downcase
      [
          Enumeration.find_by(enum_type: 'billing_rule', name: 'Monthly'),
          Enumeration.find_by(enum_type: 'billing_rule', name: 'Upon Signature')
      ]
    elsif !contract_type.blank? && contract_type.downcase == CONTRACT_TYPE_FFP.downcase
      [
          Enumeration.find_by(enum_type: 'billing_rule', name: 'Contract Term Period'),
          Enumeration.find_by(enum_type: 'billing_rule', name: '50% upon Signature, 50% upon Draft Deliverable'),
          Enumeration.find_by(enum_type: 'billing_rule', name: 'PCI - 25%/50%/25%'),
          Enumeration.find_by(enum_type: 'billing_rule', name: 'Upon Completion'),
          Enumeration.find_by(enum_type: 'billing_rule', name: 'Upon Delivery of All Draft Deliverables'),
          Enumeration.find_by(enum_type: 'billing_rule', name: 'Upon Delivery of Individual Draft Deliverables'),
          Enumeration.find_by(enum_type: 'billing_rule', name: 'Upon Signature'),
          Enumeration.find_by(enum_type: 'billing_rule', name: 'Quarterly Billing')
      ]
    else
      []
    end
  end

  def self.for_quote (sfdc_quote_id)
    WorkBreakdownStructure.find_by(sfdc_quote_id: sfdc_quote_id, is_deleted: false)
  end

=begin No longer supported, but keeping for now...
  def self.from_quote(quote)
    wbs = nil

    if quote.valid? && !quote.IsDeleted
      opportunity = SalesForce::Opportunity.fetch(quote.opportunity_id)

      wbs = WorkBreakdownStructure.new(
        title: quote.name,
        sfdc_opportunity_id: quote.opportunity_id,
        sfdc_quote_id: quote.Id,
        expenses_billable: opportunity.Expenses_Billable__c == 'Yes',
        vendor_delivered_services: opportunity.Vendor_Delivered_Services__c == 'Yes'
      )

      contact = opportunity.account_executive.contact
      wbs.gps_primary_contact_id = contact.Id if contact.valid?

      owner = quote.owner
      if owner.valid?
        scoped_by = Corporate.find_by(email: owner.Email)
        wbs.scoped_by = scoped_by unless scoped_by.nil?

        user = User.find_by(email: owner.Email)
        wbs.user_id = user.id if user.valid?

        contact = owner.contact
        wbs.gps_secondary_contact_id = contact.Id if contact.valid?
      end

      wbs.acct_primary_contact_id = quote.acct_primary_contact_id unless quote.acct_primary_contact_id.blank?
      wbs.acct_secondary_contact_id = quote.acct_secondary_contact_id unless quote.acct_secondary_contact_id.blank?

      if opportunity.account.billing_address?
        wbs.build_billing_address(
            kind: 'billing',
            address1: opportunity.account.billing.address1,
            address2: '',
            city: opportunity.account.billing.city,
            state: opportunity.account.billing.state,
            postalcode: opportunity.account.billing.zipcode,
            country: opportunity.account.billing.country
          )
      elsif opportunity.account.headquarters_address?
        wbs.build_billing_address(
            kind: 'headquarters',
            address1: opportunity.account.headquarters.address1,
            address2: '',
            city: opportunity.account.headquarters.city,
            state: opportunity.account.headquarters.state,
            postalcode: opportunity.account.headquarters.zipcode,
            country: ''
          )
      elsif opportunity.account.shipping_address?
        wbs.build_billing_address(
            kind: 'shipping',
            address1: opportunity.account.shipping.address1,
            address2: '',
            city: opportunity.account.shipping.city,
            state: opportunity.account.shipping.state,
            postalcode: opportunity.account.shipping.zipcode,
            country: ''
          )
      else
        wbs.build_billing_address(kind: 'other')
      end

      unless opportunity.Project_Structure__c.blank?
        structure = Practice.find_by(project_structure: opportunity.Project_Structure__c)

        unless structure.nil?
          wbs.project_structure = structure.project_structure
          wbs.practices << structure
        end
      end

      wbs.contract_type = if !opportunity.Contract_Type_PS__c.blank?
                            opportunity.Contract_Type_PS__c
                          else
                            Variable.get('default_contract_type')
                          end

      wbs.contract_vehicle = if !opportunity.Contract_Vehicle__c.blank?
                               opportunity.Contract_Vehicle__c
                             else
                               Variable.get('default_contract_vehicle')
                             end

      quote.lineitems.each do |lineitem|
        product = SalesForce::Product2.fetch(lineitem.product_id)

        next unless product.valid?

        wbs.wbs_entries.build(
          sku: product.name,
          billable_rate: lineitem.client_unit_price,
          internal_hourly_rate: lineitem.gps_cost,
          total_hours: lineitem.quantity,
          task: lineitem.line_item_description,
          notes: lineitem.comments,
          gsa_labor_category: GsaLaborCategory.find_by(name: lineitem.labor_category),
          ordinal: lineitem.line_number,
          contract_vehicle: lineitem.contract_vehicle
        )
      end
    end

    wbs
  end
=end

  def title
    return opportunity.Name if opportunity?

    'Untitled'
  end

  def psl_owner
    @psl_owner ||= SalesForce::Contact.find_by_email(scoped_by.email)
  end

  def practice
    @practice ||= Practice.find_by(project_structure: project_structure)
  end

  def primary_practice? (practice)
    practice.project_structure == project_structure
  end

  def actions_required?
    billing_address.nil? || billing_address.kind == 'other' ||
      acct_primary_contact_id == 'not-listed' || acct_secondary_contact_id == 'not-listed'
  end

  def can_edit? (user)
    # Does the user own this WBS?
    if self.user == user
      true
    else
      # Is the user a member of the scoping team for one of the associated project structures/practices?
      practices.each do |practice|
        return true if practice.member_scoping? user
      end

      false
    end
  end

  def watchlist (**extra)
    send_to = Set.new

    #send_to << self.user.email
    send_to << scoped_by.email

    if Rails.env.production?
      practices.each do |structure|
        structure.scoping_team.each do |member|
          send_to << member
        end
      end

      if extra.key? :sos
        if has_opportunity? && !opportunity.sos.nil?
          send_to << opportunity.sos.Email
        end
      end

      if extra.key? :ae
        if has_opportunity? && !opportunity.account_executive.nil?
          send_to << opportunity.account_executive.Email
        end
      end

      send_to << region_email unless region_email.blank?
    end

    send_to.to_a
  end

  def region_email
    region = opportunity.Region__c if has_opportunity? && opportunity.Region__c.present?
    case region
    when 'Federal'
      return 'fed.opp.scoping@guidepointsecurity.com'
    when 'Heartland'
      return 'hl.opp.scoping@guidepointsecurity.com'
    when 'Southwest'
      return 'sw.opp.scoping@guidepointsecurity.com'
    when 'Southeast'
      return 'se.opp.scoping@guidepointsecurity.com'
    when 'Northwest'
      return 'nw.opp.scoping@guidepointsecurity.com'
    when 'Northeast'
      return 'ne.opp.scoping@guidepointsecurity.com'
    when 'North Central'
      return 'nc.opp.scoping@guidepointsecurity.com'
    when 'Mid-Atlantic'
      return 'ma.opp.scoping@guidepointsecurity.com'
    end
  end

  def failure_email_list
    send_to = Set.new

    send_to << user.email

    User.joins(:roles).where(roles: {name:'Administrator'}).each do |user|
      send_to << user.email
    end

    if Rails.env.in?(['production', 'qa'])
      send_to << 'SalesforceAdmin@guidepointsecurity.com'
    end

    if Rails.env.production?
      send_to << region_email unless region_email.blank?
    end

    send_to.to_a
  end

  # Has this WBS been published?
  def is_published?
    quote.valid?
  end

  # DEPRECATED
  def has_opportunity?
    opportunity?
  end

  def opportunity?
    opportunity.valid?
  end

  def opportunity
    @opportunity ||= SalesForce::Opportunity.fetch(sfdc_opportunity_id)
  end

  def opportunity= (opportunity)
    return unless opportunity.valid?

    self.sfdc_opportunity_id = opportunity.Id
    #self.title = opportunity.Name

  # Going to always default to false...
  #@wbs.expenses_billable = @opportunity.Expenses_Billable__c == 'Yes' ? true : false
    self.expenses_billable = false

    self.gps_primary_contact_id = opportunity.account_executive.contact.Id if opportunity.account_executive? && !opportunity.account_executive.contact.nil?

    account = if opportunity.prime?
                opportunity.prime
              else
                opportunity.account
              end

    unless account.nil?
      if account.billing_address?
        full_address = [account.billing.address1]
        if (!account.billing.address1.nil? && account.billing.address1.include?("\n"))
          full_address = account.billing.address1.split("\n",2)
          full_address[1] = full_address[1].strip
          full_address[0] = full_address[0].strip
        end
        build_billing_address(
          kind: 'billing',
          address1: full_address[0],
          address2: full_address.length > 1 ? full_address[1] : '',
          city: account.billing.city,
          state: account.billing.state,
          postalcode: account.billing.zipcode,
          country: account.billing.country
        )
      elsif account.headquarters_address?
        full_address = [account.headquarters.address1]
        if (!account.headquarters.address1.nil? && account.headquarters.address1.include?("\n"))
          full_address = account.headquarters.address1.split("\n",2)
          full_address[1] = full_address[1].strip
          full_address[0] = full_address[0].strip
        end
        build_billing_address(
          kind: 'headquarters',
          address1: full_address[0],
          address2: full_address.length > 1 ? full_address[1] : '',
          city: account.headquarters.city,
          state: account.headquarters.state,
          postalcode: account.headquarters.zipcode,
          country: ''
        )
      elsif account.shipping_address?
        full_address = [account.shipping.address1]
        if (!account.shipping.address1.nil? && account.shipping.address1.include?("\n"))
          full_address = account.shipping.address1.split("\n",2)
          full_address[1] = full_address[1].strip
          full_address[0] = full_address[0].strip
        end
        build_billing_address(
          kind: 'shipping',
          address1: full_address[0],
          address2: full_address.length > 1 ? full_address[1] : '',
          city: account.shipping.city,
          state: account.shipping.state,
          postalcode: account.shipping.zipcode,
          country: ''
        )
      end
    end

    unless opportunity.Project_Structure__c.blank?
      structure = Practice.find_by(project_structure: opportunity.Project_Structure__c)

      unless structure.nil?
        self.project_structure = structure.project_structure
        practices << structure
      end
    end

    self.contract_type = if !opportunity.Contract_Type_PS__c.blank?
                           # gsub'ing in case T&M is T & M
                           opportunity.Contract_Type_PS__c.gsub(' ', '')
                         else
                           Variable.get('default_contract_type')
                         end

    self.contract_vehicle = if !opportunity.Contract_Vehicle__c.blank? && !ContractVehicle.invalid_vehicle(opportunity.Contract_Vehicle__c)
                              opportunity.Contract_Vehicle__c
                            else
                              Variable.get('default_contract_vehicle')
                            end
  end

  # DEPRECATED
  def has_account?
    account?
  end

  def account?
    opportunity? && opportunity.account?
  end

  def account
    @account ||= opportunity.account if opportunity?
  end

  def syncing?
    quote.valid? && quote.syncing?
  end

  def quote?
    quote.valid?
  end

  def quote (refresh: false)
    if @quote.nil? || refresh
      @quote ||= SalesForce.load(sfdc_quote_id, refresh: refresh)
    end

    @quote
  rescue SalesForce::NotFound
    Rails.logger.warn("Did not find a quote for id: #{sfdc_quote_id}")
    nil
  end

  def bill_to_account
    if opportunity?
      if opportunity.prime? && opportunity.prime.Name != 'GuidePoint Security LLC'
        opportunity.prime
      elsif opportunity.account?
        opportunity.account
      end
    end
  end

  # NOTE: If this returns nil, that indicates that the opportunity is not valid.  If it were valid
  #       then an empty array would be returned
  def contacts
    if opportunity?
      if opportunity.prime? && opportunity.prime.Name != 'GuidePoint Security LLC'
        opportunity.prime.contacts.where('No_Longer_With_Company__c = false').order('LastName, FirstName');
      elsif !opportunity.account.nil?
        opportunity.account.contacts.where('No_Longer_With_Company__c = false').order('LastName, FirstName');
      else
        []
      end
    end
  end

  def gps_primary_contact?
    !gps_primary_contact_id.blank?
  end

  def gps_primary_contact
    @gps_primary_contact ||= SalesForce::Contact.fetch(gps_primary_contact_id)
  end

  def gps_secondary_contact?
    !gps_secondary_contact_id.blank?
  end

  def gps_secondary_contact
    @gps_secondary_contact ||= SalesForce::Contact.fetch(gps_secondary_contact_id)
  end

  def acct_primary_contact?
    !acct_primary_contact_id.blank?
  end

  def acct_primary_contact
    @acct_primary_contact ||= if acct_primary_contact_id != 'not-listed'
                                SalesForce::Contact.fetch(acct_primary_contact_id)
                              else
                                nil
                              end
  end

  def acct_secondary_contact?
    !acct_secondary_contact_id.blank?
  end

  def acct_secondary_contact
    @acct_secondary_contact ||= if acct_secondary_contact_id != 'not-listed'
                                  SalesForce::Contact.fetch(acct_secondary_contact_id)
                                else
                                  nil
                                end
  end

  def total_hours
    wbs_entries.to_a.sum(&:total_hours)
  end

  def total_revenue
    wbs_entries.to_a.sum(&:total_revenue)
  end

  def total_internal_cost
    wbs_entries.to_a.sum(&:internal_cost)
  end

  def gross_profit_dollars
    total_revenue - total_internal_cost
  end

  def gross_profit_percent
    if total_revenue.positive?
      gross_profit_dollars / total_revenue * 100
    else
      0
    end
  end

  def actions_required
    actions_required = ''

    if !billing_address.nil? && billing_address.kind == 'other'
      actions_required << '[Billing Address:'
      actions_required << "#{billing_address.address1} "
      actions_required << "#{billing_address.address2} " unless billing_address.address2.blank?
      actions_required << "#{billing_address.city}  #{billing_address.state} #{billing_address.postalcode}"
      actions_required << " #{billing_address.country}" unless billing_address.country.blank?
      actions_required << ']'
    end

    if acct_primary_contact_id == 'not-listed'
      actions_required << "[Primary Contact: #{extra['primary_contact']['name']}"
      actions_required << " Title: #{extra['primary_contact']['title']}" unless extra['primary_contact']['title'].blank?
      actions_required << " Phone: #{extra['primary_contact']['phone']}" unless extra['primary_contact']['phone'].blank?
      actions_required << " Email: #{extra['primary_contact']['email']}" unless extra['primary_contact']['email'].blank?
      actions_required << ']'
    end

    if acct_secondary_contact_id == 'not-listed'
      actions_required << "[Secondary Contact: #{extra['secondary_contact']['name']}"
      actions_required << " Title: #{extra['secondary_contact']['title']}" unless extra['secondary_contact']['title'].blank?
      actions_required << " Phone: #{extra['secondary_contact']['phone']}" unless extra['secondary_contact']['phone'].blank?
      actions_required << " Email: #{extra['secondary_contact']['email']}" unless extra['secondary_contact']['email'].blank?
      actions_required << ']'
    end

    actions_required
  end

  def end_user
    @end_user ||= SalesForce::Contact.fetch(acct_secondary_contact_id) if acct_secondary_contact_id != 'not-listed'
  end

  def shipping_address
    if @shipping_address.nil?
      @shipping_address = SalesForce::Address.new

      if has_account?
        @shipping_address = if account.shipping_address?
                              account.shipping
                            elsif account.billing_address?
                              account.billing
                            elsif account.headquarters_address?
                              account.headquarters
                            end
      end
    end

    @shipping_address
  end

  def valid_templates
    WbsGroup.ValidTemplatesFor(practices)
  end

  def valid_sdt_templates
    ScopingDetailTemplate.ValidTemplatesFor(practices)
  end

  # Returns the valid SKUs based on the primary and secondary project structures
  def valid_skus
    practices.map(&:skus).flatten
  end

  def unique_sku
    WbsEntry.unique_sku(id)
  end

  def lineitems_for_sku(sku, category_id = nil, billable_rate = nil, internal_hourly_rate = nil)
    if category_id.nil?
      if billable_rate.nil?
        if internal_hourly_rate.nil?
          wbs_entries.where(sku: sku)
        else
          wbs_entries.where(sku: sku, internal_hourly_rate: internal_hourly_rate)
        end
      else
        if internal_hourly_rate.nil?
          wbs_entries.where(sku: sku, billable_rate: billable_rate)
        else
          wbs_entries.where(sku: sku, billable_rate: billable_rate, internal_hourly_rate: internal_hourly_rate)
        end
      end
    else
      if billable_rate.nil?
        if internal_hourly_rate.nil?
          wbs_entries.where(sku: sku, gsa_labor_category_id: category_id)
        else
          wbs_entries.where(sku: sku, gsa_labor_category_id: category_id, internal_hourly_rate: internal_hourly_rate)
        end
      else
        if internal_hourly_rate.nil?
          wbs_entries.where(sku: sku, gsa_labor_category_id: category_id, billable_rate: billable_rate)
        else
          wbs_entries.where(sku: sku, gsa_labor_category_id: category_id, billable_rate: billable_rate, internal_hourly_rate: internal_hourly_rate)
        end
      end
    end
  end

  def pm_and_engagement_hours
    results = {
        pm: 0,
        engagement: 0
    }

    wbs_entries.each do |line|
      results[:pm] += line.total_hours if line.pm?
      results[:engagement] += line.total_hours if line.engagement?
    end

    results
  end

  def pm_compliant?
    pm_and_engagement = pm_and_engagement_hours

    !(pm_and_engagement[:engagement].to_f > 0.0 && (pm_and_engagement[:pm].to_f / pm_and_engagement[:engagement].to_f) < PM_COMPLIANCE)
  end

  def gsa_compliant?
    wbs_entries.each do |entry|
      return false unless entry.gsa_compliant?
    end

    true
  end

  def nonzero_hours_compliant?
    response = true
    wbs_entries.each do |wbs_entry|
      if wbs_entry.total_hours <= 0
        response = false
        break
      end
    end

    response
  end

  def total_lines (line_ids)
    results = {
        total_hours:      0,
        total_revenue:    0.0,
        total_internal:   0.0,
        total_profit:     0.0,
        total_profit_pct: 0.0
    }

    line_ids.each do |line_id|
      line = wbs_entries.find_by(id: line_id)

      if !line.nil?
        results[:total_hours] += line.total_hours
        results[:total_revenue] += line.total_hours * line.billable_rate
        results[:total_internal] += line.total_hours * line.internal_hourly_rate
      end
    end

    results[:total_profit] = results[:total_revenue] - results[:total_internal]
    results[:total_profit_pct] = results[:total_profit] / results[:total_revenue] * 100

    results
  end

  def row_for_sku (sku_id)
    wbs_entries = lineitems_for_sku(sku_id)
    hours = 0
    revenue = 0.0
    cost = 0.0

    wbs_entries.each do |wbs_entry|
      hours   += wbs_entry.total_hours unless wbs_entry.total_hours.blank?
      revenue += wbs_entry.billable_rate * wbs_entry.total_hours unless wbs_entry.total_hours.blank? || wbs_entry.billable_rate.blank?
      cost    += wbs_entry.internal_hourly_rate * wbs_entry.total_hours unless wbs_entry.total_hours.blank? || wbs_entry.internal_hourly_rate.blank?
    end

    {
        hours: hours,
        revenue: revenue,
        cost: cost
    }
  end

  def row_for_category (sku, category_id, billable_rate, internal_hourly_rate)
    wbs_entries = lineitems_for_sku(sku, category_id, billable_rate, internal_hourly_rate)

    hours = 0
    revenue = 0.0
    cost = 0.0

    if wbs_entries.count.positive?
      wbs_entries.each do |wbs_entry|
        hours   += wbs_entry.total_hours unless wbs_entry.total_hours.blank?
        revenue += wbs_entry.billable_rate * wbs_entry.total_hours unless wbs_entry.total_hours.blank? || wbs_entry.billable_rate.blank?
        cost    += wbs_entry.internal_hourly_rate * wbs_entry.total_hours unless wbs_entry.total_hours.blank? || wbs_entry.internal_hourly_rate.blank?
      end

      {
          hours: hours,
          billable_rate: wbs_entries.first.billable_rate,
          revenue: revenue,
          internal_rate: wbs_entries.first.internal_hourly_rate,
          cost: cost
      }
    else
      nil
    end
  end

  def notes_ok?
    wbs_entries.each do |lineitem|
      return false unless lineitem.notes_ok?
    end

    true
  end

  def publishable?
    validate_publishability.empty?
  end

  def validate_publishability
    skus = valid_skus
    skus_sd = skus + GenericSku.all
    validate_publishability_with_skus(skus, skus_sd)
  end

  def validate_publishability_with_skus(skus, skus_sd)
    warnings = []

    Rails.logger.info('Starting to validate publishability of WBS: '+ id.to_s)
    # Opportunity must be selected, be a Services Opportunity, have a probability >=0 and < 100, and not be closed or deleted
    if !opportunity?
      warnings << 'This WBS has not been associated with an opportunity.'
    else
      if !opportunity.service?
        warnings <<
          'The opportunity does not have a Record Type of GPS Services or the Opportunity Type is not set to Services. '\
          'Please contact <a href="mailto:SalesforceAdmin@guidepointsecurity.com">SalesforceAdmin@guidepointsecurity.com</a>.'
      elsif opportunity.Probability <= 0 ||
        opportunity.Probability >= 100 ||
        opportunity.IsClosed ||
        opportunity.IsDeleted
        warnings <<
          'The opportunity has been closed, deleted, or its probability either 0 or greater than 100%.  '\
          'Make sure the stage of the SF opportunity is set to something other than closed/won/lost and ensure '\
          'that the opportunity\'s probability is less than 100%. '\
          'Please contact <a href="mailto:SalesforceAdmin@guidepointsecurity.com">SalesforceAdmin@guidepointsecurity.com</a>.'
      end
    end

    # Contract type must be selected
    warnings << 'The contract type has not been defined.' if contract_type.blank?

    # Contract type must valid in Salesforce
    unless contract_type.blank? || SalesForce::Opportunity.contract_types.include?(contract_type)
      warnings << 'The selected contract type is not available in Salesforce. '\
                  'Please contact the <a href="mailto:SalesforceAdmin@guidepointsecurity.com">SalesforceAdmin@guidepointsecurity.com</a>.'
    end

    # Contract vehicle must be selected
    warnings << 'The contract vehicle must be defined. '\
                'Select "GuidePoint Direct" for all direct sales to customers.' if contract_vehicle.blank?

    # Contract vehicle must be valid in Salesforce
    unless contract_vehicle.blank? || SalesForce::Opportunity.contract_vehicles.include?(contract_vehicle)
      warnings << 'The selected contract vehicle is not available in Salesforce. '\
                  'Please contact the <a href="mailto:SalesforceAdmin@guidepointsecurity.com">SalesforceAdmin@guidepointsecurity.com</a>.'
    end

    # Billing rule must be selected
    warnings << 'The billing rule must be defined.' if billing_rule.blank?

    if billing_address.nil?
      warnings << 'The billing address must be defined.'
    elsif billing_address.kind == 'other' && (billing_address.address1.blank? || billing_address.state.blank? || billing_address.city.blank? || billing_address.postalcode.blank?)
      warnings << 'The billing address is set to "other" and is incomplete.'
    end

    # Primary contact from the account must be selected
    if !acct_primary_contact?
      warnings << 'The primary client contact needs to be defined.'

    # If primary contact is set to 'not-listed', then the contact definition should have been provided
    elsif acct_primary_contact_id == 'not-listed'

      # Primary contact definition exist?
      if !extra.key?('primary_contact')
        warnings << 'Please provide the primary contact details when "Not Listed"" is selected.'
      else
        # Name of new contact is required
        if !extra['primary_contact'].key?('name') || extra['primary_contact']['name'].blank?
          warnings << 'Please provide the primary contact\'s name when "Not Listed" is selected'
        end

        # Phone number of new contact is required
        if !extra['primary_contact'].key?('phone') || extra['primary_contact']['phone'].blank?
          warnings << 'Please provide a phone number for the primary contact when "Not Listed" is selected.'
        end

        # Email address of new contact is required
        if !extra['primary_contact'].key?('email') || extra['primary_contact']['email'].blank?
          warnings << 'Please provide an email address for the primary contact when "Not Listed" is selected.'
        end
      end
    end

    # Secondary contact is optional, but if 'not-listed' is selected the validate
    if acct_secondary_contact_id == 'not-listed'

      # Secondary contact definition exist?
      if !extra.key?('secondary_contact')
        warnings << "Please provide the secondary contact details when 'Not Listed' is selected."

      else
        # Name of new contact is required
        if !extra['secondary_contact'].key?('name') || extra['secondary_contact']['name'].blank?
          warnings << "Please provide the secondary contact's name when 'Not Listed' is selected."
        end

        # Phone number of new contact is required
        if !extra['secondary_contact'].key?('phone') || extra['secondary_contact']['phone'].blank?
          warnings << "Please provide a phone number for the secondary contact when 'Not Listed' is selected."
        end

        # Email address of new contact is required
        if !extra['secondary_contact'].key?('email') || extra['secondary_contact']['email'].blank?
          warnings << "Please provide an email address for the secondary contact when 'Not Listed' is selected."
        end
      end
    end

    # Validate the primary GuidePoint contact
    warnings << if !gps_primary_contact?
                  'Please provide the primary GPS contact.'
                elsif !gps_primary_contact.valid?
                  'Could not locate the specified GPS primary contact.'
                elsif gps_primary_contact.account != Corporate.gps_account
                  'Selected primary GPS contact is not associated with the GPS account.'
                elsif gps_primary_contact.no_longer_with_company?
                  'Selected primary GPS contact is no longer with the company. Please update.'
                end

    # Validate the secondary GuidePoint contact
    warnings << if !gps_secondary_contact?
                  'Please provide the secondary GPS contact.'
                elsif !gps_secondary_contact.valid?
                  'Could not locate the specified GPS secondary contact.'
                elsif gps_secondary_contact.account != Corporate.gps_account
                  'Selected secondary GPS contact is not associated with the GPS account.'
                elsif gps_secondary_contact.no_longer_with_company?
                  'Selected secondary GPS contact is no longer with the company. Please update.'
                end

    # Make sure the Contact for the PSL Owner can be found in Salesforce
    psl_owner = nil
    psl_owner = SalesForce::Contact.find_by_email(scoped_by.email) unless scoped_by.blank?
    warnings << "Cannot find a Salesforce contact for the PSL owner: #{scoped_by.blank? ? scoped_by_id : scoped_by.email}." if psl_owner.nil?

    # Make sure we can find the practice definition so we can get the scoping email addresses, etc.
    practice = Practice.find_by(project_structure: project_structure)
    warnings << "Cannot find the project structure '#{project_structure}'." if practice.nil?

    # Makes no sense to publish a WBS with no line items.
    warnings << "The WBS does not contain any line items." if wbs_entries.empty?

    labor_categories = SalesForce::SBQQ__QuoteLine.labor_categories
    contract_vehicles = SalesForce::SBQQ__QuoteLine.contract_vehicles

    # Make sure each line item is valid
    Rails.logger.info('Loading valid skus WBS: '+id.to_s)
    Rails.logger.info('Validating line items of WBS: ' + id.to_s)
    wbs_entries.order(:ordinal).each_with_index do |entry, index|
      warnings << entry.validate_publishability(index+1, labor_categories, contract_vehicles, skus)
    end

    Rails.logger.info('Validating scoping details of WBS: ' + id.to_s)
    # Make sure each line item is valid
    scoping_details.order(:ordinal).each_with_index do |entry, index|
      warnings << entry.validate_publishability(index+1, skus_sd)
    end
    Rails.logger.info('Validation completed of WBS: ' + id.to_s)
    warnings.flatten.compact
  end

  def validate_with_quote (quote)
    quote.refresh

    issues = []
    #issues << "Quote name does not match." if quote.name != title
    issues << validate_item((!acct_primary_contact_id.blank? && acct_primary_contact_id != 'not-listed' ? acct_primary_contact_id : nil),
                            quote.acct_primary_contact_id,
                            "Quote primary account contact does not match.")
    issues << validate_item((!acct_secondary_contact_id.blank? && acct_secondary_contact_id != 'not-listed' ? acct_secondary_contact_id : nil),
                            quote.acct_secondary_contact_id,
                            "Quote secondary account contact does not match.")
    issues << validate_item(sfdc_opportunity_id, quote.opportunity_id, "Quote opportunity does not match.")
    issues << validate_item(opportunity.pricebook_id, quote.pricebook_id, "Quote pricebook does not match.")
    issues << validate_item((actions_required.blank? ? 'Reviewed / Approved' : 'Under Review'),
                            quote.cogs_status,
                            "Quote COGS status does not match.")
    issues << validate_item(psl_owner.id, quote.psl_owner_id, "Quote PSL owner does not match.")
    issues << validate_item(practice.scoping_team[0], quote.psl_team, "Quote PSL team does not match.")
    issues << validate_item(bill_to_account.name, quote.billing_name, "Quote billing name does not match.")
    issues << validate_item("#{billing_address.address1} #{billing_address.address2}".strip,
                            quote.billing_street,
                            "Quote billing street address does not match.")
    issues << validate_item(billing_address.city, quote.billing_city, "Quote billing city does not match.")
    issues << validate_item(billing_address.state, quote.billing_state, "Quote billing state does not match.")
    issues << validate_item(billing_address.postalcode, quote.billing_postal_code, "Quote billing postal code does not match.")
    issues << validate_item(billing_address.country, quote.billing_country, "Quote billing country does not match.")

    if !quote.cogs_action_required.blank?
      issues << "Quote COGS Action Required does not match." if quote.cogs_action_required != actions_required
    elsif !actions_required.blank?
      issues << "Quote COGS Action Required does not match" if quote.cogs_action_required != actions_required
    end

    lineitems = quote.lineitems(refresh:true)

    issues << "Quote number of line items does not match. Expected #{wbs_entries.count}, but found #{lineitems.count}" if lineitems.count != wbs_entries.count

    lineitems.each do |lineitem|
      lineitem.refresh

      wbs_line = wbs_entries.find_by(ordinal: (lineitem.line_number - 1).to_i)
      issues << "Could not find WBS line item that corresponds to quote line number #{lineitem.line_number}." if wbs_line.nil?

      issues << wbs_line.validate_with_quoteline(lineitem) unless wbs_line.nil?
    end

    issues.flatten.compact
  end

  private

  def validate_item (expected, actual, message)
    if expected.is_a?(String) || actual.is_a?(String)
      Rails.logger.debug("Expected: #{expected.blank?} - #{actual.blank?}")
      if (expected.blank? && !actual.blank?)
        "#{message} Expected '#{expected}' but found '#{actual}'." if expected != actual
      elsif !expected.blank? && !actual.blank? && expected != actual
        "#{message} Expected '#{expected}' but found '#{actual}'." if expected != actual
      end

    elsif expected != actual
      "#{message} Expected #{expected} but found #{actual}." if expected != actual
    end
  end

  def has_project_structure
    errors.add(:project_structure, 'must specify the project structure') if project_structure.blank?
  end

  def has_practices
    errors.add(:practice_ids, 'must add at least one practice') if practices.empty?
  end
end
