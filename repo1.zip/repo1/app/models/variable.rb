class Variable < ApplicationRecord
  validates :name, presence: true, allow_blank:false
  validates :label, presence: true, allow_blank:false

  def self.get (name, default_value:nil)
    variable = Variable.find_by(name: name)
    if !variable.nil?
      variable.value
    else
      default_value
    end
  end
end
