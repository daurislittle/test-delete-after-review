class Practice < ApplicationRecord
  has_and_belongs_to_many :work_breakdown_structures, inverse_of: :practice
  has_and_belongs_to_many :wbs_groups
  has_and_belongs_to_many :scoping_detail_templates

  validates :project_structure, presence: true

  def self.for_structure(practice_name)
    Practice.find_by(project_structure: practice_name)
  end

  def self.non_existing
    Practice.where.not(project_structure: SalesForce::Opportunity.project_structures)
  end

  # Retrieve all of the sku's for this practice
  def skus
    skus = []

    practices.each do |practice|
      SalesForce::Sku.for_practice(practice).each do |sku|
        skus << sku
      end
    end

    skus
  end

  # Does the provided name represent a valid sku for this practice?
  def sku? (name)
    product = SalesForce::Sku.find_by_name_active(name)

    product.valid? && practices.include?(product.practice)
  end

  def member_scoping? (user)
    scoping_team.each do |email|
      return true if user.email == email

      group = GpsGroup.find_by_email(email)
      unless group.nil?
        return true if group.member?(user)
      end
    end

    false
  end
end
