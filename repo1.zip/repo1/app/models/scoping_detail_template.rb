class ScopingDetailTemplate < ApplicationRecord
  ICON = 'file-plus'.freeze
  ICON_STYLE = :light
  ICON_COLOR = 'text-info'.freeze

  belongs_to :user
  has_many :sdt_items, dependent: :destroy
  has_and_belongs_to_many :practices
  accepts_nested_attributes_for :sdt_items, allow_destroy: true

  validates :name, presence: true
  validates :practices, length: {minimum: 1, message: 'is required.  Must specify at least one.'}

  has_paper_trail

  amoeba do
    enable
    prepend :name => "Copy of "
  end

  def self.ValidTemplatesFor (practices)
    valid_groups = []

    ScopingDetailTemplate.where(is_deleted: false).order(:name).each do |group|
      if (group.practices & practices) == group.practices
        valid_groups << group
      end
    end

    valid_groups
  end

  def last_updated
    last_updated = sdt_items.max { |a, b| a.updated_at <=> b.updated_at }
    !last_updated.nil? && last_updated.updated_at > updated_at ? last_updated.updated_at : updated_at
  end

  def valid_skus
    practices.map(&:skus).flatten
  end
end
