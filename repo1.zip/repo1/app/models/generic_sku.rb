class GenericSku

  def initialize(name, id)
    @name = name
    @id = id
  end

  def name
    @name
  end

  def id
    @id
  end

  def description
    'Legacy Value - Please Change'
  end

  def self.all
    generic_skus = []
    enums = Enumeration.where(enum_type: 'sku').order(:name)

    enums.each do |sku|
      generic_skus << GenericSku.new(sku.name, sku.id.to_s)
    end

    generic_skus
  end
end