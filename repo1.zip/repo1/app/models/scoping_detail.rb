class ScopingDetail < ApplicationRecord
  belongs_to :work_breakdown_structure

  #validates :item, presence: true
  #validates :sku_id, presence: true

  has_paper_trail

  def sku
    if sku_id.blank?
      ''
    else
      if sku_id.start_with?(SalesForce::Product2.class_prefix)
        SalesForce::Product2.find_by(Id: sku_id)
      elsif /\A\d+\z/.match(sku_id)
        Enumeration.find_by(id: sku_id)
      end
    end
  end

  def validate_publishability(line_number, skus)
    warnings = []
    warnings << "Scoping Detail Line ##{line_number}: Please update to an actual Salesforce SKU" if sku_id.blank? || !sku_id.start_with?(SalesForce::Product2.class_prefix)
    warnings << "Scoping Detail Line ##{line_number}: The SKU is not active in Salesforce for the Practice/Project Structure" if sku_id.length != 18 || skus.none? {|s| s.id === sku_id }
    warnings << "Scoping Detail Line ##{line_number}: Please enter a value for the Item field" unless !item.blank?
    warnings
  end
end
