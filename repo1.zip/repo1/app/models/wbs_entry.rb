class WbsEntry < ApplicationRecord
  MAX_NOTES_LENGTH = 255

  belongs_to :gsa_labor_category
  belongs_to :work_breakdown_structure, inverse_of: :wbs_entries

  validates :total_hours, numericality: true
  #has_paper_trail

  amoeba do
    enable
    nullify :sfdc_lineitem_id
  end

  # Returns the SKUs present in the given WBS
  def self.unique_sku (wbs_id)
    WbsEntry.select(:sku).distinct.where(work_breakdown_structure_id: wbs_id).pluck(:sku)
  end

  def self.collectSkus(skus)
    skuList = skus.collect { |s| [s.name, s.name, {'data-description' => s.description}] }
    skuList
  end

  def self.addSku(skus, skuList, sku)
    skuList = [] if skuList.nil?
    skuList.append([sku, sku, {'data-description' => "Inactive SKU"}]) if skus.nil? || skus.none? {|s| s.name === sku}
    skuList
  end

  def self.collectSkusWithSku(skus, sku)
    skuList = []
    skuList = skus.collect { |s| [s.name, s.name, {'data-description' => s.description}] } if skus.present?
    if skus.nil? || skus.none? {|s| s.name === sku}
      skuList.append([sku, sku, {'data-description' => "Inactive SKU"}])
    end
    skuList
  end

    # Returns the labor categories present for the given WBS
  def self.unique_labor_categories (wbs_id)
    GsaLaborCategory.where(id: WbsEntry.select(:gsa_labor_category_id).distinct.where(
      work_breakdown_structure_id: wbs_id
    ).pluck(:gsa_labor_category_id))
  end

  # Returns the billable rates present for the given WBS
  def self.unique_billable_rate (wbs_id)
    WbsEntry.select(:billable_rate).distinct.where(work_breakdown_structure_id: wbs_id).pluck(:billable_rate)
  end

  # Returns the internal rates present for the given WBS
  def self.unique_internal_hourly_rate (wbs_id)
    WbsEntry.select(:internal_hourly_rate).distinct.where(work_breakdown_structure_id: wbs_id).pluck(:internal_hourly_rate)
  end

  # Returns all line items with the given SKU
  def self.for_sku (wbs_id, sku)
    WbsEntry.where(sku: sku, work_breakdown_structure_id: wbs_id)
  end

  def pricebook_entry
    @pricebook_entry ||= SalesForce::PricebookEntry.find_by_name(sku)
  end

  # An engagement task is one that is NOT:
  #   a "management" LCAT,
  #   a 'tool' sku,
  #   a task containing substring 'gears', and
  #   a task containing the substring 'after hours'
  def engagement?
    !GsaLaborCategory::MANAGEMENT.include?(gsa_labor_category)  &&
      (sku.nil? || !sku.downcase.include?('tool')) &&
      !task.downcase.include?('gears') &&
      !task.downcase.include?('after hours')
  end

  def pm?
    GsaLaborCategory::MANAGEMENT.include?(gsa_labor_category)
  end

  def total_revenue
    if !billable_rate.nil? && !total_hours.nil?
      billable_rate * total_hours
    else
      0.0
    end
  end

  def internal_cost
    if !internal_hourly_rate.nil? && !total_hours.nil?
      internal_hourly_rate * total_hours
    else
      0.0
    end
  end

  def gross_profit_dollars
    total_revenue - internal_cost
  end

  def gross_profit_percent
    percent = gross_profit_dollars / total_revenue * 100
    percent = 0.0 if percent.nan? || percent.infinite?

    percent
  end

  def validate_publishability (line_number, labor_categories, contract_vehicles, skus)

    warnings = []

    warnings << "Line Item ##{line_number}: Please provide a task." if task.blank?
    warnings << "Line Item ##{line_number}: Please provide the billable rate." if billable_rate.blank?

    unless billable_rate.blank? || billable_rate > 0.0 || GsaLaborCategory::NON_GSA.include?(gsa_labor_category)
      warnings << "Line Item ##{line_number}: Billable rate must be greater than zero for GSA labor categories."
    end

    if GsaLaborCategory::NON_GSA.include?(gsa_labor_category) && !billable_rate.blank? && billable_rate < 0.0
      warnings << "Line Item ##{line_number}: Billable rate must be greater than or equal to zero for NON-GSA labor categories."
    end

    warnings << "Line Item ##{line_number}: Please provide the total number of hours." if total_hours.blank?
    warnings << "Line Item ##{line_number}: Total hours must be greater than zero." if !total_hours.blank? && total_hours <= 0.0
    warnings << "Line Item ##{line_number}: Total hours must be multiples of quarter hours." if !total_hours.blank? && (total_hours % 0.25) != 0.0

    warnings << "Line Item ##{line_number}: Please specify a phase." if phase.blank?
    warnings << "Line Item ##{line_number}: Phase must be greater than zero." if !phase.blank? && phase <= 0
    warnings << "Line Item ##{line_number}: Phase must be an integral value." if !phase.blank? && !phase.to_s.match?(/^\d+$/)

    warnings << "Line Item ##{line_number}: Is not GSA compliant." unless gsa_compliant?
    warnings << "Line Item ##{line_number}: No labor category selected." if gsa_labor_category.nil?


    warnings << "Line Item ##{line_number}: Must provide the internal hourly rate." if internal_hourly_rate.blank?
    if !internal_hourly_rate.blank? && internal_hourly_rate < 0.0 && gsa_labor_category.in?(GsaLaborCategory::NON_GSA)
      warnings << "Line Item ##{line_number}: Internal hourly rate must be greater than or equal to zero for Non-GSA Labor Categories."
    end

    if !internal_hourly_rate.blank? && internal_hourly_rate <= 0.0 && !gsa_labor_category.in?(GsaLaborCategory::NON_GSA)
      warnings << "Line Item ##{line_number}: Internal hourly rate must be greater than zero for GSA Labor Categories."
    end

    unless gsa_labor_category.nil? || labor_categories.include?(gsa_labor_category.name)
      warnings << "Line Item ##{line_number}: Selected labor category is not available in Salesforce. "\
                    'Please contact the <a href="mailto:SalesforceAdmin@guidepointsecurity.com">SalesforceAdmin@guidepointsecurity.com</a>.'
    end

    unless contract_vehicle.blank? || contract_vehicles.include?(contract_vehicle)
      warnings << "Line Item ##{line_number}: Selected contract vehicle is not available in Salesforce. "\
                    'Please contact the <a href="mailto:SalesforceAdmin@guidepointsecurity.com">SalesforceAdmin@guidepointsecurity.com</a>.'
    end

    # Can we Find the price book entry for the SKU
    if SalesForce::PricebookEntry.find_by_name(sku).nil?
      warnings << "Line Item ##{line_number}: Failed to locate a Salesforce pricebook entry for #{sku}"
    end

    if !skus.any? {|s| s.name === sku}
      warnings << "Line Item ##{line_number}: The SKU #{sku} is not active in Salesforce for the Practice/Project Structure"
    end

    warnings
  end

  def notes_ok?
    notes.nil? || notes.length <= MAX_NOTES_LENGTH
  end

  def gsa_compliant?
    gsa_compliance[:is_compliant]
  end

  def gsa_compliance (region = nil)
    contract_vehicle = if !self.contract_vehicle.blank?
                         self.contract_vehicle
                       else
                         work_breakdown_structure.contract_vehicle
                       end

    if contract_vehicle.blank?
      {
        is_compliant: false,
        message: 'There is not an associated contract vehicle.  Make sure it is set at the WBS level'\
                 ' or on the line item.'
      }
    elsif gsa_labor_category.nil? || billable_rate.nil?
      {
          is_compliant: false,
          message: 'The entry does not have a labor category and/or bill rate.'
      }
    else
      gsa_labor_category.compliant?(
          billable_rate,
          contract_vehicle: contract_vehicle,
          region: !work_breakdown_structure.opportunity.nil? ? work_breakdown_structure.opportunity.Region__c : region
      )
    end
  end

  def validate_with_quoteline (quoteline)
    issues = []

    quote_linenumber = quoteline.line_number.to_i

    issues << "Quote lineitem \##{quote_linenumber} total hours do not match. Expected #{total_hours}." if quoteline.quantity != total_hours
    issues << "Quote lineitem \##{quote_linenumber} internal hourly rate does not match.  Expected #{internal_hourly_rate}" if quoteline.total_cost != (internal_hourly_rate * total_hours)
    issues << "Quote lineitem \##{quote_linenumber} billable rate does not match.  Expected #{billable_rate}." if quoteline.client_unit_price != billable_rate
    issues << "Quote lineitem \##{quote_linenumber} task does not match.  Expected '#{task}'" if quoteline.line_item_description.nil? || CGI.unescapeHTML(quoteline.line_item_description.strip) != task.strip
    issues << "Quote lineitem \##{quote_linenumber} product SKU does not match.  Expected #{sku}" if quoteline.product_id != pricebook_entry.product_id
    issues.flatten
  end

  private

  def validate_internal_hourly_rate
    if internal_hourly_rate.nil?
      errors.add(:internal_hourly_rate, "Must provide the internal hourly rate.")
    elsif internal_hourly_rate < 0.0 && gsa_labor_category.in?(GsaLaborCategory::NON_GSA)
      errors.add(:internal_hourly_rate, "Internal hourly rate must be greater than or equal to zero for Non-GSA Labor Categories.")
    elsif internal_hourly_rate <= 0.0 && !gsa_labor_category.in?(GsaLaborCategory::NON_GSA)
      errors.add(:internal_hourly_rate, "Internal hourly rate must be greater than zero for GSA Labor Categories.")
    end
  end
end
