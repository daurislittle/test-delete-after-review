class ContractVehicle
  def self.contract_vehicles
    @contract_vehicles ||= SalesForce::Opportunity.contract_vehicles.filter do |cv|
      cv == 'GSA - GuidePoint Security' || !cv.include?('GSA')
    end.map { |cv| [cv, cv]}.sort_by(&:last)
  end

  def self.invalid_vehicle(vehicle)
    return vehicle != 'GSA - GuidePoint Security' && vehicle.include?('GSA')
  end
end
