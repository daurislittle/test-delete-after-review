class User < ApplicationRecord
  ICON = 'user'

  has_and_belongs_to_many :roles
  has_many :permissions, through: :roles

  def name
    "#{self.first_name} #{self.last_name}"
  end

  def lastname_first
    "#{self.last_name}, #{self.first_name}"
  end

  def corporate
    @corporate = @corporate || Corporate.find_by(email:self.email)
  end

  def groups
    GpsGroup.where(id:GpsGroupMember.where(corporate:self.corporate).pluck(:gps_group_id))
  end

  def scoping_teams
    teams = []
    GpsGroup.scoping.each do |team|
      if team.member? self
        teams << team
      end
    end

    teams
  end

  def leadership_teams
    teams = []
    GpsGroup.leadership.each do |team|
      if team.member? self
        teams << team
      end
    end

    teams
  end

  def is_administrator?
    self.has_permission? 'is_admin'
  end

  def has_permission? (permission)
    self.permissions.pluck(:name).include?(permission)
  end
end
