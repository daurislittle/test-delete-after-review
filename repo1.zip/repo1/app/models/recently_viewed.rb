class RecentlyViewed < ApplicationRecord
  belongs_to :user

  TYPE_WHITELIST = [
      "SalesForce::Account",
      "SalesForce::Contact",
      "SalesForce::Opportunity",
      "WorkBreakdownStructure"
  ]

  def exists?
    return false if class_for.blank?

    if viewed_type.starts_with?('SalesForce::')
      content = viewed_type.constantize.fetch(viewed_id)
      if !content.valid?
        content = nil
      end
    else
      content = viewed_type.constantize.find_by(id: viewed_id)
    end

    !content.nil?
  end

  def name
    name = title
    if name.blank?
      if viewed_type.starts_with?('SalesForce::')
        content = viewed_type.constantize.fetch(viewed_id)
        if content.valid?
          name = content.Name
        else
          name = "Salesforce object could not be found."
        end

      else
        content = viewed_type.constantize.find_by(id: viewed_id)
        if !content.nil?
          name = content.title
        else
          name = "Content no longer exists."
        end
      end
    end

    name
  end

  def owner
    if exists?
      if viewed_type.starts_with?('SalesForce::')
        content = viewed_type.constantize.fetch(viewed_id)
        content.owner.name

      else
        content = viewed_type.constantize.find_by(id: viewed_id)
        content.user.name
      end
    end
  end

  def created_on
    if exists?
      if viewed_type.starts_with?('SalesForce::')
        content = viewed_type.constantize.fetch(viewed_id)
        unless content.created_on.nil?
          content.created_on.strftime('%Y %b %d - %H:%M')
        else
          ''
        end
      else
        content = viewed_type.constantize.find_by(id: viewed_id)
        unless content.created_at.nil?
          content.created_at.strftime('%Y %b %d - %H:%M')
        else
          ''
        end
      end
    end
  end

  def last_updated
    if exists?
      if viewed_type.starts_with?('SalesForce::')
        content = viewed_type.constantize.fetch(viewed_id)
        content.last_modified.strftime('%Y %b %d - %H:%M')

      else
        content = viewed_type.constantize.find_by(id: viewed_id)
        content.updated_at.strftime('%Y %b %d - %H:%M')
      end
    end
  end

  def class_for
    viewed_type.constantize if TYPE_WHITELIST.include? viewed_type
  end
end
