class WbsGroup < ApplicationRecord
  ICON = 'object-group'.freeze
  ICON_STYLE = :solid
  ICON_COLOR = 'text-info'.freeze

  belongs_to :user

  has_and_belongs_to_many :practices
  has_many :wbs_group_lines, dependent: :destroy
  accepts_nested_attributes_for :wbs_group_lines, allow_destroy: true

  validates :name, presence:true, uniqueness: true
  validate :has_practices

  has_paper_trail

  amoeba do
    enable
    prepend :name => "Copy of "
  end

  def self.ValidTemplatesFor (practices)
    valid_groups = []

    WbsGroup.where(is_deleted: false).each do |group|
      if (group.practices & practices) == group.practices
        valid_groups << group
      end
    end

    valid_groups
  end

  def self.with_practice (practice)
    WbsGroup.where(is_deleted: false).select{|template| template.practices.include? practice }
  end

  def get_line_items
    line_items = []

    self.wbs_group_lines.each do |item|
      line_items << item
    end

    line_items.sort_by { |a| a.ordinal }
  end

  def total_revenue
    billable = 0
    self.wbs_group_lines.each do |item|
      billable += item.total_hours * item.billable_rate
    end

    return billable
  end

  def total_hours
    hours = 0
    self.wbs_group_lines.each do |item|
      hours += item.total_hours
    end
    hours.round(2)
  end

  def total_internal_cost
    internal_cost = 0
    self.wbs_group_lines.each do |item|
      internal_cost += item.total_hours * item.internal_hourly_rate
    end

    return internal_cost
  end

  def gross_profit_dollars
    profit = 0
    self.wbs_group_lines.each do |item|
      profit += (item.total_hours * item.billable_rate) - (item.total_hours * item.internal_hourly_rate)
    end

    return profit
  end

  def gross_profit_percent
    tr = total_revenue
    if tr.positive?
      (gross_profit_dollars / tr) * 100
    else
      0
    end
  end

  # Returns the valid SKUs based on the primary and secondary project structures
  def valid_skus
    self.practices.map {|practice| practice.skus}.flatten
  end

  def last_updated
    last_updated = wbs_group_lines.max { |a, b| a.updated_at <=> b.updated_at }
    !last_updated.nil? && last_updated.updated_at > updated_at ? last_updated.updated_at : updated_at
  end

  private
  def has_practices
    errors.add(:practices, 'must add at least on practicde') if self.practices.empty?
  end
end
