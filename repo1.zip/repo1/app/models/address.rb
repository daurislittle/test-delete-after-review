class Address < ApplicationRecord
  belongs_to :addressable, polymorphic: true

  validate :validate_when_other

  def to_s
    "#{address1} #{address2} #{city}, #{state} #{postalcode} #{country}"
  end

  def formatted
    if !address2.blank?
      "#{address1}\n#{address2}\n#{city}, #{state} #{postalcode}\n#{country}"
    else
      "#{address1}\n#{city}, #{state} #{postalcode}\n#{country}"
    end
  end

  private
  def validate_when_other
    if kind == 'other'
      if address1.blank?
        errors.add(:address1, "Street Address must be provided.")
      end

      if city.blank?
        errors.add(:city, "City must be provided.")
      end

      if country.blank? || country == 'United States' || country == 'USA'
        if state.blank?
          errors.add(:state, "State must be provided for addresses in the United States")
        end

        if postalcode.blank?
          errors.add(:postalcode, "Postal Code must be provided for addresses in the United States")
        end
      end
    end
  end
end
