class WbsGroupLine < ApplicationRecord
  LINK_TYPE_NONE    = 0
  LINK_TYPE_ONE     = 1
  LINK_TYPE_ALL_SKU = 2
  LINK_TYPE_ALL     = 3

  belongs_to :wbs_group
  belongs_to :gsa_labor_category

  validates :sku, presence: true
  validates :task, presence: true
  validates :gsa_labor_category, presence: true
  validates :total_hours, presence: true, format: { with: /\A\d+(?:\.\d{0,2})?\z/ }, numericality: {greater_than_or_equal_to: 0}

  validate :validate_internal_hourly_rate

  has_paper_trail

  amoeba do
    enable
  end

  def has_link?
    self.link_type != WbsGroupLine::LINK_TYPE_NONE
  end

  def link_to_all?
    self.link_type == LINK_TYPE_ALL
  end

  def link_to_all_sku?
    self.link_type == LINK_TYPE_ALL_SKU
  end

  # An engagement task is one that is NOT:
  #   a "management" LCAT,
  #   a 'tool' sku,
  #   a task containing subsring 'gears', and
  #   a task contaiing the substring 'after hours'
  def engagement?
    !sku.blank? &&
      !task.blank? &&
      !gsa_labor_category.blank? &&
      !GsaLaborCategory::MANAGEMENT.include?(gsa_labor_category)  &&
      !sku.downcase.include?('tool') &&
      !task.downcase.include?('gears') &&
      !task.downcase.include?('after hours')
  end

  private

  def validate_internal_hourly_rate
    if internal_hourly_rate.nil?
      errors.add(:internal_hourly_rate, "Must provide the internal hourly rate.")
    elsif internal_hourly_rate < 0.0 && gsa_labor_category.in?(GsaLaborCategory::NON_GSA)
      errors.add(:internal_hourly_rate, "Internal hourly rate must be greater than or equal to zero for Non-GSA Labor Categories.")
    elsif internal_hourly_rate <= 0.0 && !gsa_labor_category.in?(GsaLaborCategory::NON_GSA)
      errors.add(:internal_hourly_rate, "Internal hourly rate must be greater than zero for GSA Labor Categories.")
    end
  end
end
