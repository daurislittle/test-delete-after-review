class Corporate < ApplicationRecord
  has_many :gps_group_members, dependent: :destroy
  has_many :gps_groups, through: :gps_group_members

  # Retrieve the Salesforce account for GuidePoint
  def self.gps_account
    @gps_account ||= SalesForce::Account.find_by(Id: '001300000113Y8mAAE')
  end

  # Retrieves SalesForce contacts that are associated with the GuidePoint Security LLC account
  def self.gps_contacts
    SalesForce::Contact.where(AccountId: '001300000113Y8mAAE').where('No_Longer_with_Company__c = false')
  end

  # Find the corporate entry for the given email
  def self.for_email (email)
    Corporate.where('lower(email) = ?', email.downcase).first
  end

  # Search for a corporate entry given the User object
  def self.for_user (user)
    for_email(user.email)
  end

  def name
    "#{firstname} #{lastname}"
  end

  def lastname_first
    lastname + ', ' + firstname
  end

  def groups
    GpsGroupMember.where(corporate: self).distinct.pluck(:gps_group_id).map do |id|
      GpsGroup.find_by(id: id)
    end
  end

  def member? (group)
    group.member?(self)
  end

  def self.createFromOkta(user)
    corporate = nil

    okta_client ||= Oktakit.new(token:Rails.application.credentials.okta_api[Rails.env.to_sym][:security_token],
                                organization:Rails.application.credentials.okta_api[Rails.env.to_sym][:organization])
    okta_users, status = okta_client.list_users({ query: {q: user.email, limit: 1} })

    if status == 200
      okta_user = okta_users.first
      corporate = Corporate.new(firstname:okta_user[:profile][:firstName],
                              lastname:okta_user[:profile][:lastName],
                              email:okta_user[:profile][:email],
                              title:okta_user[:profile][:title],
                              mobile:okta_user[:profile][:mobilePhone],
                              manager:okta_user[:profile][:manager],
                              okta_id:okta_user[:id],
                              is_legacy:false)
      corporate.save
    end

    corporate
  end

  def self.sync
    okta_client ||= Oktakit.new(token:Rails.application.credentials.okta_api[Rails.env.to_sym][:security_token],
                                organization:Rails.application.credentials.okta_api[Rails.env.to_sym][:organization])
    okta_users, status = okta_client.list_group_members('00g1hhjgn3t7OHwBb0h8')

    if status != 200
      raise StandardError.new("Failed to get list of Okta groups")
    end

    existingIds = Corporate.all.map { |person| person.okta_id unless person.okta_id.nil? }
    importedIds = []

    createdCorporates = []
    updatedCorporates = []
    removedCorporates = []
    deletedDupCorporates = []
    deletedCorporates = []

    okta_users.each do |okta_user|
      corporates = Corporate.where(okta_id: okta_user[:id]).all
      if corporates.empty?
        corporate = Corporate.new(firstname:okta_user[:profile][:firstName],
                                  lastname:okta_user[:profile][:lastName],
                                  email:okta_user[:profile][:email],
                                  title:okta_user[:profile][:title],
                                  mobile:(okta_user[:profile][:mobilePhone].nil? ? nil : okta_user[:profile][:mobilePhone].gsub("\u0000",'')),
                                  manager:okta_user[:profile][:manager],
                                  okta_id:okta_user[:id],
                                  is_legacy:false)
        createdCorporates << corporate
      else
        corporates = corporates.to_a
        corporate = corporates.pop
        corporate.firstname = okta_user[:profile][:firstName]
        corporate.lastname = okta_user[:profile][:lastName]
        corporate.title = okta_user[:profile][:title]
        corporate.email = okta_user[:profile][:email]
        corporate.mobile = okta_user[:profile][:mobilePhone].nil? ? nil : okta_user[:profile][:mobilePhone].gsub("\u0000",'')
        corporate.manager = okta_user[:profile][:manager]
        corporate.okta_id = okta_user[:id]
        corporate.is_legacy = false
        if corporate.changed?
          updatedCorporates << corporate
        end

        corporates.each do |corp|
          deletedDupCorporates << corp
          WorkBreakdownStructure.where(scoped_by_id: corp.id).all.to_a.each do |wbs|
            wbs.scoped_by_id = corporate.id
            wbs.save
          end
        end
      end

      importedIds << corporate.okta_id
    end

    removeIds = existingIds - importedIds
    removeIds.each do |okta_id|
      corporate = Corporate.find_by(okta_id: okta_id)
      next if corporate.blank?

      if WorkBreakdownStructure.where(scoped_by_id: corporate.id).count > 0
        corporate.is_legacy = true
        removedCorporates << corporate
      else
        deletedCorporates << corporate
      end
    end

    results = {
      created: [],
      updated: [],
      removed: [],
      deleted: [],
      deleteddup: [],
      errors: []
    }

    if createdCorporates.size > 0 || updatedCorporates.size > 0 || removedCorporates.size > 0 || deletedCorporates.size > 0 || deletedDupCorporates.size > 0
      createdCorporates.each do |corporate|
        if corporate.save
          results[:created] << corporate
        else
          results[:errors] << corporate
        end
      end

      updatedCorporates.each do |corporate|
        if corporate.save
          results[:updated] << corporate
        else
          results[:errors] << corporate
        end
      end

      removedCorporates.each do |corporate|
        if corporate.save
          results[:removed] << corporate
        else
          results[:errors] << corporate
        end
      end

      deletedCorporates.each do |corporate|
        if corporate.destroy
          results[:deleted] << corporate
        else
          results[:errors] << corporate
        end
      end

      deletedDupCorporates.each do |corporate|
        if corporate.destroy
          results[:deleteddup] << corporate
        else
          results[:errors] << corporate
        end
      end
    end

    results
  end

end
