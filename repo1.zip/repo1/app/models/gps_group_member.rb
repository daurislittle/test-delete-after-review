class GpsGroupMember < ApplicationRecord
  belongs_to :gps_group
  belongs_to :corporate

  def email
    self.corporate.email
  end
end
