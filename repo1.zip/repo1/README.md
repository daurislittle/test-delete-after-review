# README

This is an initial attempt at setup instructions for this project. It is currently specific to Mac OSX.

1. Installed RubyMine from JetBrains
2. Installed Xcode Developer Tools
3. Installed Homebrew (unix pckg manager for OS X) using the following command line: ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
4. Installed XQuartz X-11 Windowing System per homebrew recommendation.
5. Ran the following command line to test for issues: brew doctor
6. Ran the following command line to cleanup warnings per ‘brew doctor’ output recommendation: brew cleanup
7. Installed gpg and gpg2 with command line: brew install gnupg gnupg2
8. Disabled ipv6 for gpg by creating/editing the file ~/.gnupg/dirmngr.conf and adding the line “disable-ipv6”
9. Got gpg keys for RVM (based on the install instructions on the RVM.io website) with command: gpg --keyserver hkp://pool.sks-keyservers.net --recv-keys 409B6B1796C275462A1703113804BB82D39DC0E3 7D2BAF1CF37B13E2069D6956105BD0E739499BDB
10. Ran following command line to install rvm and ruby/rails: \curl -sSL https://get.rvm.io | bash -s stable --rails
11. Ran the following command to install the Ruby version 2.5.1: rvm install “ruby-2.5.1”
12. Ran the following command to install documentation: rvm docs generate-ri
13. Make sure latest RubyGem is install: gem update —system
14. Ran the following command to install all gems: bundle install
15. #14 had errors - could not find libpq-fe.h — after googling, I ran: brew install postgresql
16. After #15, gems installed with: bundle install
17. Run following command to start Postgres and ensure it starts at boot as well: pg_ctl -D /usr/local/var/postgres start && brew services start postgresql
18. Enter Postgres command line: psql postgres
19. Home-brew does not seem to create the postgres user, so, remove the existing db (/usr/local/var/postgres files) and run:  initdb /usr/local/var/postgres -E utf8
20. Installed DataGrip from Jetbrains
21. Can access in DataGrip with: host: localhost, port: 5432, database: postgres
22. Created gears_user and granted create DB access with command: ALTER USER gears_user WITH createdb;
23. Set gears_user password with command: ALTER USER gears_user WITH PASSWORD ‘g3@rsus3r’;
24. Brew install xml2
25. Ran command to install libxml2: gem install libxml-ruby -- --with-xml2-config=/usr/local/Cellar/libxml2/2.9.9_2/bin/xml2-config
26. Added master.key file to COGS/config directory (provided by Tracey)
27. For COGS I ran command: RAILS_ENV=development rake db:setup
28. For COGS I ran command: RAILS_ENV=development rake db:seed
29. Edited RubyMine configuration and set port to 3010 for COGS. (COGS = 3010, Gears-tas = 3000, Gears-GRC = 5000)
35. To install elasticsearch, I ran the command: brew tap elastic/tap
36. To finalize install of elasticsearch, I ran the command: brew install elastic/tap/elasticsearch-full
37. To set elastic search as a background service with auto-startup: brew services start elastic/tap/elasticsearch-full

Things you may want to cover:

* Ruby version
2.5.1

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...

# Elasticsearch

Installing elasticsearch on CentOS

Download and install the public signing key:
```
rpm --import https://artifacts.elastic.co/GPG-KEY-elasticsearch
```
Create a file called elasticsearch.repo in the /etc/yum.repos.d/ directory:
```
[elasticsearch-6.x]
name=Elasticsearch repository for 6.x packages
baseurl=https://artifacts.elastic.co/packages/6.x/yum
gpgcheck=1
gpgkey=https://artifacts.elastic.co/GPG-KEY-elasticsearch
enabled=1
autorefresh=1
type=rpm-md
```

And your repository is ready for use. You can now install Elasticsearch with the following commands:
```
sudo yum install elasticsearch
```

After install...Use the chkconfig command to configure Elasticsearch to start automatically 
when the system boots up:
```
sudo chkconfig --add elasticsearch
```

Elasticsearch can be started and stopped using the service command:
```
sudo -i service elasticsearch start
sudo -i service elasticsearch stop
```
