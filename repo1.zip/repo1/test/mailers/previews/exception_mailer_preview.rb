# Preview all emails at http://localhost:3000/rails/mailers/exception_mailer
class ExceptionMailerPreview < ActionMailer::Preview

end
