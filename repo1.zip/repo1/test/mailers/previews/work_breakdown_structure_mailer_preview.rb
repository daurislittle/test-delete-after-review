# Preview all emails at http://localhost:3000/rails/mailers/work_breakdown_structure_mailer
class WorkBreakdownStructureMailerPreview < ActionMailer::Preview

end
