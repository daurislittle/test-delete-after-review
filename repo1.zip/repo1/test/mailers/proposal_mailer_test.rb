require 'test_helper'

class ProposalMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
