require 'test_helper'

class ExceptionMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
