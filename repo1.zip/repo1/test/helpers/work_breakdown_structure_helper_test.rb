require 'test_helper'

class WorkBreakdownStructureHelperTest < ActionView::TestCase
  include WorkBreakdownStructuresHelper

  def setup
    # Do nothing
  end

  test 'task highlight class should return afterhours' do
    entry1 = WbsEntry.new(
      sku: 'IA-AS-AAR',
      task: 'after hours',
      gsa_labor_category: gsa_labor_categories(:senior_security_consultant),
      billable_rate:250.00,
      total_hours:10,
      internal_hourly_rate:150.00,
      phase:1,
      ordinal:1
    )
    assert_equal 'after-hours', task_highlight_class(entry1)

    entry1.task = 'After Hours'
    assert_equal 'after-hours', task_highlight_class(entry1)

    entry1.task = 'AfterHours'
    assert_equal 'after-hours', task_highlight_class(entry1)
  end

  test 'task highlight class should return tools' do
    entry1 = WbsEntry.new(
      sku: 'IA-AS-TOOLS',
      task: 'tools',
      gsa_labor_category: gsa_labor_categories(:senior_security_consultant),
      billable_rate:250.00,
      total_hours:10,
      internal_hourly_rate:150.00,
      phase:1,
      ordinal:1
    )
    assert_equal 'tools', task_highlight_class(entry1)
  end
end