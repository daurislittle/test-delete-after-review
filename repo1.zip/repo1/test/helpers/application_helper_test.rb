require 'test_helper'

class ApplicationHelperTest < ActionView::TestCase
  include ApplicationHelper

  def setup
    # Do nothing
  end

  test 'returns text success for approved' do
    assert_equal 'text-success', quote_status_class('Reviewed / Approved')
  end

  test 'returns text danger for rejected' do
    assert_equal 'text-danger', quote_status_class('Rejected')
  end

  test 'returns text warning for others' do
    assert_equal 'text-warning', quote_status_class('Pending')
    assert_equal 'text-warning', quote_status_class('Under Review')
  end
end