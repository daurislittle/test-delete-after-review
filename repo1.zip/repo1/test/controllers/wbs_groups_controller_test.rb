require 'test_helper'

class WbsGroupsControllerTest < ActionDispatch::IntegrationTest
  def setup
    @user = users(:admin)
    login_as(@user)

    @template = WbsGroup.new
    @template.name = "My New Test Group"
    @template.practices << practices(:application_security)
    @lineitem = @template.wbs_group_lines.build(
      sku: 'IA-AS-AAR',
      task: 'Assessment',
      gsa_labor_category: gsa_labor_categories(:senior_security_consultant),
      billable_rate:250.00,
      total_hours:10,
      internal_hourly_rate:150.00,
      phase:1,
      ordinal:1
    )
    @template.user = @user

    assert @template.save!
  end

  test "should get index" do
    get wbs_groups_url
    assert_response :success
  end

  test "should get show" do
    get wbs_group_url(@template)
    assert_response :success
  end

  test "should display totals on show" do
    get wbs_group_url(@template)
    assert_response :success
    assert_select "tbody#wbs_template_summary_table" do
      count = 0
      assert_select "tr" do |row|
        if count == 0
          assert_select "th", "Total Hours"
          assert_select "td", @template.total_hours.to_s
        elsif count == 1
          assert_select "th", "Revenue"
          assert_select "td", @template.total_revenue
        elsif count == 2
          assert_select "th", "Cost"
          assert_select "td", @template.total_internal_cost
        elsif count == 3
          assert_select "th", "Gross Profit $"
          assert_select "td", @template.gross_profit_dollars
        elsif count == 4
          assert_select "th", "Gross Profit %"
          assert_select "td", @template.gross_profit_percent
        end
        count += 1
      end
    end
  end

  test 'show should fail' do
    get wbs_group_url('abs')
    assert_toast_error
  end

  test 'should get new' do
    get new_wbs_group_path
    assert_response :success
  end

  test 'should get edit' do
    get edit_wbs_group_path(@template)
    assert_response :success
  end

  test 'edit should fail' do
    get edit_wbs_group_path('abs')
    assert_toast_error
  end

  test 'should create new - UI' do
    assert_difference 'WbsGroup.count' do
      post wbs_groups_path, params: {
        wbs_group: {
          name: 'My New Group',
          practice_ids: [practices(:application_security).id],
          wbs_group_lines_attributes: [
            {
              sku: 'IA-AS-AAR',
              task: 'Assessment',
              gsa_labor_category_id: gsa_labor_categories(:senior_security_consultant).id,
              billable_rate:250.00,
              total_hours:10,
              internal_hourly_rate:150.00,
              phase:1,
              ordinal:1
            }
          ]
        }
      }
    end

    assert_redirected_to wbs_group_url(@controller.view_assigns['wbs_group'])
  end

  test 'should create new - JS' do
    assert_difference 'WbsGroup.count' do
      post wbs_groups_path, params: {
        wbs_group: {
          name: 'My New Group',
          practice_ids: [practices(:application_security).id],
          wbs_group_lines_attributes: [
            {
              sku: 'IA-AS-AAR',
              task: 'Assessment',
              gsa_labor_category_id: gsa_labor_categories(:senior_security_consultant).id,
              billable_rate:250.00,
              total_hours:10,
              internal_hourly_rate:150.00,
              phase:1,
              ordinal:1
            }
          ]
        }
      }, xhr: true
    end

    assert_response :success
  end

  test 'create should fail - no practices' do
    assert_difference 'WbsGroup.count', 0 do
      post wbs_groups_path, params: {
        wbs_group: {
          name: 'My New Group',
          wbs_group_lines_attributes: [
            {
              sku: 'IA-AS-AAR',
              task: 'Assessment',
              gsa_labor_category_id: gsa_labor_categories(:senior_security_consultant).id,
              billable_rate:250.00,
              total_hours:10,
              internal_hourly_rate:150.00,
              phase:1,
              ordinal:1
            }
          ]
        }
      }
    end
  end

  test 'should update template' do
    patch wbs_group_url(@template), params: { wbs_group: {name: 'updated template'}}

    assert_redirected_to wbs_group_url(@template)

    @template.reload
    assert_equal "updated template", @template.name
  end

  test 'update should fail - not found' do
    patch wbs_group_url('abc'), params: { wbs_group: {name: 'updated template'}}
    assert_toast_error
  end

  test 'update should fail - invalid name' do
    patch wbs_group_url(@template), params: { wbs_group: {name: ''}}

    assert_not @controller.view_assigns['wbs_group'].errors.empty?
  end

  test "delete marks as deleted" do
    delete wbs_group_url(@template)
    assert_redirected_to templates_url

    @template.reload
    assert @template.is_deleted?
  end

  test 'delete fails - not found' do
    delete wbs_group_url('abc')
    assert_toast_error
  end

  test 'should restore deleted' do
    delete wbs_group_url(@template)
    assert_redirected_to templates_url

    @template.reload
    assert @template.is_deleted?

    post restore_wbs_group_url(@template)
    assert_redirected_to(@template)

    @template.reload
    assert_not @template.is_deleted?
  end

  test 'assert restore fails - not found' do
    post restore_wbs_group_url('abc')
    assert_toast_error
  end

  test 'delete permanently' do
    assert_difference("WbsGroup.count", -1) do
      delete wbs_group_url(@template, permanent:true)
    end

    assert_redirected_to trashcan_url

    assert_raises ActiveRecord::RecordNotFound do
      @template.reload
    end
  end

  test 'should create copy' do
    assert_difference('WbsGroup.count') do
      post copy_wbs_group_url(@template)
    end

    assert_redirected_to(@controller.view_assigns['copy'])
    assert_equal "Copy of #{@template.name}", @controller.view_assigns['copy'].name
  end

  test 'copy should fail - not found' do
    assert_difference('WbsGroup.count', 0) do
      post copy_wbs_group_url('abc')
    end

    assert_toast_error
  end

  test 'should select skus for practice' do
    get practices_wbs_groups_url(practices:[practices(:application_security).id]), xhr: true
    assert_not @controller.view_assigns['skus'].empty?
  end

  test 'adds new line item' do
    get add_line_wbs_groups_url, params: {
      practices: [practices(:application_security).id],
      sku: 'IA-AS-AAR'
    }, xhr: true

    assert_response :success
    assert_not @controller.view_assigns['new_line'].nil?
  end

  test 'should update last modified date' do
    last_updated = @template.last_updated

    @lineitem.task = "My New Task"
    assert @lineitem.save!, "Save failed: #{@lineitem.errors.inspect}"

    assert @template.last_updated > last_updated
  end
end
