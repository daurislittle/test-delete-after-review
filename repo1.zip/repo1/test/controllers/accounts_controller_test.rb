require 'test_helper'

class AccountsControllerTest < ActionDispatch::IntegrationTest
  def setup
    @user = users(:scoper)
    login_as(@user)

    @account = SalesForce::Account.limit(1).first
  end

  test "should get index" do
    get accounts_url
    assert_response :success
  end

  test 'should adjust invalid page' do
    get accounts_url(page: -1)
    assert_equal 1, @controller.view_assigns['page']

    num_pages = @controller.view_assigns['num_pages']
    get accounts_url(page: num_pages + 10)
    assert_equal num_pages, @controller.view_assigns['page']
  end

  test 'should search for account' do
    get accounts_url(search_for:'aaa')
    assert_response :success

    get accounts_url(search_for:'aaa', refresh: true)
    assert_response :success
  end

  test "should get show" do
    get account_url(@account.id)
    assert_response :success

    get account_url(@account.id, refresh:true)
    assert_response :success
  end

  test 'handles ObjectNotFound' do
    login_as(users(:scoper))

    get account_path('0031400002MOYmfAA2')
    assert_toast_error
  end

  test 'should return shipping address' do
    get address_account_url(@account.id, which:'shipping')
    assert_response :success
  end

  test 'should return billing address' do
    get address_account_url(@account.id, which:'billing')
    assert_response :success
  end

  test 'should return headquarters address' do
    get address_account_url(@account.id, which:'headquarters')
    assert_response :success
  end

  test 'should throw argument exception for bad address' do
    get address_account_url(@account.id, which:'headquarters-invalid')
    assert_toast_error
  end
end
