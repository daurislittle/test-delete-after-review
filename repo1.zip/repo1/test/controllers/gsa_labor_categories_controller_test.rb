require 'test_helper'

class GsaLaborCategoriesControllerTest < ActionDispatch::IntegrationTest
  def setup
    @user = users(:scoper)
    login_as(@user)
  end

  test 'should show template' do
    gsa = gsa_labor_categories(:sme)

    get gsa_labor_category_url(gsa), as: :json
    assert_response :success
  end

  test 'should fail show' do
    get gsa_labor_category_url(-1)
    assert_toast_error
  end
end
