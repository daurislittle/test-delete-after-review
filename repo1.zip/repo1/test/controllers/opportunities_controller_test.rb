require 'test_helper'

class OpportunitiesControllerTest < ActionDispatch::IntegrationTest
  def setup
    @user = users(:admin)
    login_as(@user)
  end

  test "should get index" do
    get opportunities_url
    assert_response :success

    get opportunities_url, as: :json
    assert_response :success

    response = JSON.parse(@response.body)
    assert response.key?('results')
    assert response.key?('pagination')
  end

  test 'should adjust invalid page' do
    get opportunities_url(page: -1)
    assert_equal 1, @controller.view_assigns['page']

    num_pages = @controller.view_assigns['num_pages']
    get opportunities_url(page: num_pages + 10)
    assert_equal num_pages, @controller.view_assigns['page']
  end

  test 'should search for opportunity' do
    get opportunities_url(search_for:'colgate')
    assert_response :success

    get opportunities_url(search_for:'colgate', refresh: true)
    assert_response :success
  end

  test "should get show" do
    opportunity = SalesForce::Opportunity.limit(1).first

    get opportunity_url(opportunity.gps_opportunity_number)
    assert_response :success

    get opportunity_url(opportunity.gps_opportunity_number, refresh: true)
    assert_response :success

    get opportunity_url(opportunity.gps_opportunity_number, refresh: true), as: :json
    assert_response :success

    response = JSON.parse(@response.body)
  end

  test 'handles ObjectNotFound' do
    login_as(users(:scoper))

    get opportunity_path('0031400002MOYmfAA2')
    assert_toast_error
  end

  test 'should only load services' do
    SalesForce::Opportunity.only_services.each { |opp|
      Rails.logger.debug("Checking #{opp.id}")
      assert opp.service?
    }
  end
end
