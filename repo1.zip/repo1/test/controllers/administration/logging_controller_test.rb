require 'test_helper'

module Administration
  class LoggingControllerTest < ActionDispatch::IntegrationTest
    def setup
      @user = users(:admin)

    end

# Logger support is temporarily disabled...
=begin
    test "should get index" do
      login_as(@user)

      get administration_logging_index_url
      assert_response :success
    end
=end
  end
end
