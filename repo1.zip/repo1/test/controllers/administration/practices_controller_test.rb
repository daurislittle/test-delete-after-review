require 'test_helper'

module Administration
  class PracticesControllerTest < ActionDispatch::IntegrationTest
    def setup
      @admin = users(:admin)
    end

    test "should get index" do
      login_as(@admin)

      get administration_practices_url
      assert_response :success
    end

    test 'non-admin cannot access' do
      login_as(@admin)

      user = users(:scoper)
      login_as(user)

      get administration_practices_url
      assert_toast_error
    end

    test 'should get edit' do
      login_as(@admin)

      get edit_administration_practice_url(practices(:application_security)), xhr: true
      assert_response :success
    end

    test 'should update practice' do
      login_as(@admin)

      practice = practices(:application_security)

      patch administration_practice_url(practice), params: {
        practice: {
          in_active: true,
          scoping_slack: 'someslack channel'
        }
      }, xhr: true

      assert_response :success

      practice.reload
      assert_equal true, practice.in_active
      assert_equal 'someslack channel', practice.scoping_slack
    end

    test 'should destroy practice' do
      login_as(@admin)

      appsec = practices(:application_security)

      assert_difference("Practice.count", -1) do
        delete administration_practice_url(appsec), xhr: true
      end
    end

    test 'should not destroy practice' do
      login_as(@admin)

      practice = practices(:security_assessments)
      wbs = create_test_wbs

      assert_difference("Practice.count", 0) do
        delete administration_practice_url(practice), xhr: true
      end
    end

    test 'retrieves emails for' do
      login_as(@admin)

      get emails_administration_practices_url, as: :json

      json = JSON.parse(@response.body)
      assert json.key?('pagination')
      assert json.key?('results')
    end

    test 'retrieves skus for' do
      login_as(@admin)

      get skus_administration_practice_path(practices(:application_security)), xhr: true
      assert_response :success
    end
  end
end

