require 'test_helper'

module Administration
  class RolesControllerTest < ActionDispatch::IntegrationTest
    def setup
      @admin = users(:admin)
      @scoper = users(:scoper)
    end

    test "should get index" do
      login_as(@admin)

      get administration_roles_path
      assert_response :success
    end

    test 'non-admin cannot access' do
      login_as(@scoper)

      get administration_roles_path
      assert_toast_error
    end

    test 'should get show' do
      login_as(@admin)

      get administration_role_path(roles(:administrator))
      assert_response :success
    end

    test 'show role not found' do
      login_as(@admin)

      get administration_role_path(-1)
      assert_toast_error
    end

    test 'should get edit' do
      login_as(@admin)

      get edit_administration_role_path(roles(:administrator))
      assert_response :success
    end

    test 'edit role not found' do
      login_as(@admin)

      get edit_administration_role_path(-1)
      assert_toast_error
    end

    test 'should create role' do
      login_as(@admin)

      assert_difference("Role.count") do
        post administration_roles_path, params: {role: {name: 'my new role'}}
      end

      assert_redirected_to administration_roles_path

      result = JSON.parse(flash[:toast])
      assert_equal 'success', result['type']
      assert_equal "Role my new role has been successfully created.", result['message']
    end

    test 'create should fail - no name' do
      login_as(@admin)

      assert_difference('Role.count', 0) do
        post administration_roles_path, params: {role: {name: ''}}
      end

      assert_not @controller.view_assigns['role'].errors.empty?
    end

    test 'update role not found' do
      login_as(@admin)

      patch administration_role_path(-1), params: {role: {name: 'my bad name'}}
      assert_toast_error
    end

    test 'should update role' do
      login_as(@admin)

      role = roles(:psg)

      patch administration_role_path(role), params: {role: {name: 'new psg role'}}
      assert_redirected_to administration_roles_path

      role.reload
      assert_equal 'new psg role', role.name
    end

    test 'update role should fail - invalid name' do
      login_as(@admin)

      role = roles(:psg)

      patch administration_role_path(role), params: {role: {name: ''}}
      assert_not @controller.view_assigns['role'].errors.empty?
    end

    test 'no roles provided to update' do
      login_as(@admin)

      post update_roles_administration_roles_url

      toast = JSON.parse(flash[:toast])
      assert_equal 'warn', toast['type']
      assert_equal 'No roles were provided to update.', toast['message']
    end

=begin
    test 'should update roles' do
      login_as(@admin)

      roles = {
        'PSG' => {
          'wbs_view' => true
        }
      }

      roles = ['PSG', ['wbs_view', [true]]]

      # todo: Generate params to pass in...
      post update_roles_administration_roles_url, params: {
        roles: roles
      }
    end
=end
  end
end
