require 'test_helper'

module Administration
  class SalesforceControllerTest < ActionDispatch::IntegrationTest
    def setup
      @admin = users(:admin)
      @scoper = users(:scoper)
    end

    test "should get index" do
      login_as(@admin)

      get administration_salesforce_admin_url
      assert_response :success
    end

    test 'non-admin cannot access' do
      login_as(@scoper)

      get administration_salesforce_admin_url
      assert_toast_error
    end

    test 'shows parameters' do
      login_as(@admin)

      get administration_salesforce_admin_parameters_url
      assert_response :success
    end

    test 'shows query test interface' do
      login_as(@admin)

      get administration_salesforce_admin_query_url
      assert_response :success
    end

    test 'ajax connect salesforce' do
      login_as(@admin)

      get administration_salesforce_connect_url(env: 'uat'), xhr: true
      assert_response :success

      assert SalesForce.client.connected?
    end

    test 'salesforce query' do
      login_as(@admin)

      get administration_salesforce_query_url(
            query: 'SELECT Id FROM Account LIMIT 10'
          ), as: :json
      assert_response :success
    end

    test 'salesforce describe' do
      login_as(@admin)

      get administration_salesforce_describe_url(query: 'Account'), as: :json
      assert_response :success
    end

    test 'salesforce picklist' do
      login_as(@admin)

      get administration_salesforce_picklist_url(object: 'Opportunity', field: 'Region__c'), as: :json
      assert_response :success
    end

    test 'salesforce find' do
      login_as(@admin)

      account = SalesForce::Account.all.first

      get administration_salesforce_find_url(what: 'Account', value: account.id)
      assert_response :success
    end
  end
end
