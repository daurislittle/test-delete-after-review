require 'test_helper'

module Administration
  class SkusControllerTest < ActionDispatch::IntegrationTest
    # test "the truth" do
    #   assert true
    # end
  end
end
