require 'test_helper'

module Administration
  class PermissionsControllerTest < ActionDispatch::IntegrationTest
    def setup
      @user = users(:admin)
      login_as(@user)
    end

    test "should get index" do
      get administration_permissions_url
      assert_response :success
    end

    test 'non-admin cannot access' do
      user = users(:scoper)
      login_as(user)

      get administration_permissions_url
      assert_toast_error
    end
  end
end
