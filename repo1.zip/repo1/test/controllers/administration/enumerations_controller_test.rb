require 'test_helper'

module Administration
  class EnumerationsControllerTest < ActionDispatch::IntegrationTest
    def setup
      @admin = users(:admin)
      @scoper = users(:scoper)
    end

    test "should get index" do
      login_as(@admin)

      get administration_enumerations_url
      assert_response :success

      get administration_enumerations_url(enum_type: 'sku')
      assert_response :success

      # Should use the session.rb variable...set by previous request
      get administration_enumerations_url
      assert_response :success
    end

    test 'non-admin cannot access' do
      login_as(@scoper)

      get administration_enumerations_url
      assert_toast_error
    end

    test 'should show new' do
      login_as(@admin)

      get new_administration_enumeration_url
      assert_response :success
    end

    test 'should create enumeration' do
      login_as(@admin)

      assert_difference("Enumeration.count") do
        post administration_enumerations_path, params: {
          enumeration: {
            name: 'New Enumeration Item',
            enum_type: 'new_enumeration'
          }
        }
      end
    end

    test 'should fail create enumeration' do
      login_as(@admin)

      assert_difference("Enumeration.count", 0) do
        post administration_enumerations_path, params: {
          enumeration: {
            name: 'IPT',
            enum_type: 'sku'
          }
        }
      end
    end
  end
end
