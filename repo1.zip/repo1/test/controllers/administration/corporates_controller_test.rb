require 'test_helper'

module Administration
  class CorporatesControllerTest < ActionDispatch::IntegrationTest

    test 'should get index' do
      login_as(users(:admin))

      get administration_corporates_url
      assert_response :success
    end

    test 'corporate directory file upload' do
      login_as(users(:admin))

      corp_file = fixture_file_upload('files/GuidePointCorporateDirectory.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

      post "/administration/corporates/import", params: {file: corp_file, format: :js}
      assert_response :success
      assert response.body.include?('Created')
      assert !response.body.include?('error')
    end

    test 'bad file right mimetype corporate directory file upload' do
      login_as(users(:admin))

      corp_file = fixture_file_upload('files/NotAGuidePointCorporateDirectory.txt','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

      post "/administration/corporates/import", params: {file: corp_file, format: :js}
      assert response.body.include?('Not a valid file format.')
    end

    test 'bad file wrong mimetype corporate directory file upload' do
      login_as(users(:admin))

      corp_file = fixture_file_upload('files/NotAGuidePointCorporateDirectory.txt','text/plain')

      post "/administration/corporates/import", params: {file: corp_file, format: :js}
      assert response.body.include?('Invalid file selected.')
    end

    test 'no file corporate directory file upload' do
      login_as(users(:admin))

      post "/administration/corporates/import", params: {format: :js}
      assert response.body.include?('No file selected.')
    end

  end
end
