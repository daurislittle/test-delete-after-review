require 'test_helper'

module Administration
  class GsaLaborCategoriesControllerTest < ActionDispatch::IntegrationTest
    def setup
      @user = users(:admin)
      login_as(@user)
    end

    test 'should get index sorted' do
      get administration_gsa_labor_categories_path
      assert_response :success

      last = ''
      table_data = @response.body[@response.body.index('<table id="labor-categories"'), @response.body.length]
      table_data = table_data[table_data.index('<tbody') + 6, table_data.length]
      while !table_data.lstrip.starts_with?('</tbody>') do
        table_data = table_data[table_data.index('<td>') + 4, table_data.length]
        name = table_data[0, table_data.index('</td>')]

        assert_equal -1, last.casecmp(name)

        last = name
        table_data = table_data[table_data.index('</tr>') + 5, table_data.length]
      end
    end

    test 'should get show' do
      gsa = gsa_labor_categories(:sme)

      get administration_gsa_labor_category_url(gsa)
      assert_response :success
    end

    test 'should not show' do
      get administration_gsa_labor_category_url(23)
      assert_toast_error
    end

    test 'should get new' do
      get new_administration_gsa_labor_category_path
      assert_response :success
    end

    test 'should create' do
      assert_difference("GsaLaborCategory.count") do
        post administration_gsa_labor_categories_path, params: {
          gsa_labor_category: {
            name: "My New Category",
            gsa_floor_price: 160.0,
            federal_max_price: 290.0
          }
        }
      end
    end

    test 'create should fail' do
      assert_difference("GsaLaborCategory.count", 0) do
        post administration_gsa_labor_categories_path, params: {
          gsa_labor_category: {
            name: "My New Category",
            gsa_floor_price: -1.0
          }
        }
      end
    end

    test 'should get edit' do
      gsa = gsa_labor_categories(:sme)

      get edit_administration_gsa_labor_category_url(gsa)
      assert_response :success
    end

    test 'should not edit' do
      get edit_administration_gsa_labor_category_url(23)
      assert_toast_error
    end

    test 'should update lcat' do
      gsa = gsa_labor_categories(:sme)

      patch administration_gsa_labor_category_path(gsa), params: {gsa_labor_category: {name: 'SME updated'}}

      assert_redirected_to administration_gsa_labor_category_url(gsa)

      gsa.reload
      assert_equal "SME updated", gsa.name
    end

    test 'update should fail' do
      gsa = gsa_labor_categories(:sme)

      patch administration_gsa_labor_category_path(gsa), params: {gsa_labor_category: {
        name: 'SME updated',
        gsa_floor_price: -1.0
      }}

      gsa.reload
      assert_not_equal -1.0, gsa.gsa_floor_price
    end

    test 'update bad id should show notfound' do
      patch administration_gsa_labor_category_path(90), params: {gsa_labor_category: {name: 'SME updated'}}
      assert_toast_error
    end

    test 'lcat is destroyed' do
      gsa = gsa_labor_categories(:sme)

      assert_difference("GsaLaborCategory.count", -1) do
        delete administration_gsa_labor_category_url(gsa)
      end

      assert_redirected_to administration_gsa_labor_categories_path

      assert_raises ActiveRecord::RecordNotFound do
        gsa.reload
      end
    end

    test 'non-lcat raises not found' do
      assert_difference('GsaLaborCategory.count', 0) do
        delete administration_gsa_labor_category_url(0)
      end

      assert_toast_error
    end
  end
end
