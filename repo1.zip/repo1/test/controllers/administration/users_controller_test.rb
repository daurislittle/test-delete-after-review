require 'test_helper'

module Administration
  class UsersControllerTest < ActionDispatch::IntegrationTest
    def setup
      @admin = users(:admin)
    end

    test "should get index" do
      login_as(@admin)

      get administration_users_path
      assert_response :success
    end

    test 'non-admin cannot access' do
      user = users(:scoper)
      login_as(user)

      get administration_users_path
      assert_toast_error

      get administration_user_path(user)
      assert_toast_error

      patch administration_user_url(user), params: { user: { is_disabled:true}}
      assert_toast_error

      post disable_administration_user_path(user)
      assert_toast_error

      post enable_administration_user_path(user)
      assert_toast_error
    end

    test 'should get show' do
      login_as(@admin)

      get administration_user_url(users(:scoper))
      assert_response :success
    end

    test 'user is updated' do
      login_as(@admin)

      user = users(:scoper)

      patch administration_user_url(user), params: { user: { is_disabled:true}}
      assert_redirected_to administration_user_url(user)

      user.reload
      assert user.is_disabled?

      assert_equal "Successfully updated user \"#{user.name}\".", JSON.parse(flash[:toast])['message']
    end

    test 'disable user' do
      login_as(@admin)

      user = users(:scoper)

      post disable_administration_user_path(user)
      assert_redirected_to administration_user_url(user)

      user.reload
      assert user.is_disabled?
      assert_equal "#{user.name} has been disabled.", JSON.parse(flash[:toast])['message']
    end

    test 'enable user' do
      login_as(@admin)

      user = users(:scoper)
      post enable_administration_user_path(user)
      assert_redirected_to administration_user_url(user)

      user.reload
      assert_not user.is_disabled?
      assert_equal "#{user.name} has been reinstated.", JSON.parse(flash[:toast])['message']
    end

    test 'user not found displays exception on show' do
      login_as(@admin)

      get administration_user_url(-1)
      assert_toast_error

      patch administration_user_url(-1), params: { user: { is_disabled:true}}
      assert_toast_error

      post enable_administration_user_path(-1)
      assert_toast_error

      post disable_administration_user_path(-1)
      assert_toast_error
    end

    test 'index returns all users' do
      login_as(@admin)

      get administration_users_path
      assert_equal User.count, @controller.view_assigns['users'].count
    end
  end
end
