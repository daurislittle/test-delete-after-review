require 'test_helper'

module Administration
  class GpsGroupsControllerTest < ActionDispatch::IntegrationTest
    def setup
      @admin = users(:admin)
      @scoper = users(:scoper)
    end

    test "should get index" do
      login_as(@admin)

      get administration_gps_groups_url
      assert_response :success
    end

    test 'non-admin cannot access' do
      login_as(@scoper)

      get administration_gps_groups_url
      assert_toast_error
    end

    test 'import' do
      login_as(@admin)

      file = fixture_file_upload('files/CorporateEmailDistributionLists.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

      post import_administration_gps_groups_url, params: { file: file }, xhr: true
      assert_response :success
    end

    test 'bad file type import' do
      login_as(@admin)

      file = fixture_file_upload('files/NotAGuidePointCorporateDirectory.txt', 'plain/text')

      post import_administration_gps_groups_url, params: { file: file }, xhr: true
      assert_not @controller.view_assigns['error'].blank?

      assert_equal "Invalid file selected.  Only XLSX formatted files are supported.", @controller.view_assigns['error']
    end

    test 'invalid file import' do
      login_as(@admin)

      file = fixture_file_upload('files/GuidePointCorporateDirectory.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

      post import_administration_gps_groups_url, params: { file: file }, xhr: true
      assert_not @controller.view_assigns['error'].blank?

      assert_not @controller.view_assigns['validation_messages'].empty?
    end

    test 'purge removes all' do
      login_as(@admin)

      file = fixture_file_upload('files/CorporateEmailDistributionLists.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

      post import_administration_gps_groups_url, params: { file: file }, xhr: true
      assert_response :success, 'Email distribution file import failed'
      assert GpsGroup.count.positive?

      post purge_administration_gps_groups_url
      assert GpsGroup.count.zero?
    end

    test 'group existence' do
      login_as(@admin)

      file = fixture_file_upload('files/CorporateEmailDistributionLists.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

      post import_administration_gps_groups_url, params: { file: file }, xhr: true
      assert_response :success

      assert_not GpsGroup.psg.nil?
      assert_not GpsGroup.pmo.nil?
      assert_not GpsGroup.scoping.empty?
      assert_not GpsGroup.leadership.empty?
    end

    test 'is in group' do
      login_as(@admin)

      file = fixture_file_upload('files/CorporateEmailDistributionLists.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

      post import_administration_gps_groups_url, params: { file: file }, xhr: true
      assert_response :success

      corporate_member = corporates(:scoper)

      # Add scoper to psg group
      assert GpsGroupMember.new(
        gps_group: GpsGroup.psg,
        corporate: corporate_member
      ).save

      assert GpsGroup.member_psg?(corporate_member)
      assert GpsGroup.member_psg?(@scoper)
      assert GpsGroup.member_psg?('scopefn.scopeln@test.com')

      # Add scoper to pmo group
      assert GpsGroupMember.new(
        gps_group: GpsGroup.pmo,
        corporate: corporate_member
      ).save

      assert GpsGroup.member_pmo?(corporate_member)
      assert GpsGroup.member_pmo?(@scoper)
      assert GpsGroup.member_pmo?('scopefn.scopeln@test.com')

      # Find a scoping team
      scoping_teams = GpsGroup.scoping
      assert_not scoping_teams.empty?

      # Add scoper to pmo group
      assert GpsGroupMember.new(
        gps_group: scoping_teams.first,
        corporate: corporate_member
      ).save

      assert GpsGroup.member_scoping?(corporate_member)
      assert GpsGroup.member_scoping?(@scoper)
      assert GpsGroup.member_scoping?('scopefn.scopeln@test.com')
    end

    test 'is not in group' do
      login_as(@admin)

      file = fixture_file_upload('files/CorporateEmailDistributionLists.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

      post import_administration_gps_groups_url, params: { file: file }, xhr: true
      assert_response :success

      corporate_member = corporates(:scoper)

      assert_not GpsGroup.member_psg?(corporate_member)
      assert_not GpsGroup.member_pmo?(corporate_member)
      assert_not GpsGroup.member_scoping?(corporate_member)
    end
  end
end
