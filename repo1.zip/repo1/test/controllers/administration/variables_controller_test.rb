require 'test_helper'

module Administration
  class VariablesControllerTest < ActionDispatch::IntegrationTest
    def setup
      @admin = users(:admin)
    end

    test "should get index" do
      login_as(@admin)

      get administration_variables_path
      assert_response :success
    end

    test 'non-admin cannot access' do
      user = users(:scoper)
      login_as(user)

      get administration_variables_path
      assert_toast_error
    end

    test 'should update variable' do
      login_as(@admin)

      variable = variables(:default_internal_rate)
      patch administration_variable_url(variable), params: { variable: { value: 5.0 }}, xhr: true

      variable.reload
      assert_equal 5.0, variable.value

      variable = variables(:float_variable)
      patch administration_variable_url(variable), params: { variable: { value: 15.0 }}, xhr: true

      variable.reload
      assert_equal 15.0, variable.value

      variable = variables(:integer_variable)
      patch administration_variable_url(variable), params: { variable: { value: 15 }}, xhr: true

      variable.reload
      assert_equal 15, variable.value

      variable = variables(:string_variable)
      patch administration_variable_url(variable), params: { variable: { value: "my new value" }}, xhr: true

      variable.reload
      assert_equal "my new value", variable.value
    end

    test 'variable not found asserts error' do
      login_as(@admin)

      patch administration_variable_url(-1), params: {variable: {value: 2}}, xhr: true
      assert_toast_error
    end

    test 'variable bad value shows error' do
      login_as(@admin)

      variable = variables(:integer_variable)
      patch administration_variable_url(variable), params: { variable: { value: "abc" }}, xhr: true

      assert_toast_error message: "Invalid value for #{variable.name}, was expecting #{variable.kind}", status_code: 200
    end

    test 'variable requires name' do
      login_as(@admin)

      variable = variables(:integer_variable)
      patch administration_variable_url(variable), params: {
        variable: {
          name: "",
          value: 10
        }
      }, xhr: true

      assert_toast_error message: 'There was a problem saving variable', status_code: 200
    end

    test 'variable requires label' do
      login_as(@admin)

      variable = variables(:integer_variable)
      patch administration_variable_url(variable), params: {
        variable: {
          label: "",
          value: 10
        }
      }, xhr: true

      assert_toast_error message: 'There was a problem saving variable', status_code: 200
    end
  end
end
