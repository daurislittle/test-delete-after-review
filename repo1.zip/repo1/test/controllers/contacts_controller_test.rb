require 'test_helper'

class ContactsControllerTest < ActionDispatch::IntegrationTest
  def setup
    @user = users(:scoper)
    login_as(@user)
  end

  test "should get index" do
    get contacts_url
    assert_response :success
  end

  test 'should adjust invalid page' do
    get contacts_url(page: -1)
    assert_equal 1, @controller.view_assigns['page']

    num_pages = @controller.view_assigns['num_pages']
    get contacts_url(page: num_pages + 10)
    assert_equal num_pages, @controller.view_assigns['page']
  end

  test 'should search for contact' do
    get contacts_url(search_for:'tracey')
    assert_response :success

    get contacts_url(search_for:'tracey', refresh: true)
    assert_response :success
  end

  test "should get show" do
    contact = SalesForce::Contact.limit(1).first

    get contact_url(contact.id)
    assert_response :success

    get contact_url(contact.id, refresh:true)
    assert_response :success
  end

  test 'handles ObjectNotFound' do
    login_as(users(:scoper))

    get contact_path('0031400002MOYmfAA2')
    assert_toast_error
  end
end
