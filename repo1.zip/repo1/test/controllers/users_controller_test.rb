require 'test_helper'

class UsersControllerTest < ActionDispatch::IntegrationTest
  test "new users get created when authorized" do
    user = User.new
    user.first_name = "user3"
    user.last_name = "user3last"
    user.email = "user3.user3last@test.com"

    login_as user

    assert_not session[:user_id].nil?
  end
end
