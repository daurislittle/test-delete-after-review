require 'minitest/autorun'

class SamlControllerTest < ActionDispatch::IntegrationTest
  def setup
    # Do nothing
  end

  def teardown
    # Do nothing
  end

  def test
    skip 'Not implemented'
  end
end