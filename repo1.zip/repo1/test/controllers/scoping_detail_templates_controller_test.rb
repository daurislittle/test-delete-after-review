require 'test_helper'

class ScopingDetailTemplatesControllerTest < ActionDispatch::IntegrationTest
  def setup
    @user = users(:scoper)
    login_as(@user)

    @template = ScopingDetailTemplate.new(
      name: 'scoping detail template test name',
      practices: Practice.all,
      user: @user
    )

    assert @template.save
  end

  test "should get index" do
    get scoping_detail_templates_url
    assert_response :success
  end

  test 'should get show' do
    get scoping_detail_template_url(@template)
    assert_response :success
  end

  test 'should get new' do
    get new_scoping_detail_template_url
    assert_response :success
  end

  test 'should create template' do
    assert_difference("ScopingDetailTemplate.count") do
      post scoping_detail_templates_url, params: {
        scoping_detail_template: {
          name: 'A New Scoping template',
          description: 'This a new test scoping detail template',
          practice_ids: [practices(:application_security).id]
        }
      }
    end
  end

  test 'should get edit' do
    get edit_scoping_detail_template_url(@template)
    assert_response :success
    sf_sku_count = 0
    generic_sku_count = 0
    @skus_sd = @controller.instance_variable_get(:@skus)
    @skus_sd.each do |sku|
      if sku.id.start_with?(SalesForce::Product2.class_prefix)
        sf_sku_count += 1
      elsif
        generic_sku_count += 1
      end
    end
    assert sf_sku_count > 0
    assert generic_sku_count > 0
  end

  test 'edit not found' do
    get edit_scoping_detail_template_url(12)
    assert_toast_error
  end

  test 'should update template' do
    patch scoping_detail_template_url(@template), params: { scoping_detail_template: {name: 'updated template'}}

    assert_redirected_to scoping_detail_template_path(@template)

    @template.reload
    assert_equal "updated template", @template.name
  end

  test 'update not found' do
    patch scoping_detail_template_url(-1), params: { scoping_detail_template: {name: 'updated template'}}
    assert_toast_error
  end

  test 'should copy template' do
    # Assert that a new template was created
    assert_difference 'ScopingDetailTemplate.count' do
      post copy_scoping_detail_template_url(@template)
    end

    assert_redirected_to scoping_detail_template_path(@controller.view_assigns['copy'].id)
  end

  test 'copy not found' do
    post copy_scoping_detail_template_url(0)
    assert_toast_error
  end

  test "delete marks as deleted" do
    delete scoping_detail_template_path(@template)
    assert_redirected_to templates_url

    @template.reload
    assert @template.is_deleted?
  end

  test 'delete permanently' do
    assert_difference("ScopingDetailTemplate.count", -1) do
      delete scoping_detail_template_path(@template, permanent:true)
    end

    assert_redirected_to trashcan_url

    assert_raises ActiveRecord::RecordNotFound do
      @template.reload
    end
  end

  test 'delete not found' do
    delete scoping_detail_template_path(0)
    assert_toast_error
  end

  test 'template is restored' do
    delete scoping_detail_template_path(@template)
    assert_redirected_to templates_url

    @template.reload
    assert @template.is_deleted?

    post restore_scoping_detail_template_path(@template)
    assert_redirected_to scoping_detail_template_path(@template)

    @template.reload
    assert_not @template.is_deleted?
  end

  test 'sdt item is created' do
    get edit_scoping_detail_template_url(@template)
    assert_response :success

    assert_select 'table.scoping-template-table' do
      assert_select 'tbody' do
        assert_select 'tr', 0
      end
    end

    get add_detail_scoping_detail_templates_path, xhr: true
    assert_response :success
  end
end
