require 'test_helper'

class TrashcanControllerTest < ActionDispatch::IntegrationTest
  def setup
    @scoper = users(:scoper)
    @admin = users(:admin)

    @wbs = WorkBreakdownStructure.new(
      user:@scoper,
      scoped_by:corporates(:victor),
      project_structure: practices(:application_security).project_structure,
      is_deleted: true
    )

    @wbs.opportunity = SalesForce::Opportunity.fetch('0061O00001PA8bzQAD')
    @wbs.practices << practices(:application_security)
    @wbs.updated_by = @scoper
    assert @wbs.save!

    @wbs_template = WbsGroup.new(
      name: "My New Test Group",
      is_deleted: true
    )

    @wbs_template.practices << practices(:application_security)

    @wbs_template.wbs_group_lines.build(
      sku: 'IA-AS-AAR',
      task: 'Assessment',
      gsa_labor_category: gsa_labor_categories(:senior_security_consultant),
      billable_rate:250.00,
      total_hours:10,
      internal_hourly_rate:150.00,
      phase:1,
      ordinal:1,
    )
    @wbs_template.user = @scoper
    assert @wbs_template.save

    @template = ScopingDetailTemplate.new(
      name: 'scoping detail template test name',
      user: @scoper,
      is_deleted: true
    )
    @template.practices << Practice.first
    assert @template.save!
  end

  test "should get index" do
    login_as(@scoper)

    get trashcan_url
    assert_response :success
  end

  test 'should not remove all for non-admin' do
    login_as(@scoper)

    post trashcan_empty_path
    assert_toast_error
  end

  test 'should remove all' do
    login_as(@admin)

    post trashcan_empty_path, xhr: true
    assert_response :success
  end
end
