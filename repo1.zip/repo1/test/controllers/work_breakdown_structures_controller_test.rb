require 'test_helper'
require 'sales_force/objects/opportunity'

class WorkBreakdownStructuresControllerTest < ActionDispatch::IntegrationTest
  def setup
    @user = users(:scoper)
    login_as(@user)

    @wbs = create_test_wbs
  end

  test 'should get index' do
    get work_breakdown_structures_url
    assert_response :success
  end

  test 'should get show' do
    get work_breakdown_structure_path(@wbs)
    assert_response :success
  end

  test 'should get new' do
    get new_work_breakdown_structure_url
    assert_response :success
    assert_select 'title', 'COGS : New WBS'
  end

  test 'should get new for opportunity' do
    get new_work_breakdown_structure_url(opportunity:'0061O00001PA8bz')
    assert_response :success

    wbs = @controller.view_assigns['wbs']
    assert_not wbs.nil?
    assert_not wbs.opportunity.nil?
    assert_equal '0061O00001PA8bzQAD', wbs.opportunity.Id
  end

  test 'should create' do
    opportunity = SalesForce::Opportunity.fetch('0061O00001PA8bz')
    assert_not opportunity.nil?

    assert_difference 'WorkBreakdownStructure.count' do
      post work_breakdown_structures_path, params: {
        work_breakdown_structure: {
          scoped_by_id:corporates(:victor).id,
          project_structure: practices(:application_security).project_structure,
          sfdc_opportunity_id: '0061O00001PA8bz',
          practice_ids: [
            practices(:application_security).id
          ],
          billing_address_attributes: {
            kind: 'billing',
            address1: opportunity.account.billing.address1,
            city: opportunity.account.billing.city,
            state: opportunity.account.billing.state,
            postalcode: opportunity.account.billing.zipcode
          }
        }
      }
    end

    assert_redirected_to work_breakdown_structure_path(@controller.view_assigns['wbs'])
  end

  test 'should get edit' do
    get edit_work_breakdown_structure_path(@wbs)
    assert_response :success
    assert_select 'title', 'COGS : Edit WBS: ' + @wbs.title
    count = 0
    @skus_sd = @controller.instance_variable_get(:@skus_sd)
    @skus_sd.each do |sku|
      if !sku.id.start_with?(SalesForce::Product2.class_prefix)
        count += 1
      end
    end
    assert count > 0
  end

  test 'should update' do
    patch work_breakdown_structure_path(@wbs), params: {
      work_breakdown_structure: {
        billing_rule: enumerations(:completion).name
      }
    }

    assert_redirected_to work_breakdown_structure_path(@wbs)

    @wbs.reload
    assert_equal enumerations(:completion).name, @wbs.billing_rule
  end

  test 'should update update_by' do
    @user = users(:victor)
    login_as(@user)

    previous_update = @wbs.updated_at
    patch work_breakdown_structure_path(@wbs), params: {
      work_breakdown_structure: {
        billing_rule: enumerations(:monthly).name
      }
    }

    assert_redirected_to work_breakdown_structure_path(@wbs)

    @wbs.reload
    assert_equal @user, @wbs.updated_by
    assert previous_update < @wbs.updated_at
  end

  test 'no billing address' do
    # If the WBS has a billing address then remove it
    if !@wbs.billing_address.nil?
      @wbs.billing_address.destroy
      @wbs.billing_address = nil
    end

    # Make sure the billing address is gone
    assert @wbs.billing_address.nil?, 'Billing address still exists.'

    # Make sure the show still works with no billing address
    get work_breakdown_structure_path(@wbs)
    assert_response :success
  end

  test 'wbs gets published' do
    post publish_work_breakdown_structure_path(@wbs)

    @wbs.reload
    assert @wbs.quote?, 'Appears the quote was not generated.'
    assert !@wbs.published_by.nil?
    assert !@wbs.published_at.nil?
  end

  test 'should allow 0 billable and internal rate for certain LCATs' do
    index = 3 # wbs already has two entries
    GsaLaborCategory::NON_GSA.each { |cat|
      entry = WbsEntry.new(
          work_breakdown_structure: @wbs,
          sku: 'IA-AS-AAR',
          task: 'task value',
          gsa_labor_category: cat,
          billable_rate:0.00,
          internal_hourly_rate:0.00,
          phase:1,
          link_type:3,
          link_percent:0.10,
          total_hours: 10,
          ordinal:index
      )
      assert entry.valid?
      assert entry.save
      index += 1
    }
  end

# This test is no longer valid because we are not using Rails validations.  We are now
# checking the publishability by validating the line item as a whole.
=begin
  test 'should not allow 0 billable rate for certain LCATs' do
    index = 3 # wbs already has two entries
    GsaLaborCategory.all.each { |cat|
      if !GsaLaborCategory::NON_GSA.include? cat
        entry = WbsEntry.new(
            work_breakdown_structure: @wbs,
            sku: 'IA-AS-AAR',
            task: 'task value',
            gsa_labor_category: cat,
            billable_rate:0.00,
            internal_hourly_rate:160.00,
            phase:1,
            link_type:3,
            link_percent:0.10,
            total_hours: 10,
            ordinal:index
        )
        assert !entry.valid?
      end
    }
  end

  test 'should not allow 0 internal rate for certain LCATs' do
    index = 3 # wbs already has two entries
    GsaLaborCategory.all.each { |cat|
      if !GsaLaborCategory::NON_GSA.include? cat
        entry = WbsEntry.new(
            work_breakdown_structure: @wbs,
            sku: 'IA-AS-AAR',
            task: 'task value',
            gsa_labor_category: cat,
            billable_rate:200.00,
            internal_hourly_rate:0.00,
            phase:1,
            link_type:3,
            link_percent:0.10,
            total_hours: 10,
            ordinal:index
        )
        assert !entry.valid?
      end
    }
  end
=end

  test 'should move to trash' do
    delete work_breakdown_structure_path(@wbs)

    if !@wbs.sfdc_opportunity_id.blank?
      assert_redirected_to opportunity_path(@wbs.opportunity.gps_opportunity_number)
    else
      assert_redirected_to work_breakdown_structures_url
    end

    @wbs.reload
    assert @wbs.is_deleted?
  end

  test 'should restore from trash' do
    delete work_breakdown_structure_path(@wbs)

    if !@wbs.sfdc_opportunity_id.blank?
      assert_redirected_to opportunity_path(@wbs.opportunity.gps_opportunity_number)
    else
      assert_redirected_to work_breakdown_structures_url
    end

    @wbs.reload
    assert @wbs.is_deleted?

    post restore_work_breakdown_structure_url(@wbs)
    assert_redirected_to work_breakdown_structure_path(@wbs)

    @wbs.reload
    assert_not @wbs.is_deleted?
  end

  test 'should destroy' do
    @wbs.is_deleted = true
    assert @wbs.save!

    assert_difference 'WorkBreakdownStructure.count', -1 do
      delete work_breakdown_structure_path(@wbs), params: { permanent: true }
    end

    assert_redirected_to trashcan_url
  end

  #test 'creates wbs from quote' do
  #  assert_difference 'WorkBreakdownStructure.count' do
  #    post from_quote_work_breakdown_structures_url('a450r000000CGW3')
  #  end
  #
  #  assert_redirected_to work_breakdown_structure_path(@controller.view_assigns['wbs'])
  #end

  test 'creates copy of wbs' do
    assert_difference 'WorkBreakdownStructure.count' do
      post copy_work_breakdown_structure_url(@wbs)
    end

    assert_redirected_to work_breakdown_structure_path(@controller.view_assigns['copy'])
  end

  test 'updates opportunity on select' do
    get new_work_breakdown_structure_path
    assert_response :success

    get opportunity_work_breakdown_structures_path, params: {
      opportunity_id: '0061O00001PA8bz'
    }, xhr: true

    assert_response :success
    assert @controller.view_assigns.key?('opportunity')
    assert_not @controller.view_assigns['opportunity'].nil?
    assert_equal '0061O00001PA8bzQAD', @controller.view_assigns['opportunity'].Id
  end

  test 'returns valid skus for wbs' do
    get valid_skus_work_breakdown_structure_url(@wbs), xhr: true

    assert_response :success
    json_response = JSON.parse(response.body)
    assert_not json_response.empty?
  end

  test 'calculates totals' do
    post calculate_work_breakdown_structure_url(@wbs), xhr: true
    assert_response :success

    json_response = JSON.parse(response.body)
    assert json_response.key?('total_hours')
    assert json_response.key?('total_revenue')
    assert json_response.key?('total_internal')
    assert json_response.key?('total_profit')
    assert json_response.key?('total_profit_pct')
  end

  test 'should accept floats XX.' do
    login_as(users(:scoper))

    entry = @wbs.wbs_entries.order(:ordinal).first

    patch work_breakdown_structure_path(@wbs), params: {
      work_breakdown_structure: {
        wbs_entries_attributes: {
          '0': {
            id: entry.id,
            total_hours: '1.',
            billable_rate: '150.',
            internal_hourly_rate: '120.'
          }
        }
      }
    }

    assert_redirected_to work_breakdown_structure_path(@wbs)
    @wbs.reload

    entry = @wbs.wbs_entries.order(:ordinal).first
    assert_equal entry.total_hours, 1.0
    assert_equal entry.billable_rate, 150.0
    assert_equal entry.internal_hourly_rate, 120.0
  end
end
