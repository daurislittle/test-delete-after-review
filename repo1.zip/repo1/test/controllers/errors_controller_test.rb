require 'test_helper'

class ErrorsControllerTest < ActionDispatch::IntegrationTest
end
