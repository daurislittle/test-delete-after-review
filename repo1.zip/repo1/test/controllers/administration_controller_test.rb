require 'test_helper'

class AdministrationControllerTest < ActionDispatch::IntegrationTest
  def setup
    @user = users(:admin)
    login_as(@user)
  end

  test "should get index" do
    get administration_url
    assert_response :success
  end

  test 'non-admin cannot access' do
    user = users(:scoper)
    login_as(user)

    get administration_url
    assert_toast_error
  end
end
