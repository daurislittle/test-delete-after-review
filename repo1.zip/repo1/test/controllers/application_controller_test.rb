require 'test_helper'

class ApplicationControllerTest < ActionDispatch::IntegrationTest
  test 'should get index' do
    login_as(users(:scoper))

    get root_path
    assert_response :success
  end

  test 'should show welcome' do
    login_as(users(:scoper))

    get welcome_path
    assert_response :success
  end

  test 'should get search' do
    login_as(users(:scoper))

    get search_path, params: {search_for: 'aaa'}
    assert_response :success
  end

  test 'should get recently viewed' do
    login_as(users(:scoper))

    get recently_viewed_path, xhr: true
    assert_response :success
    assert @controller.view_assigns['viewed']
    assert @controller.view_assigns['recent_viewed_page']
    assert @controller.view_assigns['recent_max_page']
  end

  test 'should get wbs statuses' do
    login_as(users(:scoper))

    get wbs_status_path, xhr: true
    assert_response :success
    assert @controller.view_assigns['quotes']
    assert @controller.view_assigns['status_viewed_page']
    assert @controller.view_assigns['status_max_page']
  end

  test 'handles unauthorized' do
    login_as(users(:scoper))

    get administration_url
    assert_toast_error
  end

  test 'handles forbidden' do
    login_as(users(:disabled))

    get work_breakdown_structures_url
    assert_response 403
  end

  test 'recently viewed contains 15' do
    login_as(users(:scoper))

    get root_path
    assert @controller.view_assigns['viewed'].count == 15 || @controller.view_assigns['recent_max_page'] <= 1
  end

  test 'wbs status contains 15' do
    login_as(users(:scoper))

    get root_path
    assert @controller.view_assigns['quotes'].count == 15 || @controller.view_assigns['status_max_page'] <= 1
  end
end