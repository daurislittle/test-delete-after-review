require 'test_helper'

class TemplatesControllerTest < ActionDispatch::IntegrationTest
  def setup
    @user = users(:scoper)
    login_as(@user)
  end

  test 'should get index' do
    get templates_url
    assert_response :success
  end
end
