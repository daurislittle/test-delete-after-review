require "application_system_test_case"

class WorkBreakdownStructureSystemTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit pci_rocs_url
  #
  #   assert_selector "h1", text: "PciRoc"
  # end
  #
  def setup
    #Rails.application.load_seed
    @user = users(:one)
    @wbs = WorkBreakdownStructure.new(
        title:"New WBS",
        user:@user,
        scoped_by:corporates(:corporate1),
        project_structure: practices(:application_security).project_structure,
        opportunity: SalesForce::Opportunity.new('0061700000KNtoMAAT'),
        contract_type: 'FFP'
    )

    @wbs.practices << practices(:application_security)
    @wbs.save

    entry1 = WbsEntry.new(
      work_breakdown_structure: @wbs,
      sku: 'IA_AS_AAR',
      task: 'Assessment',
      gsa_labor_category: gsa_labor_categories(:senior_security_consultant),
      billable_rate:250.00,
      total_hours:10,
      internal_hourly_rate:150.00,
      phase:1,
      ordinal:1
    )

    entry1.save

    entry2 = WbsEntry.new(
        work_breakdown_structure: @wbs,
        sku: 'IA_AS_AAR',
        task: 'Program Management',
        gsa_labor_category: gsa_labor_categories(:program_manager),
        billable_rate:250.00,
        internal_hourly_rate:150.00,
        phase:1,
        link_type:3,
        link_percent:0.10,
        ordinal:0
    )

    entry2.save
  end
end

