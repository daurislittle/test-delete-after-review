require 'test_helper'

class WbsGroupTest < ActiveSupport::TestCase
  def setup
    @template = WbsGroup.new
    @template.name = "My New Test Group"
    @template.practices << practices(:application_security)
    @template.wbs_group_lines.build(
      sku: 'IA-AS-AAR',
      task: 'Assessment',
      gsa_labor_category: gsa_labor_categories(:senior_security_consultant),
      billable_rate:250.00,
      total_hours:10,
      internal_hourly_rate:150.00,
      phase:1,
      ordinal:1
    )
    @template.user = users(:scoper)
    assert @template.save
  end

  test 'updating item updates last_updated' do
    # Sleep for a second to ensure timestamp changes.
    sleep 1

    @template.wbs_group_lines.first.task = 'My New Task'
    @template.wbs_group_lines.first.save

    assert_equal @template.last_updated, @template.wbs_group_lines.first.updated_at
  end
end
