require 'test_helper'

class GpsGroupTest < ActiveSupport::TestCase
  test 'can get PSG group' do
    assert_not GpsGroup.psg.nil?
  end

  test 'can get PMO group' do
    assert_not GpsGroup.pmo.nil?
  end

  test 'can get scoping group(s)' do
    assert_not GpsGroup.scoping.empty?
  end

  test 'can get leadership group(s)' do
    assert_not GpsGroup.leadership.empty?
  end

  test 'returns false for invalid object types' do
    assert_not gps_groups(:generic).member?(1.0)
  end

  test 'scoping group returns true for members' do
    scoping = gps_groups(:scoping)

    assert scoping.member?(users(:scoper))
    assert scoping.member?(corporates(:scoper))
    assert scoping.member?('scopefn.scopeln@test.com')

    assert GpsGroup.member_scoping?(users(:scoper))
  end

  test 'scoping group returns false for non-members' do
    assert_not GpsGroup.member_scoping?(users(:admin))
  end

  test 'pmo group returns true for members' do
    scoping = gps_groups(:pmo)

    assert scoping.member?(users(:pmo))
    assert scoping.member?(corporates(:pmo))
    assert scoping.member?('james.pmo@gps.org')

    assert GpsGroup.member_pmo?(users(:pmo))
  end

  test 'pmo group returns false for non-members' do
    assert_not GpsGroup.member_pmo?(users(:admin))
  end

  test 'psg group returns true for members' do
    scoping = gps_groups(:psg)

    assert scoping.member?(users(:psg))
    assert scoping.member?(corporates(:psg))
    assert scoping.member?('frank.psg@gps.org')

    assert GpsGroup.member_psg?(users(:psg))
  end

  test 'psg group returns false for non-members' do
    assert_not GpsGroup.member_psg?(users(:admin))
  end
end
