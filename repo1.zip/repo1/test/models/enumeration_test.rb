require 'test_helper'

class EnumerationTest < ActiveSupport::TestCase
  test 'test get enumeration by name' do
    assert Enumeration.for_name('billing_rule', 'Upon Completion')
  end

  test 'test is valid enumeration type' do
    assert Enumeration.is_valid_type?('billing_rule')
    assert_not Enumeration.is_valid_type?('some_other_type')
  end

  test 'test get for type' do
    enums = Enumeration.for_type('billing_rule')
    assert_not enums.empty?

    enums.each do |e|
      assert_equal 'billing_rule', e.enum_type
      assert e.is_type?('billing_rule')
    end
  end

  test 'test equality of enums' do
    enumeration = enumerations(:completion)

    assert enumeration == Enumeration.for_name('billing_rule', 'Upon Completion')
    assert_not enumeration == Enumeration.for_name('contract_vehicle', 'GSA - GuidePoint Security')
  end

  test 'test equality of enum with strings' do
    enumeration = enumerations(:completion)

    assert enumeration == 'Upon Completion'
    assert_not enumeration == 'GSA - GuidePoint Security'
  end

  test 'test equality with object' do
    enumeration = enumerations(:completion)
    assert_not enumeration == Integer(2)
  end

  test 'test inequality of enums' do
    enumeration = enumerations(:completion)

    assert_not enumeration != Enumeration.for_name('billing_rule', 'Upon Completion')
    assert enumeration != Enumeration.for_name('contract_vehicle', 'GSA - GuidePoint Security')
  end

  test 'test inequality of enum with strings' do
    enumeration = enumerations(:completion)

    assert_not enumeration != 'Upon Completion'
    assert enumeration != 'GSA - GuidePoint Security'
  end

  test 'test inequality with object' do
    enumeration = enumerations(:completion)
    assert enumeration != Integer(2)
  end
end
