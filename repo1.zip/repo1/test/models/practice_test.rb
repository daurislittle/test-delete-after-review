require 'test_helper'

class PracticeTest < ActiveSupport::TestCase
  def setup
    @appsec = Practice.new(
      project_structure: 'Application Security'
    )
    @appsec.practices << 'Application Security'
    assert @appsec.save

    @non_existing = Practice.new(
      project_structure: 'vSoc'
    )

    assert @non_existing.save
  end

  test 'practice is valid' do
    assert @appsec.valid?
  end

  test 'is non-existing' do
    assert @non_existing.in?(Practice.non_existing)
  end

  test 'practice has project_structure' do
    @appsec.project_structure = ''
    assert_not @appsec.valid?
  end

  test 'finds by structure' do
    assert_not Practice.for_structure('Application Security').nil?
  end

  test 'returns skus for practice' do
    assert_not @appsec.skus.empty?
  end

  test 'returns true for valid sku' do
    assert @appsec.sku?('IA-AS-TOOLS')
  end

  test 'returns false for invalid sku' do
    assert_not @appsec.sku?('IA-AS-JUNK')
  end
end
