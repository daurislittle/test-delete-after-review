require 'test_helper'

class SdtItemTest < ActiveSupport::TestCase
  def setup
    @template = ScopingDetailTemplate.new(
      name: 'My Scoping Detail Template',
      user: users(:scoper)
    )

    @template.practices << Practice.first
    assert @template.save!
    assert @template.valid?
  end

  test 'test sdt item has valid sku' do
    assert SdtItem.new(
      scoping_detail_template: @template,
      item: 'Item 1',
      value: 'Value 1',
      sku_id: Enumeration.where(enum_type: 'sku').first.id
    ).valid?
  end

end
