require 'test_helper'

class GpsGroupMemberTest < ActiveSupport::TestCase
  def setup
    group = GpsGroup.new(
      name: 'My GPS Group',
      email: 'gps_group@guidepointsecurity.com'
    )

    @member = GpsGroupMember.new(
      gps_group: group,
      corporate: corporates(:scoper)
    )
  end

  test 'returns corporate member email' do
    assert_not @member.email.blank?
    assert_equal corporates(:scoper).email, @member.email
  end
end
