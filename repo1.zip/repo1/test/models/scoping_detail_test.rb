require 'test_helper'

class ScopingDetailTest < ActiveSupport::TestCase
  test 'test scoping detail sku is valid' do
    wbs = WorkBreakdownStructure.new

    assert ScopingDetail.new(
      item: 'Item 1',
      value: 'Value 1',
      sku_id: Enumeration.where(enum_type: 'sku').first,
      work_breakdown_structure: wbs
    ).valid?

    assert_not ScopingDetail.new(
      value: 'Value 1',
      work_breakdown_structure: wbs
    ).validate_publishability(1).count == 0
  end
end
