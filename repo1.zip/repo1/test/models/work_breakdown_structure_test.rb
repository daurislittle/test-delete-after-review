require 'test_helper'

class WorkBreakdownStructureTest < ActiveSupport::TestCase
  def setup
    @wbs = create_test_wbs
  end

  test 'WBS should be valid' do
    assert @wbs.valid?
  end

  test 'WBS has title' do
    assert_not @wbs.title.blank?
  end

  # The owner/user requirement is enforced by the belongs_to association
  test 'WBS has an owner' do
    @wbs.user = nil
    assert_not @wbs.valid?
  end

  # The scoped_by requirement is enforced by the belongs_to association
  test 'WBS has scoped_by' do
    @wbs.scoped_by = nil
    assert_not @wbs.valid?
  end

  test 'WBS has updated_by' do
    @wbs.updated_by = nil
    assert_not @wbs.valid?
  end

  test 'WBS has at least one practice' do
    @wbs.practice_ids = nil
    assert_not @wbs.valid?
  end

  test 'WBS has a project_structure' do
    @wbs.project_structure = ''
    assert_not @wbs.valid?
  end

  test 'WBS contacts does not include No Longer With Company' do
    @wbs.contacts.each do |contact|
      assert_not contact.no_longer_with_company?
    end
  end

  test 'WBS is publishable' do
    assert @wbs.publishable?, 'WBS is not publishable'
  end

  test 'WBS is not publishable if generic scoping details are used' do
    sd_line = ScopingDetail.new(
      work_breakdown_structure: @wbs,
      sku_id: enumerations(:ipt_sku).id,
      item: 'item',
      value: 'value',
      ordinal:1
    )
    assert sd_line.save

    assert_not @wbs.publishable?, 'WBS is publishable'
  end

  test 'WBS requires contract vehicle' do
    @wbs.contract_vehicle = nil
    assert_not @wbs.publishable?, 'WBS is still publishable without contract vehicle.'
  end

  test 'WBS is not publishable with bad contract vehicle' do
    @wbs.contract_vehicle = 'Unknown Contract Vehicle'
    assert_not @wbs.publishable?
  end

  test 'WBS is not publishable with bad contract vehicle on line item' do
    entry = @wbs.wbs_entries.first
    current_cv = entry.contract_vehicle

    entry.contract_vehicle = 'Invalid Contract Vehicle'

    assert entry.save
    assert_not @wbs.publishable?

    # put things back
    entry.contract_vehicle = current_cv
    assert entry.save
  end

  test 'WBS is not publishable with bad LCAT on line item' do
    entry = @wbs.wbs_entries.first
    current_lcat = entry.gsa_labor_category

    lcat = GsaLaborCategory.new(name: 'Unknown labor category')
    lcat.save

    entry.gsa_labor_category = lcat

    assert entry.save
    assert_not @wbs.publishable?

    # put things back
    entry.gsa_labor_category = current_lcat
    assert entry.save
  end

  test 'WBS is not publishable with zero hour line items' do
    entry = WbsEntry.new(
        work_breakdown_structure: @wbs,
        sku: 'IA-AS-AAR',
        task: 'task value',
        gsa_labor_category: gsa_labor_categories(:sme),
        billable_rate:180.00,
        internal_hourly_rate:160.00,
        phase:1,
        link_type:3,
        link_percent:0.10,
        total_hours: 0,
        ordinal:1
    )
    assert entry.save
    assert !@wbs.publishable?, 'WBS is publishable'
  end

  test "Returns WBS with practice" do
    wbs = WorkBreakdownStructure.with_practice(practices(:security_assessments))
    assert_not wbs.empty?
  end

  test 'not publishable when note length exceeded' do
    wbs_entry = @wbs.wbs_entries.first

    wbs_entry.notes =
      "COGS User informed when notes field exceeds the limit."\
      "COGS user can save the WBS if the limit is exceeded."\
      "COGS user can easily see which lines have notes that exceed the allowed character limit."\
      "When a notes field entry exceeds the character limit, user cannot publish the wbs "\
      "When a notes field entry exceeds the character limit, publish icon is disabled with a "\
      "notification that a note exceeds the character limit and thus is preventing the WBS from being published"
    assert wbs_entry.save

    assert_not @wbs.publishable?
  end

  test "Returns proper contract types for FFP" do
    contract_types = WorkBreakdownStructure.billing_rules(WorkBreakdownStructure::CONTRACT_TYPE_FFP)

    assert contract_types.include?(Enumeration.find_by(enum_type: 'billing_rule', name: 'Contract Term Period'))
    assert contract_types.include?(Enumeration.find_by(enum_type: 'billing_rule', name: '50% upon Signature, 50% upon Draft Deliverable'))
    assert contract_types.include?(Enumeration.find_by(enum_type: 'billing_rule', name: 'PCI - 25%/50%/25%'))
    assert contract_types.include?(Enumeration.find_by(enum_type: 'billing_rule', name: 'Upon Completion'))
    assert contract_types.include?(Enumeration.find_by(enum_type: 'billing_rule', name: 'Upon Delivery of All Draft Deliverables'))
    assert contract_types.include?(Enumeration.find_by(enum_type: 'billing_rule', name: 'Upon Delivery of Individual Draft Deliverables'))
    assert contract_types.include?(Enumeration.find_by(enum_type: 'billing_rule', name: 'Upon Signature'))
  end

  test 'user can edit own' do
    wbs = create_test_wbs
    assert wbs.can_edit?(users(:scoper))
  end

  test 'user cannot edit when not member of practices' do
    wbs = create_test_wbs
    assert_not wbs.can_edit?(users(:pmo))
  end

  test 'member of practices can edit' do
    wbs = create_test_wbs
    assert wbs.can_edit?(users(:victor))
  end

  test 'watchlist includes scoper' do
    wbs = create_test_wbs
    watchlist = wbs.watchlist

    assert watchlist.include?(users(:victor).email)
  end

  test 'watchlist includes sos and ae in production' do
    rails_env = Rails.env

    Rails.env = 'production'

    wbs = create_test_wbs
    watchlist = wbs.watchlist(sos:true, ae:true)

    assert watchlist.include?(wbs.opportunity.sos.Email)
    assert watchlist.include?(wbs.opportunity.account_executive.Email)

    # Reset rails environment
    Rails.env = rails_env
  end

  test 'returns proper totals' do
    wbs = create_test_wbs
    line_ids = wbs.wbs_entries.pluck(:id)
    totals = wbs.total_lines(line_ids)

    total_hours = 0
    revenue = 0
    cost = 0
    wbs.wbs_entries.each do |line|
      total_hours += line.total_hours
      revenue += (line.total_hours * line.billable_rate)
      cost += (line.total_hours * line.internal_hourly_rate)
    end

    assert_equal totals[:total_hours], total_hours
    assert_equal totals[:total_revenue], revenue
    assert_equal totals[:total_internal], cost
    assert_equal totals[:total_profit], revenue - cost
  end
end
