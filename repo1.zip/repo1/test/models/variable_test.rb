require 'test_helper'

class VariableTest < ActiveSupport::TestCase
  test 'gets variable value' do
    assert_equal 160.0, Variable.get('default_internal_rate', default_value: 10.0)
  end

  test 'gets default value for no variable' do
    assert_equal 5, Variable.get("some-non-existent-variable", default_value: 5)
  end
end
