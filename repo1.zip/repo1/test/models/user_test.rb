require 'test_helper'

class UserTest < ActiveSupport::TestCase
  test 'gets proper name' do
    user = users(:scoper)

    assert_equal "#{user.first_name} #{user.last_name}", user.name
  end

  test 'gets lastname first' do
    user = users(:scoper)

    assert_equal "#{user.last_name}, #{user.first_name}", user.lastname_first
  end

  test 'is_administrator' do
    non_admin = users(:scoper)
    admin = users(:admin)

    assert_not non_admin.is_administrator?
    assert admin.is_administrator?
  end

  test 'returns group memberships' do
    user = users(:scoper)

    group = GpsGroup.new(
      name: 'My GPS Group',
      email: 'gps_group@guidepointsecurity.com',
    )
    assert group.save, 'Failed to save GpsGroup'

    member = GpsGroupMember.new(
      gps_group: group,
      corporate: corporates(:scoper)
    )
    assert member.save, 'Failed to save GpsGroupMember'

    corporate = user.corporate
    ids = GpsGroupMember.where(corporate:user.corporate).pluck(:gps_group_id)

    assert_not user.groups.empty?
  end

  test 'returns empty scoping teams' do
    assert users(:admin).scoping_teams.empty?
  end

  test 'returns scoping teams' do
    user = users(:scoper)

    group = GpsGroup.new(
      name: 'My Scoping Group',
      email: 'gps_group@guidepointsecurity.com',
    )
    assert group.save, 'Failed to save GpsGroup'

    member = GpsGroupMember.new(
      gps_group: group,
      corporate: corporates(:scoper)
    )
    assert member.save, 'Failed to save GpsGroupMember'
    assert_not user.scoping_teams.empty?
  end

  test 'returns empty leadership teams' do
    assert users(:scoper).leadership_teams.empty?
  end

  test 'returns leadership teams' do
    user = users(:scoper)

    group = GpsGroup.new(
      name: 'My Leadership Group',
      email: 'gps_group@guidepointsecurity.com',
      )
    assert group.save, 'Failed to save GpsGroup'

    member = GpsGroupMember.new(
      gps_group: group,
      corporate: corporates(:scoper)
    )
    assert member.save, 'Failed to save GpsGroupMember'

    assert_not user.leadership_teams.empty?
  end
end
