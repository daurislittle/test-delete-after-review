require 'test_helper'

class AddressTest < ActiveSupport::TestCase
  def setup
    @wbs = create_test_wbs

    @valid_address = Address.new(
      kind: 'other',
      address1: '123 Main St',
      city: 'Some City',
      state: 'AT',
      postalcode: '12324',
      country: 'United States'
    )

    @valid_address.addressable = @wbs
  end

  test 'produces proper string' do
    assert_equal "#{@valid_address.address1} #{@valid_address.address2} #{@valid_address.city}, #{@valid_address.state} #{@valid_address.postalcode} #{@valid_address.country}", @valid_address.to_s
  end

  test 'formatted address' do
    assert_equal "#{@valid_address.address1}\n#{@valid_address.city}, #{@valid_address.state} #{@valid_address.postalcode}\n#{@valid_address.country}", @valid_address.formatted

    @valid_address.address2 = 'Suite 100'

    assert_equal "#{@valid_address.address1}\n#{@valid_address.address2}\n#{@valid_address.city}, #{@valid_address.state} #{@valid_address.postalcode}\n#{@valid_address.country}", @valid_address.formatted
  end

  test 'other is valid' do
    assert @valid_address.valid?
  end

  test 'other US address is invalid' do
    address = Address.new
    assert_not address.valid?

    assert address.errors.messages.key?(:address1)
    assert address.errors.messages.key?(:city)
    assert address.errors.messages.key?(:state)
    assert address.errors.messages.key?(:postalcode)
  end
end
