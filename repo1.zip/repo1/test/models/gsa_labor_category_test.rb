require 'test_helper'

class GsaLaborCategoryTest < ActiveSupport::TestCase
  def setup
    @gsa_lcat = GsaLaborCategory.find_by(name:'Senior Security Consultant')
    assert_not @gsa_lcat.nil?, 'Unable to locate Senior Security Consultant LCAT'

    @nongsa_lcat = GsaLaborCategory::NON_GSA.first
    assert_not @nongsa_lcat.nil?, 'Unable to locate a non-GSA LCAT'
  end

  test 'management? returns true for management LCAT' do
    lcat = GsaLaborCategory.find_by(name: 'Project Manager')
    assert lcat.management?
  end

  test 'management? returns false for non-management LCAT' do
    assert_not @gsa_lcat.management?
  end

  test 'returns default billrate' do
    assert_equal Variable.get('default_billable_rate'), @gsa_lcat.default_billrate
    assert_equal @gsa_lcat.federal_max_price, @gsa_lcat.default_billrate(contract_vehicle: GsaLaborCategory::GSA_GUIDEPOINTSECURITY)
  end

  test 'should return compliant' do
    assert @gsa_lcat.compliant?(
      @gsa_lcat.federal_max_price,
      contract_vehicle: GsaLaborCategory::GSA_GUIDEPOINTSECURITY,
      region: GsaLaborCategory::FEDERAL_REGION)[:is_compliant]
    assert @gsa_lcat.compliant?(
      @gsa_lcat.federal_max_price,
      contract_vehicle: GsaLaborCategory::GSA_GUIDEPOINTSECURITY)[:is_compliant]
    assert @gsa_lcat.compliant?(@gsa_lcat.gsa_floor_price)[:is_compliant]

    @gsa_lcat = GsaLaborCategory.find_by(name: 'Project Coordinator')
    assert @gsa_lcat.compliant?(1.0, region: GsaLaborCategory::FEDERAL_REGION)[:is_compliant]
    assert @gsa_lcat.compliant?(0.0)[:is_compliant]
  end

  test 'should return non-compliant' do
    # Cannot use non-GSA LCAT in GSA contract
    assert_not @nongsa_lcat.compliant?(
      0.0,
      contract_vehicle: GsaLaborCategory::GSA_GUIDEPOINTSECURITY
    )[:compliant], 'Allowed non-GSA LCAT in GSA contract'

    # Cannot use $0 for Federal region
    assert_not @nongsa_lcat.compliant?(
      0.0,
      region: GsaLaborCategory::FEDERAL_REGION
    )[:compliant], 'Allowed $0 for non-GSA LCAT in federal contract'

    # GSA contract in federal region requires bill rate < federal max
    assert_not @gsa_lcat.compliant?(
      300.0,
      contract_vehicle: GsaLaborCategory::GSA_GUIDEPOINTSECURITY,
      region: GsaLaborCategory::FEDERAL_REGION
    )[:compliant], 'Allowed bill rate < federal max in GSA/federal contract'

    # GSA contract in non-federal region requires bill rate < federal max
    assert_not @gsa_lcat.compliant?(
      300.0,
      contract_vehicle: GsaLaborCategory::GSA_GUIDEPOINTSECURITY
    )[:compliant], 'Allowed bill rate < federal max in GSA contract'

    # non-GSA contract in non-federal requires bill rate > gsa floor
    assert_not @gsa_lcat.compliant?(
      100.0
    )[:compliant], 'Allowed bill rate > gsa floor in non-GSA/non-federal contract'

    # GSA LCAT requires bill rate > 0
    assert_not @gsa_lcat.compliant?(
      0.0
    )[:compliant], 'Allowed $0 bill rate for GSA LCAT'

    # Bill rate cannot be negative
    assert_not @nongsa_lcat.compliant?(
      -10.0
    )[:compliant], 'Allowed a negative bill rate'
  end
end
