require 'test_helper'

class ScopingDetailTemplateTest < ActiveSupport::TestCase
  def setup
    @user = users(:scoper)

    @template = ScopingDetailTemplate.new(
      name: 'scoping detail template test name',
      user: @user
    )
    @template.practices << Practice.first
    @template.sdt_items.build(
      sku_id: enumerations(:ipt_sku).id,
      item: 'Test Item 1',
      value: 'Some Value 1'
    )

    assert @template.save!
  end

  test 'updating template item updates last updated' do
    sleep 1

    @template.sdt_items.first.item = 'New Test Item 1'
    @template.sdt_items.first.save!

    assert_equal @template.last_updated, @template.sdt_items.first.updated_at
  end
end
