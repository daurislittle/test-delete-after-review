require 'test_helper'

class WbsGroupLineTest < ActiveSupport::TestCase
  def setup
    @template = WbsGroup.new
    @template.name = "My New Test Group"
    @template.user = users(:scoper)
    @template.practices << practices(:application_security)

    @template.wbs_group_lines.build(
      sku: 'IA-AS-AAR',
      task: 'Assessment',
      gsa_labor_category: gsa_labor_categories(:associate_cloud_security_engineer),
      billable_rate:250.00,
      total_hours:10,
      internal_hourly_rate:150.00,
      phase:1,
      ordinal:1
    )
  end

  test 'does not have link' do
    assert_not @template.wbs_group_lines.first.has_link?
  end

  test 'negative internal rate is invalid for non-gsa LCAT' do
    @template.wbs_group_lines.first.internal_hourly_rate = -1.0
    assert_not @template.wbs_group_lines.first.valid?
  end

  test '0.0 is valid internal rate for non-gsa LCAT' do
    @template.wbs_group_lines.first.internal_hourly_rate = 0.0
    assert @template.wbs_group_lines.first.valid?
  end

  test 'negative internal rate is invalid for GSA LCATs' do
    @template.wbs_group_lines.first.gsa_labor_category = gsa_labor_categories(:senior_security_consultant)
    @template.wbs_group_lines.first.internal_hourly_rate = -1.0
    assert_not @template.wbs_group_lines.first.valid?
  end

  test '0.0 is invalid internal rate for gsa LCATs' do
    @template.wbs_group_lines.first.gsa_labor_category = gsa_labor_categories(:senior_security_consultant)
    @template.wbs_group_lines.first.internal_hourly_rate = 0.0
    assert_not @template.wbs_group_lines.first.valid?
  end
end
