require 'test_helper'

class CorporateTest < ActiveSupport::TestCase
  def setup
    group = GpsGroup.new(
      name: 'My GPS Group',
      email: 'gps_group@guidepointsecurity.com',
    )
    assert group.save

    assert GpsGroupMember.new(
      gps_group: group,
      corporate: corporates(:scoper)
    ).save
  end

  test 'format of name' do
    corporate = corporates(:scoper)

    assert_equal "#{corporate.firstname} #{corporate.lastname}", corporate.name
  end

  test 'format of last name first' do
    corporate = corporates(:scoper)

    assert_equal "#{corporate.lastname}, #{corporate.firstname}", corporate.lastname_first
  end

  test "employees does not include not with company" do
    Corporate.gps_contacts.each do |employee|
      assert_not employee.No_Longer_with_Company__c
    end
  end

  test 'finds corporate for user' do
    assert_not Corporate.for_user(users(:scoper)).nil?
  end

  test 'returns groups for corporate' do
    assert_not corporates(:scoper).groups.empty?
  end

  test 'checks membership in group' do
    assert corporates(:scoper).member?(GpsGroup.find_by(name: 'My GPS Group'))
  end
end
