require 'test_helper'

class RecentlyViewedTest < ActiveSupport::TestCase
  def setup
    @wbs = create_test_wbs

    @recently_viewed = RecentlyViewed.new(
      viewed_type: 'WorkBreakdownStructure',
      viewed_id: @wbs.id,
      viewed_url: 'wbs/@wbs.id',
      user: users(:scoper)
    )

    assert @recently_viewed.save
  end

  test 'exists should return true for existing object' do
    object = recently_vieweds(:sf_last_visited)
    assert object.exists?
  end

  test 'exists returns false for non-existing object' do
    object = recently_vieweds(:sf_non_existant)
    assert_not object.exists?
  end

  test 'exists returns true for wbs' do
    assert @recently_viewed.exists?
  end

  test 'should return name' do
    assert_not @recently_viewed.name.blank?
    assert_not recently_vieweds(:sf_last_visited).name.blank?
    assert_not recently_vieweds(:sf_last_visited_no_title).name.blank?
  end

  test 'should return owner' do
    assert_not @recently_viewed.owner.nil?
    assert_not recently_vieweds(:sf_last_visited).owner.nil?
  end

  test 'should return object created_on' do
    assert_not @recently_viewed.created_on.blank?
    assert_not recently_vieweds(:sf_last_visited).created_on.blank?
  end

  test 'should return object last_updated' do
    assert_not @recently_viewed.last_updated.blank?
    assert_not recently_vieweds(:sf_last_visited).last_updated.blank?
  end
end
