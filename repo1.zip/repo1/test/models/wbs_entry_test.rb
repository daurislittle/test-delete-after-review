require 'test_helper'

class WbsEntryTest < ActiveSupport::TestCase
  def setup
    @wbs = WorkBreakdownStructure.new(
        user:users(:scoper),
        scoped_by:corporates(:corporate1),
        project_structure: practices(:security_assessments).project_structure,
        updated_by: users(:scoper)
    )

    @wbs.practices << practices(:security_assessments)

    assert @wbs.save!

    labor_category = gsa_labor_categories(:security_analyst)

    @entry = WbsEntry.new(
      work_breakdown_structure: @wbs,
      gsa_labor_category: labor_category,
      total_hours: 1,
      billable_rate: labor_category.default_billrate,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      task: 'Assessment',
      sku: 'IA-SA-IPT'
    )
    assert @entry.save

    entry2 = WbsEntry.new(
      work_breakdown_structure: @wbs,
      gsa_labor_category: labor_category,
      total_hours: 1,
      billable_rate: labor_category.default_billrate,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      task: 'QA',
      sku: 'IA-SA-IPT'
    )
    assert entry2.save

    entry3 = WbsEntry.new(
      work_breakdown_structure: @wbs,
      gsa_labor_category: labor_category,
      total_hours: 1,
      billable_rate: labor_category.default_billrate,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      task: 'Assessment',
      sku: 'IA-SA-EPT'
    )
    assert entry3.save

    @tools = WbsEntry.new(
      work_breakdown_structure: @wbs,
      gsa_labor_category: labor_category,
      total_hours: 1,
      billable_rate: labor_category.default_billrate,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      task: 'TOOLS',
      sku: 'IA-SA-TOOLS'
    )
    assert @tools.save

    pm = gsa_labor_categories(:program_manager)

    @pm = WbsEntry.new(
      work_breakdown_structure: @wbs,
      gsa_labor_category: pm,
      total_hours: 1,
      billable_rate: pm.default_billrate,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      task: 'Program Management',
      sku: 'IA-SA-IPT'
    )
    assert @pm.save
  end

  test 'entry is valid' do
    @entry.valid?
    assert @entry.valid?
  end

# This test is no longer valid because we are not using Rails validations.  We are now
# checking the publishability by validating the line item as a whole.
=begin
  test 'validates internal_hourly_rate' do
    labor_category = gsa_labor_categories(:security_analyst)

    entry = WbsEntry.new(
      work_breakdown_structure: @wbs,
      gsa_labor_category: labor_category,
      total_hours: 1,
      billable_rate: labor_category.default_billrate,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      task: 'Assessment',
      sku: 'IA-SA-IPT'
    )
    assert entry.save

    # We allow doing work for free now...
    #entry.internal_hourly_rate = 0.0
    #assert_not entry.save

    entry.gsa_labor_category = gsa_labor_categories(:associate_cloud_security_engineer)
    assert entry.save

    entry.internal_hourly_rate = -10.0
    assert_not entry.save
  end
=end

# This test is no longer valid because we are not using Rails validations.  We are now
# checking the publishability by validating the line item as a whole.  
=begin
  test 'total_hours is valid' do
    @entry.total_hours = 1.35
    assert @entry.valid?

    @entry.total_hours = 1.5
    assert @entry.valid?

    @entry.total_hours = -1.0
    assert_not @entry.valid?

    @entry.total_hours = 0.0
    assert @entry.valid?

    @entry.total_hours = 1.3456
    assert_not @entry.valid?
  end
=end

  test 'finds line items in wbs for sku' do
    wbs_entries = WbsEntry.for_sku(@wbs.id, 'IA-SA-IPT')
    assert_not wbs_entries.nil?

    assert_equal 5, @wbs.wbs_entries.count
    assert_equal 3, wbs_entries.count
  end

  test 'test returns unique skus' do
    wbs_entries = WbsEntry.unique_sku(@wbs.id)
    assert_equal 3, wbs_entries.count
  end

  test 'test returns used lcats' do
    wbs_entries = WbsEntry.unique_labor_categories(@wbs.id)
    assert_equal 2, wbs_entries.count
  end

  test 'test engangement check' do
    assert @entry.engagement?
    assert_not @tools.engagement?
    assert_not @pm.engagement?
  end

  test 'test pm check' do
    assert_not @entry.pm?
    assert_not @tools.pm?
    assert @pm.pm?
  end

  test 'test gross profit dollars' do
    labor_category = gsa_labor_categories(:security_analyst)

    entry2 = WbsEntry.new(
      work_breakdown_structure: @wbs,
      gsa_labor_category: labor_category,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      total_hours: 10,
      billable_rate: labor_category.default_billrate,
      task: 'QA',
      sku: 'IA-SA-IPT'
    )

    total_revenue = labor_category.default_billrate * 10
    total_cost = Variable.get('default_internal_rate') * 10
    profit = total_revenue - total_cost

    assert_equal profit, entry2.gross_profit_dollars
  end

  test 'test gross profit percent' do
    labor_category = gsa_labor_categories(:security_analyst)

    entry2 = WbsEntry.new(
      work_breakdown_structure: @wbs,
      gsa_labor_category: labor_category,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      total_hours: 10,
      billable_rate: labor_category.default_billrate,
      task: 'QA',
      sku: 'IA-SA-IPT'
    )

    total_revenue = labor_category.default_billrate * 10
    total_cost = Variable.get('default_internal_rate') * 10
    profit = total_revenue - total_cost

    assert_equal profit / total_revenue * 100, entry2.gross_profit_percent
  end

  test 'returns 0.0 for total_revenue for bad data' do
    labor_category = gsa_labor_categories(:security_analyst)

    entry2 = WbsEntry.new(
      work_breakdown_structure: @wbs,
      gsa_labor_category: labor_category,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      total_hours: 1,
      billable_rate: labor_category.default_billrate,
      task: 'QA',
      sku: 'IA-SA-IPT'
    )
    assert_not_equal 0.0, entry2.total_revenue

    entry2.billable_rate = nil
    assert_equal 0.0, entry2.total_revenue
  end

  test 'returns 0.0 for internal_cost for bad data' do
    labor_category = gsa_labor_categories(:security_analyst)

    entry2 = WbsEntry.new(
      work_breakdown_structure: @wbs,
      gsa_labor_category: labor_category,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      total_hours: 1,
      billable_rate: labor_category.default_billrate,
      task: 'QA',
      sku: 'IA-SA-IPT'
    )
    assert_not_equal 0.0, entry2.internal_cost

    entry2.internal_hourly_rate = nil
    assert_equal 0.0, entry2.internal_cost
  end

  test 'returns violation with no contract vehicle' do

    contract_vehicle = enumerations(:contract_vehicle_gps).name

    wbs = WorkBreakdownStructure.new(
      user:users(:scoper),
      scoped_by:corporates(:corporate1),
      project_structure: practices(:security_assessments).project_structure,
      contract_vehicle: contract_vehicle
    )

    wbs.practices << practices(:security_assessments)
    wbs.updated_by = users(:scoper)
    wbs.updated_at = DateTime.current
    assert wbs.save!

    labor_category = gsa_labor_categories(:security_analyst)

    entry = WbsEntry.new(
      work_breakdown_structure: wbs,
      gsa_labor_category: labor_category,
      total_hours: 1,
      billable_rate: labor_category.default_billrate,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      task: 'Assessment',
      sku: 'IA-SA-IPT'
    )
    assert entry.gsa_compliant?

    wbs.contract_vehicle = nil
    assert_not entry.gsa_compliant?
  end

  test 'returns violation with no LCAT or no bill rate' do

    contract_vehicle = enumerations(:contract_vehicle_gps).name

    wbs = WorkBreakdownStructure.new(
      user:users(:scoper),
      scoped_by:corporates(:corporate1),
      project_structure: practices(:security_assessments).project_structure,
      contract_vehicle: contract_vehicle
    )

    wbs.practices << practices(:security_assessments)
    wbs.updated_by = users(:scoper)
    wbs.updated_at = DateTime.current

    assert wbs.save!

    labor_category = gsa_labor_categories(:security_analyst)
    entry = WbsEntry.new(
      work_breakdown_structure: wbs,
      gsa_labor_category: labor_category,
      total_hours: 1,
      billable_rate: labor_category.default_billrate,
      internal_hourly_rate: Variable.get('default_internal_rate'),
      task: 'Assessment',
      sku: 'IA-SA-IPT'
    )
    assert entry.gsa_compliant?

    entry.gsa_labor_category = nil
    assert_not entry.gsa_compliant?

    entry.gsa_labor_category = labor_category
    entry.billable_rate = nil
    assert_not entry.gsa_compliant?
  end
end
