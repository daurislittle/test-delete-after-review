require 'simplecov'
SimpleCov.start do
  add_filter '/config/'
  add_filter '/test/'
  add_filter '/tmp/'
end

ENV['RAILS_ENV'] ||= 'test'
require File.expand_path('../../config/environment', __FILE__)
require 'rails/test_help'

class ActiveSupport::TestCase

  # Setup all fixtures in test/fixtures/*.yml for all tests in alphabetical order.
  fixtures :all

  # Add more helper methods to be used by all tests here...
  def login_as (user)
    assert_not user.nil?

    post saml_consume_path, params:{email:user.email, last_name:user.last_name, first_name:user.first_name}
    user.roles << Role.find_by(name:'Scoping')
  end

  def assert_object_not_found
    assert_select 'div.exception-card' do
      assert_select 'div.card-body' do
        assert_select 'h1.card-title', 'Object Not Found'
      end
    end
  end

  def assert_toast_error (message: nil, status_code: 302)
    assert_response status_code

    assert flash.key?(:toast)

    data = JSON.parse(flash[:toast])
    assert data.key?('type')
    assert_equal 'error', data['type']

    unless message.blank?
      assert data.key?('message') && data['message'].include?(message)
    end
  end

  def create_test_wbs
    # Find a valid opportunity for scoping
    opportunity =  SalesForce::Opportunity.only_services.where("(NOT StageName LIKE '%%Closed%%')").limit(1).first
    assert opportunity.valid?

    gps = SalesForce::Account.find_by(Name:'GuidePoint Security LLC')
    assert gps.valid?

    gps_contacts = SalesForce::Contact.where(AccountId: gps.id).where('No_Longer_with_Company__c != true').first(2)

    wbs = WorkBreakdownStructure.new(
      user:users(:scoper),
      opportunity: opportunity,
      scoped_by:corporates(:victor),
      project_structure: practices(:security_assessments).project_structure,
      contract_type: 'FFP',
      contract_vehicle: 'GuidePoint Direct',
      billing_rule:'Upon Completion',
      acct_primary_contact_id: opportunity.contacts.first.id,
      gps_primary_contact_id: gps_contacts[0].id,
      gps_secondary_contact_id: gps_contacts[1].id,
      updated_by:users(:scoper)
    )

    wbs.practices << practices(:security_assessments)
    wbs.save

    entry1 = WbsEntry.new(
      work_breakdown_structure: wbs,
      sku: 'IA-AS-AAR',
      task: 'Assessment',
      gsa_labor_category: gsa_labor_categories(:senior_security_consultant),
      billable_rate:250.00,
      total_hours:10,
      internal_hourly_rate:150.00,
      phase:1,
      ordinal:1
    )

    entry1.save

    entry2 = WbsEntry.new(
      work_breakdown_structure: wbs,
      sku: 'IA-AS-AAR',
      task: 'Program Management',
      gsa_labor_category: gsa_labor_categories(:program_manager),
      billable_rate:250.00,
      internal_hourly_rate:150.00,
      phase:1,
      link_type:3,
      link_percent:0.10,
      total_hours: 0.10 * entry1.total_hours,
      ordinal:2
    )

    entry2.save

    WorkBreakdownStructure.reindex
    wbs
  end
end
