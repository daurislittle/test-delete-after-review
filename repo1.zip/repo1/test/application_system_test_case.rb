require "test_helper"

Capybara.always_include_port = true
Capybara.app_host = 'http://localhost'
Capybara.server_port = 3010

class ApplicationSystemTestCase < ActionDispatch::SystemTestCase
  driven_by :selenium, using: :chrome, screen_size: [1400, 1400]
end
